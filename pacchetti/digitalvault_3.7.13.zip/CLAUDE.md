# DigitalValut Evolution — Invarianti di affidabilità fiscale

**Documento di vincolo per Claude Code.** Questo file codifica le regole non negoziabili per la manutenzione e l'evoluzione di DigitalValut, in particolare per i calcoli tributari.

> 📘 **Handover completo (architettura totale di tutto il progetto):** vedi `SOLO PROPRIETARIO/RELAZIONE_TECNICA_E_HANDOVER.md`. Leggilo PRIMA di lavorare. Regola d'oro: a ogni modifica aggiorna quel documento, alza `APP_VERSION` in `config.py`, aggiorna queste invarianti.

**Data di efficacia:** 16 giugno 2026  
**Fonte:** Brief operativo sulla affidabilità fiscale — Fase 0 audit completato.

---

## 🔴 DIRETTIVA PRIMARIA (NON NEGOZIABILE)

> **Nessun numero fiscalmente rilevante può essere prodotto dal modello linguistico (LLM).**

Importi, aliquote, coefficienti, scaglioni, moltiplicatori, scadenze e date devono provenire **esclusivamente da codice deterministico testato** che legge **dati di riferimento versionati e autorevoli**.

**Regola d'oro:** Se un numero non è tracciabile a una funzione del `fiscal_engine/`, non esce mai al cliente.

---

## 📋 Casi ad alto rischio (da monitorare)

### 1. **doc_classifier.py** — 🔴 CRITICO
- **Funzione:** `classifica(testo, nome_file, clienti)`
- **Rischio:** L'AI estrae `importo` da documenti scansionati senza validazione
- **Azione obbligatoria:** Aggiungere validazione post-AI (range check, confronto con OCR confidenza, marcare come "estratto da AI")
- **Conseguenze:** Importi alimentano `motore_proattivo.py` → avvisi di soglia forfettario

### 2. **riconciliazione.py** — 🟠 ALTA
- **Funzione:** `estrai_movimenti(testo_estratto)`
- **Rischio:** L'AI legge estratti conto e genera importi con tolleranza 2%
- **Azione obbligatoria:** Loggare sempre che proviene da AI; mostrare in UI "movimenti estratti da AI — verificare con documento originale"

### 3. **ocr_processor.py + ocr_massa.py** — 🟠 ALTA
- **Rischio:** L'AI vision legge interi documenti fiscali; testo scansionato diventa fonte di verità
- **Azione obbligatoria:** Marcare con watermark "OCR da AI, controllare originale" nel PDF generato

### 4. **ai_client.py — Chat Consulente AI** — 🟡 MEDIA
- **Endpoint:** `POST /api/chat`
- **Rischio:** Commercialista legge numero dalla risposta narrativa e lo usa come valore definitivo
- **Azione obbligatoria:** System prompt deve dire "Usa sempre `/api/calcola/*` per numeri definitivi". UI deve mostrare disclaimer.

---

## ✅ Moduli corretti (niente regressioni)

- **`tax_calculator.py`**: Calcoli IRPEF, Forfettario, INPS — puri, hard-coded, testati. OK.
- **`scadenze_cliente.py`**: Scadenzario standard — dati statici. OK.
- **`fatture_elettroniche.py`**: Parsing XML SDI strutturato. OK.

---

## 🛠️ Implementazione in corso (Fase A-J del Brief)

### **Fase A — Motore fiscale (`fiscal_engine/`)**
- ✅ `imu.py`: Calcolatore IMU per fabbricati — **IMPLEMENTATO E TESTATO**
  - Test golden case passa (moltiplicatore A/3 = 160, non 100)
  - Struttura: input tipizzati → calcolo puro → breakdown strutturato + fonte normativa
- 🔲 `f24.py`: Calcolatore F24 (in coda)
- 🔲 `irpef.py`: IRPEF (in coda)
- 🔲 `forfettario.py`: Regime forfettario (in coda)

### **Fase B — Dati di riferimento (`fiscal_reference/`)**
- ✅ `imu.yaml`: Moltiplicatori IMU, aliquote, regole di possesso — **IMPLEMENTATO**
  - Fonte: Art. 1 commi 739-783 L. 160/2019
  - Versionato: schema_version=1, data_efficacia="2020-01-01"
- 🔲 `irpef.yaml`: Scaglioni, aliquote 2025 (in coda)
- 🔲 `f24.yaml`: Righi F24, termini, versamenti (in coda)

### **Fase C — Tool-calling contract**
- ✅ Endpoint REST `POST /api/calcola/imu` (app.py) che chiama `fiscal_engine.imu.calcola_imu_fabbricato()` — **IMPLEMENTATO E TESTATO** (golden case HTTP 200; categoria sconosciuta → 400; aliquota mancante → 422 con campo, così l'AI lo chiede)
- ✅ System prompt Consulente AI (ai_client.py) irrobustito con "REGOLE INVIOLABILI SUI NUMERI FISCALI" — **IMPLEMENTATO E TESTATO**: sul caso IMU A/3 l'AI ora rimanda al calcolatore, chiede i dati mancanti, usa moltiplicatore 160 (non 100), etichetta le cifre come stime e chiude col disclaimer
- 🔲 (avanzato) Function-calling nativo (tool-use) per instradare automaticamente i calcoli della chat al motore — richiede modifica più profonda del gateway AI; da valutare

### **Fase D — Validazione**
- ✅ Validazione su `doc_classifier.importo` — **IMPLEMENTATA E TESTATA**
  - `_valida_importo()`: scarta ≤ 0, segnala importi > 100M, e **cross-check di presenza nel testo** (`_numeri_nel_testo()` gestisce formato italiano) → se l'AI inventa un importo non presente, viene marcato `importo_da_verificare` con `warnings[]`
  - Confidenza declassata da "alta" se l'importo è sospetto; `fonte_importo="ai"`
  - Persistito in `dati_estratti` (sia `classifica_coda` sia endpoint `/riclassifica`)
  - Esposto da `GET /api/documents` (`importo_da_verificare`, `warnings`) e mostrato in UI come badge "⚠ verifica importo" (tooltip coi motivi)
  - Test: 6 casi unit (presente/inventato/≤0/enorme/None/senza-testo) + integrazione API end-to-end
- ✅ Pattern estratto in modulo condiviso `validazione_importi.py` (`valida_importo`, `numeri_nel_testo`, `MAX_IMPORTO`) e riusato in:
  - `riconciliazione.py`: ogni movimento è marcato `da_verificare` se l'importo (in valore assoluto) non compare nell'estratto; report espone `movimenti_da_verificare`; UI mostra banner d'avviso
  - `ocr_processor.py`: validazione di range (no cross-check, è una foto) + ogni importo marcato `importo_da_verificare`; CSV con colonna "Controllo: Verificare originale (letto da OCR)"
  - Test: refactor doc_classifier senza regressioni + conteggio riconciliazione + CSV OCR

### **Fase E — System prompt**
- ✅ Regole inviolabili integrate direttamente in `ai_client.SYSTEM_PROMPT` (vedi Fase C) — la riga dannosa "Per calcoli mostra sempre i passaggi" è stata corretta
- 🔲 (opzionale) estrarre il prompt in `prompts/fiscal_assistant_system_prompt.md` caricato a runtime

### **Fase F — Disclaimer standardizzato**
- ✅ Centralizzato in `fiscal_engine/common.py` (`DISCLAIMER`, `disclaimer()`) — **IMPLEMENTATO E TESTATO**
  - Aggiunto agli endpoint `/api/calcola/imu`, `/irpef`, `/forfettario` (helper `_con_disclaimer`)
  - Stesso testo usato nelle regole del Consulente AI

### **Fase G — Test di regressione**
- ✅ `fiscal_engine/test_imu.py` + `fiscal_engine/test_irpef.py` — **25 test, tutti verdi** (pytest installato in python-win)
  - IMU: fallisce se moltiplicatore A/3 ≠ 160; confine categorie/validazione
  - IRPEF 2026: 28k→6440, 35k→8750, 38k→9740, 60k→18000; **test negativo: fallisce se rientra il 35%/25%**
  - Forfettario: imponibile 30k×0.78=23400, 50k×0.86=43000, 60k×0.40=24000; avviso soglia
  - Data freshness: anno non disponibile (2030) → blocco
  - Esecuzione: `cd D:\MOTORE; python-win\python.exe -m pytest fiscal_engine/ -q`

### **Fase H — Audit log**
- ✅ Tabella `fiscal_audit` (database.py, auto-creata da `create_all`) + modulo `fiscal_audit.py` (`registra()`, `ultimi()`) — **IMPLEMENTATO E TESTATO**
  - L'endpoint `/api/calcola/imu` registra ogni calcolo (input, output, costanti, fonte, versione dati, esito) — sia successi sia errori
  - Consultabile via `GET /api/calcola/audit?limite=N`
  - Robusto: se la scrittura audit fallisce, logga e prosegue (non blocca il calcolo)

### **Fase I — Modello (nessun degrado silenzioso)**
- 🔲 Garantire che LLM "ultimo resort" (free) non possa generare numeri non validati dal motore

---

## PARTE 2 — Dati di riferimento, collaudo e aggiornamento

Riferimento: `Downloads/DigitalValut_Affidabilita_Parte2_*.md`. Implementato il 16/06/2026.

### Dati di riferimento versionati (`fiscal_reference/`)
- ✅ `imu.yaml` (strutturale), `irpef.yaml` (3 scaglioni 2026: 23/33/43, **2° al 33% non 35%**), `forfettario.yaml` (soglia 85k, 0.15/0.05, coefficienti Allegato 4)
- Ogni file: `schema_version`, `anno_imposta`, `valid_from/valid_to`, `legal_source`, `verificato_il`
- **Governance: una sola sede per ogni costante** (i `.yaml`), mai nel codice. `tax_calculator.py` allineato (35%→33%) e marcato come superato dal motore per IRPEF/forfettario.

### Motore (`fiscal_engine/`)
- ✅ `irpef.py`, `forfettario.py` — leggono i `.yaml`, output compatibile col frontend + tracciabilità
- ✅ **Data-freshness guard** (`common.verifica_anno` + `DataNotFreshError`): se l'anno richiesto ≠ anno dei dati → BLOCCA, non usa silenziosamente dati vecchi
- Endpoint `/api/calcola/irpef` e `/forfettario` migrati al motore (anno=2026) con disclaimer + audit

### Processo di aggiornamento (SOP)
- A ogni Legge di Bilancio: aggiornare SOLO il `.yaml` (nuovo `valid_from/to`, `legal_source`, bump `schema_version`), rilanciare la suite golden, aggiungere un caso, changelog datato con validazione umana.
- Se per cambiare un'aliquota devi toccare la logica del motore → quel valore non era modellato come dato (difetto di design).
- ⚠️ Voci "VARIABILE ANNUALE" (IRPEF, forfettario, INPS, IVA, TARI) da riverificare alla fonte primaria. TARI/aliquote comunali: mai default nazionale, leggere delibera del Comune.

---

## 📝 Quando tocchi il codice

### ✅ CONSENTITO
1. Aggiungere funzioni in `fiscal_engine/` purché testate (golden case + confine)
2. Aggiungere dati in `fiscal_reference/` con versione + fonte normativa
3. Aggiungere test che **falliscono se un errore noto viene reintrodotto**
4. Aggiungere validazione / range check
5. Refactor di moduli **non fiscali** (UI, backend gen-purpose, etc.)

### ❌ VIETATO
1. Toccare `ai_client.py` senza aggiungere guardrail al system prompt
2. Modificare costanti hard-code fiscali in `tax_calculator.py` — estrarle in `fiscal_reference/`
3. Aggiungere calcoli tributari FUORI da `fiscal_engine/`
4. Permettere all'AI di rispondere numeri fiscali senza che il Consulente AI chiami `/api/calcola/*`
5. Rimuovere o debilitare i test di regressione

---

## 🧪 Test di regressione obbligatori

Prima di qualsiasi merge che tocca fiscalità:
```bash
cd D:\MOTORE\fiscal_engine
python -m pytest test_imu.py -v
```

Tutti i test devono passare. Se uno fallisce, **non mergare**.

---

## 📞 Escalation

Se trovi un punto dove il codice **non rispetta questa guida**:
1. Documenta il file/funzione/problema in una issue o memo
2. Proponi la correzione incrementale
3. **Non by-passare** le regole per fretta

Es. "Se l'LLM genera un importo, aggiungere validazione range check prima di salvare in DB".

---

## 🔗 Riferimenti

- **Brief operativo:** `/downloads/DigitalValut_ClaudeCode_Reliability_Brief.md` (Fase 0 audit completato)
- **Audit report:** Identificati 12 punti critici (1 CRITICO, 3 ALTA, 5 MEDIA, 3 BASSA OK)
- **Caso golden:** IMU A/3 rendita 232,41€ con moltiplicatore 160 (NON 100)
- **Norma madre:** Art. 1 commi 739-783 L. 160/2019 (IMU ordinaria)

---

---

## PARTE 3 — Hardening sicurezza (in corso, un Tier alla volta)

Riferimento: `Downloads/DigitalValut_Hardening_Parte3_*.md`. Audit Fase 0 completato 16/06/2026.

**Audit (stato):** Tier1.1 DB cifrato=ASSENTE; 2.1 chiave AI in chiaro + modello non loggato=ASSENTE/parziale; 2.2 update firmati=ASSENTE (updater.py:75 solo is_zipfile; applica_aggiornamento.py:62 extractall senza firma né Zip-Slip guard); 2.3 auth locale=ASSENTE (solo require_license; CORS solo-localhost OK); 3.1 parsing=PARZIALE; 3.2 prompt-injection=PARZIALE (mitigato da numeri deterministici); 4.1/4.2 offuscamento/firma app=ASSENTE.

**✅ Tier 3.1 (parsing input) — PRIMO TIER FATTO E TESTATO:**
- `fatture_elettroniche.py`: sostituito `xml.etree` con **`defusedxml`** (installato in python-win) → XXE e billion-laughs neutralizzati. Il chiamante `importa_fatture` (app.py:1190-1196) già cattura gli errori per-file → file invalidi rifiutati con errore gestito.
- Test: `test_security.py` (4 test: XXE, billion-laughs, non-fattura, uso di defusedxml). Suite totale **29/29 verde**.
- Resta opzionale per 3.1: verifica magic-bytes sugli upload (oggi: estensione + max 50MB).

**✅ Tier 2.2 (aggiornamenti firmati) — FATTO E TESTATO:**
- `update_security.py` (nuovo, a bordo): `verifica_firma(data, firma_b64)` con chiave pubblica Ed25519 già presente + `estrai_sicuro()` anti Zip-Slip.
- `updater.scarica()`: scarica, verifica is_zipfile, poi **verifica la firma** (presa dal manifest del titolare, non dal browser); rifiuta e non scrive nulla se non firmato/manomesso; salva `aggiornamento.sig`.
- `applica_aggiornamento.py`: ri-verifica la firma prima di toccare i file e usa `estrai_sicuro()` (no più `extractall` cieco). Pulisce zip+sig a fine.
- Master: `SOLO PROPRIETARIO/firma_aggiornamento.py` firma lo zip con la chiave privata → output `firma` (base64) + `sha256` da incollare nel manifest (campo `"firma"`).
- Test in `test_security.py`: Zip-Slip bloccato, estrazione benigna ok, firma roundtrip (valida/manomessa/assente). **Suite totale 32/32 verde.** App si avvia regolarmente.
- ⚠️ Operativo: d'ora in poi ogni manifest di aggiornamento DEVE contenere il campo `"firma"` (generato dal tool sul master), altrimenti i client rifiutano il pacchetto.

**✅ Tier 1.1 (cifratura DB a livello di campi) — FATTO E TESTATO:**
- `db_crypto.py`: chiave derivata dal serial SSD (scrypt) + fallback file; `cifra/decifra` idempotenti e tolleranti ai valori legacy in chiaro; tipo SQLAlchemy `EncryptedText` (cifra in bind, decifra in result).
- Applicato in database.py ai campi: Client.email/telefono/indirizzo/note, Document.controparte/note/dati_estratti, ChatMessage.content. IN CHIARO (searched/unique): Document.testo_estratto, codice_fiscale, partita_iva.
- `migra_cifra_campi()` one-shot in init_db (SQL grezzo, idempotente) + marker `data/.campi_cifrati`.
- Testato: DB temp (su disco cifrato `gAAAAA...`, via app in chiaro; CF/testo in chiaro), migrazione DB reale, e round-trip via API live (crea/leggi cliente). Suite sicurezza 13/13, totale 38/38.
- Nota onesta: chiave derivabile dal codice → protegge da furto SSD aperto in viewer, non da chi esegue il programma. Per protezione totale: SQLCipher o cifratura di volume.

**✅ Bug backup CORRETTO (scoperto durante il Tier 1.1):**
- `backup_manager._derived_key()` dipendeva da `license_manager._SECRET` (rimosso) → andava sempre in fallback su file `backup.key`; se quel file veniva rigenerato, TUTTI i backup precedenti diventavano indecifrabili.
- Fix: chiave backup ora DETERMINISTICA dal serial SSD (scrypt, label `DGV-BACKUP-v2`). I nuovi backup sono ripristinabili finché si ha l'SSD, anche se `backup.key` si perde. Testato: backup decifrato con la sola chiave derivata.
- ⚠️ Incidente correlato (16 giu): 69 clienti di PROVA persi PRIMA del Tier 1.1 (DB già vuoto al backup); backup vecchi (08:59/11:59) cifrati con chiave persa → non recuperabili. Erano dati demo (confermato dall'utente), nessuna perdita reale.
**🟡 Tier 2.1 — IN CORSO:**
- ✅ Part B (disciplina failover): `ai_client.chat_with_ai_meta()` → {content, model, degraded}; logga il modello nel server; `_is_free_model()` rileva la riserva `:free`. `/api/chat` ritorna `modalita_riserva` (MAI il nome del modello → protezione identità); UI mostra avviso "modalità di riserva". `chat_with_ai` resta stringa (retrocompatibile). Testato.
- ✅ Part A (chiave AI cifrata a riposo) — FATTO E TESTATO: in `config.py` risoluzione `_risolvi_chiave_ai()` con precedenza env > `data/ai_key.enc` (cifrato db_crypto) > inline; `salva_chiave_ai()` + `migra_chiave_ai()` (in init_db) cifrano l'inline su file e SVUOTANO il literal. **La chiave NON è più in chiaro in config.py** (riga = `OPENROUTER_API_KEY = ""`), risolta dal file cifrato; AI verificata in processo nuovo. CAMBIA CHIAVE/imposta_chiave_api restano invariati (scrivono inline → ri-cifrato al riavvio); update preserva via `data/`. GOTCHA risolto: la prima regex (non ancorata) svuotava l'esempio nel COMMENTO invece della riga vera → ora regex ancorata `(?m)^OPENROUTER_API_KEY...` + rimosso il pattern dai commenti (anche per non confondere gli altri tool che usano la stessa regex). Backup config.py.bak eliminato (conteneva la chiave in chiaro).

**🔲 Prossimi Tier:** Tier 2.3 login/PIN locale; Tier 3.2 isolamento prompt-injection; Tier 4 offuscamento/firma app.

---

## PERFORMANCE & SCALA (16 giu 2026)

Architettura chiave: **un'installazione per studio** (SSD/PC). Lo scaling è PER-STUDIO (decine di migliaia di documenti in un solo SQLite), non multi-tenant. Benchmark su 20–30k doc.

- ✅ **FTS5 full-text** (`database._crea_indici_fts`, in init_db): tabella `documents_fts` (external content su `testo_estratto,nome_originale,client_nome` — campi IN CHIARO) + 3 trigger di sync (ai/ad/au) + rebuild se disallineata. Indici su anno/tipo/created_at. Helper `cerca_documenti_fts(db, termine, limite)` (prefix+AND, ordina per bm25 rank) e `_fts_query` (sanitizza input). Misurato: ricerca testo 160ms→38ms; "chiedi archivio" 321ms+56MB→60ms.
- ✅ **Paginazione** in `/api/documents` (offset/limite, cap 200) + ricerca via FTS con fallback LIKE; ordine per rilevanza quando c'è `q`.
- ✅ **doc_brain.cerca_documenti**: recupera candidati via FTS (`_candidati_fts`, OR dei sinonimi) poi applica il punteggio fine, invece di caricare TUTTI i documenti → niente più 56MB/query. Fallback a load-all se FTS non disponibile.
- Benchmark riproducibile: seminare N doc in un DB temp e confrontare LIKE vs load-all vs FTS (vedi storico sessione).
- ✅ **Token economy — classificazione**: `doc_classifier.classifica()` NON manda più l'intera anagrafica clienti nel prompt (era ~3.500 token PER documento con 200 clienti). Abbinamento ora 100% deterministico: `_match_cliente_deterministico` (CF/P.IVA/nome nel testo, nome in ENTRAMBI gli ordini) + `_match_per_cf_piva` (CF/P.IVA estratti dall'AI). Rimosso campo `cliente_id` dal JSON AI e funzione `_clienti_compatti`. Testato: match corretto + classify reale ok. Più economico E più affidabile (l'AI non può sbagliare cliente).
- ✅ **DIFFERENZIAZIONE — Copilota collegato al motore** (`copilota_calcoli.py`): la chat capisce le richieste di CALCOLO (imu/irpef/forfettario) e risponde col **numero ESATTO dal fiscal_engine**, mai inventato. Flusso: gate a parole chiave `sembra_calcolo` (niente AI se non è un calcolo → 0 token extra sulla chat normale) → `interpreta()` (1 sola chiamata AI per estrarre i parametri) → `esegui()` deterministico → `formatta()` (numeri+scaglioni+disclaimer). Dati mancanti → chiede all'utente. Collegato a `/api/chat` (campo `da_motore`) e `/api/chat/stream` (un delta + DONE). Testato: gate, esegui (IMU 39044.88/molt.160, IRPEF 8750, forf 23400), end-to-end ("calcola IRPEF su 35000" → € 8.750,00). È il cuneo vs i big: AI a parole, numeri esatti dal motore.
- ✅ **INTEROP coi gestionali (cuneo)**: import già robusto (CSV clienti con auto-mappatura colonne `importa_clienti`, fatture XML `importa_fatture`, scopri_clienti). Aggiunto **EXPORT**: `GET /api/clients/esporta` (CSV, stesse colonne del modello → round-trip; campi cifrati escono in chiaro via ORM) e `GET /api/documents/esporta` (CSV elenco doc, filtri client_id/anno). Pulsanti "Esporta CSV" in UI (pagina clienti + documenti). CSV con BOM utf-8-sig (Excel-friendly). Testato via server (round-trip + decifratura). Posizionamento: "tieni il tuo gestionale per SDI/dichiarativi, DigitalValut è il cervello sopra i tuoi dati".
- ✅ **Token economy 2**: (contesto) `doc_brain._estratto_mirato` estrae una finestra ~1600 char CENTRATA sulla parola chiave (prima: primi 4000 char) → prompt ~60% più corto e più pertinente; `costruisci_contesto(risultati, chiavi, max_caratteri_per_doc=1600)`, `costruisci_prompt` passa le chiavi. (memoria chat) `_prepara_chat` invia gli ultimi messaggi entro BUDGET_CARATTERI=8000 (storico salvato per intero). Testato.
- 🔲 Da fare (opzionale): cache classificazione duplicati; export Excel (.xlsx) oltre al CSV. NON costruire: SDI/dichiarativi/paghe/conservazione a norma (regolato → integrare).

## RECUPERO DATI / BACKUP (17 giu 2026)

Problema risolto: db_crypto e i `.dvb` erano cifrati con chiave derivata dal **serial SSD** → copiare i file su un SSD nuovo li rendeva illeggibili (serial diverso). Soluzioni aggiunte in `backup_manager.py`:
- ✅ **Copia IN CHIARO sul PC** (`esporta_chiaro` → `~/DigitalValut_DatiPC`): snapshot del DB con i campi sensibili DECIFRATI (via `db_crypto.decifra`, dict `_CAMPI_CIFRATI`) + uploads + LEGGIMI. Nessuna password, nessun serial → "copia e incolla" su un SSD nuovo funziona SUBITO (i campi in chiaro vengono ri-cifrati dal nuovo dispositivo al primo avvio, perché `decifra` tollera il plaintext legacy). Rete anti-disastro. **Auto-aggiornata** nel loop di `avvia_backup_automatico` (avvio + ogni 3h). `ripristina_da_cartella` per il ripristino.
- ✅ **Backup PORTATILE protetto-password** (`esporta_protetto`/`ripristina_protetto`): file `DGVPWB1`+salt(16)+Fernet(scrypt(pw,salt)); auto-contenuto (porta il suo salt) → ripristinabile su QUALSIASI dispositivo con la password. Password errata → respinta. Logica zip estratta in `_ripristina_zip` (condivisa con ripristina_backup).
- Endpoint: `POST /api/backup/copia-pc`, `/protetto` {password}, `/ripristina-protetto` (file+Form password). UI: pulsanti in sezione Backup + funzioni JS `copiaDatiPC`/`backupProtetto`/`ripristinaProtetto`.
- Tutto testato (decifratura copia, round-trip password, endpoint via server, suite 38/38).
- ✅ **DECISIONE (17 giu) — NIENTE escrow/passe-partout**: l'utente ha scelto di NON avere una chiave di recupero del fornitore (più semplice e difendibile su GDPR: nessuna scorciatoia del vendor sui dati fiscali dei clienti). Il recupero della password dimenticata = la **copia in chiaro sul PC** (i dati non si perdono comunque). La password protegge solo il file portatile; se persa, il file portatile non si apre ma i dati restano nella copia PC. NON aggiungere un backdoor di recupero salvo richiesta esplicita futura.

## LICENZA — VINCOLO SOLO SSD (17 giu 2026, scelta utente)

Cambiato il modello di licenza da "PC + SSD" a **SOLO SSD** (il prodotto è portatile: stesso SSD = funziona su qualsiasi PC).
- `license_manager.get_machine_id()`: ora `SHA256("DGV-SSD|"+volume_id)[:24]`. **Fallback** a host+MAC+serial SOLO se `get_volume_id()=="NOVOLUME"` (per non collassare a un ID condiviso fra macchine). Anti-clone preservato (clonare l'SSD cambia il serial → ID diverso → serve nuova licenza).
- Compatibile col master: `genera_licenza.make_key(tier, machine_id)` firma la STRINGA dell'ID ricevuta dal cliente → nessuna modifica alla logica di firma. Aggiornati solo i testi (genera_licenza, schermata attivazione, UI: "ID di questo SSD").
- Conseguenza recupero: SSD rotto → SSD nuovo (serial diverso) → serve **nuova licenza** (cliente manda nuovo ID, titolare rigenera). I DATI tornano via copia in chiaro; la licenza è un passo a parte.
- Testato: ID = SSD-only; cambiando nome PC+MAC l'ID NON cambia (portabilità provata); licenza generata col timbro si attiva; master ripristinato.
- NB: la cifratura dati/backup (`db_crypto`, backup SSD) era già legata al solo serial SSD → ora coerente con la licenza.

## EVOLUTION — moduli consulenza (avviata 25 giu 2026)

Decisione titolare: costruire i 3 moduli "Evolution" in ordine **Risk → Finance → Legal**, in modalità **legale piena** (atti/memorie complete, RAG generativo) — responsabilità professionale assunta dal titolare. **PALETTO TECNICO NON NEGOZIABILE che resta:** i NUMERI (capitale, importi, proiezioni, soglie) restano deterministici dal motore/dati versionati; solo il TESTO legale può essere generato dall'Ai. La regola d'oro sui numeri NON si tocca.

- ✅ **Risk-Audit** (`risk_audit.py`, v3.4.0) — 1° modulo, **deterministico, zero AI**. `analizza(db)` → rilievi azionabili ordinati per gravità: soglie regime forfettario (soglia da `fiscal_reference/forfettario.yaml`, 85k/100k), importi estratti dall'AI da verificare (flag Fase D in `dati_estratti`), possibili doppioni (controparte+importo+anno), anagrafiche incomplete (CF/P.IVA), scadenze scadute. Endpoint `GET /api/risk/scan`. **UI**: pagina "Controllo Rischi" (nav + `caricaRischi()`, anti-XSS via `escHtml`). Isolato (plugin). Test: `test_risk_audit.py` (6 casi, DB in-memory).
- ✅ **Finance-Engine** (`finance_engine.py`, v3.5.0) — 2° modulo, **numeri deterministici (Decimal)**. Ancorato agli adeguati assetti (art. 2086 c.c. / CCII). `proiezione()` (compound N anni), `dscr()` (sostenibilità debito, soglie da `finance_reference/adeguati_assetti.yaml`: adeguato≥1.2 / limite≥1.0 / <1.0 allerta), `stress_test()` (shock ricavi/costi → ricalcola margine+DSCR), `analisi()` orchestratore. Endpoint `POST /api/finance/analisi`. **UI**: pagina "Adeguati Assetti" (form → proiezione+DSCR+stress, `calcolaFinance()`). Test: `test_finance_engine.py` (8 casi). 🔲 Da fare: generazione TESTO business plan/merito creditizio (AI, numeri dal motore).
- ✅ **Legal-Engine** (`legal_engine.py`, v3.6.0) — 3° modulo, Step 1. Framework "intervista → generazione" su template VERSIONATI (`legal_reference/*.yaml`). `tipi_disponibili()`, `campi_richiesti(tipo)`, `genera(tipo, parametri)` (assembla dal template, segnala campi obbligatori mancanti, li evidenzia tra [parentesi]). 5 template versionati: `statuto_aps`, `statuto_ets` (D.Lgs. 117/2017), `atto_costitutivo_srl` (art. 2463 c.c., BOZZA per notaio), `atto_costitutivo_snc` (art. 2295 c.c.), `risposta_formale` (lettera amministrativa; NON memoria giudiziale). Endpoint `GET /api/legal/tipi|campi`, `POST /api/legal/genera`, `POST /api/legal/pdf` (riusa `genera_pdf_consulenza`). **UI**: pagina "Atti & Statuti" (select dinamico → campi → bozza textarea, copia/.txt/PDF). **Generazione AI** (`genera_ai`, async, endpoint `POST /api/legal/genera-ai`): raffina SOLO la forma con guardrail inviolabile (`_SISTEMA_AI`: vietato toccare numeri/dati/riferimenti); la versione deterministica resta in `testo_base`; se l'AI manca → fallback al deterministico; bloccata se ci sono campi obbligatori mancanti. UI: bottone "Genera con AI" + badge; PDF usa il testo mostrato via `/api/pdf/consulenza` (riflette rifiniture AI/modifiche a mano). Test: `test_legal_engine.py` (12 casi, incl. PDF + AI happy/fallback/guardia). Pubblicato 3.6.0.
- ✅ **Legal v3.6.1** — template RISCRITTI come documenti COMPLETI (non più stub di 6-7 righe) + **10 tipi totali**: atto SNC (19 art.), atto+statuto Srl (17), statuto APS (20), statuto ETS (18), + **contratti**: locazione abitativa (L.431/98, 15 art.), locazione commerciale (L.392/78, 14), comodato (artt.1803-1812, 10), affitto d'azienda (artt.2555/2557/2561, 10), prestazione servizi/opera (artt.2222-2238, 10), risposta formale. Rimossa la dicitura "BOZZA" dai titoli (resta nota professionale a piè di pagina nel campo `disclaimer`). I template sono additivi: nuovi `.yaml` in `legal_reference/` compaiono da soli nel menu. Test: `test_legal_engine.py` (15 casi).
- ✅ **Legal v3.6.2** — **15 documenti totali**: aggiunti contratto di lavoro subordinato (CCNL), cessione quote Srl, verbale di assemblea, riconoscimento di debito (art. 1988 c.c.), accordo di riservatezza/NDA. `test_legal_engine.py` (17 casi). **NB onestà (registrato)**: l'AI/software NON può "validare legalmente"; i documenti sono modelli professionali completi con fonti normative, da adattare e firmare a cura del professionista (notaio dove richiesto). La dicitura resta nel `disclaimer` a piè di pagina.
- ✅ **v3.6.3** — (A) guida interna aggiornata: `ai_client.HELP_PROMPT` ora descrive Controllo Rischi, Adeguati Assetti, Atti & Statuti + nuove FAQ in `AIUTO_FAQ`. (B) **precompilazione da cliente** in Atti & Statuti: endpoint `GET /api/legal/clienti` (id/etichetta/anagrafica formattata da CF/P.IVA/indirizzo); UI con menu "Cliente" + pulsante "↳ cliente" sui campi-parte (`LEGAL_PARTI`) → `legalUsaCliente()` riempie il campo selezionato con l'anagrafica del cliente già in archivio.

## REBRAND nome corretto: DigitalVault → DigitalValut (v3.7.1)

Il marchio corretto è **DigitalValut** (sito digitalvalut.it), non "DigitalVault". Corretto il nome VISIBILE ovunque (352 occorrenze CamelCase/ALLCAPS in 92 file: UI, prompt AI/identità, APP_NAME, PDF, .bat, ecc.) con sostituzione `DigitalVault→DigitalValut` e `DIGITALVAULT→DIGITALVALUT`. **PRESERVATI gli identificatori TECNICI** (non visibili, cambiarli rompe dati/aggiornamenti): `digitalvault.db`, URL repo `digitalvault-aggiornamenti`, nomi pacchetti `digitalvault_X.Y.Z.zip`, e le **variabili d'ambiente** `DIGITALVAULT_*` (RETE/AUTO/PIN/UPDATE_*/OPENROUTER_KEY) — queste ultime ripristinate dopo il replace perché i `.bat` alla radice (fuori MOTORE) usano ancora `DIGITALVAULT_RETE`. NB residuo da valutare: i tool owner in `SOLO PROPRIETARIO/` e la cartella destinazione copie `{lettera}:\DigitalVault` non sono stati rinominati (owner-side). 132 test verdi.

## CHAT PROFESSIONALE — stile "parere" + più memoria (v3.7.0)

Obiettivo utente: ora che i modelli primari sono economici (GLM/DeepSeek), alzare la QUALITÀ della chat per impressionare il commercialista. Fatto SENZA aumentare `max_tokens` (già alti) — la qualità non è lunghezza:
- ✅ `ai_client.SYSTEM_PROMPT` (Consulente AI): aggiunta sezione **"STILE DELLA RISPOSTA — LIVELLO PROFESSIONALE"**: struttura tipo parere (Inquadramento → Analisi → Riferimenti normativi puntuali con fonti IN LINEA → Conclusione operativa), tono tecnico ma leggibile, completo ma non prolisso, tabelle/elenchi dove utili, chiusura sempre con «Passo operativo». Le REGOLE INVIOLABILI SUI NUMERI restano intatte (citazioni solo se reggono, numeri definitivi dai calcolatori deterministici).
- ✅ `config.py` memoria_chat alzata: BASE 20→25, MEDIA 30→45, SUPERIOR 50→80 (continuità conversazione migliore, costo basso coi modelli economici).
- Suite COMPLETA 132 test verdi (incluso test_sciame), smoke test app OK.

## ECONOMIA TOKEN — riordino flotta modelli (v3.6.9)

Segnalazione utente: Claude (Opus 4.8/Sonnet) come primario consumava troppo. Riordinata la priorità in `config.py` TIERS (il sistema usa il PRIMO modello che risponde, gli altri sono fallback):
- **MEDIA/SUPERIOR testo**: primario ora `z-ai/glm-5.2`, poi `deepseek/deepseek-v4-pro`, poi Gemini; Claude Sonnet in pos. 4 (riserva di qualità), Opus 4.8 spinto in fondo (pos. 7 in SUPERIOR) — usato di rado.
- **Vision (OCR) tutti i tier**: primario `google/gemini-3.5-flash` (economico) invece di Claude → l'OCR delle foto/scansioni costa una frazione. Claude/Opus solo come riserva. NB: GLM/DeepSeek sono solo-testo, restano fuori dalle liste vision.
- BASE invariato (già economico). Effetto: ~90% richieste su modelli economici-forti, stessa qualità sui casi fiscali/legali. Tradeoff: SUPERIOR non guida più con Opus (marketing "il massimo"): se serve, rimettere Opus primo nel SUPERIOR.

## SICUREZZA COPIE NUOVO SSD — anti-leak dati + chiave AI (v3.6.8)

Segnalazione utente: una copia su nuovo SSD si era portata DATI VECCHI del master + la CHIAVE AI (rischio furto). Cause: la cartella `data/` contiene `digitalvault.db` (tutti i dati), `ai_key.enc` (chiave AI cifrata), `dbfield.key`/`backup.key` (chiavi di cifratura). Se la copia porta `data/`, trapela tutto. Fix in ENTRAMBI i tool:
- ✅ `prepara_nuovo_ssd.py` (PREPARA SSD NUOVO CLIENTE): `_azzera_per_nuovo_cliente` aggiunge `dbfield.key`. `_verifica_sicurezza(dest, azzera)` POTENZIATA: rimuove ovunque `ai_key.enc`/`dbfield.key`/`backup.key`/`.campi_cifrati` + segreto titolare, **azzera** `OPENROUTER_API_KEY="sk-..."` in ogni `config.py`, e per nuovo cliente (azzera) verifica/rimuove `digitalvault.db*`, `licenza.dat`, documenti in `uploads/`. Anche il ramo `--clona` toglie le chiavi.
- ✅ `crea_copia.py` (CREA COPIA): `EXCLUDE_FILES` +ai_key.enc/dbfield.key/backup.key/.campi_cifrati/rete_pin.txt; `verifica()` bonifica anti-leak (rimuove chiavi+db residui, azzera chiave AI in config.py).
- Testato su copia FINTA: chiave AI, chiavi cifratura, database, documenti vecchi, SOLO PROPRIETARIO, chiave in config → tutti rimossi ("COPIA COMPLETAMENTE PULITA"). NB: la chiave AI è comunque cifrata col serial dell'SSD (inutilizzabile altrove), ma non deve MAI viaggiare. Regola per l'utente: usare SEMPRE i tool, mai copiare l'SSD a mano.

## OCR AUTOMATICO PDF FOTOGRAFATI + bugfix CamScanner (v3.6.5)

Problema utente: un 730 fotografato con CamScanner veniva caricato ma NON riconosciuto. Causa diagnosticata sul file reale: il PDF non ha testo (pdfplumber → 0 caratteri, solo immagini), quindi la classificazione (che lavora su `testo_estratto`) non parte. **Due fix:**
- ✅ **BUG `ocr_massa._immagini_da_pdf`**: prendeva la PRIMA immagine di ogni pagina e faceva `break`. I PDF CamScanner hanno 2 immagini/pagina: img1 = banner watermark (1076×105, ~38KB, identico) + img2 = scansione vera (~2240×3005, ~800KB). Risultato: l'OCR leggeva solo "Scansionato con CamScanner". **Fix**: ora sceglie l'immagine con AREA MASSIMA per pagina (la scansione vera). Colpiva anche l'OCR di massa esistente. Provato sul file reale: ora legge il 730 (contribuente, CF, dati).
- ✅ **Auto-OCR all'upload**: in `app.py` upload, se un PDF ha testo vuoto → `stato_classifica="ocr_in_coda"` + `ocr_massa.avvia_singolo(doc.id)` (nuova funzione, thread daemon): OCR AI in background → riempie `testo_estratto` con marcatura `[TESTO LETTO CON OCR AI…]` → mette il doc in `in_coda` → `classifica_coda.assicura_avvio()` lo riconosce. UI: stato "Lettura OCR…" + auto-refresh lista include `ocr_in_coda`.
- ✅ **v3.6.6 — token economy OCR**: `avvia_singolo` default `max_pagine` 10 → **2**. L'auto-OCR all'upload legge solo le prime 2 pagine (bastano a RICONOSCERE tipo + dati chiave) per non bruciare token/tempo; la lettura COMPLETA di tutte le pagine resta nell'OCR di massa ("Leggi le scansioni"), lanciato dall'utente. Motivo: su un 730 da 10 pagine l'auto-OCR mangiava token e restava lento/"GENERICO" in attesa di finire tutte le pagine.
- ✅ **v3.6.7 — RETE DI SICUREZZA anti-blocco OCR**: un OCR interrotto (riavvio/chiusura) lasciava il documento per SEMPRE in `ocr_in_coda` ("Lettura OCR…") perché nessuno lo riprendeva → bug serio segnalato dall'utente. Fix: `app._recupera_stati_orfani()` in `lifespan` (avvio): i doc `ocr_in_coda` orfani tornano a stato finale (`da_assegnare`/`manuale`) **SENZA ritento automatico** (l'OCR vision costa: il ritento lo decide l'utente con "Leggi le scansioni"); i doc `in_coda` (già con testo) vengono ripresi dal classificatore. Garanzie: OCR one-shot (no loop), `max_pagine=2`, ogni chiamata AI con `TIMEOUT=60s` → non può mai girare all'infinito né bruciare token senza limite.

## AGGIORNAMENTI OTA — auto-applicazione (v3.6.4)

Problema utente: il nuovo SSD restava a versione vecchia perché l'update è in 2 passi (in app "Scarica" → poi lanciare a mano `AGGIORNA DIGITALVALUT.bat`) e il 2° passo si dimentica. Server/GitHub erano OK (manifest 3.6.3 live, URL giusto, zip firmato; `applica_aggiornamento` NON ha config.py in `PRESERVA` → la versione si aggiorna; chiave AI conservata a parte). **Nessun bug**, solo flusso manuale.
- ✅ **Auto-apply all'avvio**: `app._applica_update_in_attesa()` (chiamata in cima a `__main__`): se esiste `_aggiornamento/aggiornamento.zip` e nessuna istanza è già attiva (`_gia_in_esecuzione`), lancia `applica_aggiornamento.py` in subprocess con `DIGITALVAULT_AUTO=1`, poi `os.execv` per ripartire col codice nuovo. Guardia anti-loop via env `DIGITALVAULT_UPDATE_APPLICATO`; best-effort (se fallisce, avvia la versione attuale). Lo zip viene cancellato dall'applicatore → niente loop.
- ✅ `applica_aggiornamento.py`: aggiunta modalità **AUTO** (`--auto`/`DIGITALVAULT_AUTO=1`) → `_pausa()` salta i prompt `input()` che bloccherebbero l'avvio non interattivo. Il `.bat` manuale resta valido.
- ✅ `updater.scarica()`: messaggio aggiornato ("chiudi e riapri, si installa da solo").
- Ora il cliente: in app preme **Scarica**, **riapre** → aggiornato. Niente più passo manuale.

## LOCAL-FIRST — risorse UI bundlate offline (v3.7.3, 29 giu 2026)

Difetto: `templates/index.html` caricava font e icone da CDN esterni (Google Fonts + RemixIcon via jsdelivr). Senza internet l'interfaccia si imbruttiva (icone/font assenti, `ERR_INTERNET_DISCONNECTED`). Un'app che gira su SSD dev'essere autosufficiente anche offline.
- ✅ **RemixIcon 4.3.0** bundlato in `static/remixicon/` (`remixicon.css` + `remixicon.woff2`). `@font-face` riscritto a solo-woff2 locale (rimossi eot/woff/ttf/svg → zero richieste 404).
- ✅ **Google Fonts (Inter 300-800 + Sora 400/600/700/800)** bundlati in `static/fonts/`: 20 woff2 (subset latin + latin-ext, sufficiente per l'italiano) + `fonts.css` generato con URL relativi. Niente più `fonts.googleapis.com`/`gstatic.com`.
- ✅ `index.html`: rimossi i 4 `<link>` esterni (2 preconnect + Google Fonts + RemixIcon) → 2 `<link>` locali a `/static/...` (StaticFiles già montato su `/static` in `app.py:220`).
- ✅ `e2e_browser.py` controllo #5: tolto il filtro `_rumore` di rete/CDN — ora un errore di rete è una vera regressione (risorsa `/static` non bundlata), non più rumore da ignorare.
- Verificato: E2E 6/6 verde; **prova offline** (Playwright con tutte le richieste non-localhost bloccate) → 0 richieste esterne, 0 errori console, font `remixicon`/`Inter`/`Sora` caricati da `/static`, icone `ri-*` renderizzate. Unici link esterni residui = `wa.me` (condivisione WhatsApp, azione utente volontaria, non risorsa di pagina).

## UX — Atti & Statuti "Genera con AI" a due fasi (v3.7.4, 29 giu 2026)

Segnalazione utente: il pulsante "Genera con AI" sembrava non funzionare. Diagnosi (browser reale + endpoint): NON era rotto. Il backend `legal_engine.genera_ai` e l'endpoint `/api/legal/genera-ai` funzionano (modello glm risponde). Il problema era la LATENZA: rifinire un documento lungo (~5300 char) impiega 16s da solo, ma **fino a ~58s nel browser** per la contesa sull'event-loop singolo (stesso limite dello stress test) mentre la pagina fa polling → spinner fermo ~1 min → l'utente pensa sia rotto. (Due falsi negativi nei test automatici: bottone sotto il viewport con `force=True` click fuori schermo; overlay onboarding `#ob-overlay` che intercetta i click su DB di test vuoto — nessuno dei due tocca l'utente reale.)
- ✅ Fix in `templates/index.html` `legalGenera(ai)`: ora a DUE FASI. Mostra SUBITO la bozza deterministica (`/api/legal/genera`, ~0.1s; i numeri vengono SEMPRE da qui), badge `#legal-ai-stato` "Sto rifinendo con l'AI…", poi chiama `/api/legal/genera-ai` e SOSTITUISCE col testo rifinito quando arriva. Se l'utente modifica la bozza nel frattempo, le modifiche restano (guardia `tarea.value !== baseTesto`). Estratto helper `_legalRender(d, opts)`. Selettore campi esteso a `input[data-chiave], textarea[data-chiave]`. Il pulsante non appare mai più bloccato. Verificato nel browser: bozza in 0.1s, rifinitura sostituita dopo ~56s, 0 errori JS.
- Incluso anche il fix microfono (`continuous=true` in `toggleDettatura`): la dettatura resta attiva finché non si riclicca il microfono.

## MICROFONO — stop realmente affidabile (v3.7.5, 30 giu 2026)

Segnalazione utente dopo il fix precedente (continuous=true): "il microfono rimane attaccato", confermato essere il caso (B) = ricliccando per fermare, il microfono continuava ad ascoltare/registrare. **Causa:** `toggleDettatura` (templates/index.html) faceva SOLO `_recognizer.stop(); return;` sul click di stop — pulsante e stato venivano ripuliti SOLO dentro `onend`. Con `continuous=true`, Chrome fa uno stop "gentile" che aspetta di finire di processare l'audio: se sta ancora captando rumore di fondo, `onend` può tardare parecchio o non arrivare affatto → pulsante bloccato su "attivo" e microfono percepito come mai fermato.
- ✅ Fix: il ramo di stop ora spegne SUBITO l'aspetto del pulsante (non aspetta `onend`), stacca gli handler (`onresult/onend/onerror = null`) dal vecchio recognizer così non tocca più la pagina, chiama `.stop()` e aggiunge una rete di sicurezza `setTimeout(() => rec.abort(), 300)` nel caso lo stop si blocchi davvero.
- Verificato con un finto SpeechRecognition iniettato via Playwright che simula il caso peggiore (`.stop()` non fa NULLA, solo `.abort()` ferma davvero): pulsante si spegne a click (immediato, non aspetta i 300ms), il colpo di sicurezza ferma l'ascolto reale (contatore di attività stabile dopo l'abort), si può ridettare subito dopo senza stati bloccati, zero errori JS.

## EVOLUTION — Trasparenza AI (L. 132/2025) — v3.7.6, 1 lug 2026

Nuovo modulo di conformità, nato da ricerca di mercato (WebSearch): la **Legge 23/9/2025 n. 132 art. 13** (in vigore 10 ott 2025) obbliga commercialisti/avvocati/notai/CdL a **informare per iscritto il cliente** sull'uso dell'IA (quali sistemi, per quali attività, grado di automazione, garanzie di supervisione umana). Principio della norma «l'IA propone, il professionista dispone» = combacia col paletto d'oro del prodotto (numeri dal motore deterministico, mai dall'AI). Gap di mercato: i big (TeamSystem/Zucchetti) hanno già chat AI e portale cliente, ma **nessuno gestisce l'informativa L.132 in automatico** (solo un modulo di carta Confprofessioni). Cuneo difendibile perché richiede la tracciabilità che noi già abbiamo.
- ✅ `ai_trasparenza.py`: `registra(db, funzione, descrizione, client_id, automazione, fonte_numeri)` robusto (non solleva); `registro(db, client_id, limite)` (risolve nomi clienti); `funzioni_usate(db, client_id)`; `genera_informativa(cliente, studio, usate)` → testo dell'informativa personalizzata (fonte, disclaimer, spazio firma). Catalogo `ATTIVITA_AI` (5 attività: chat_consulenza, ocr_lettura, classificazione_doc, riconciliazione, rifinitura_atto) con garanzie per ognuna. NESSUN numero prodotto qui.
- ✅ `database.py`: nuova tabella `AiUso` (id, created_at, client_id, funzione, descrizione, automazione, fonte_numeri) — auto-creata da `create_all`, nessuna migrazione.
- ✅ `app.py`: 3 endpoint `GET /api/trasparenza/registro`, `POST /api/trasparenza/informativa`, `POST /api/trasparenza/informativa/pdf` (riusa `genera_pdf_consulenza`). Helper `_registra_uso_ai()` (sessione dedicata, non blocca la richiesta). Agganci: `/api/chat` registra ogni risposta (fonte_numeri deterministico se dal motore, ai altrimenti); `/api/legal/genera-ai` registra `rifinitura_atto` (fonte misto). Nota: OCR/classificazione/riconciliazione girano in thread di background e NON sono ancora agganciati (facili da aggiungere via `_registra_uso_ai`).
- ✅ UI: pagina "Trasparenza AI" (nav `ri-scales-3-line`, `page-trasparenza`): select cliente, "Genera informativa" (textarea+Copia+PDF), tabella "Registro usi AI" con badge fonte-numeri colorato (verde=motore, blu=AI, arancio=misto). Funzioni JS `trInit/trGeneraInformativa/trCopia/trScaricaPdf/trCaricaRegistro`.
- Test: `test_ai_trasparenza.py` (7 casi: registro roundtrip, filtro cliente, registra-non-solleva, funzioni distinte, informativa contiene elementi di legge, generica senza cliente, evidenzia attività registrate). Verificato live+browser: 3 endpoint OK (PDF valido 6.5KB), pagina genera informativa 4KB con "132/2025"+nome cliente, registro mostra righe, 0 errori JS. Suite deterministica totale 83 verdi. **NB onestà**: modello di informativa conforme all'impianto dell'art. 13, da far validare/adattare dal professionista (disclaimer a piè di pagina); non è consulenza legale.

## REVISIONE — Enti Pubblici, equilibri di bilancio (v3.7.7, 1 lug 2026)

Terzo modulo della linea "Revisione" (dopo Risk-Audit e Adeguati Assetti per privati). **Decisione titolare: saltare direttamente alla revisione degli ENTI PUBBLICI (Comuni)**, invece di partire dal modulo "Revisione Società private" originariamente proposto come primo passo. Dominio **completamente diverso** dalla fiscalità privata: IRPEF/forfettario non c'entrano nulla con un Comune, che usa la contabilità armonizzata (D.Lgs. 118/2011). **Onestà tecnica dichiarata**: implementati SOLO gli equilibri STRUTTURALI di bilancio (definiti direttamente dalla legge, non da parametri che cambiano ogni anno) — gli "indicatori di deficitarietà strutturale" (parametri ministeriali da decreto annuale) NON sono inclusi in questa fase: servirebbe una fonte normativa annuale verificata puntualmente, da aggiungere in una fase 2 separata, MAI inventata.
- ✅ `public_finance_reference/equilibri_bilancio.yaml`: struttura normativa versionata (fonte: D.Lgs. 118/2011 Allegato 9 "Prospetto verifica equilibri"; artt. 162 comma 6, 193, 239 TUEL/D.Lgs. 267/2000).
- ✅ `revisione_enti_pubblici.py` (motore, zero AI): `equilibrio_parte_corrente()`, `equilibrio_parte_capitale()`, `equilibrio_cassa()`, `pareggio_complessivo()` — ognuna Decimal-based e tracciabile; `analizza_bilancio(dati)` orchestratore → rilievi ordinati per gravità + esito `regolare|irregolare|critico`; `genera_parere(ente, dati, risultato=None)` assembla la bozza di relazione/parere dell'organo di revisione (art. 239 TUEL) dai risultati del motore — NESSUNA chiamata AI in tutto il modulo.
- ✅ `app.py`: `RevisioneEntiReq` (calcolatore puro, nessun `client_id` — stesso pattern di `finance_engine`/Adeguati Assetti, un ente non è un "cliente" nel DB). Endpoint `POST /api/revisione-enti/analisi|parere|parere/pdf` (PDF riusa `genera_pdf_consulenza`).
- ✅ UI: pagina "Revisione Enti Pubblici" (nav `ri-government-line`, `page-revisione-enti`): form voci di bilancio (parte corrente/capitale/cassa/totali) → "Verifica equilibri" (badge colorato regolare/irregolare/critico) o "Genera bozza di parere" (textarea+Copia+PDF). Nessun hook su `showPage` (calcolatore puro, come Adeguati Assetti).
- Test: `test_revisione_enti_pubblici.py` (16 casi golden: equilibri singoli positivi/negativi, avanzo che riporta in equilibrio, analisi completa regolare/irregolare/critica, cassa assente se non fornita, parere favorevole/con rilievi/riuso risultato). Verificato live+browser: 3 endpoint OK (PDF 4KB), form compilato → "REGOLARE" con importi corretti (50.000€/0€/0€ ✓), "Nessun rilievo", bozza parere con "PARERE FAVOREVOLE" e art. 239, 0 errori JS. Suite deterministica totale 155/155 verde.
- **Prossimi passi (non ancora fatti)**: indicatori di deficitarietà strutturale (serve il D.M. annuale come fonte); relazione al rendiconto della gestione (oggi solo bilancio di previsione); import diretto da bilancio armonizzato XML/XBRL enti locali.

## GUIDA INTERNA aggiornata + upload documenti in Revisione Enti (v3.7.8, 1 lug 2026)

Segnalazione utente: (1) "l'AI non riconosce" i moduli nuovi — il Cervello dello Studio (`/api/studio/chiedi`) lavora SOLO su dati reali (clienti/documenti/scadenze), non descrive le funzionalità del programma; la guida vera è `HELP_PROMPT` (pagina "Aiuto"), che però era rimasta indietro di PIÙ versioni (mancavano Calcolatori Fiscali, Riconciliazione, Posta PEC, Genera Documenti, oltre ai 2 moduli appena fatti). (2) Su Revisione Enti Pubblici non si potevano allegare i file del bilancio (PDF/Excel).
- ✅ `ai_client.HELP_PROMPT`: aggiunta la lista COMPLETA dei moduli mancanti (Calcolatori Fiscali, Riconciliazione Bancaria, Posta PEC, Genera Documenti, Trasparenza AI, Revisione Enti Pubblici) — ora rispecchia tutto il menu reale.
- ✅ `app.chiedi_studio` (Cervello dello Studio): aggiunto un paragrafo nel prompt che elenca i moduli disponibili se l'utente chiede "cosa sai fare" — resta comunque uno strumento sui DATI, rimanda alla pagina "Aiuto" per il come-si-fa.
- ✅ Pagina "Revisione Enti Pubblici": nuovo box "Documenti dell'ente" con pulsante "Allega file" — riusa **l'endpoint esistente** `/api/documents/upload` (già accettava `client_id` opzionale) passando `client_nome`=nome ente come etichetta, NESSUNA modifica al DB. I file allegati vengono archiviati/classificati come qualunque documento e diventano SUBITO consultabili da Consulente AI/Cervello dello Studio (indicizzazione FTS esistente, cross-cliente) — **non riempiono automaticamente i campi degli equilibri** (nessun autofill numerico da AI, resta la regola d'oro).
- Verificato live+browser: pulsante presente, upload di un file di prova → "✓ nomefile — GENERICO", il documento compare in Archivio Documenti pochi secondi dopo, 0 errori JS. Suite deterministica 155/155 verde, invariata (nessuna modifica al motore).

## FLOTTA MODELLI — Sonnet 4.6 → Sonnet 5 (v3.7.9, 1 lug 2026)

Segnalazione utente: chiesto se la flotta AI è "la più potente che c'è". Risposta onesta data: quasi — mancava l'aggiornamento di Anthropic (Sonnet 4.6 non più l'ultima versione; Claude Fable 5 assente ma escluso di proposito per costo/uso raro come riserva). L'utente ha chiesto il "ritocco a costo zero": Sonnet 4.6 → Sonnet 5 (stessa fascia di prezzo, più forte).
- ✅ `config.py` TIERS: sostituito `anthropic/claude-sonnet-4.6` → `anthropic/claude-sonnet-5` in **4 punti** (MEDIA testo+vision, SUPERIOR testo+vision). Nessun cambio di posizione in coda (resta riserva di qualità dopo GLM/DeepSeek/Gemini, per costo). Opus 4.8 resta invariato (già il top Anthropic). Fable 5 volutamente escluso (costo 10$/50$ per MTok vs 5$/25$ di Opus, per una riserva usata di rado non conviene).
- Verificato: chiamata reale a `anthropic/claude-sonnet-5` via OpenRouter → risponde correttamente (non è un placeholder, esiste ed è attivo). Boot OK, suite 155/155 invariata (nessuna modifica al motore/logica, solo stringa modello).

## CALCOLATORI FISCALI — pulsanti per IVA/730/cedolare/ravvedimento (v3.7.10, 1 lug 2026)

Motori già esistenti e testati (`fiscal_engine/iva.py`, `dichiarativo_730.py`, `cedolare.py`, `ravvedimento.py`, 49 test verdi) ma raggiungibili SOLO in chat (via `copilota_calcoli`/`sciame`), senza un pulsante dedicato come IRPEF/Forfettario. Utente ha chiesto di completarli con un pulsante prima di passare a INPS (prossimo).
- ✅ `app.py`: 4 nuovi endpoint `POST /api/calcola/iva` (un solo endpoint per le 3 operazioni: calcola/scorpora/liquidazione, dispatch su `operazione`), `/730`, `/cedolare`, `/ravvedimento`. Stesso pattern di IRPEF/Forfettario/IMU: disclaimer + `fiscal_audit.registra()` + `DataNotFreshError` → 422. Nuovi modelli richiesta `CalcIva`, `Calc730`, `CalcCedolare`, `CalcRavvedimento`.
- ✅ UI: 4 nuove card nella pagina "Calcolatori Fiscali" (`page-calcolatori`, già ospitava IRPEF+Forfettario). IVA con selettore di modalità (mostra/nasconde i campi giusti per calcolo/scorporo/liquidazione); 730 con detrazione indicata o stimata (select tipo reddito); Cedolare con selettore tipo locazione; Ravvedimento con avviso "stima da verificare" in evidenza. Tutte riusano l'helper esistente `exportCalcoloPDF()` — zero codice PDF nuovo.
- Verificato live+browser: tutti e 6 i calcoli (IRPEF/Forfettario esistenti + 4 nuovi) danno numeri matematicamente corretti (IVA 1000→220,00; scorporo 1220→1000,00; liquidazione 5000-3000→2000 a debito; 730 reddito 35000/ritenute 9000/detr 1910→rimborso 2160; cedolare 12000×21%→2520; ravvedimento 1000€/30gg→1026,64 totale). Zero errori JS. Suite 155/155 invariata (nessuna modifica ai motori, solo endpoint+UI). NB test: formattazione senza punto delle migliaia (es. "8750,00") è un limite dell'ICU del browser headless di test, preesistente e identico anche in IRPEF/Forfettario — non introdotto ora, cosmetico, non riguarda l'esattezza del numero.
- **Prossimo passo (richiesto dall'utente):** motore INPS (contributi artigiani/commercianti, gestione separata) — ancora da fare.

## PERFORMANCE — cache dei file statici (v3.7.11, 1 lug 2026)

Utente ha chiesto miglioramenti "a rischio zero" per performance senza sconvolgere il progetto. Prima verificato che il polling della UI è già sano (orologio 1s solo client-side, checkAIStatus 30s, OCR 2.5s solo durante elaborazione) e lo sciame fa GIÀ 1 sola chiamata AI per calcolo (Revisore deterministico) — niente da tagliare lì.
- ✅ `app.py`: sottoclasse `CachedStaticFiles(StaticFiles)` che aggiunge `Cache-Control: public, max-age=86400` (solo su 200) ai file serviti da `/static` (font Inter/Sora + RemixIcon woff2/css — vendored, non cambiano mai). Beneficio reale in RETE STUDIO: gli altri PC non riscaricano ~20 font ad ogni pagina via Wi-Fi. 1 giorno = se un file statico cambiasse con un update, i browser lo riprendono entro 24h. `index.html` (via route `/`) NON è in `/static` → resta senza cache, gli aggiornamenti si vedono subito.
- Verificato: `/static/remixicon/remixicon.woff2` → 200 + header cache; `/` → nessuna cache (corretto); pagina carica font+icone, 0 richieste static fallite, 0 errori JS. Suite 155/155 invariata (nessuna modifica a motori/logica).
- Nota per il futuro (NON fatto ora, richiede test reale): prompt caching lato AI su OpenRouter per abbattere i token del system prompt fisso — dipende dal supporto per-modello (GLM/DeepSeek variano), va misurato prima di implementare.

## INPS in chat + Deficitarietà enti pubblici (v3.7.13, 1 lug 2026)

Completati due fili aperti richiesti dall'utente ("2 e 3 completali").
- ✅ **INPS anche in chat**: aggiunto `sciame.rispondi_inps` (chiarificatore AI 1 giro → motore `fiscal_engine.inps` → revisore deterministico `revisiona_inps` → comunicatore `comunica_inps`), sullo stesso pattern di IVA/730/cedolare/ravvedimento. Collegato in `copilota_calcoli.rispondi_calcolo` con `_INPS_HINT` (inps/contributi/previdenziali/artigiani/commercianti/gestione separata) + esteso il gate `_TASSA`. Verificato end-to-end con AI reale: "calcola contributi INPS artigiano 30000" → € 7.200,00 dal motore + avviso Circolare INPS. Test deterministici `test_sciame_inps.py` (routing + comunicatore + revisore blocca contributo negativo/oltre imponibile).
- ✅ **Indicatori di deficitarietà strutturale** (completa Revisione Enti Pubblici): `public_finance_reference/indicatori_deficitarieta.yaml` (8 parametri D.M. 28/12/2018 con soglia + direzione sopra/sotto + fonte), funzione `revisione_enti_pubblici.analizza_deficitarieta(valori)` — CONFRONTO deterministico valore-inserito vs soglia + regola art. 242 TUEL (deficitario se ≥ 4/8). Endpoint `POST /api/revisione-enti/deficitarieta` (`DeficitarietaReq`, 8 float opzionali → compilazione parziale supportata). UI: box "Indicatori di deficitarietà" nella pagina Revisione Enti (8 campi costruiti da JS `_DEF_PARAMETRI`, hook `reInitDef()` su showPage). Verificato browser: 8 campi, caso 4/8→"Strutturalmente deficitario", caso sano→"Non deficitario", 0 errori JS. Test `test_revisione_enti_pubblici.py` (6 casi: sano, direzioni sopra/sotto, soglia 4/8, valore=soglia non deficitario, parziale, avviso D.M.).
- ⚠️ **ONESTÀ (registrato):** il MOTORE non calcola gli 8 indicatori (richiederebbero molte più voci di bilancio): il revisore inserisce i valori dal prospetto ufficiale e il motore applica solo il confronto + la regola di legge. Parametri/soglie = D.M. → ogni output porta l'avviso "verificare al D.M. vigente". Giudizio finale resta dell'organo di revisione.
- Suite **179 test** (168 + 6 deficitarietà + 5 sciame INPS). 119 rotte.

## MOTORE INPS — contributi lavoratori autonomi (v3.7.12, 1 lug 2026)

Ultimo motore fiscale mancante nella "flotta" (dopo IRPEF/forfettario/IMU/IVA/730/cedolare/ravvedimento). Copre le due gestioni più usate da un commercialista.
- ✅ `fiscal_engine/inps.py` + `fiscal_reference/inps.yaml`: **Artigiani/Commercianti (IVS)** — contributo fisso sul minimale + quota % sull'eccedenza, +1% sulla quota oltre la soglia (55.448), cap al massimale (ante/post 1996), riduzione 50% pensionati over 65, aliquote 24% / 24,48% (commercianti +0,48% indennizzo). **Gestione Separata** — aliquota sul reddito effettivo fino al massimale (26,07% senza altra copertura / 24% con). Dispatcher `calcola_inps(reddito, gestione, ...)`.
- ⚠️ **ONESTÀ (registrato):** minimale/massimale/soglie sono VARIABILI ANNUALI (Circolare INPS) — come già segnalato in CLAUDE.md tra le voci da riverificare. Valori 2025 nel YAML, marcati con `avviso` prominente ("STIMA — verificare alla Circolare INPS"); ogni output porta il warning (come ravvedimento.py). Endpoint passa `anno=None` (NON forza la freschezza: già marcato stima). Aliquote strutturalmente stabili. NON inclusi: contributo maternità fisso, riduzioni under-21/nuove attività, rivalsa 4% G.S.
- ✅ `app.py`: `POST /api/calcola/inps` (modello `CalcInps`), stesso pattern degli altri (disclaimer + fiscal_audit). UI: card "Contributi INPS" in Calcolatori Fiscali con select gestione (mostra/nasconde i campi giusti: ante/post-96 + over65 per IVS, altra-copertura per G.S.) + avviso di verifica in evidenza + export PDF.
- Test: `fiscal_engine/test_inps.py` (13 casi golden: sotto/sopra minimale, +1% oltre soglia, cap massimale ante/post-96, riduzione over65, G.S. con/senza copertura, freschezza anno, avviso presente). Verificato a mano (70k artigiani = 55448×24% + 14552×25% = 16945,52) e nel browser (30k→7200; over65→3600; G.S. campi corretti; 0 errori JS). Suite **168/168** (155+13).
- **Flotta calcolatori ora COMPLETA** per il commercialista tipo: IRPEF, forfettario, IMU, IVA, 730, cedolare, ravvedimento, INPS — tutti con pulsante dedicato + chat.

## PERFORMANCE — cache dei file statici (v3.7.11, 1 lug 2026)
**Stato:** Parte 1 — Fasi A, B, C, D (+OCR/riconciliazione), E, F, G, H, J complete. Parte 2 — dati versionati (IMU/IRPEF/forfettario), motori IRPEF+forfettario, data-freshness guard, suite golden 25/25 verdi, SOP di aggiornamento: complete. Tutti i punti 🔴CRITICO/🟠ALTA chiusi. Evolution: Risk-Audit (engine+endpoint+test) fatto, UI in coda. In coda: I (guardrail modello free), function-calling nativo, ev. seed INPS/IVA come `.yaml`.
