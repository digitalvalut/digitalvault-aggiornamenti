@echo off
REM ============================================================
REM  FiscoSicuro - Apre il Firewall di Windows per la RETE STUDIO
REM  Doppio clic e rispondi "Si" alla richiesta di amministratore.
REM ============================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo  Chiedo i permessi di amministratore...
  powershell -Command "Start-Process '%~f0' -Verb RunAs"
  exit /b
)

echo.
echo  Apro la porta 8000-8010 per i colleghi della rete studio...
netsh advfirewall firewall delete rule name="FiscoSicuro Rete Studio" >nul 2>&1
netsh advfirewall firewall add rule name="FiscoSicuro Rete Studio" dir=in action=allow protocol=TCP localport=8000-8010

echo.
echo  ============================================================
echo   FATTO. Ora i colleghi possono collegarsi a:
echo       http://10.170.109.72:8000
echo  ============================================================
echo.
pause
