# DigitalVault Evolution — Invarianti di affidabilità fiscale

**Documento di vincolo per Claude Code.** Questo file codifica le regole non negoziabili per la manutenzione e l'evoluzione di DigitalVault, in particolare per i calcoli tributari.

> 📘 **Handover completo (architettura totale di tutto il progetto):** vedi `SOLO PROPRIETARIO/RELAZIONE_TECNICA_E_HANDOVER.md`. Leggilo PRIMA di lavorare. Regola d'oro: a ogni modifica aggiorna quel documento, alza `APP_VERSION` in `config.py`, aggiorna queste invarianti.

**Data di efficacia:** 16 giugno 2026  
**Fonte:** Brief operativo sulla affidabilità fiscale — Fase 0 audit completato.

---

## 🔴 DIRETTIVA PRIMARIA (NON NEGOZIABILE)

> **Nessun numero fiscalmente rilevante può essere prodotto dal modello linguistico (LLM).**

Importi, aliquote, coefficienti, scaglioni, moltiplicatori, scadenze e date devono provenire **esclusivamente da codice deterministico testato** che legge **dati di riferimento versionati e autorevoli**.

**Regola d'oro:** Se un numero non è tracciabile a una funzione del `fiscal_engine/`, non esce mai al cliente.

---

## 📋 Casi ad alto rischio (da monitorare)

### 1. **doc_classifier.py** — 🔴 CRITICO
- **Funzione:** `classifica(testo, nome_file, clienti)`
- **Rischio:** L'AI estrae `importo` da documenti scansionati senza validazione
- **Azione obbligatoria:** Aggiungere validazione post-AI (range check, confronto con OCR confidenza, marcare come "estratto da AI")
- **Conseguenze:** Importi alimentano `motore_proattivo.py` → avvisi di soglia forfettario

### 2. **riconciliazione.py** — 🟠 ALTA
- **Funzione:** `estrai_movimenti(testo_estratto)`
- **Rischio:** L'AI legge estratti conto e genera importi con tolleranza 2%
- **Azione obbligatoria:** Loggare sempre che proviene da AI; mostrare in UI "movimenti estratti da AI — verificare con documento originale"

### 3. **ocr_processor.py + ocr_massa.py** — 🟠 ALTA
- **Rischio:** L'AI vision legge interi documenti fiscali; testo scansionato diventa fonte di verità
- **Azione obbligatoria:** Marcare con watermark "OCR da AI, controllare originale" nel PDF generato

### 4. **ai_client.py — Chat Consulente AI** — 🟡 MEDIA
- **Endpoint:** `POST /api/chat`
- **Rischio:** Commercialista legge numero dalla risposta narrativa e lo usa come valore definitivo
- **Azione obbligatoria:** System prompt deve dire "Usa sempre `/api/calcola/*` per numeri definitivi". UI deve mostrare disclaimer.

---

## ✅ Moduli corretti (niente regressioni)

- **`tax_calculator.py`**: Calcoli IRPEF, Forfettario, INPS — puri, hard-coded, testati. OK.
- **`scadenze_cliente.py`**: Scadenzario standard — dati statici. OK.
- **`fatture_elettroniche.py`**: Parsing XML SDI strutturato. OK.

---

## 🛠️ Implementazione in corso (Fase A-J del Brief)

### **Fase A — Motore fiscale (`fiscal_engine/`)**
- ✅ `imu.py`: Calcolatore IMU per fabbricati — **IMPLEMENTATO E TESTATO**
  - Test golden case passa (moltiplicatore A/3 = 160, non 100)
  - Struttura: input tipizzati → calcolo puro → breakdown strutturato + fonte normativa
- 🔲 `f24.py`: Calcolatore F24 (in coda)
- 🔲 `irpef.py`: IRPEF (in coda)
- 🔲 `forfettario.py`: Regime forfettario (in coda)

### **Fase B — Dati di riferimento (`fiscal_reference/`)**
- ✅ `imu.yaml`: Moltiplicatori IMU, aliquote, regole di possesso — **IMPLEMENTATO**
  - Fonte: Art. 1 commi 739-783 L. 160/2019
  - Versionato: schema_version=1, data_efficacia="2020-01-01"
- 🔲 `irpef.yaml`: Scaglioni, aliquote 2025 (in coda)
- 🔲 `f24.yaml`: Righi F24, termini, versamenti (in coda)

### **Fase C — Tool-calling contract**
- ✅ Endpoint REST `POST /api/calcola/imu` (app.py) che chiama `fiscal_engine.imu.calcola_imu_fabbricato()` — **IMPLEMENTATO E TESTATO** (golden case HTTP 200; categoria sconosciuta → 400; aliquota mancante → 422 con campo, così l'AI lo chiede)
- ✅ System prompt Consulente AI (ai_client.py) irrobustito con "REGOLE INVIOLABILI SUI NUMERI FISCALI" — **IMPLEMENTATO E TESTATO**: sul caso IMU A/3 l'AI ora rimanda al calcolatore, chiede i dati mancanti, usa moltiplicatore 160 (non 100), etichetta le cifre come stime e chiude col disclaimer
- 🔲 (avanzato) Function-calling nativo (tool-use) per instradare automaticamente i calcoli della chat al motore — richiede modifica più profonda del gateway AI; da valutare

### **Fase D — Validazione**
- ✅ Validazione su `doc_classifier.importo` — **IMPLEMENTATA E TESTATA**
  - `_valida_importo()`: scarta ≤ 0, segnala importi > 100M, e **cross-check di presenza nel testo** (`_numeri_nel_testo()` gestisce formato italiano) → se l'AI inventa un importo non presente, viene marcato `importo_da_verificare` con `warnings[]`
  - Confidenza declassata da "alta" se l'importo è sospetto; `fonte_importo="ai"`
  - Persistito in `dati_estratti` (sia `classifica_coda` sia endpoint `/riclassifica`)
  - Esposto da `GET /api/documents` (`importo_da_verificare`, `warnings`) e mostrato in UI come badge "⚠ verifica importo" (tooltip coi motivi)
  - Test: 6 casi unit (presente/inventato/≤0/enorme/None/senza-testo) + integrazione API end-to-end
- ✅ Pattern estratto in modulo condiviso `validazione_importi.py` (`valida_importo`, `numeri_nel_testo`, `MAX_IMPORTO`) e riusato in:
  - `riconciliazione.py`: ogni movimento è marcato `da_verificare` se l'importo (in valore assoluto) non compare nell'estratto; report espone `movimenti_da_verificare`; UI mostra banner d'avviso
  - `ocr_processor.py`: validazione di range (no cross-check, è una foto) + ogni importo marcato `importo_da_verificare`; CSV con colonna "Controllo: Verificare originale (letto da OCR)"
  - Test: refactor doc_classifier senza regressioni + conteggio riconciliazione + CSV OCR

### **Fase E — System prompt**
- ✅ Regole inviolabili integrate direttamente in `ai_client.SYSTEM_PROMPT` (vedi Fase C) — la riga dannosa "Per calcoli mostra sempre i passaggi" è stata corretta
- 🔲 (opzionale) estrarre il prompt in `prompts/fiscal_assistant_system_prompt.md` caricato a runtime

### **Fase F — Disclaimer standardizzato**
- ✅ Centralizzato in `fiscal_engine/common.py` (`DISCLAIMER`, `disclaimer()`) — **IMPLEMENTATO E TESTATO**
  - Aggiunto agli endpoint `/api/calcola/imu`, `/irpef`, `/forfettario` (helper `_con_disclaimer`)
  - Stesso testo usato nelle regole del Consulente AI

### **Fase G — Test di regressione**
- ✅ `fiscal_engine/test_imu.py` + `fiscal_engine/test_irpef.py` — **25 test, tutti verdi** (pytest installato in python-win)
  - IMU: fallisce se moltiplicatore A/3 ≠ 160; confine categorie/validazione
  - IRPEF 2026: 28k→6440, 35k→8750, 38k→9740, 60k→18000; **test negativo: fallisce se rientra il 35%/25%**
  - Forfettario: imponibile 30k×0.78=23400, 50k×0.86=43000, 60k×0.40=24000; avviso soglia
  - Data freshness: anno non disponibile (2030) → blocco
  - Esecuzione: `cd D:\MOTORE; python-win\python.exe -m pytest fiscal_engine/ -q`

### **Fase H — Audit log**
- ✅ Tabella `fiscal_audit` (database.py, auto-creata da `create_all`) + modulo `fiscal_audit.py` (`registra()`, `ultimi()`) — **IMPLEMENTATO E TESTATO**
  - L'endpoint `/api/calcola/imu` registra ogni calcolo (input, output, costanti, fonte, versione dati, esito) — sia successi sia errori
  - Consultabile via `GET /api/calcola/audit?limite=N`
  - Robusto: se la scrittura audit fallisce, logga e prosegue (non blocca il calcolo)

### **Fase I — Modello (nessun degrado silenzioso)**
- 🔲 Garantire che LLM "ultimo resort" (free) non possa generare numeri non validati dal motore

---

## PARTE 2 — Dati di riferimento, collaudo e aggiornamento

Riferimento: `Downloads/DigitalVault_Affidabilita_Parte2_*.md`. Implementato il 16/06/2026.

### Dati di riferimento versionati (`fiscal_reference/`)
- ✅ `imu.yaml` (strutturale), `irpef.yaml` (3 scaglioni 2026: 23/33/43, **2° al 33% non 35%**), `forfettario.yaml` (soglia 85k, 0.15/0.05, coefficienti Allegato 4)
- Ogni file: `schema_version`, `anno_imposta`, `valid_from/valid_to`, `legal_source`, `verificato_il`
- **Governance: una sola sede per ogni costante** (i `.yaml`), mai nel codice. `tax_calculator.py` allineato (35%→33%) e marcato come superato dal motore per IRPEF/forfettario.

### Motore (`fiscal_engine/`)
- ✅ `irpef.py`, `forfettario.py` — leggono i `.yaml`, output compatibile col frontend + tracciabilità
- ✅ **Data-freshness guard** (`common.verifica_anno` + `DataNotFreshError`): se l'anno richiesto ≠ anno dei dati → BLOCCA, non usa silenziosamente dati vecchi
- Endpoint `/api/calcola/irpef` e `/forfettario` migrati al motore (anno=2026) con disclaimer + audit

### Processo di aggiornamento (SOP)
- A ogni Legge di Bilancio: aggiornare SOLO il `.yaml` (nuovo `valid_from/to`, `legal_source`, bump `schema_version`), rilanciare la suite golden, aggiungere un caso, changelog datato con validazione umana.
- Se per cambiare un'aliquota devi toccare la logica del motore → quel valore non era modellato come dato (difetto di design).
- ⚠️ Voci "VARIABILE ANNUALE" (IRPEF, forfettario, INPS, IVA, TARI) da riverificare alla fonte primaria. TARI/aliquote comunali: mai default nazionale, leggere delibera del Comune.

---

## 📝 Quando tocchi il codice

### ✅ CONSENTITO
1. Aggiungere funzioni in `fiscal_engine/` purché testate (golden case + confine)
2. Aggiungere dati in `fiscal_reference/` con versione + fonte normativa
3. Aggiungere test che **falliscono se un errore noto viene reintrodotto**
4. Aggiungere validazione / range check
5. Refactor di moduli **non fiscali** (UI, backend gen-purpose, etc.)

### ❌ VIETATO
1. Toccare `ai_client.py` senza aggiungere guardrail al system prompt
2. Modificare costanti hard-code fiscali in `tax_calculator.py` — estrarle in `fiscal_reference/`
3. Aggiungere calcoli tributari FUORI da `fiscal_engine/`
4. Permettere all'AI di rispondere numeri fiscali senza che il Consulente AI chiami `/api/calcola/*`
5. Rimuovere o debilitare i test di regressione

---

## 🧪 Test di regressione obbligatori

Prima di qualsiasi merge che tocca fiscalità:
```bash
cd D:\MOTORE\fiscal_engine
python -m pytest test_imu.py -v
```

Tutti i test devono passare. Se uno fallisce, **non mergare**.

---

## 📞 Escalation

Se trovi un punto dove il codice **non rispetta questa guida**:
1. Documenta il file/funzione/problema in una issue o memo
2. Proponi la correzione incrementale
3. **Non by-passare** le regole per fretta

Es. "Se l'LLM genera un importo, aggiungere validazione range check prima di salvare in DB".

---

## 🔗 Riferimenti

- **Brief operativo:** `/downloads/DigitalVault_ClaudeCode_Reliability_Brief.md` (Fase 0 audit completato)
- **Audit report:** Identificati 12 punti critici (1 CRITICO, 3 ALTA, 5 MEDIA, 3 BASSA OK)
- **Caso golden:** IMU A/3 rendita 232,41€ con moltiplicatore 160 (NON 100)
- **Norma madre:** Art. 1 commi 739-783 L. 160/2019 (IMU ordinaria)

---

---

## PARTE 3 — Hardening sicurezza (in corso, un Tier alla volta)

Riferimento: `Downloads/DigitalVault_Hardening_Parte3_*.md`. Audit Fase 0 completato 16/06/2026.

**Audit (stato):** Tier1.1 DB cifrato=ASSENTE; 2.1 chiave AI in chiaro + modello non loggato=ASSENTE/parziale; 2.2 update firmati=ASSENTE (updater.py:75 solo is_zipfile; applica_aggiornamento.py:62 extractall senza firma né Zip-Slip guard); 2.3 auth locale=ASSENTE (solo require_license; CORS solo-localhost OK); 3.1 parsing=PARZIALE; 3.2 prompt-injection=PARZIALE (mitigato da numeri deterministici); 4.1/4.2 offuscamento/firma app=ASSENTE.

**✅ Tier 3.1 (parsing input) — PRIMO TIER FATTO E TESTATO:**
- `fatture_elettroniche.py`: sostituito `xml.etree` con **`defusedxml`** (installato in python-win) → XXE e billion-laughs neutralizzati. Il chiamante `importa_fatture` (app.py:1190-1196) già cattura gli errori per-file → file invalidi rifiutati con errore gestito.
- Test: `test_security.py` (4 test: XXE, billion-laughs, non-fattura, uso di defusedxml). Suite totale **29/29 verde**.
- Resta opzionale per 3.1: verifica magic-bytes sugli upload (oggi: estensione + max 50MB).

**✅ Tier 2.2 (aggiornamenti firmati) — FATTO E TESTATO:**
- `update_security.py` (nuovo, a bordo): `verifica_firma(data, firma_b64)` con chiave pubblica Ed25519 già presente + `estrai_sicuro()` anti Zip-Slip.
- `updater.scarica()`: scarica, verifica is_zipfile, poi **verifica la firma** (presa dal manifest del titolare, non dal browser); rifiuta e non scrive nulla se non firmato/manomesso; salva `aggiornamento.sig`.
- `applica_aggiornamento.py`: ri-verifica la firma prima di toccare i file e usa `estrai_sicuro()` (no più `extractall` cieco). Pulisce zip+sig a fine.
- Master: `SOLO PROPRIETARIO/firma_aggiornamento.py` firma lo zip con la chiave privata → output `firma` (base64) + `sha256` da incollare nel manifest (campo `"firma"`).
- Test in `test_security.py`: Zip-Slip bloccato, estrazione benigna ok, firma roundtrip (valida/manomessa/assente). **Suite totale 32/32 verde.** App si avvia regolarmente.
- ⚠️ Operativo: d'ora in poi ogni manifest di aggiornamento DEVE contenere il campo `"firma"` (generato dal tool sul master), altrimenti i client rifiutano il pacchetto.

**✅ Tier 1.1 (cifratura DB a livello di campi) — FATTO E TESTATO:**
- `db_crypto.py`: chiave derivata dal serial SSD (scrypt) + fallback file; `cifra/decifra` idempotenti e tolleranti ai valori legacy in chiaro; tipo SQLAlchemy `EncryptedText` (cifra in bind, decifra in result).
- Applicato in database.py ai campi: Client.email/telefono/indirizzo/note, Document.controparte/note/dati_estratti, ChatMessage.content. IN CHIARO (searched/unique): Document.testo_estratto, codice_fiscale, partita_iva.
- `migra_cifra_campi()` one-shot in init_db (SQL grezzo, idempotente) + marker `data/.campi_cifrati`.
- Testato: DB temp (su disco cifrato `gAAAAA...`, via app in chiaro; CF/testo in chiaro), migrazione DB reale, e round-trip via API live (crea/leggi cliente). Suite sicurezza 13/13, totale 38/38.
- Nota onesta: chiave derivabile dal codice → protegge da furto SSD aperto in viewer, non da chi esegue il programma. Per protezione totale: SQLCipher o cifratura di volume.

**✅ Bug backup CORRETTO (scoperto durante il Tier 1.1):**
- `backup_manager._derived_key()` dipendeva da `license_manager._SECRET` (rimosso) → andava sempre in fallback su file `backup.key`; se quel file veniva rigenerato, TUTTI i backup precedenti diventavano indecifrabili.
- Fix: chiave backup ora DETERMINISTICA dal serial SSD (scrypt, label `DGV-BACKUP-v2`). I nuovi backup sono ripristinabili finché si ha l'SSD, anche se `backup.key` si perde. Testato: backup decifrato con la sola chiave derivata.
- ⚠️ Incidente correlato (16 giu): 69 clienti di PROVA persi PRIMA del Tier 1.1 (DB già vuoto al backup); backup vecchi (08:59/11:59) cifrati con chiave persa → non recuperabili. Erano dati demo (confermato dall'utente), nessuna perdita reale.
**🟡 Tier 2.1 — IN CORSO:**
- ✅ Part B (disciplina failover): `ai_client.chat_with_ai_meta()` → {content, model, degraded}; logga il modello nel server; `_is_free_model()` rileva la riserva `:free`. `/api/chat` ritorna `modalita_riserva` (MAI il nome del modello → protezione identità); UI mostra avviso "modalità di riserva". `chat_with_ai` resta stringa (retrocompatibile). Testato.
- ✅ Part A (chiave AI cifrata a riposo) — FATTO E TESTATO: in `config.py` risoluzione `_risolvi_chiave_ai()` con precedenza env > `data/ai_key.enc` (cifrato db_crypto) > inline; `salva_chiave_ai()` + `migra_chiave_ai()` (in init_db) cifrano l'inline su file e SVUOTANO il literal. **La chiave NON è più in chiaro in config.py** (riga = `OPENROUTER_API_KEY = ""`), risolta dal file cifrato; AI verificata in processo nuovo. CAMBIA CHIAVE/imposta_chiave_api restano invariati (scrivono inline → ri-cifrato al riavvio); update preserva via `data/`. GOTCHA risolto: la prima regex (non ancorata) svuotava l'esempio nel COMMENTO invece della riga vera → ora regex ancorata `(?m)^OPENROUTER_API_KEY...` + rimosso il pattern dai commenti (anche per non confondere gli altri tool che usano la stessa regex). Backup config.py.bak eliminato (conteneva la chiave in chiaro).

**🔲 Prossimi Tier:** Tier 2.3 login/PIN locale; Tier 3.2 isolamento prompt-injection; Tier 4 offuscamento/firma app.

---

## PERFORMANCE & SCALA (16 giu 2026)

Architettura chiave: **un'installazione per studio** (SSD/PC). Lo scaling è PER-STUDIO (decine di migliaia di documenti in un solo SQLite), non multi-tenant. Benchmark su 20–30k doc.

- ✅ **FTS5 full-text** (`database._crea_indici_fts`, in init_db): tabella `documents_fts` (external content su `testo_estratto,nome_originale,client_nome` — campi IN CHIARO) + 3 trigger di sync (ai/ad/au) + rebuild se disallineata. Indici su anno/tipo/created_at. Helper `cerca_documenti_fts(db, termine, limite)` (prefix+AND, ordina per bm25 rank) e `_fts_query` (sanitizza input). Misurato: ricerca testo 160ms→38ms; "chiedi archivio" 321ms+56MB→60ms.
- ✅ **Paginazione** in `/api/documents` (offset/limite, cap 200) + ricerca via FTS con fallback LIKE; ordine per rilevanza quando c'è `q`.
- ✅ **doc_brain.cerca_documenti**: recupera candidati via FTS (`_candidati_fts`, OR dei sinonimi) poi applica il punteggio fine, invece di caricare TUTTI i documenti → niente più 56MB/query. Fallback a load-all se FTS non disponibile.
- Benchmark riproducibile: seminare N doc in un DB temp e confrontare LIKE vs load-all vs FTS (vedi storico sessione).
- ✅ **Token economy — classificazione**: `doc_classifier.classifica()` NON manda più l'intera anagrafica clienti nel prompt (era ~3.500 token PER documento con 200 clienti). Abbinamento ora 100% deterministico: `_match_cliente_deterministico` (CF/P.IVA/nome nel testo, nome in ENTRAMBI gli ordini) + `_match_per_cf_piva` (CF/P.IVA estratti dall'AI). Rimosso campo `cliente_id` dal JSON AI e funzione `_clienti_compatti`. Testato: match corretto + classify reale ok. Più economico E più affidabile (l'AI non può sbagliare cliente).
- ✅ **DIFFERENZIAZIONE — Copilota collegato al motore** (`copilota_calcoli.py`): la chat capisce le richieste di CALCOLO (imu/irpef/forfettario) e risponde col **numero ESATTO dal fiscal_engine**, mai inventato. Flusso: gate a parole chiave `sembra_calcolo` (niente AI se non è un calcolo → 0 token extra sulla chat normale) → `interpreta()` (1 sola chiamata AI per estrarre i parametri) → `esegui()` deterministico → `formatta()` (numeri+scaglioni+disclaimer). Dati mancanti → chiede all'utente. Collegato a `/api/chat` (campo `da_motore`) e `/api/chat/stream` (un delta + DONE). Testato: gate, esegui (IMU 39044.88/molt.160, IRPEF 8750, forf 23400), end-to-end ("calcola IRPEF su 35000" → € 8.750,00). È il cuneo vs i big: AI a parole, numeri esatti dal motore.
- ✅ **INTEROP coi gestionali (cuneo)**: import già robusto (CSV clienti con auto-mappatura colonne `importa_clienti`, fatture XML `importa_fatture`, scopri_clienti). Aggiunto **EXPORT**: `GET /api/clients/esporta` (CSV, stesse colonne del modello → round-trip; campi cifrati escono in chiaro via ORM) e `GET /api/documents/esporta` (CSV elenco doc, filtri client_id/anno). Pulsanti "Esporta CSV" in UI (pagina clienti + documenti). CSV con BOM utf-8-sig (Excel-friendly). Testato via server (round-trip + decifratura). Posizionamento: "tieni il tuo gestionale per SDI/dichiarativi, DigitalVault è il cervello sopra i tuoi dati".
- ✅ **Token economy 2**: (contesto) `doc_brain._estratto_mirato` estrae una finestra ~1600 char CENTRATA sulla parola chiave (prima: primi 4000 char) → prompt ~60% più corto e più pertinente; `costruisci_contesto(risultati, chiavi, max_caratteri_per_doc=1600)`, `costruisci_prompt` passa le chiavi. (memoria chat) `_prepara_chat` invia gli ultimi messaggi entro BUDGET_CARATTERI=8000 (storico salvato per intero). Testato.
- 🔲 Da fare (opzionale): cache classificazione duplicati; export Excel (.xlsx) oltre al CSV. NON costruire: SDI/dichiarativi/paghe/conservazione a norma (regolato → integrare).

## RECUPERO DATI / BACKUP (17 giu 2026)

Problema risolto: db_crypto e i `.dvb` erano cifrati con chiave derivata dal **serial SSD** → copiare i file su un SSD nuovo li rendeva illeggibili (serial diverso). Soluzioni aggiunte in `backup_manager.py`:
- ✅ **Copia IN CHIARO sul PC** (`esporta_chiaro` → `~/DigitalVault_DatiPC`): snapshot del DB con i campi sensibili DECIFRATI (via `db_crypto.decifra`, dict `_CAMPI_CIFRATI`) + uploads + LEGGIMI. Nessuna password, nessun serial → "copia e incolla" su un SSD nuovo funziona SUBITO (i campi in chiaro vengono ri-cifrati dal nuovo dispositivo al primo avvio, perché `decifra` tollera il plaintext legacy). Rete anti-disastro. **Auto-aggiornata** nel loop di `avvia_backup_automatico` (avvio + ogni 3h). `ripristina_da_cartella` per il ripristino.
- ✅ **Backup PORTATILE protetto-password** (`esporta_protetto`/`ripristina_protetto`): file `DGVPWB1`+salt(16)+Fernet(scrypt(pw,salt)); auto-contenuto (porta il suo salt) → ripristinabile su QUALSIASI dispositivo con la password. Password errata → respinta. Logica zip estratta in `_ripristina_zip` (condivisa con ripristina_backup).
- Endpoint: `POST /api/backup/copia-pc`, `/protetto` {password}, `/ripristina-protetto` (file+Form password). UI: pulsanti in sezione Backup + funzioni JS `copiaDatiPC`/`backupProtetto`/`ripristinaProtetto`.
- Tutto testato (decifratura copia, round-trip password, endpoint via server, suite 38/38).
- ✅ **DECISIONE (17 giu) — NIENTE escrow/passe-partout**: l'utente ha scelto di NON avere una chiave di recupero del fornitore (più semplice e difendibile su GDPR: nessuna scorciatoia del vendor sui dati fiscali dei clienti). Il recupero della password dimenticata = la **copia in chiaro sul PC** (i dati non si perdono comunque). La password protegge solo il file portatile; se persa, il file portatile non si apre ma i dati restano nella copia PC. NON aggiungere un backdoor di recupero salvo richiesta esplicita futura.

## LICENZA — VINCOLO SOLO SSD (17 giu 2026, scelta utente)

Cambiato il modello di licenza da "PC + SSD" a **SOLO SSD** (il prodotto è portatile: stesso SSD = funziona su qualsiasi PC).
- `license_manager.get_machine_id()`: ora `SHA256("DGV-SSD|"+volume_id)[:24]`. **Fallback** a host+MAC+serial SOLO se `get_volume_id()=="NOVOLUME"` (per non collassare a un ID condiviso fra macchine). Anti-clone preservato (clonare l'SSD cambia il serial → ID diverso → serve nuova licenza).
- Compatibile col master: `genera_licenza.make_key(tier, machine_id)` firma la STRINGA dell'ID ricevuta dal cliente → nessuna modifica alla logica di firma. Aggiornati solo i testi (genera_licenza, schermata attivazione, UI: "ID di questo SSD").
- Conseguenza recupero: SSD rotto → SSD nuovo (serial diverso) → serve **nuova licenza** (cliente manda nuovo ID, titolare rigenera). I DATI tornano via copia in chiaro; la licenza è un passo a parte.
- Testato: ID = SSD-only; cambiando nome PC+MAC l'ID NON cambia (portabilità provata); licenza generata col timbro si attiva; master ripristinato.
- NB: la cifratura dati/backup (`db_crypto`, backup SSD) era già legata al solo serial SSD → ora coerente con la licenza.

## EVOLUTION — moduli consulenza (avviata 25 giu 2026)

Decisione titolare: costruire i 3 moduli "Evolution" in ordine **Risk → Finance → Legal**, in modalità **legale piena** (atti/memorie complete, RAG generativo) — responsabilità professionale assunta dal titolare. **PALETTO TECNICO NON NEGOZIABILE che resta:** i NUMERI (capitale, importi, proiezioni, soglie) restano deterministici dal motore/dati versionati; solo il TESTO legale può essere generato dall'Ai. La regola d'oro sui numeri NON si tocca.

- ✅ **Risk-Audit** (`risk_audit.py`, v3.4.0) — 1° modulo, **deterministico, zero AI**. `analizza(db)` → rilievi azionabili ordinati per gravità: soglie regime forfettario (soglia da `fiscal_reference/forfettario.yaml`, 85k/100k), importi estratti dall'AI da verificare (flag Fase D in `dati_estratti`), possibili doppioni (controparte+importo+anno), anagrafiche incomplete (CF/P.IVA), scadenze scadute. Endpoint `GET /api/risk/scan`. **UI**: pagina "Controllo Rischi" (nav + `caricaRischi()`, anti-XSS via `escHtml`). Isolato (plugin). Test: `test_risk_audit.py` (6 casi, DB in-memory).
- ✅ **Finance-Engine** (`finance_engine.py`, v3.5.0) — 2° modulo, **numeri deterministici (Decimal)**. Ancorato agli adeguati assetti (art. 2086 c.c. / CCII). `proiezione()` (compound N anni), `dscr()` (sostenibilità debito, soglie da `finance_reference/adeguati_assetti.yaml`: adeguato≥1.2 / limite≥1.0 / <1.0 allerta), `stress_test()` (shock ricavi/costi → ricalcola margine+DSCR), `analisi()` orchestratore. Endpoint `POST /api/finance/analisi`. **UI**: pagina "Adeguati Assetti" (form → proiezione+DSCR+stress, `calcolaFinance()`). Test: `test_finance_engine.py` (8 casi). 🔲 Da fare: generazione TESTO business plan/merito creditizio (AI, numeri dal motore).
- ✅ **Legal-Engine** (`legal_engine.py`, v3.6.0) — 3° modulo, Step 1. Framework "intervista → generazione" su template VERSIONATI (`legal_reference/*.yaml`). `tipi_disponibili()`, `campi_richiesti(tipo)`, `genera(tipo, parametri)` (assembla dal template, segnala campi obbligatori mancanti, li evidenzia tra [parentesi]). 5 template versionati: `statuto_aps`, `statuto_ets` (D.Lgs. 117/2017), `atto_costitutivo_srl` (art. 2463 c.c., BOZZA per notaio), `atto_costitutivo_snc` (art. 2295 c.c.), `risposta_formale` (lettera amministrativa; NON memoria giudiziale). Endpoint `GET /api/legal/tipi|campi`, `POST /api/legal/genera`, `POST /api/legal/pdf` (riusa `genera_pdf_consulenza`). **UI**: pagina "Atti & Statuti" (select dinamico → campi → bozza textarea, copia/.txt/PDF). **Generazione AI** (`genera_ai`, async, endpoint `POST /api/legal/genera-ai`): raffina SOLO la forma con guardrail inviolabile (`_SISTEMA_AI`: vietato toccare numeri/dati/riferimenti); la versione deterministica resta in `testo_base`; se l'AI manca → fallback al deterministico; bloccata se ci sono campi obbligatori mancanti. UI: bottone "Genera con AI" + badge; PDF usa il testo mostrato via `/api/pdf/consulenza` (riflette rifiniture AI/modifiche a mano). Test: `test_legal_engine.py` (12 casi, incl. PDF + AI happy/fallback/guardia). Pubblicato 3.6.0.
- ✅ **Legal v3.6.1** — template RISCRITTI come documenti COMPLETI (non più stub di 6-7 righe) + **10 tipi totali**: atto SNC (19 art.), atto+statuto Srl (17), statuto APS (20), statuto ETS (18), + **contratti**: locazione abitativa (L.431/98, 15 art.), locazione commerciale (L.392/78, 14), comodato (artt.1803-1812, 10), affitto d'azienda (artt.2555/2557/2561, 10), prestazione servizi/opera (artt.2222-2238, 10), risposta formale. Rimossa la dicitura "BOZZA" dai titoli (resta nota professionale a piè di pagina nel campo `disclaimer`). I template sono additivi: nuovi `.yaml` in `legal_reference/` compaiono da soli nel menu. Test: `test_legal_engine.py` (15 casi).
- ✅ **Legal v3.6.2** — **15 documenti totali**: aggiunti contratto di lavoro subordinato (CCNL), cessione quote Srl, verbale di assemblea, riconoscimento di debito (art. 1988 c.c.), accordo di riservatezza/NDA. `test_legal_engine.py` (17 casi). **NB onestà (registrato)**: l'AI/software NON può "validare legalmente"; i documenti sono modelli professionali completi con fonti normative, da adattare e firmare a cura del professionista (notaio dove richiesto). La dicitura resta nel `disclaimer` a piè di pagina.
- ✅ **v3.6.3** — (A) guida interna aggiornata: `ai_client.HELP_PROMPT` ora descrive Controllo Rischi, Adeguati Assetti, Atti & Statuti + nuove FAQ in `AIUTO_FAQ`. (B) **precompilazione da cliente** in Atti & Statuti: endpoint `GET /api/legal/clienti` (id/etichetta/anagrafica formattata da CF/P.IVA/indirizzo); UI con menu "Cliente" + pulsante "↳ cliente" sui campi-parte (`LEGAL_PARTI`) → `legalUsaCliente()` riempie il campo selezionato con l'anagrafica del cliente già in archivio.

## ECONOMIA TOKEN — riordino flotta modelli (v3.6.9)

Segnalazione utente: Claude (Opus 4.8/Sonnet) come primario consumava troppo. Riordinata la priorità in `config.py` TIERS (il sistema usa il PRIMO modello che risponde, gli altri sono fallback):
- **MEDIA/SUPERIOR testo**: primario ora `z-ai/glm-5.2`, poi `deepseek/deepseek-v4-pro`, poi Gemini; Claude Sonnet in pos. 4 (riserva di qualità), Opus 4.8 spinto in fondo (pos. 7 in SUPERIOR) — usato di rado.
- **Vision (OCR) tutti i tier**: primario `google/gemini-3.5-flash` (economico) invece di Claude → l'OCR delle foto/scansioni costa una frazione. Claude/Opus solo come riserva. NB: GLM/DeepSeek sono solo-testo, restano fuori dalle liste vision.
- BASE invariato (già economico). Effetto: ~90% richieste su modelli economici-forti, stessa qualità sui casi fiscali/legali. Tradeoff: SUPERIOR non guida più con Opus (marketing "il massimo"): se serve, rimettere Opus primo nel SUPERIOR.

## SICUREZZA COPIE NUOVO SSD — anti-leak dati + chiave AI (v3.6.8)

Segnalazione utente: una copia su nuovo SSD si era portata DATI VECCHI del master + la CHIAVE AI (rischio furto). Cause: la cartella `data/` contiene `digitalvault.db` (tutti i dati), `ai_key.enc` (chiave AI cifrata), `dbfield.key`/`backup.key` (chiavi di cifratura). Se la copia porta `data/`, trapela tutto. Fix in ENTRAMBI i tool:
- ✅ `prepara_nuovo_ssd.py` (PREPARA SSD NUOVO CLIENTE): `_azzera_per_nuovo_cliente` aggiunge `dbfield.key`. `_verifica_sicurezza(dest, azzera)` POTENZIATA: rimuove ovunque `ai_key.enc`/`dbfield.key`/`backup.key`/`.campi_cifrati` + segreto titolare, **azzera** `OPENROUTER_API_KEY="sk-..."` in ogni `config.py`, e per nuovo cliente (azzera) verifica/rimuove `digitalvault.db*`, `licenza.dat`, documenti in `uploads/`. Anche il ramo `--clona` toglie le chiavi.
- ✅ `crea_copia.py` (CREA COPIA): `EXCLUDE_FILES` +ai_key.enc/dbfield.key/backup.key/.campi_cifrati/rete_pin.txt; `verifica()` bonifica anti-leak (rimuove chiavi+db residui, azzera chiave AI in config.py).
- Testato su copia FINTA: chiave AI, chiavi cifratura, database, documenti vecchi, SOLO PROPRIETARIO, chiave in config → tutti rimossi ("COPIA COMPLETAMENTE PULITA"). NB: la chiave AI è comunque cifrata col serial dell'SSD (inutilizzabile altrove), ma non deve MAI viaggiare. Regola per l'utente: usare SEMPRE i tool, mai copiare l'SSD a mano.

## OCR AUTOMATICO PDF FOTOGRAFATI + bugfix CamScanner (v3.6.5)

Problema utente: un 730 fotografato con CamScanner veniva caricato ma NON riconosciuto. Causa diagnosticata sul file reale: il PDF non ha testo (pdfplumber → 0 caratteri, solo immagini), quindi la classificazione (che lavora su `testo_estratto`) non parte. **Due fix:**
- ✅ **BUG `ocr_massa._immagini_da_pdf`**: prendeva la PRIMA immagine di ogni pagina e faceva `break`. I PDF CamScanner hanno 2 immagini/pagina: img1 = banner watermark (1076×105, ~38KB, identico) + img2 = scansione vera (~2240×3005, ~800KB). Risultato: l'OCR leggeva solo "Scansionato con CamScanner". **Fix**: ora sceglie l'immagine con AREA MASSIMA per pagina (la scansione vera). Colpiva anche l'OCR di massa esistente. Provato sul file reale: ora legge il 730 (contribuente, CF, dati).
- ✅ **Auto-OCR all'upload**: in `app.py` upload, se un PDF ha testo vuoto → `stato_classifica="ocr_in_coda"` + `ocr_massa.avvia_singolo(doc.id)` (nuova funzione, thread daemon): OCR AI in background → riempie `testo_estratto` con marcatura `[TESTO LETTO CON OCR AI…]` → mette il doc in `in_coda` → `classifica_coda.assicura_avvio()` lo riconosce. UI: stato "Lettura OCR…" + auto-refresh lista include `ocr_in_coda`.
- ✅ **v3.6.6 — token economy OCR**: `avvia_singolo` default `max_pagine` 10 → **2**. L'auto-OCR all'upload legge solo le prime 2 pagine (bastano a RICONOSCERE tipo + dati chiave) per non bruciare token/tempo; la lettura COMPLETA di tutte le pagine resta nell'OCR di massa ("Leggi le scansioni"), lanciato dall'utente. Motivo: su un 730 da 10 pagine l'auto-OCR mangiava token e restava lento/"GENERICO" in attesa di finire tutte le pagine.
- ✅ **v3.6.7 — RETE DI SICUREZZA anti-blocco OCR**: un OCR interrotto (riavvio/chiusura) lasciava il documento per SEMPRE in `ocr_in_coda` ("Lettura OCR…") perché nessuno lo riprendeva → bug serio segnalato dall'utente. Fix: `app._recupera_stati_orfani()` in `lifespan` (avvio): i doc `ocr_in_coda` orfani tornano a stato finale (`da_assegnare`/`manuale`) **SENZA ritento automatico** (l'OCR vision costa: il ritento lo decide l'utente con "Leggi le scansioni"); i doc `in_coda` (già con testo) vengono ripresi dal classificatore. Garanzie: OCR one-shot (no loop), `max_pagine=2`, ogni chiamata AI con `TIMEOUT=60s` → non può mai girare all'infinito né bruciare token senza limite.

## AGGIORNAMENTI OTA — auto-applicazione (v3.6.4)

Problema utente: il nuovo SSD restava a versione vecchia perché l'update è in 2 passi (in app "Scarica" → poi lanciare a mano `AGGIORNA DIGITALVAULT.bat`) e il 2° passo si dimentica. Server/GitHub erano OK (manifest 3.6.3 live, URL giusto, zip firmato; `applica_aggiornamento` NON ha config.py in `PRESERVA` → la versione si aggiorna; chiave AI conservata a parte). **Nessun bug**, solo flusso manuale.
- ✅ **Auto-apply all'avvio**: `app._applica_update_in_attesa()` (chiamata in cima a `__main__`): se esiste `_aggiornamento/aggiornamento.zip` e nessuna istanza è già attiva (`_gia_in_esecuzione`), lancia `applica_aggiornamento.py` in subprocess con `DIGITALVAULT_AUTO=1`, poi `os.execv` per ripartire col codice nuovo. Guardia anti-loop via env `DIGITALVAULT_UPDATE_APPLICATO`; best-effort (se fallisce, avvia la versione attuale). Lo zip viene cancellato dall'applicatore → niente loop.
- ✅ `applica_aggiornamento.py`: aggiunta modalità **AUTO** (`--auto`/`DIGITALVAULT_AUTO=1`) → `_pausa()` salta i prompt `input()` che bloccherebbero l'avvio non interattivo. Il `.bat` manuale resta valido.
- ✅ `updater.scarica()`: messaggio aggiornato ("chiudi e riapri, si installa da solo").
- Ora il cliente: in app preme **Scarica**, **riapre** → aggiornato. Niente più passo manuale.

**Ultima modifica:** 2026-06-25  
**Stato:** Parte 1 — Fasi A, B, C, D (+OCR/riconciliazione), E, F, G, H, J complete. Parte 2 — dati versionati (IMU/IRPEF/forfettario), motori IRPEF+forfettario, data-freshness guard, suite golden 25/25 verdi, SOP di aggiornamento: complete. Tutti i punti 🔴CRITICO/🟠ALTA chiusi. Evolution: Risk-Audit (engine+endpoint+test) fatto, UI in coda. In coda: I (guardrail modello free), function-calling nativo, ev. seed INPS/IVA come `.yaml`.
