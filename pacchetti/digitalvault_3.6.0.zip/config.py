import os
from pathlib import Path

BASE_DIR = Path(__file__).parent
UPLOAD_DIR = BASE_DIR / "uploads"
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "digitalvault.db"

# NOTA: la riga della chiave qui sotto viene aggiornata automaticamente da
# "CAMBIA CHIAVE AI.bat" (non cambiare il formato della riga).
# SICUREZZA (Tier 2.1): la chiave resta in chiaro QUI solo finché non viene
# cifrata al primo avvio. migra_chiave_ai() la sposta in data/ai_key.enc
# (cifrata) e SVUOTA questa riga. Una nuova chiave scritta qui da "CAMBIA
# CHIAVE AI" viene ri-cifrata al successivo avvio.
OPENROUTER_API_KEY = ""
_INLINE_OPENROUTER_KEY = OPENROUTER_API_KEY

OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
_AI_KEY_FILE = DATA_DIR / "ai_key.enc"


def _decifra_chiave_ai():
    """Legge la chiave cifrata da data/ai_key.enc, se presente."""
    try:
        if _AI_KEY_FILE.exists():
            import db_crypto
            v = db_crypto.decifra(_AI_KEY_FILE.read_text(encoding="utf-8").strip())
            return v or None
    except Exception:
        return None
    return None


def _risolvi_chiave_ai() -> str:
    """Precedenza: variabile d'ambiente > chiave cifrata su file > inline (legacy)."""
    env = os.environ.get("DIGITALVAULT_OPENROUTER_KEY")
    if env:
        return env
    return _decifra_chiave_ai() or _INLINE_OPENROUTER_KEY


OPENROUTER_API_KEY = _risolvi_chiave_ai()


def salva_chiave_ai(chiave: str) -> bool:
    """Cifra e salva la chiave AI in data/ai_key.enc (chiave derivata dal dispositivo)."""
    try:
        import db_crypto
        DATA_DIR.mkdir(exist_ok=True)
        _AI_KEY_FILE.write_text(db_crypto.cifra(chiave), encoding="utf-8")
        return True
    except Exception:
        return False


def migra_chiave_ai():
    """Se in config.py c'è una chiave AI in chiaro (inline), la cifra su file e
    SVUOTA la riga inline (toglie il segreto dal disco). Re-eseguibile: una
    nuova chiave scritta da 'CAMBIA CHIAVE AI' viene ri-cifrata al riavvio."""
    if os.environ.get("DIGITALVAULT_OPENROUTER_KEY"):
        return  # la chiave arriva dall'ambiente: non toccare l'inline
    inline = (_INLINE_OPENROUTER_KEY or "").strip()
    if not inline or not inline.lower().startswith("sk-"):
        return  # niente da migrare (già vuota o non una chiave)
    if not salva_chiave_ai(inline):
        return
    try:
        import re as _re
        p = BASE_DIR / "config.py"
        testo = p.read_text(encoding="utf-8")
        nuovo = _re.sub(r'(?m)^OPENROUTER_API_KEY\s*=\s*"[^"]*"',
                        'OPENROUTER_API_KEY = ""', testo, count=1)
        if nuovo != testo:
            p.write_text(nuovo, encoding="utf-8")
    except Exception:
        pass

# ============================================================================
#  LE TRE VERSIONI DI DIGITALVAULT (abbonamento dello studio)
# ============================================================================
#  La versione attiva NON si imposta qui: e' scritta DENTRO la chiave di
#  licenza (DGV-B-... / DGV-M-... / DGV-S-...). Vedi license_manager.py.
#
#  Ogni versione ha la sua "flotta" di modelli AI su OpenRouter, in ordine
#  di preferenza: se il primo non risponde si passa automaticamente al
#  successivo (il programma non si ferma MAI per colpa di un modello).
#  L'ultimo modello a pagamento di ogni lista e' "openrouter/auto":
#  OpenRouter sceglie da solo un modello potente e ATTUALE, quindi la
#  flotta resta aggiornata anche quando escono modelli nuovi.
# ============================================================================

TIERS = {
    "BASE": {
        "nome": "DigitalVault BASE",
        "descrizione": "Per studi piccoli: AI veloce ed economica per le domande di ogni giorno.",
        "max_tokens": 4096,        # lunghezza massima di ogni risposta
        "memoria_chat": 20,        # quanti messaggi precedenti ricorda la chat
        "modelli": [
            "google/gemini-3.5-flash",              # primario: nuovissimo, contesto 1M, economico
            "deepseek/deepseek-v4-flash",           # riserva ULTRA economica
            "deepseek/deepseek-v4-pro",             # riserva forte e molto economica (solo testo)
            "z-ai/glm-5.2",                         # riserva forte e economica (solo testo)
            "openai/gpt-5.4-mini",                  # riserva economica OpenAI
            "google/gemini-3.1-flash-lite",         # riserva super economica
            "openrouter/auto",                      # rete di sicurezza sempre aggiornata
            "openai/gpt-oss-120b:free",             # gratuito come ultima spiaggia
        ],
        "modelli_vision": [
            "google/gemini-3.5-flash",
            "openai/gpt-5.4-mini",
            "google/gemini-3.1-flash-lite",
        ],
    },
    "MEDIA": {
        "nome": "DigitalVault MEDIA",
        "descrizione": "Per studi strutturati: AI di fascia alta, risposte piu' lunghe e piu' memoria.",
        "max_tokens": 8192,
        "memoria_chat": 30,
        "modelli": [
            "anthropic/claude-sonnet-4.6",          # primario: eccellente su testi fiscali/legali, contesto 1M
            "google/gemini-3.1-pro-preview",        # riserva di pari livello
            "z-ai/glm-5.2",                         # riserva forte e economica (solo testo)
            "deepseek/deepseek-v4-pro",             # riserva forte e molto economica (solo testo)
            "openai/gpt-5.4",                       # riserva potente OpenAI
            "google/gemini-3.5-flash",              # riserva veloce
            "openrouter/auto",                      # rete di sicurezza sempre aggiornata
            "openai/gpt-oss-120b:free",
        ],
        "modelli_vision": [
            "anthropic/claude-sonnet-4.6",
            "google/gemini-3.1-pro-preview",
            "openai/gpt-5.4",
            "google/gemini-3.5-flash",
        ],
    },
    "SUPERIOR": {
        "nome": "DigitalVault SUPERIOR",
        "descrizione": "Il massimo assoluto: i modelli AI piu' potenti esistenti, risposte lunghissime, memoria estesa.",
        "max_tokens": 16384,
        "memoria_chat": 50,
        "modelli": [
            "anthropic/claude-opus-4.8",            # primario: massima qualita' di ragionamento, contesto 1M
            "openai/gpt-5.5",                       # riserva top OpenAI
            "google/gemini-3.1-pro-preview",        # riserva top Google
            "anthropic/claude-sonnet-4.6",          # riserve di altissimo livello
            "x-ai/grok-4.3",
            "z-ai/glm-5.2",                         # riserva forte e economica (solo testo)
            "deepseek/deepseek-v4-pro",             # riserva forte e molto economica (solo testo)
            "openrouter/auto",                      # rete di sicurezza sempre aggiornata
            "openai/gpt-oss-120b:free",
        ],
        "modelli_vision": [
            "anthropic/claude-opus-4.8",
            "openai/gpt-5.5",
            "google/gemini-3.1-pro-preview",
            "anthropic/claude-sonnet-4.6",
        ],
    },
}

DEFAULT_TIER = "BASE"   # usata solo se la licenza non specifica la versione

# --- Compatibilita' con il codice esistente (puntano alla versione MEDIA) ---
AI_MODELS = TIERS["MEDIA"]["modelli"]
VISION_MODELS = TIERS["MEDIA"]["modelli_vision"]
PRIMARY_MODEL = AI_MODELS[0]

APP_NAME = "FiscoSicuro by DigitalVault"
APP_VERSION = "3.6.0"

# Controllo aggiornamenti: il titolare pubblica un piccolo file JSON a questo
# indirizzo (es. su un suo spazio web o un Gist). Il programma lo legge e, se
# c'e' una versione piu' nuova, avvisa. Lascia "" per disattivare il controllo.
# Formato del file: {"versione": "3.1.0", "note": "novita'...", "url_zip": "https://.../digitalvault_3.1.0.zip"}
UPDATE_MANIFEST_URL = os.environ.get(
    "DIGITALVAULT_UPDATE_URL",
    "https://raw.githubusercontent.com/digitalvalut/digitalvault-aggiornamenti/main/aggiornamenti.json",
)

# Porte su cui il programma può avviarsi (la prima libera viene usata)
PORT_RANGE = list(range(8000, 8011))

UPLOAD_DIR.mkdir(exist_ok=True)
DATA_DIR.mkdir(exist_ok=True)
