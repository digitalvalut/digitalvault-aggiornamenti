"""Test del Legal-Engine (Step 1): intervista + generazione da template versionato."""
import legal_engine as le


def test_tipi_disponibili_contiene_aps():
    tipi = [t["tipo"] for t in le.tipi_disponibili()]
    assert "statuto_aps" in tipi


def test_campi_richiesti():
    chiavi = [c["chiave"] for c in le.campi_richiesti("statuto_aps")]
    assert "denominazione" in chiavi and "sede" in chiavi and "oggetto" in chiavi


def test_genera_completo():
    r = le.genera("statuto_aps", {
        "denominazione": "Vivere Insieme APS",
        "sede": "Palermo",
        "oggetto": "attività culturali e ricreative per la comunità",
    })
    assert r["ok"] is True
    assert r["completo"] is True and r["campi_mancanti"] == []
    assert "Vivere Insieme APS" in r["testo"]
    assert "Palermo" in r["testo"]
    assert "Art. 1" in r["testo"] and "Art. 8" in r["testo"]
    # default applicato (durata illimitata)
    assert "illimitata" in r["testo"]
    assert r["fonte"]


def test_genera_segnala_mancanti():
    r = le.genera("statuto_aps", {"sede": "Roma"})   # manca denominazione e oggetto
    assert r["ok"] is True and r["completo"] is False
    assert "denominazione" in r["campi_mancanti"]
    assert "oggetto" in r["campi_mancanti"]
    # i mancanti restano evidenziati tra [parentesi] nella bozza
    assert "[" in r["testo"]


def test_tipo_inesistente():
    r = le.genera("non_esiste", {})
    assert r["ok"] is False


def test_tutti_i_tipi_presenti():
    tipi = [t["tipo"] for t in le.tipi_disponibili()]
    for atteso in ["statuto_aps", "statuto_ets", "atto_costitutivo_srl",
                   "atto_costitutivo_snc", "risposta_formale"]:
        assert atteso in tipi


def test_genera_srl_con_capitale_deterministico():
    r = le.genera("atto_costitutivo_srl", {
        "denominazione": "Alfa S.r.l.", "sede": "Milano",
        "oggetto": "commercio al dettaglio", "capitale": "10.000",
        "soci": "Mario Rossi 100%"})
    assert r["completo"] is True
    assert "10.000" in r["testo"] and "Alfa S.r.l." in r["testo"]
    assert "NOTARILE" in r["testo"]            # avviso atto pubblico


def test_genera_srl_mancanti():
    r = le.genera("atto_costitutivo_srl", {"denominazione": "Beta S.r.l."})
    for k in ["sede", "oggetto", "capitale", "soci"]:
        assert k in r["campi_mancanti"]


def test_pdf_endpoint():
    from fastapi.testclient import TestClient
    import app
    c = TestClient(app.app)
    r = c.post("/api/legal/pdf", json={"tipo": "statuto_aps",
               "parametri": {"denominazione": "Test APS", "sede": "Roma", "oggetto": "attività"}})
    assert r.status_code == 200
    assert r.headers["content-type"] == "application/pdf"
    assert r.content[:4] == b"%PDF"


def test_genera_ai_happy(monkeypatch):
    import asyncio, ai_client
    async def fake(messages, model=None, system=None):
        return "TESTO RAFFINATO DAL GIURISTA\n\nArt. 1 — Denominazione\n... forma migliorata, dati invariati."
    monkeypatch.setattr(ai_client, "chat_with_ai", fake)
    r = asyncio.run(le.genera_ai("statuto_aps", {"denominazione": "X APS", "sede": "Roma", "oggetto": "y"}))
    assert r["ai"] is True
    assert "RAFFINATO" in r["testo"]
    assert "testo_base" in r and "X APS" in r["testo_base"]   # deterministico conservato


def test_genera_ai_fallback(monkeypatch):
    import asyncio, ai_client
    async def boom(messages, model=None, system=None):
        raise RuntimeError("no ai")
    monkeypatch.setattr(ai_client, "chat_with_ai", boom)
    r = asyncio.run(le.genera_ai("statuto_aps", {"denominazione": "X APS", "sede": "Roma", "oggetto": "y"}))
    assert r["ai"] is False
    assert "X APS" in r["testo"]                              # ricade sul deterministico


def test_genera_ai_blocca_se_mancanti(monkeypatch):
    import asyncio, ai_client
    async def fake(messages, model=None, system=None):
        return "non dovrei essere chiamato"
    monkeypatch.setattr(ai_client, "chat_with_ai", fake)
    r = asyncio.run(le.genera_ai("statuto_aps", {"sede": "Roma"}))   # mancano denominazione+oggetto
    assert r["ai"] is False and r.get("campi_mancanti")
