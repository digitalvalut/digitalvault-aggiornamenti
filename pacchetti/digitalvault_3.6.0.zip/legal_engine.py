"""
FiscoSicuro - Legal-Engine: intervista guidata + generazione documentale.
Terzo modulo della linea "Evolution".
(c) 2026 DigitalVault - Capo Team del Progetto: Dr. Falsone Giuseppe

Step 1: framework "intervista → generazione" su template VERSIONATI
(legal_reference/). Il documento è assemblato dal template deterministico
riempiendo i campi raccolti; i campi obbligatori mancanti sono segnalati.

Modalità scelta dal titolare: "versione piena" (in seguito il testo narrativo
potrà essere ampliato dall'AI). PALETTO che resta: i dati strutturali e i
riferimenti normativi vengono dal template versionato, non inventati a caso.
Documenti che richiedono notaio (atto costitutivo Srl/Spa) restano BOZZE.
"""
import yaml

from config import BASE_DIR

_DIR = BASE_DIR / "legal_reference"


class _Safe(dict):
    """Per format_map: lascia intatto un eventuale placeholder non fornito."""
    def __missing__(self, k):
        return "{" + k + "}"


def _load_template(tipo: str):
    f = _DIR / f"{tipo}.yaml"
    if not f.exists():
        return None
    try:
        return yaml.safe_load(f.read_text(encoding="utf-8"))
    except Exception:
        return None


def tipi_disponibili() -> list:
    """Elenco dei tipi di documento generabili (uno per file in legal_reference/)."""
    out = []
    if not _DIR.exists():
        return out
    for f in sorted(_DIR.glob("*.yaml")):
        try:
            t = yaml.safe_load(f.read_text(encoding="utf-8"))
            out.append({"tipo": t.get("tipo", f.stem), "nome": t.get("nome", f.stem),
                        "fonte": t.get("legal_source", "")})
        except Exception:
            continue
    return out


def campi_richiesti(tipo: str) -> list:
    """Domande dell'intervista guidata per il tipo richiesto."""
    t = _load_template(tipo)
    return t.get("campi", []) if t else []


def genera(tipo: str, parametri: dict = None) -> dict:
    """Assembla il documento dal template versionato riempiendo i campi.
    I campi obbligatori non forniti sono segnalati in `campi_mancanti` e nel
    testo restano evidenziati tra [parentesi], così la bozza è completabile."""
    tpl = _load_template(tipo)
    if not tpl:
        return {"ok": False, "errore": f"Tipo documento non disponibile: {tipo}"}
    parametri = parametri or {}

    valori = {}
    mancanti = []
    for c in tpl.get("campi", []):
        chiave = c["chiave"]
        v = (parametri.get(chiave) or "").strip() if isinstance(parametri.get(chiave), str) else parametri.get(chiave)
        if not v:
            if c.get("default"):
                v = c["default"]
            elif c.get("obbligatorio"):
                mancanti.append(chiave)
                v = f"[{c['label']}]"
            else:
                v = ""
        valori[chiave] = v

    parti = [tpl.get("nome", tipo).upper(), ""]
    for a in tpl.get("articoli", []):
        testo = str(a.get("testo", "")).format_map(_Safe(valori))
        parti.append(f"Art. {a.get('num', '')} — {a.get('titolo', '')}".rstrip())
        parti.append(testo)
        parti.append("")

    return {
        "ok": True,
        "tipo": tipo,
        "nome": tpl.get("nome", tipo),
        "testo": "\n".join(parti).strip(),
        "campi_mancanti": mancanti,
        "completo": not mancanti,
        "fonte": tpl.get("legal_source"),
        "schema_version": tpl.get("schema_version"),
        "disclaimer": ("BOZZA generata da modello versionato: va verificata e validata da un "
                       "professionista (e, dove richiesto dalla legge, da un notaio) prima dell'uso."),
    }


_SISTEMA_AI = (
    "Sei un giurista italiano che MIGLIORA soltanto la FORMA di una bozza di documento legale. "
    "REGOLE INVIOLABILI: non modificare, non aggiungere e non inventare NUMERI, importi, capitali, "
    "percentuali, date, denominazioni, codici fiscali, quote o riferimenti normativi. Mantieni TUTTI "
    "i dati e la numerazione degli articoli ESATTAMENTE come sono. Migliora solo la chiarezza e la "
    "correttezza giuridica del linguaggio italiano. Non introdurre clausole con nuovi contenuti "
    "numerici. Restituisci SOLO il testo del documento, senza commenti."
)


async def genera_ai(tipo: str, parametri: dict = None) -> dict:
    """Come genera(), ma raffina la FORMA del testo con l'AI. I numeri e i dati
    restano quelli del template versionato (la versione deterministica è sempre
    conservata in `testo_base`). Se l'AI non risponde, ricade sul deterministico."""
    base = genera(tipo, parametri)
    if not base.get("ok"):
        return base
    if base.get("campi_mancanti"):
        # con campi obbligatori mancanti non chiamo l'AI: prima vanno completati
        return {**base, "ai": False, "ai_nota": "Completa i campi obbligatori prima di rifinire con l'AI."}
    try:
        import ai_client
        msg = [{"role": "user",
                "content": "Migliora la forma di questa bozza mantenendo invariati tutti i dati, "
                           "i numeri e la numerazione degli articoli:\n\n" + base["testo"]}]
        raffinato = (await ai_client.chat_with_ai(msg, system=_SISTEMA_AI) or "").strip()
        if raffinato and len(raffinato) > 50:
            return {**base, "testo_base": base["testo"], "testo": raffinato, "ai": True}
        return {**base, "ai": False}
    except Exception:
        return {**base, "ai": False, "ai_errore": True}
