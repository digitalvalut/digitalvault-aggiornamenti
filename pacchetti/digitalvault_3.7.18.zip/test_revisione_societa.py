"""Test dell'analisi di bilancio per indici (Revisione Società, deterministico)."""
import revisione_societa as rs


def _bilancio_sano():
    return dict(attivo_corrente=500000, rimanenze=100000, passivo_corrente=250000,
                immobilizzazioni=400000, patrimonio_netto=500000, totale_debiti=400000,
                totale_attivo=900000, totale_passivo=900000, ricavi=1000000,
                risultato_operativo=120000, utile_netto=80000)


def _indice(r, chiave):
    return next(i for i in r["indici"] if i["chiave"] == chiave)


def test_indici_calcolo_corretto():
    r = rs.analizza_bilancio(_bilancio_sano())
    assert _indice(r, "current_ratio")["valore"] == 2.0
    assert _indice(r, "quick_ratio")["valore"] == 1.6           # (500-100)/250
    assert _indice(r, "autonomia_finanziaria")["valore"] == 0.56  # 500/900
    assert _indice(r, "indice_indebitamento")["valore"] == 0.8   # 400/500
    assert _indice(r, "roe")["valore"] == 16.0                   # 80/500 ×100
    assert _indice(r, "roi")["valore"] == 13.33                  # 120/900 ×100
    assert _indice(r, "ros")["valore"] == 12.0                   # 120/1000 ×100


def test_margini_e_quadratura():
    r = rs.analizza_bilancio(_bilancio_sano())
    assert r["margini"]["capitale_circolante_netto"] == 250000.0  # 500-250
    assert r["margini"]["margine_di_struttura"] == 100000.0       # 500-400
    assert r["quadratura"]["quadra"] is True


def test_salute_buona_tutti_verdi():
    r = rs.analizza_bilancio(_bilancio_sano())
    assert r["salute"] == "buona"
    assert r["n_verdi"] == 8 and r["n_rossi"] == 0


def test_indebitamento_direzione_basso():
    # leverage alto (debiti >> PN) → rosso; leverage basso → verde
    d = _bilancio_sano()
    d.update(patrimonio_netto=100000, totale_debiti=800000, totale_attivo=900000, totale_passivo=900000)
    r = rs.analizza_bilancio(d)
    assert _indice(r, "indice_indebitamento")["valore"] == 8.0   # 800/100
    assert _indice(r, "indice_indebitamento")["semaforo"] == "rosso"


def test_quadratura_sbilanciata_segnala():
    d = _bilancio_sano()
    d["totale_passivo"] = 850000   # non quadra con attivo 900000
    r = rs.analizza_bilancio(d)
    assert r["quadratura"]["quadra"] is False
    assert r["quadratura"]["sbilancio"] == 50000.0
    assert r["salute"] == "da_verificare"
    assert any("NON quadrano" in w for w in r["warnings"])


def test_divisione_per_zero_gestita():
    # patrimonio netto = 0 → gli indici con PN al DENOMINATORE (ROE, indebitamento)
    # non sono calcolabili (None), senza crash. La copertura (PN al numeratore) = 0.
    d = _bilancio_sano()
    d.update(patrimonio_netto=0, totale_debiti=900000)
    r = rs.analizza_bilancio(d)
    assert _indice(r, "roe")["valore"] is None
    assert _indice(r, "indice_indebitamento")["valore"] is None
    assert _indice(r, "copertura_immobilizzazioni")["valore"] == 0.0


def test_salute_critica_con_molti_rossi():
    d = dict(attivo_corrente=100000, rimanenze=80000, passivo_corrente=300000,
             immobilizzazioni=600000, patrimonio_netto=50000, totale_debiti=650000,
             totale_attivo=700000, totale_passivo=700000, ricavi=500000,
             risultato_operativo=-20000, utile_netto=-30000)
    r = rs.analizza_bilancio(d)
    assert r["n_rossi"] >= 3
    assert r["salute"] == "critica"


def test_avviso_soglie_convenzionali():
    r = rs.analizza_bilancio(_bilancio_sano())
    assert any("CONVENZIONALI" in w for w in r["warnings"])
