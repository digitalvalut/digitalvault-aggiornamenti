"""Verifica che il prompt caching sia attivato SOLO per i modelli Anthropic
(dove è supportato e conviene), lasciando gli altri provider col formato normale.
Nessuna chiamata reale all'AI: si ispeziona solo la forma del payload."""
import ai_client


def test_anthropic_riceve_cache_control():
    p = ai_client._payload("anthropic/claude-sonnet-5", [{"role": "user", "content": "ciao"}])
    sys = p["messages"][0]
    assert sys["role"] == "system"
    # system come ARRAY con cache_control ephemeral
    assert isinstance(sys["content"], list)
    assert sys["content"][0]["type"] == "text"
    assert sys["content"][0]["cache_control"] == {"type": "ephemeral"}
    # il testo fisso è presente
    assert len(sys["content"][0]["text"]) > 100


def test_opus_riceve_cache_control():
    p = ai_client._payload("anthropic/claude-opus-4.8", [{"role": "user", "content": "x"}])
    assert isinstance(p["messages"][0]["content"], list)
    assert p["messages"][0]["content"][0]["cache_control"] == {"type": "ephemeral"}


def test_altri_provider_formato_normale_stringa():
    for m in ("z-ai/glm-5.2", "deepseek/deepseek-v4-pro", "google/gemini-3.5-flash",
              "openai/gpt-5.5", "openrouter/auto"):
        p = ai_client._payload(m, [{"role": "user", "content": "ciao"}])
        sys = p["messages"][0]
        # nessun cache_control: content resta una STRINGA semplice
        assert isinstance(sys["content"], str), f"{m} non deve ricevere cache_control"


def test_messaggi_utente_preservati():
    msgs = [{"role": "user", "content": "primo"}, {"role": "assistant", "content": "ok"},
            {"role": "user", "content": "secondo"}]
    p = ai_client._payload("z-ai/glm-5.2", msgs)
    # system + i 3 messaggi
    assert len(p["messages"]) == 4
    assert p["messages"][1:] == msgs


def test_system_esplicito_usato_se_fornito():
    p = ai_client._payload("anthropic/claude-sonnet-5", [{"role": "user", "content": "x"}],
                           system="ISTRUZIONI PERSONALIZZATE")
    assert p["messages"][0]["content"][0]["text"] == "ISTRUZIONI PERSONALIZZATE"
