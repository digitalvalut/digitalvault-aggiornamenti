"""Test delle parti DETERMINISTICHE dello sciame INPS (comunicatore + revisore)
e del routing della chat verso INPS. Nessuna chiamata AI qui (il chiarificatore,
unico passo AI, è coperto dal test end-to-end separato)."""
import sciame
import copilota_calcoli as cop
from fiscal_engine import inps as _inps


def test_routing_riconosce_richiesta_inps():
    assert cop.sembra_calcolo("calcola i contributi INPS su 30000")
    assert cop._INPS_HINT.search("quanto pago di INPS da commerciante?")
    assert cop._INPS_HINT.search("contributi artigiani su 40 mila")
    # una domanda non-calcolo non deve attivare il gate
    assert not cop.sembra_calcolo("che ore sono?")


def test_comunicatore_inps_mostra_numeri_e_avviso():
    dati = _inps.calcola_inps(30000, "artigiani")
    testo = sciame.comunica_inps(dati)
    assert "7.200,00" in testo            # 30000 × 24%
    assert "artigiani" in testo.lower()
    assert "Circolare INPS" in testo      # avviso di verifica
    assert "24.0%" in testo or "24%" in testo


def test_revisore_inps_accetta_risultato_corretto():
    dati = _inps.calcola_inps(30000, "artigiani")
    rev = sciame.revisiona_inps(30000, dati)
    assert rev["ok"] is True
    assert rev["problemi"] == []


def test_revisore_inps_blocca_contributo_negativo():
    dati = _inps.calcola_inps(30000, "artigiani")
    manomesso = {**dati, "contributo_totale": -100}
    rev = sciame.revisiona_inps(30000, manomesso)
    assert rev["ok"] is False
    assert any("negativo" in p for p in rev["problemi"])


def test_revisore_inps_blocca_contributo_oltre_imponibile():
    dati = _inps.calcola_inps(30000, "artigiani")
    manomesso = {**dati, "contributo_totale": 999999}
    rev = sciame.revisiona_inps(30000, manomesso)
    assert rev["ok"] is False
