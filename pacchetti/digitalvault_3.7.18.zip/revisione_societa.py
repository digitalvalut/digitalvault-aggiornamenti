"""
FiscoSicuro — Revisione Società private: analisi di bilancio per indici.
(c) 2026 DigitalValut - Capo Team del Progetto: Dr. Falsone Giuseppe

A supporto del revisore legale (D.Lgs. 39/2010, principi ISA Italia) e
dell'analista: dai principali aggregati di Stato Patrimoniale e Conto Economico
calcola in modo DETERMINISTICO gli indici di liquidità, solidità e redditività,
con un semaforo verde/giallo/rosso rispetto a SOGLIE CONVENZIONALI di prassi
(non norme di legge). Include il controllo di QUADRATURA (Attivo = Passivo).

REGOLA D'ORO: le formule sono definizioni consolidate; le soglie sono di prassi e
marcate come tali. Il giudizio finale resta del professionista.
"""
from decimal import Decimal, ROUND_HALF_UP

import yaml

from config import BASE_DIR

_REF = BASE_DIR / "private_finance_reference" / "indici_bilancio.yaml"


def _load() -> dict:
    return yaml.safe_load(_REF.read_text(encoding="utf-8"))


def _q2(x) -> float:
    return float(Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def _rapporto(num, den):
    """Rapporto robusto: None se il denominatore è ~0 (evita divisioni per zero)."""
    try:
        num = Decimal(str(num)); den = Decimal(str(den))
    except Exception:
        return None
    if den == 0:
        return None
    return _q2(num / den)


def _semaforo(valore, buono, minimo, direzione):
    """verde / giallo / rosso in base alle soglie e alla direzione ('alto'|'basso')."""
    if valore is None:
        return "nd"
    v = float(valore)
    if direzione == "alto":
        if v >= buono:
            return "verde"
        return "giallo" if v >= minimo else "rosso"
    else:  # 'basso' = meglio se piccolo (es. indebitamento)
        if v <= buono:
            return "verde"
        return "giallo" if v <= minimo else "rosso"


def analizza_bilancio(dati: dict) -> dict:
    """`dati` (aggregati di bilancio): attivo_corrente, rimanenze, passivo_corrente,
    immobilizzazioni, patrimonio_netto, totale_debiti, totale_attivo, totale_passivo,
    ricavi, risultato_operativo, utile_netto. Restituisce indici + semaforo + margini
    + controllo di quadratura."""
    ref = _load()
    g = lambda k: float(dati.get(k) or 0)

    attivo_corrente = g("attivo_corrente")
    rimanenze = g("rimanenze")
    passivo_corrente = g("passivo_corrente")
    immobilizzazioni = g("immobilizzazioni")
    pn = g("patrimonio_netto")
    debiti = g("totale_debiti")
    tot_attivo = g("totale_attivo")
    tot_passivo = g("totale_passivo") or tot_attivo  # se non dato, si assume quadrato
    ricavi = g("ricavi")
    ro = g("risultato_operativo")
    utile = g("utile_netto")

    # Totale fonti = patrimonio netto + debiti (per l'autonomia finanziaria).
    tot_fonti = pn + debiti if (pn + debiti) > 0 else tot_passivo

    calcolo = {
        "current_ratio": _rapporto(attivo_corrente, passivo_corrente),
        "quick_ratio": _rapporto(attivo_corrente - rimanenze, passivo_corrente),
        "autonomia_finanziaria": _rapporto(pn, tot_fonti),
        "indice_indebitamento": _rapporto(debiti, pn),
        "copertura_immobilizzazioni": _rapporto(pn, immobilizzazioni),
        "roe": _rapporto(utile * 100, pn),
        "roi": _rapporto(ro * 100, tot_attivo),
        "ros": _rapporto(ro * 100, ricavi),
    }

    indici = []
    for chiave, cfg in ref["indici"].items():
        val = calcolo.get(chiave)
        sem = _semaforo(val, float(cfg["buono"]), float(cfg["minimo"]), cfg["direzione"])
        indici.append({
            "chiave": chiave, "nome": cfg["nome"], "formula": cfg["formula"],
            "valore": val, "semaforo": sem,
            "buono": float(cfg["buono"]), "minimo": float(cfg["minimo"]),
            "direzione": cfg["direzione"],
        })

    # Margini assoluti utili al revisore.
    ccn = _q2(attivo_corrente - passivo_corrente)                 # capitale circolante netto
    margine_struttura = _q2(pn - immobilizzazioni)                # patrimonio netto − immobilizzazioni

    # Controllo di quadratura (Attivo = Passivo): fondamentale in revisione.
    sbilancio = _q2(tot_attivo - tot_passivo)
    quadratura = {
        "totale_attivo": _q2(tot_attivo), "totale_passivo": _q2(tot_passivo),
        "sbilancio": sbilancio, "quadra": abs(sbilancio) < 0.01,
    }

    n_rossi = sum(1 for i in indici if i["semaforo"] == "rosso")
    n_verdi = sum(1 for i in indici if i["semaforo"] == "verde")
    if not quadratura["quadra"]:
        salute = "da_verificare"
    elif n_rossi == 0 and n_verdi >= len(indici) // 2:
        salute = "buona"
    elif n_rossi >= 3:
        salute = "critica"
    else:
        salute = "attenzione"

    return {
        "indici": indici,
        "margini": {"capitale_circolante_netto": ccn, "margine_di_struttura": margine_struttura},
        "quadratura": quadratura,
        "salute": salute,
        "n_rossi": n_rossi, "n_verdi": n_verdi,
        "legal_source": ref.get("legal_source"),
        "schema_version": ref.get("schema_version"),
        "warnings": [ref.get("avviso", "").strip()]
                    + ([] if quadratura["quadra"]
                       else [f"ATTENZIONE: Attivo e Passivo NON quadrano (sbilancio {sbilancio:.2f} €): verifica i dati inseriti."]),
    }
