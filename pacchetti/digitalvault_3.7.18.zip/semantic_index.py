"""
DigitalValut - Ricerca SEMANTICA per il Cervello Studio: capisce il SIGNIFICATO
delle domande e dei documenti, non solo le parole esatte (a differenza di
doc_brain.py, che cerca per parole chiave/sinonimi via FTS5).
(c) 2026 DigitalValut Team - Dr. Falsone Giuseppe

Come funziona (tutto in locale, il modello gira sull'SSD, nessun testo esce
verso l'esterno per fare la ricerca):
1. Un piccolo modello AI (multilingual-e5-small, quantizzato, ~130MB) trasforma
   ogni domanda e ogni documento in un "vettore" numerico che rappresenta il
   significato del testo.
2. Due testi con significato simile hanno vettori vicini (similarita' coseno
   alta), anche se usano parole completamente diverse.
3. Il modello NON produce mai numeri fiscali: serve solo a TROVARE i documenti
   pertinenti, esattamente come doc_brain.py. La regola d'oro non cambia.

Il modello va scaricato una volta sola (~130MB, richiesta esplicita
dell'utente in Impostazioni) e resta in data/ai_models/ (cartella esclusa
dagli aggiornamenti OTA: non appesantisce mai i pacchetti di aggiornamento).
Se il modello manca o e' corrotto, la ricerca semantica si disattiva da sola
SENZA bloccare nulla: il Cervello Studio continua a funzionare con le sole
parole chiave (doc_brain.py), come ha sempre fatto.
"""
import hashlib
import logging
import os
import threading
from pathlib import Path

from config import DATA_DIR

logger = logging.getLogger("digitalvalut.semantic")

# ============================================================================
# Modello: multilingual-e5-small quantizzato (Microsoft, licenza MIT), via
# Xenova/multilingual-e5-small su Hugging Face. Scelto perche' allenato
# APPOSTA per la ricerca domanda->documento (non solo similarita' generica) e
# multilingue (italiano compreso). ~118M parametri, 384 dimensioni.
# ============================================================================
_MODEL_DIR = DATA_DIR / "ai_models" / "e5_small"
_MODEL_FILE = _MODEL_DIR / "model_quantized.onnx"
_TOKENIZER_FILE = _MODEL_DIR / "tokenizer.json"
MODELLO_NOME = "multilingual-e5-small-q8-v1"  # cambia SOLO se si cambia modello (invalida gli embedding salvati)

_URL_MODEL = "https://huggingface.co/Xenova/multilingual-e5-small/resolve/main/onnx/model_quantized.onnx"
_URL_TOKENIZER = "https://huggingface.co/Xenova/multilingual-e5-small/resolve/main/tokenizer.json"
# Hash SHA256 verificati al momento del download dal titolare: proteggono da
# un file manomesso/corrotto in transito (lo stesso principio degli
# aggiornamenti firmati, applicato qui a un asset che non passa dalla firma
# Ed25519 del programma perche' non e' codice ma un modello di terze parti).
_SHA256_MODEL = "f80102d3f2a1229f387d3c81909990d8945513e347b0eab049f7de3c6f98c193"
_SHA256_TOKENIZER = "0b44a9d7b51c3c62626640cda0e2c2f70fdacdc25bbbd68038369d14ebdf4c39"
_DIMENSIONE_ATTESA_MB = 129  # per l'avviso in UI prima del download

_MAX_CARATTERI_DOC = 1500   # quanto testo del documento entra nell'embedding
_LOTTO = 16                 # documenti per volta nel backfill (limita il picco di CPU/RAM)

# ---------------------------------------------------------------------------
# Import pesanti: SOLO se disponibili. Se mancano (ambiente non ancora
# aggiornato dal launcher, o errore di installazione) la ricerca semantica si
# disattiva da sola: il resto del programma non deve MAI dipendere da questo.
# ---------------------------------------------------------------------------
try:
    import numpy as np
    import onnxruntime as ort
    from tokenizers import Tokenizer
    _LIBRERIE_OK = True
except Exception as _e:  # pragma: no cover - ambiente senza le librerie
    _LIBRERIE_OK = False
    logger.warning("Librerie ricerca semantica non disponibili: %s", _e)


class _Stato:
    """Singleton di processo: modello caricato in RAM una sola volta."""
    caricato = False
    integro = None          # None=non verificato, True/False dopo la 1a verifica
    sessione = None
    tokenizzatore = None
    lock = threading.Lock()


_download_stato = {"in_corso": False, "percentuale": 0, "fase": None, "errore": None}
_backfill_stato = {"in_corso": False, "fatti": 0, "totale": 0, "errore": None}


def _sha256_file(percorso: Path) -> str:
    h = hashlib.sha256()
    with open(percorso, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def modello_scaricato() -> bool:
    """Controllo ECONOMICO (solo esistenza file), per mostrare lo stato in UI
    senza ricalcolare hash di 130MB ad ogni richiesta."""
    return _MODEL_FILE.exists() and _TOKENIZER_FILE.exists()


def _carica_modello() -> bool:
    """Carica modello+tokenizzatore in RAM (una volta sola per processo).
    Verifica l'integrita' (hash) alla PRIMA chiamata soltanto."""
    if not _LIBRERIE_OK:
        return False
    with _Stato.lock:
        if _Stato.caricato:
            return _Stato.integro is True
        if not modello_scaricato():
            _Stato.integro = False
            return False
        try:
            if _sha256_file(_MODEL_FILE) != _SHA256_MODEL or _sha256_file(_TOKENIZER_FILE) != _SHA256_TOKENIZER:
                logger.error("Modello ricerca semantica: hash non corrispondente, file scartato")
                _Stato.integro = False
                _Stato.caricato = True
                return False
            _Stato.tokenizzatore = Tokenizer.from_file(str(_TOKENIZER_FILE))
            _Stato.tokenizzatore.enable_padding()
            _Stato.tokenizzatore.enable_truncation(max_length=256)
            _Stato.sessione = ort.InferenceSession(str(_MODEL_FILE), providers=["CPUExecutionProvider"])
            _Stato.integro = True
        except Exception:
            logger.exception("Errore caricamento modello ricerca semantica")
            _Stato.integro = False
        finally:
            _Stato.caricato = True
        return _Stato.integro is True


def disponibile() -> bool:
    """True se la ricerca semantica e' pronta all'uso in questo momento."""
    return _carica_modello()


def _embed(testi: list, prefisso: str):
    """Trasforma una lista di testi in vettori normalizzati (norma=1).
    prefisso: 'query' per le domande, 'passage' per i documenti (convenzione
    del modello E5: e' cosi' che e' stato allenato, ignorarla peggiora i
    risultati)."""
    if not testi:
        return None
    if not _carica_modello():
        return None
    testi_prefissati = [f"{prefisso}: {t}" for t in testi]
    encs = _Stato.tokenizzatore.encode_batch(testi_prefissati)
    ids = np.array([e.ids for e in encs], dtype=np.int64)
    mask = np.array([e.attention_mask for e in encs], dtype=np.int64)
    type_ids = np.zeros_like(ids)
    out = _Stato.sessione.run(None, {"input_ids": ids, "attention_mask": mask, "token_type_ids": type_ids})
    last_hidden = out[0]
    m = mask[:, :, None].astype(np.float32)
    pooled = (last_hidden * m).sum(axis=1) / np.clip(m.sum(axis=1), 1e-9, None)
    norma = np.linalg.norm(pooled, axis=1, keepdims=True)
    return pooled / np.clip(norma, 1e-9, None)


def embed_domanda(domanda: str):
    """Un vettore per una domanda dell'utente. None se il modello non c'e'."""
    v = _embed([domanda], "query")
    return v[0] if v is not None else None


def _testo_per_embedding(doc) -> str:
    intestazione = f"{doc.tipo or ''} | {doc.nome_originale or ''} | {doc.client_nome or ''} | anno {doc.anno_riferimento or ''}"
    corpo = (doc.testo_estratto or "")[:_MAX_CARATTERI_DOC]
    return f"{intestazione}. {corpo}".strip()


def imposta_embedding_documento(db, documento_id: int) -> bool:
    """Calcola e salva il vettore di UN documento. Robusto: non solleva mai
    (un fallimento qui non deve mai bloccare l'archiviazione di un
    documento)."""
    from database import Document, DocumentEmbedding
    try:
        doc = db.query(Document).filter(Document.id == documento_id).first()
        if not doc or not (doc.testo_estratto or "").strip():
            return False
        vettori = _embed([_testo_per_embedding(doc)], "passage")
        if vettori is None:
            return False
        vettore = vettori[0].astype(np.float32)
        riga = db.query(DocumentEmbedding).filter(DocumentEmbedding.document_id == documento_id).first()
        if riga is None:
            riga = DocumentEmbedding(document_id=documento_id)
            db.add(riga)
        riga.vettore = vettore.tobytes()
        riga.dimensioni = int(vettore.shape[0])
        riga.modello = MODELLO_NOME
        from datetime import datetime as _dt
        riga.creato_il = _dt.now()
        db.commit()
        return True
    except Exception:
        logger.exception("Errore embedding documento %s", documento_id)
        db.rollback()
        return False


def avvia_embedding_singolo(documento_id: int):
    """Calcola l'embedding di un documento in un thread separato (non blocca
    la risposta all'utente), stesso pattern di ocr_massa.avvia_singolo."""
    if not _LIBRERIE_OK:
        return

    def _job():
        from database import SessionLocal
        db = SessionLocal()
        try:
            imposta_embedding_documento(db, documento_id)
        finally:
            db.close()

    threading.Thread(target=_job, daemon=True).start()


def cerca_semantico(db, domanda: str, client_id=None, limite: int = 20):
    """Ritorna [{'document_id':.., 'cosine':..}] ordinati per pertinenza di
    SIGNIFICATO. Lista vuota se il modello non e' disponibile (fallback
    trasparente su doc_brain, che resta la fonte primaria)."""
    from database import Document, DocumentEmbedding
    if not disponibile():
        return []
    vq = embed_domanda(domanda)
    if vq is None:
        return []
    q = db.query(DocumentEmbedding.document_id, DocumentEmbedding.vettore, DocumentEmbedding.dimensioni)
    if client_id:
        q = q.join(Document, Document.id == DocumentEmbedding.document_id).filter(Document.client_id == client_id)
    righe = q.all()
    if not righe:
        return []
    risultati = []
    for doc_id, blob, dim in righe:
        v = np.frombuffer(blob, dtype=np.float32)
        if v.shape[0] != vq.shape[0]:
            continue  # embedding di un modello diverso/incompatibile: ignora
        risultati.append((doc_id, float(np.dot(v, vq))))
    risultati.sort(key=lambda x: x[1], reverse=True)
    return [{"document_id": d, "cosine": c} for d, c in risultati[:limite]]


def imposta_embeddings_mancanti(db, limite=None, callback_progresso=None) -> dict:
    """Backfill: calcola l'embedding di tutti i documenti che ne sono privi
    (o calcolati con un modello precedente). Usato dopo il primo download del
    modello, per indicizzare l'archivio gia' esistente."""
    from database import Document, DocumentEmbedding
    sub = db.query(DocumentEmbedding.document_id).filter(DocumentEmbedding.modello == MODELLO_NOME)
    q = (db.query(Document.id)
         .filter(Document.testo_estratto.isnot(None))
         .filter(~Document.id.in_(sub)))
    ids = [r[0] for r in q.all()]
    if limite:
        ids = ids[:limite]
    fatti, falliti = 0, 0
    for i, doc_id in enumerate(ids, 1):
        ok = imposta_embedding_documento(db, doc_id)
        fatti += 1 if ok else 0
        falliti += 0 if ok else 1
        if callback_progresso:
            callback_progresso(i, len(ids))
    return {"totali": len(ids), "aggiornati": fatti, "falliti": falliti}


# ============================================================================
# Download del modello (lato cliente): azione ESPLICITA dell'utente (pulsante
# in Impostazioni), mai automatica in background senza che l'utente l'abbia
# chiesta - lo stesso principio degli aggiornamenti OTA (l'utente preme
# "Scarica").
# ============================================================================

def stato_download() -> dict:
    stato = dict(_download_stato)
    stato["modello_presente"] = modello_scaricato()
    stato["backfill"] = dict(_backfill_stato)
    stato["dimensione_mb"] = _DIMENSIONE_ATTESA_MB
    return stato


def avvia_download_modello():
    """Avvia il download in un thread separato. Se gia' in corso o gia'
    presente, non fa nulla (idempotente)."""
    if _download_stato["in_corso"] or modello_scaricato():
        return
    threading.Thread(target=_download_worker, daemon=True).start()


def _scarica_file(url: str, destinazione: Path, hash_atteso: str, callback_percentuale=None) -> bool:
    import httpx
    tmp = destinazione.with_suffix(destinazione.suffix + ".part")
    h = hashlib.sha256()
    try:
        with httpx.stream("GET", url, follow_redirects=True, timeout=300) as r:
            r.raise_for_status()
            totale = int(r.headers.get("content-length", 0)) or 1
            scaricati = 0
            with open(tmp, "wb") as f:
                for chunk in r.iter_bytes(1 << 16):
                    f.write(chunk)
                    h.update(chunk)
                    scaricati += len(chunk)
                    if callback_percentuale:
                        callback_percentuale(min(99, int(scaricati * 100 / totale)))
        if h.hexdigest() != hash_atteso:
            tmp.unlink(missing_ok=True)
            return False
        os.replace(tmp, destinazione)
        return True
    except Exception:
        logger.exception("Errore download %s", url)
        tmp.unlink(missing_ok=True)
        return False


def _download_worker():
    _download_stato.update(in_corso=True, percentuale=0, fase="tokenizzatore", errore=None)
    try:
        _MODEL_DIR.mkdir(parents=True, exist_ok=True)
        ok = _scarica_file(_URL_TOKENIZER, _TOKENIZER_FILE, _SHA256_TOKENIZER,
                            lambda p: _download_stato.update(percentuale=int(p * 0.1)))
        if not ok:
            _download_stato.update(in_corso=False, errore="Tokenizzatore: file non integro o download fallito")
            return
        _download_stato.update(fase="modello")
        ok = _scarica_file(_URL_MODEL, _MODEL_FILE, _SHA256_MODEL,
                            lambda p: _download_stato.update(percentuale=10 + int(p * 0.9)))
        if not ok:
            _download_stato.update(in_corso=False, errore="Modello: file non integro o download fallito")
            return
        _download_stato.update(percentuale=100, fase="completato", in_corso=False)
        _avvia_backfill_dopo_download()
    except Exception:
        logger.exception("Errore imprevisto nel download del modello semantico")
        _download_stato.update(in_corso=False, errore="Errore imprevisto durante il download")


def _avvia_backfill_dopo_download():
    """Dopo il primo download, indicizza subito l'archivio gia' esistente
    (altrimenti la ricerca semantica funzionerebbe solo sui documenti NUOVI)."""
    from database import SessionLocal
    _backfill_stato.update(in_corso=True, fatti=0, totale=0, errore=None)

    def _progresso(fatti, totale):
        _backfill_stato.update(fatti=fatti, totale=totale)

    db = SessionLocal()
    try:
        imposta_embeddings_mancanti(db, callback_progresso=_progresso)
    except Exception:
        logger.exception("Errore backfill embedding archivio")
        _backfill_stato["errore"] = "Errore durante l'indicizzazione dell'archivio"
    finally:
        db.close()
        _backfill_stato["in_corso"] = False


def avvia_backfill_manuale():
    """Rilancia l'indicizzazione dell'archivio a comando (es. dopo un
    ripristino da backup, o se il backfill automatico era stato interrotto)."""
    if _backfill_stato["in_corso"] or not modello_scaricato():
        return
    threading.Thread(target=_avvia_backfill_dopo_download, daemon=True).start()
