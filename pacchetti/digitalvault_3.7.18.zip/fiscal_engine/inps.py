"""
FiscoSicuro — Contributi INPS dei lavoratori autonomi (deterministico, STIMA).
(c) 2026 DigitalValut - Capo Team del Progetto: Dr. Falsone Giuseppe

Due gestioni:
  - Artigiani e Commercianti (IVS): contributo FISSO sul minimale + quota a
    percentuale sul reddito eccedente, con +1% sulla quota oltre la soglia,
    fino al massimale. Riduzione 50% per pensionati over 65.
  - Gestione Separata (professionisti senza cassa): aliquota sul reddito
    effettivo fino al massimale (nessun minimale sull'importo dovuto).

REGOLA D'ORO: i numeri (minimale, massimale, soglie, aliquote) vengono SOLO da
fiscal_reference/inps.yaml, mai inventati. Ogni valore è VARIABILE ANNUALE →
ogni output porta un avviso esplicito "verificare alla Circolare INPS".
"""
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import yaml

from fiscal_engine.common import verifica_anno

REFERENCE = Path(__file__).parent.parent / "fiscal_reference" / "inps.yaml"


def _load() -> dict:
    if not REFERENCE.exists():
        raise FileNotFoundError(f"Dati di riferimento INPS non trovati: {REFERENCE}")
    with open(REFERENCE, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _q(n: Decimal) -> float:
    return float(n.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def _D(x) -> Decimal:
    return Decimal(str(x))


def contributi_artigiani_commercianti(reddito, tipo="artigiani", iscritto_ante_1996=True,
                                       pensionato_over_65=False, anno=None) -> dict:
    """`tipo`: 'artigiani' | 'commercianti'. Restituisce il contributo IVS annuo."""
    ref = _load()
    verifica_anno(ref, anno)
    ac = ref["artigiani_commercianti"]

    reddito = _D(max(0.0, float(reddito)))
    minimale = _D(ac["reddito_minimale"])
    soglia = _D(ac["soglia_secondo_scaglione"])
    massimale = _D(ac["massimale_ante_1996"] if iscritto_ante_1996 else ac["massimale_post_1996"])
    aliquota = _D(ac["aliquota_commercianti"] if str(tipo).lower().startswith("commerc")
                  else ac["aliquota_artigiani"])
    magg = _D(ac["maggiorazione_secondo_scaglione"])
    tipo_lbl = "commercianti" if str(tipo).lower().startswith("commerc") else "artigiani"

    imponibile = min(reddito, massimale)
    base = max(imponibile, minimale)          # si versa ALMENO sul minimale (contributi fissi)

    q1 = min(base, soglia)                     # prima fascia: aliquota piena
    q2 = max(Decimal("0"), base - soglia)      # oltre soglia: aliquota + maggiorazione
    contributo = q1 * aliquota / 100 + q2 * (aliquota + magg) / 100

    riduzione_pct = _D(ac["riduzione_pensionato_over_65"]) if pensionato_over_65 else Decimal("0")
    if riduzione_pct > 0:
        contributo = contributo * (1 - riduzione_pct / 100)

    contributo_minimale = (min(minimale, soglia) * aliquota / 100)  # quota fissa (informativa)

    return {
        "gestione": f"Artigiani/Commercianti (IVS) — {tipo_lbl}",
        "reddito": _q(reddito),
        "imponibile": _q(imponibile),
        "base_contributiva": _q(base),
        "aliquota": float(aliquota),
        "maggiorazione_oltre_soglia": float(magg),
        "contributo_minimale": _q(contributo_minimale),
        "contributo_totale": _q(contributo),
        "minimale": _q(minimale),
        "massimale": _q(massimale),
        "soglia_secondo_scaglione": _q(soglia),
        "pensionato_over_65": bool(pensionato_over_65),
        "anno_imposta": ref.get("anno_imposta"),
        "schema_version": ref.get("schema_version"),
        "legal_source": ref.get("legal_source"),
        "warnings": [ref.get("avviso", "").strip()],
    }


def contributi_gestione_separata(reddito, altra_copertura=False, anno=None) -> dict:
    """Gestione Separata: aliquota sul reddito effettivo fino al massimale."""
    ref = _load()
    verifica_anno(ref, anno)
    gs = ref["gestione_separata"]

    reddito = _D(max(0.0, float(reddito)))
    massimale = _D(gs["massimale"])
    aliquota = _D(gs["aliquota_con_altra_copertura"] if altra_copertura
                  else gs["aliquota_senza_altra_copertura"])

    imponibile = min(reddito, massimale)
    contributo = imponibile * aliquota / 100

    return {
        "gestione": "Gestione Separata" + (" (con altra copertura/pensionato)" if altra_copertura else ""),
        "reddito": _q(reddito),
        "imponibile": _q(imponibile),
        "aliquota": float(aliquota),
        "contributo_totale": _q(contributo),
        "massimale": _q(massimale),
        "altra_copertura": bool(altra_copertura),
        "anno_imposta": ref.get("anno_imposta"),
        "schema_version": ref.get("schema_version"),
        "legal_source": ref.get("legal_source"),
        "warnings": [ref.get("avviso", "").strip()],
    }


def calcola_inps(reddito, gestione="artigiani", iscritto_ante_1996=True,
                 pensionato_over_65=False, altra_copertura=False, anno=None) -> dict:
    """Dispatcher: 'artigiani' | 'commercianti' | 'gestione_separata' | 'separata'."""
    g = str(gestione or "artigiani").lower()
    if g.startswith("separat") or g == "gestione_separata":
        return contributi_gestione_separata(reddito, altra_copertura=altra_copertura, anno=anno)
    return contributi_artigiani_commercianti(
        reddito, tipo=g, iscritto_ante_1996=iscritto_ante_1996,
        pensionato_over_65=pensionato_over_65, anno=anno)


if __name__ == "__main__":
    print(calcola_inps(30000, "artigiani"))
    print(calcola_inps(30000, "commercianti"))
    print(calcola_inps(70000, "artigiani"))         # oltre soglia → +1%
    print(calcola_inps(10000, "artigiani"))         # sotto minimale → paga sul minimale
    print(calcola_inps(40000, "gestione_separata"))
