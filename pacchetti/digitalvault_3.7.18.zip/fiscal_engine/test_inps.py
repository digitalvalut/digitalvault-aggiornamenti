"""Test golden del motore INPS (deterministico). I valori attesi sono coerenti
con fiscal_reference/inps.yaml: se qualcuno rompe la logica di calcolo o cambia
una costante senza aggiornare i test, questi falliscono."""
import pytest

from fiscal_engine import inps
from fiscal_engine.common import DataNotFreshError


# ── Artigiani / Commercianti ─────────────────────────────────────────────

def test_artigiani_sopra_minimale_sotto_soglia():
    # 30.000 tutto in prima fascia: 30000 × 24%
    r = inps.calcola_inps(30000, "artigiani")
    assert r["contributo_totale"] == 7200.0
    assert r["aliquota"] == 24.0


def test_commercianti_aliquota_maggiorata_048():
    # commercianti pagano 24,48% (24% + 0,48% indennizzo)
    r = inps.calcola_inps(30000, "commercianti")
    assert r["contributo_totale"] == 7344.0
    assert r["aliquota"] == 24.48


def test_artigiani_oltre_soglia_applica_piu_1_percento():
    # 70.000: 55.448 × 24% + 14.552 × 25%  = 13307,52 + 3638,00 = 16945,52
    r = inps.calcola_inps(70000, "artigiani")
    assert r["contributo_totale"] == 16945.52
    assert r["maggiorazione_oltre_soglia"] == 1.0


def test_sotto_minimale_paga_comunque_sul_minimale():
    # reddito 10.000 < minimale 18.555 → si versa sul minimale: 18555 × 24%
    r = inps.calcola_inps(10000, "artigiani")
    assert r["base_contributiva"] == 18555.0
    assert r["contributo_totale"] == 4453.20


def test_massimale_cap_ante_1996():
    # reddito enorme oltre il massimale ante-96 (92.413): l'imponibile si ferma lì
    r = inps.calcola_inps(200000, "artigiani", iscritto_ante_1996=True)
    assert r["imponibile"] == 92413.0
    # 55448×24% + (92413-55448)×25% = 13307,52 + 9241,25 = 22548,77
    assert r["contributo_totale"] == 22548.77


def test_massimale_post_1996_piu_alto():
    r_post = inps.calcola_inps(200000, "artigiani", iscritto_ante_1996=False)
    assert r_post["imponibile"] == 120607.0
    assert r_post["massimale"] == 120607.0


def test_pensionato_over_65_riduzione_50():
    pieno = inps.calcola_inps(30000, "artigiani")["contributo_totale"]
    ridotto = inps.calcola_inps(30000, "artigiani", pensionato_over_65=True)["contributo_totale"]
    assert ridotto == round(pieno * 0.5, 2)


# ── Gestione Separata ────────────────────────────────────────────────────

def test_gestione_separata_senza_altra_copertura():
    r = inps.calcola_inps(40000, "gestione_separata")
    assert r["aliquota"] == 26.07
    assert r["contributo_totale"] == 10428.0


def test_gestione_separata_con_altra_copertura_aliquota_ridotta():
    r = inps.calcola_inps(40000, "separata", altra_copertura=True)
    assert r["aliquota"] == 24.0
    assert r["contributo_totale"] == 9600.0


def test_gestione_separata_massimale():
    r = inps.calcola_inps(200000, "gestione_separata")
    assert r["imponibile"] == 120607.0  # cap al massimale
    # 120607 × 26,07% = 31442,24
    assert r["contributo_totale"] == 31442.24


# ── Robustezza ───────────────────────────────────────────────────────────

def test_ogni_output_porta_avviso_verifica():
    for g in ("artigiani", "commercianti", "gestione_separata"):
        r = inps.calcola_inps(30000, g)
        assert r["warnings"] and "STIMA" in r["warnings"][0]
        assert "Circolare INPS" in r["warnings"][0]


def test_freschezza_anno_blocca_anno_diverso():
    # i dati sono per il 2025: chiedendo il 2030 deve bloccare (non usare dati vecchi)
    with pytest.raises(DataNotFreshError):
        inps.calcola_inps(30000, "artigiani", anno=2030)


def test_reddito_negativo_azzerato():
    r = inps.calcola_inps(-5000, "artigiani")
    # reddito negativo → 0 → si versa sul minimale
    assert r["base_contributiva"] == 18555.0
