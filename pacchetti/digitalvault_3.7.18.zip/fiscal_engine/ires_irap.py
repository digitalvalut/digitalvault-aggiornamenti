"""
FiscoSicuro — IRES e IRAP (imposte delle società), deterministico.
(c) 2026 DigitalValut - Capo Team del Progetto: Dr. Falsone Giuseppe

  IRES = base imponibile fiscale × 24%   (art. 77 TUIR)
  IRAP = valore della produzione netta × aliquota   (D.Lgs. 446/1997)

L'IRES si applica alla base imponibile FISCALE già determinata (con le variazioni
in aumento/diminuzione del reddito civilistico): qui non si stimano le variazioni,
si applica l'aliquota alla base fornita. L'aliquota IRAP è variabile per Regione:
default 3,9% con avviso di verifica. Aliquote da fiscal_reference/ires_irap.yaml.
"""
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import yaml

from fiscal_engine.common import verifica_anno

REFERENCE = Path(__file__).parent.parent / "fiscal_reference" / "ires_irap.yaml"


def _load() -> dict:
    if not REFERENCE.exists():
        raise FileNotFoundError(f"Dati di riferimento IRES/IRAP non trovati: {REFERENCE}")
    with open(REFERENCE, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _q(n: Decimal) -> float:
    return float(n.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def calcola_ires(base_imponibile, anno: int = None) -> dict:
    """IRES = base imponibile fiscale × 24%."""
    ref = _load()
    verifica_anno(ref, anno)
    base = Decimal(str(max(0.0, float(base_imponibile))))
    aliquota = Decimal(str(ref["ires"]["aliquota"]))
    imposta = (base * aliquota / 100).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return {
        "imposta": "IRES",
        "base_imponibile": _q(base),
        "aliquota": float(aliquota),
        "ires": _q(imposta),
        "anno_imposta": ref.get("anno_imposta"),
        "schema_version": ref.get("schema_version"),
        "legal_source": ref.get("legal_source"),
        "warnings": [ref.get("avviso", "").strip()],
    }


def calcola_irap(valore_produzione_netta, aliquota=None, anno: int = None) -> dict:
    """IRAP = valore della produzione netta × aliquota (default 3,9%, variabile per Regione)."""
    ref = _load()
    verifica_anno(ref, anno)
    base = Decimal(str(max(0.0, float(valore_produzione_netta))))
    al = Decimal(str(aliquota)) if aliquota is not None else Decimal(str(ref["irap"]["aliquota_base"]))
    imposta = (base * al / 100).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    warn = [ref.get("avviso", "").strip()]
    if aliquota is None:
        warn.insert(0, "Usata l'aliquota IRAP BASE 3,9%: se la tua Regione la varia, indicala e ricalcolo.")
    return {
        "imposta": "IRAP",
        "base_imponibile": _q(base),
        "aliquota": float(al),
        "irap": _q(imposta),
        "anno_imposta": ref.get("anno_imposta"),
        "schema_version": ref.get("schema_version"),
        "legal_source": ref.get("legal_source"),
        "warnings": warn,
    }


if __name__ == "__main__":
    print(calcola_ires(100000, anno=2026))
    print(calcola_irap(200000, anno=2026))
    print(calcola_irap(200000, aliquota=4.82, anno=2026))
