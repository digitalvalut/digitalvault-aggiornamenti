"""Test golden IRES/IRAP (deterministico)."""
import pytest
from fiscal_engine import ires_irap as ii
from fiscal_engine.common import DataNotFreshError


def test_ires_24_percento():
    r = ii.calcola_ires(100000, anno=2026)
    assert r["aliquota"] == 24.0
    assert r["ires"] == 24000.0


def test_ires_base_zero():
    assert ii.calcola_ires(0, anno=2026)["ires"] == 0.0


def test_ires_base_negativa_azzerata():
    assert ii.calcola_ires(-50000, anno=2026)["ires"] == 0.0


def test_irap_base_3_9():
    r = ii.calcola_irap(200000, anno=2026)
    assert r["aliquota"] == 3.9
    assert r["irap"] == 7800.0
    # avvisa che ha usato l'aliquota base
    assert any("BASE" in w for w in r["warnings"])


def test_irap_aliquota_regionale_esplicita():
    r = ii.calcola_irap(200000, aliquota=4.82, anno=2026)
    assert r["aliquota"] == 4.82
    assert r["irap"] == 9640.0


def test_freschezza_anno():
    with pytest.raises(DataNotFreshError):
        ii.calcola_ires(100000, anno=2030)
