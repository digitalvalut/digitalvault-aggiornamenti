"""Test del motore Revisione Enti Pubblici (equilibri di bilancio, deterministico)."""
import revisione_enti_pubblici as rep


# ── Equilibrio di parte corrente ─────────────────────────────────────────

def test_equilibrio_corrente_positivo():
    r = rep.equilibrio_parte_corrente(entrate_correnti=1_000_000, spese_correnti=850_000,
                                       rimborso_prestiti=100_000)
    assert r["saldo"] == 50_000.0
    assert r["in_equilibrio"] is True


def test_equilibrio_corrente_negativo():
    r = rep.equilibrio_parte_corrente(entrate_correnti=1_000_000, spese_correnti=950_000,
                                       rimborso_prestiti=100_000)
    assert r["saldo"] == -50_000.0
    assert r["in_equilibrio"] is False


def test_equilibrio_corrente_con_avanzo_lo_riporta_in_equilibrio():
    base = rep.equilibrio_parte_corrente(entrate_correnti=1_000_000, spese_correnti=950_000,
                                          rimborso_prestiti=100_000)
    assert base["in_equilibrio"] is False
    con_avanzo = rep.equilibrio_parte_corrente(entrate_correnti=1_000_000, spese_correnti=950_000,
                                                rimborso_prestiti=100_000, utilizzo_avanzo_corrente=60_000)
    assert con_avanzo["saldo"] == 10_000.0
    assert con_avanzo["in_equilibrio"] is True


# ── Equilibrio di parte capitale ─────────────────────────────────────────

def test_equilibrio_capitale_pareggiato():
    r = rep.equilibrio_parte_capitale(entrate_capitale=500_000, spese_capitale=500_000)
    assert r["saldo"] == 0.0
    assert r["in_equilibrio"] is True


def test_equilibrio_capitale_negativo():
    r = rep.equilibrio_parte_capitale(entrate_capitale=300_000, spese_capitale=500_000)
    assert r["saldo"] == -200_000.0
    assert r["in_equilibrio"] is False


# ── Equilibrio di cassa ───────────────────────────────────────────────────

def test_equilibrio_cassa_regolare():
    r = rep.equilibrio_cassa(fondo_cassa_iniziale=100_000, incassi_totali=1_500_000,
                              pagamenti_totali=1_400_000)
    assert r["fondo_cassa_finale"] == 200_000.0
    assert r["in_equilibrio"] is True


def test_equilibrio_cassa_negativo():
    r = rep.equilibrio_cassa(fondo_cassa_iniziale=50_000, incassi_totali=1_000_000,
                              pagamenti_totali=1_200_000)
    assert r["fondo_cassa_finale"] == -150_000.0
    assert r["in_equilibrio"] is False


# ── Pareggio complessivo ──────────────────────────────────────────────────

def test_pareggio_complessivo_ok():
    r = rep.pareggio_complessivo(totale_entrate=2_000_000, totale_spese=2_000_000)
    assert r["in_pareggio"] is True


def test_pareggio_complessivo_squilibrato():
    r = rep.pareggio_complessivo(totale_entrate=2_000_000, totale_spese=2_050_000)
    assert r["in_pareggio"] is False
    assert r["differenza"] == -50_000.0


# ── Analisi completa (orchestratore) ─────────────────────────────────────

def test_analizza_bilancio_tutto_regolare():
    dati = {
        "entrate_correnti": 1_000_000, "spese_correnti": 850_000, "rimborso_prestiti": 100_000,
        "entrate_capitale": 400_000, "spese_capitale": 400_000,
        "totale_entrate": 1_400_000, "totale_spese": 1_400_000,
    }
    r = rep.analizza_bilancio(dati)
    assert r["esito"] == "regolare"
    assert r["rilievi"] == []
    assert r["legal_source"] and "118/2011" in r["legal_source"]


def test_analizza_bilancio_irregolare_su_corrente():
    dati = {
        "entrate_correnti": 1_000_000, "spese_correnti": 980_000, "rimborso_prestiti": 100_000,
        "entrate_capitale": 400_000, "spese_capitale": 400_000,
        "totale_entrate": 1_400_000, "totale_spese": 1_400_000,
    }
    r = rep.analizza_bilancio(dati)
    assert r["esito"] == "irregolare"
    categorie = [x["categoria"] for x in r["rilievi"]]
    assert "equilibrio_corrente" in categorie


def test_analizza_bilancio_critico_su_cassa():
    dati = {
        "entrate_correnti": 1_000_000, "spese_correnti": 850_000, "rimborso_prestiti": 100_000,
        "entrate_capitale": 400_000, "spese_capitale": 400_000,
        "totale_entrate": 1_400_000, "totale_spese": 1_400_000,
        "fondo_cassa_iniziale": 10_000, "incassi_totali": 500_000, "pagamenti_totali": 600_000,
    }
    r = rep.analizza_bilancio(dati)
    assert r["esito"] == "critico"
    categorie = [x["categoria"] for x in r["rilievi"]]
    assert "equilibrio_cassa" in categorie


def test_analizza_bilancio_cassa_assente_se_non_fornita():
    dati = {
        "entrate_correnti": 1_000_000, "spese_correnti": 850_000, "rimborso_prestiti": 100_000,
        "entrate_capitale": 400_000, "spese_capitale": 400_000,
        "totale_entrate": 1_400_000, "totale_spese": 1_400_000,
    }
    r = rep.analizza_bilancio(dati)
    assert r["equilibrio_cassa"] is None


# ── Generazione parere ───────────────────────────────────────────────────

def test_genera_parere_favorevole():
    dati = {
        "entrate_correnti": 1_000_000, "spese_correnti": 850_000, "rimborso_prestiti": 100_000,
        "entrate_capitale": 400_000, "spese_capitale": 400_000,
        "totale_entrate": 1_400_000, "totale_spese": 1_400_000,
    }
    p = rep.genera_parere("Comune di Prova", dati)
    assert p["ok"] and p["esito"] == "regolare"
    assert "Comune di Prova" in p["testo"]
    assert "PARERE FAVOREVOLE" in p["testo"]
    assert "239" in p["testo"]  # riferimento normativo TUEL


def test_genera_parere_con_rilievi():
    dati = {
        "entrate_correnti": 1_000_000, "spese_correnti": 980_000, "rimborso_prestiti": 100_000,
        "entrate_capitale": 400_000, "spese_capitale": 400_000,
        "totale_entrate": 1_400_000, "totale_spese": 1_400_000,
    }
    p = rep.genera_parere("Comune di Prova", dati)
    assert p["esito"] == "irregolare"
    assert "PARERE CON RILIEVI" in p["testo"]
    assert "RILIEVI" in p["testo"]


def test_genera_parere_riusa_risultato_gia_calcolato():
    dati = {
        "entrate_correnti": 1_000_000, "spese_correnti": 850_000, "rimborso_prestiti": 100_000,
        "entrate_capitale": 400_000, "spese_capitale": 400_000,
        "totale_entrate": 1_400_000, "totale_spese": 1_400_000,
    }
    risultato = rep.analizza_bilancio(dati)
    p = rep.genera_parere("Comune di Prova", dati, risultato=risultato)
    assert p["esito"] == risultato["esito"]


# ── Indicatori di deficitarietà strutturale (D.M. 28/12/2018) ────────────

def _valori_sani():
    # tutti i parametri sotto la soglia di deficitarietà (ente sano)
    return {"p1_1": 40, "p2_8": 30, "p3_2": 0, "p10_3": 10,
            "p12_4": 0.5, "p13_1": 0.0, "p13_2": 0.0, "p_riscossione": 60}


def test_deficitarieta_ente_sano():
    r = rep.analizza_deficitarieta(_valori_sani())
    assert r["parametri_deficitari"] == 0
    assert r["strutturalmente_deficitario"] is False
    assert r["completo"] is True


def test_deficitarieta_direzione_sopra_e_sotto():
    v = _valori_sani()
    v["p1_1"] = 55   # soglia 48, direzione sopra → deficitario
    v["p2_8"] = 15   # soglia 22, direzione sotto → deficitario
    v["p_riscossione"] = 40  # soglia 47, direzione sotto → deficitario
    r = rep.analizza_deficitarieta(v)
    per_chiave = {p["chiave"]: p["deficitario"] for p in r["parametri"]}
    assert per_chiave["p1_1"] is True
    assert per_chiave["p2_8"] is True
    assert per_chiave["p_riscossione"] is True
    assert r["parametri_deficitari"] == 3
    assert r["strutturalmente_deficitario"] is False   # 3 < 4


def test_deficitarieta_soglia_4_su_8_scatta():
    v = _valori_sani()
    v["p1_1"] = 55; v["p2_8"] = 15; v["p10_3"] = 20; v["p12_4"] = 2.0  # 4 deficitari
    r = rep.analizza_deficitarieta(v)
    assert r["parametri_deficitari"] == 4
    assert r["strutturalmente_deficitario"] is True
    assert r["esito"] == "strutturalmente deficitario"


def test_deficitarieta_valore_uguale_soglia_non_deficitario():
    # esattamente 48 con direzione "sopra" (>) → NON deficitario
    v = _valori_sani(); v["p1_1"] = 48
    per = {p["chiave"]: p["deficitario"] for p in rep.analizza_deficitarieta(v)["parametri"]}
    assert per["p1_1"] is False


def test_deficitarieta_parziale_se_non_tutti_compilati():
    r = rep.analizza_deficitarieta({"p1_1": 55, "p2_8": 15})
    assert r["completo"] is False
    assert r["parametri_compilati"] == 2
    assert any("parziale" in w.lower() for w in r["warnings"])


def test_deficitarieta_avviso_dm_presente():
    r = rep.analizza_deficitarieta(_valori_sani())
    assert any("D.M." in w for w in r["warnings"])
