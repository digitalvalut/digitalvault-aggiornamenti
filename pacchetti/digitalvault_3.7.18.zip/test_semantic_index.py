"""Test della ricerca semantica (embeddings locali) e della fusione ibrida
con la ricerca per parole chiave. DB SQLite in-memory, modello REALE già
scaricato in data/ai_models/ (nessuna chiamata di rete in questi test)."""
import pathlib
import numpy as np
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import database as dbmod
import semantic_index as si
import doc_brain


def _sess():
    eng = create_engine("sqlite:///:memory:")
    dbmod.Base.metadata.create_all(eng)
    return sessionmaker(bind=eng)()


def _doc(db, **kw):
    d = dbmod.Document(
        nome_file=kw.pop("nome_file", "x.pdf"),
        nome_originale=kw.pop("nome_originale", "x.pdf"),
        tipo=kw.pop("tipo", None),
        client_nome=kw.pop("client_nome", None),
        client_id=kw.pop("client_id", None),
        anno_riferimento=kw.pop("anno_riferimento", 2025),
        testo_estratto=kw.pop("testo_estratto", None),
    )
    db.add(d)
    db.commit()
    db.refresh(d)
    return d


# ── Resilienza: modello assente/corrotto non deve MAI far esplodere nulla ────

def test_modello_assente_disponibile_false(tmp_path, monkeypatch):
    monkeypatch.setattr(si, "_MODEL_DIR", tmp_path / "nessun_modello")
    monkeypatch.setattr(si, "_MODEL_FILE", si._MODEL_DIR / "model_quantized.onnx")
    monkeypatch.setattr(si, "_TOKENIZER_FILE", si._MODEL_DIR / "tokenizer.json")
    monkeypatch.setattr(si._Stato, "caricato", False)
    monkeypatch.setattr(si._Stato, "integro", None)
    assert si.modello_scaricato() is False
    assert si.disponibile() is False


def test_modello_corrotto_hash_non_combacia_disponibile_false(tmp_path, monkeypatch):
    finto = tmp_path / "finto"
    finto.mkdir()
    (finto / "model_quantized.onnx").write_bytes(b"non e' il modello vero")
    (finto / "tokenizer.json").write_text("{}")
    monkeypatch.setattr(si, "_MODEL_DIR", finto)
    monkeypatch.setattr(si, "_MODEL_FILE", finto / "model_quantized.onnx")
    monkeypatch.setattr(si, "_TOKENIZER_FILE", finto / "tokenizer.json")
    monkeypatch.setattr(si._Stato, "caricato", False)
    monkeypatch.setattr(si._Stato, "integro", None)
    assert si.modello_scaricato() is True       # i file esistono...
    assert si.disponibile() is False            # ...ma l'hash non corrisponde: rifiutato


def test_cerca_semantico_senza_modello_ritorna_vuoto(tmp_path, monkeypatch):
    monkeypatch.setattr(si, "_MODEL_DIR", tmp_path / "assente")
    monkeypatch.setattr(si, "_MODEL_FILE", si._MODEL_DIR / "model_quantized.onnx")
    monkeypatch.setattr(si, "_TOKENIZER_FILE", si._MODEL_DIR / "tokenizer.json")
    monkeypatch.setattr(si._Stato, "caricato", False)
    monkeypatch.setattr(si._Stato, "integro", None)
    db = _sess()
    _doc(db, testo_estratto="qualsiasi cosa")
    assert si.cerca_semantico(db, "una domanda") == []


# ── Con il modello REALE: qualità della ricerca per SIGNIFICATO ─────────────

def _modello_reale_presente():
    return (pathlib.Path(r"D:\MOTORE\data\ai_models\e5_small") / "model_quantized.onnx").exists()


import pytest
_skip_se_assente = pytest.mark.skipif(not _modello_reale_presente(), reason="modello semantico non scaricato in questo ambiente")


@_skip_se_assente
def test_embedding_documento_e_ricerca_per_significato():
    db = _sess()
    d1 = _doc(db, nome_originale="cedolino.pdf", tipo="CU", client_nome="Bianchi",
              testo_estratto="Cedolino paga di gennaio: retribuzione lorda dipendente Mario Bianchi "
                              "euro 1.850,00, contributi INPS a carico azienda euro 410,00.")
    d2 = _doc(db, nome_originale="ricetta.pdf", tipo="altro", client_nome="Neri",
              testo_estratto="Ricetta medica per terapia antibiotica, prescrizione del dottor Neri.")

    assert si.imposta_embedding_documento(db, d1.id) is True
    assert si.imposta_embedding_documento(db, d2.id) is True

    riga = db.query(dbmod.DocumentEmbedding).filter(dbmod.DocumentEmbedding.document_id == d1.id).first()
    assert riga is not None and riga.dimensioni == 384 and riga.modello == si.MODELLO_NOME

    # La domanda usa "stipendi", il documento dice "retribuzione": NESSUNA
    # parola in comune, ma il significato è lo stesso -> deve vincere comunque.
    risultati = si.cerca_semantico(db, "quanto ha speso in stipendi ai dipendenti?")
    assert risultati[0]["document_id"] == d1.id
    assert risultati[0]["cosine"] > risultati[1]["cosine"]


@_skip_se_assente
def test_embedding_documento_senza_testo_non_salva_nulla():
    db = _sess()
    d = _doc(db, testo_estratto=None)
    assert si.imposta_embedding_documento(db, d.id) is False
    assert db.query(dbmod.DocumentEmbedding).count() == 0


@_skip_se_assente
def test_backfill_calcola_solo_i_mancanti():
    db = _sess()
    d1 = _doc(db, testo_estratto="Fattura fornitore materiale edile euro 3.200,00 IVA 22%.")
    d2 = _doc(db, testo_estratto="Estratto conto bancario bonifico ricevuto euro 5.000,00.")
    d3 = _doc(db, testo_estratto=None)  # niente testo: mai imbustato

    stats = si.imposta_embeddings_mancanti(db)
    assert stats == {"totali": 2, "aggiornati": 2, "falliti": 0}
    assert db.query(dbmod.DocumentEmbedding).count() == 2

    # Rilanciato: non c'è più nulla da fare (idempotente)
    stats2 = si.imposta_embeddings_mancanti(db)
    assert stats2["totali"] == 0


@_skip_se_assente
def test_cerca_semantico_filtra_per_cliente():
    db = _sess()
    d1 = _doc(db, client_id=1, testo_estratto="Fattura del cliente uno, lavori di ristrutturazione.")
    d2 = _doc(db, client_id=2, testo_estratto="Fattura del cliente due, lavori di ristrutturazione.")
    si.imposta_embedding_documento(db, d1.id)
    si.imposta_embedding_documento(db, d2.id)
    solo_1 = si.cerca_semantico(db, "lavori di ristrutturazione", client_id=1)
    assert {r["document_id"] for r in solo_1} == {d1.id}


# ── Ricerca IBRIDA in doc_brain: fusione RRF parole+significato ─────────────

@_skip_se_assente
def test_doc_brain_trova_per_significato_anche_senza_parole_in_comune():
    db = _sess()
    # Nessuna parola della domanda compare nel testo: la ricerca per parole
    # chiave da sola non troverebbe NULLA.
    d = _doc(db, nome_originale="busta_paga.pdf", tipo="CU",
              testo_estratto="Cedolino paga: retribuzione lorda dipendente, contributi previdenziali versati.")
    si.imposta_embedding_documento(db, d.id)
    risultati = doc_brain.cerca_documenti(db, "quanto ha speso in stipendi ai dipendenti?")
    assert len(risultati) == 1
    assert risultati[0]["doc"].id == d.id


def test_doc_brain_senza_semantica_si_comporta_come_prima(monkeypatch):
    # Con la semantica disattivata, l'ordine deve dipendere SOLO dalle parole
    # chiave (nessuna regressione sul comportamento storico).
    import semantic_index as si_mod
    monkeypatch.setattr(si_mod, "cerca_semantico", lambda *a, **kw: [])
    db = _sess()
    forte = _doc(db, testo_estratto="scadenza IVA scadenza IVA versamento importo")
    debole = _doc(db, testo_estratto="scadenza qualcosa")
    risultati = doc_brain.cerca_documenti(db, "scadenza IVA versamento")
    assert risultati[0]["doc"].id == forte.id
