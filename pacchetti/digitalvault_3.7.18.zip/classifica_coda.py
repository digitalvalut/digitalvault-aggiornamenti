"""
DigitalValut - Classificazione documenti IN BACKGROUND (coda).
(c) 2026 DigitalValut - Capo Team del Progetto: Dr. Falsone Giuseppe

Perché: classificare un documento richiede una chiamata all'AI (qualche
secondo). Farlo durante l'upload "appende" l'interfaccia, e con tanti file in
fila diventa pesante. Qui l'upload risponde SUBITO e la classificazione gira
in sottofondo, un documento alla volta, con stato consultabile — esattamente
come l'OCR di massa. Risultato: l'app non si blocca MAI, regge anche 100 file.

Flusso:
  - l'upload salva il documento con stato_classifica = "in_coda" e chiama
    assicura_avvio();
  - un thread daemon prende i documenti "in_coda" e li classifica con
    doc_classifier, aggiornando i campi e lo stato (auto/da_assegnare/manuale);
  - va avanti finché la coda è vuota, poi si ferma da solo.
"""
import asyncio
import json
import threading
from datetime import datetime

import doc_classifier

# Stato globale consultabile dall'interfaccia (come ocr_massa.stato)
stato = {
    "in_corso": False,
    "in_coda": 0,
    "fatti": 0,
    "ok": 0,
    "errori": 0,
    "ultimo_documento": "",
    "avviato": None,
    "finito": None,
}

_lock = threading.Lock()


def _clienti(db) -> list:
    from database import Client
    return [{"id": c.id, "nome": c.nome, "cognome": c.cognome,
             "codice_fiscale": c.codice_fiscale, "partita_iva": c.partita_iva}
            for c in db.query(Client).all()]


def _classifica_uno(db, d):
    """Classifica un singolo documento e aggiorna i suoi campi. Rispetta un
    cliente già assegnato manualmente (dall'upload)."""
    cl = asyncio.run(doc_classifier.classifica(d.testo_estratto or "", d.nome_originale, _clienti(db)))
    d.tipo = cl.get("tipo") or d.tipo
    if cl.get("anno") and not d.anno_riferimento:
        d.anno_riferimento = cl["anno"]
    d.importo = cl.get("importo")
    d.controparte = cl.get("controparte")
    d.confidenza = cl.get("confidenza")
    d.dati_estratti = json.dumps({k: cl.get(k) for k in
        ("riassunto", "controparte", "importo", "codice_fiscale", "partita_iva", "anno",
         "fonte_importo", "importo_da_verificare", "warnings")},
        ensure_ascii=False)
    if d.client_id:
        # Cliente già scelto a mano in fase di upload: lo si mantiene.
        d.stato_classifica = "manuale"
    elif cl.get("cliente_id"):
        from database import Client
        c = db.query(Client).filter(Client.id == cl["cliente_id"]).first()
        if c:
            d.client_id = c.id
            d.client_nome = f"{c.cognome} {c.nome}".strip()
            d.stato_classifica = "auto"
        else:
            d.stato_classifica = "da_assegnare"
    else:
        d.stato_classifica = "da_assegnare"


def _lavora():
    """Thread di lavoro: svuota la coda dei documenti 'in_coda'."""
    from database import SessionLocal, Document
    db = SessionLocal()
    visti = set()   # anti-loop: id già tentati in questo giro (non riprenderli all'infinito)
    try:
        while True:
            q = db.query(Document).filter(Document.stato_classifica == "in_coda")
            if visti:
                q = q.filter(Document.id.notin_(visti))
            d = q.order_by(Document.id).first()
            if not d:
                break
            visti.add(d.id)
            stato["ultimo_documento"] = d.nome_originale
            try:
                _classifica_uno(db, d)
                db.commit()
                stato["ok"] += 1
            except Exception as e:
                db.rollback()
                # Non lasciare il documento bloccato "in_coda": lo si segna da assegnare
                try:
                    d.stato_classifica = "da_assegnare" if not d.client_id else "manuale"
                    db.commit()
                except Exception:
                    db.rollback()
                stato["errori"] += 1
                print(f"[classifica_coda] errore su '{d.nome_originale}': {e}")
            # Impronta semantica per il Cervello Studio: il testo c'e' comunque
            # (anche se la classificazione fallisce), quindi si tenta sempre.
            try:
                import semantic_index
                semantic_index.avvia_embedding_singolo(d.id)
            except Exception:
                pass
            stato["fatti"] += 1
            stato["in_coda"] = db.query(Document).filter(
                Document.stato_classifica == "in_coda").count()
    finally:
        db.close()
        with _lock:
            stato["in_corso"] = False
            stato["finito"] = datetime.now().isoformat()


def assicura_avvio():
    """Avvia il worker se non è già in esecuzione. Sicuro da chiamare a ogni upload."""
    with _lock:
        if stato["in_corso"]:
            return
        stato.update({"in_corso": True, "avviato": datetime.now().isoformat(),
                      "finito": None, "ultimo_documento": "",
                      "fatti": 0, "ok": 0, "errori": 0})
    threading.Thread(target=_lavora, daemon=True).start()


def stato_coda(db) -> dict:
    """Stato corrente + quanti documenti restano in coda (per l'interfaccia)."""
    from database import Document
    in_coda = db.query(Document).filter(Document.stato_classifica == "in_coda").count()
    s = dict(stato)
    s["in_coda"] = in_coda
    return s
