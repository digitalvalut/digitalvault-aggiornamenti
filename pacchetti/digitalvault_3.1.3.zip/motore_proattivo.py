"""
DigitalVault - Motore proattivo (l'assistente che "ti avvisa da solo").
(c) 2026 DigitalVault - Capo Team del Progetto: Dr. Falsone Giuseppe

Scansiona i dati reali dello studio e produce AVVISI azionabili, senza che il
commercialista debba chiedere nulla. E' deterministico (niente AI): veloce e
affidabile, gira a ogni apertura della dashboard.

Tipi di avviso:
  - scadenze SCADUTE non gestite
  - scadenze imminenti (7 e 30 giorni)
  - documenti caricati ma non ancora assegnati a un cliente
  - clienti in regime FORFETTARIO vicini/oltre la soglia di ricavi (stima)
  - clienti con dati anagrafici mancanti (email / codice fiscale)
"""
from datetime import datetime, timedelta

from sqlalchemy import func

from database import Client, Document, Scadenza, ClientEvent

# Soglia ricavi regime forfettario (L. 197/2022). E' una STIMA di allerta.
SOGLIA_FORFETTARIO = 85000.0
SOGLIA_AVVICINAMENTO = 70000.0


def _avviso(gravita, categoria, icona, testo, azione=None, vai=None):
    return {"gravita": gravita, "categoria": categoria, "icona": icona,
            "testo": testo, "azione": azione, "vai": vai}


def _scadute(db, oggi):
    out = []
    q = db.query(Scadenza).filter(
        Scadenza.completata == False,
        Scadenza.data_scadenza < oggi,
    ).order_by(Scadenza.data_scadenza)
    scadute = q.all()
    if scadute:
        esempi = "; ".join(s.titolo for s in scadute[:3])
        out.append(_avviso(
            "alta", "scadenze", "ri-alarm-warning-line",
            f"{len(scadute)} scadenze SCADUTE da gestire ({esempi}{'…' if len(scadute) > 3 else ''})",
            azione="Vai alle scadenze", vai="scadenze",
        ))
    return out


def _imminenti(db, oggi):
    out = []
    entro7 = db.query(Scadenza).filter(
        Scadenza.completata == False,
        Scadenza.data_scadenza >= oggi,
        Scadenza.data_scadenza <= oggi + timedelta(days=7),
    ).count()
    entro30 = db.query(Scadenza).filter(
        Scadenza.completata == False,
        Scadenza.data_scadenza > oggi + timedelta(days=7),
        Scadenza.data_scadenza <= oggi + timedelta(days=30),
    ).count()
    if entro7:
        out.append(_avviso("alta", "scadenze", "ri-time-line",
                           f"{entro7} scadenze nei prossimi 7 giorni",
                           azione="Vai alle scadenze", vai="scadenze"))
    if entro30:
        out.append(_avviso("media", "scadenze", "ri-calendar-event-line",
                           f"{entro30} scadenze tra 8 e 30 giorni",
                           azione="Vai alle scadenze", vai="scadenze"))
    return out


def _documenti_da_assegnare(db):
    out = []
    n = db.query(Document).filter(
        (Document.stato_classifica == "da_assegnare") |
        ((Document.client_id.is_(None)) & (Document.stato_classifica.isnot(None)))
    ).count()
    if n:
        out.append(_avviso("media", "documenti", "ri-folder-warning-line",
                           f"{n} documenti caricati non sono ancora assegnati a un cliente",
                           azione="Apri l'archivio", vai="archive"))
    return out


def _forfettari_soglia(db, oggi):
    out = []
    forfettari = db.query(Client).filter(Client.regime == "forfettario").all()
    anno = oggi.year
    for c in forfettari:
        # Stima ricavi: importi delle fatture (documenti) + eventi fattura/pagamento, anno corrente
        ric_doc = db.query(func.coalesce(func.sum(Document.importo), 0.0)).filter(
            Document.client_id == c.id,
            Document.importo.isnot(None),
            Document.anno_riferimento == anno,
        ).scalar() or 0.0
        ric_ev = db.query(func.coalesce(func.sum(ClientEvent.importo), 0.0)).filter(
            ClientEvent.client_id == c.id,
            ClientEvent.tipo.in_(["fattura", "pagamento"]),
            ClientEvent.importo.isnot(None),
        ).scalar() or 0.0
        ricavi = max(ric_doc, ric_ev)  # evita doppi conteggi: prende la fonte piu' alta
        if ricavi >= SOGLIA_FORFETTARIO:
            out.append(_avviso(
                "alta", "forfettario", "ri-error-warning-line",
                f"{c.cognome} {c.nome} (forfettario): ricavi stimati €{ricavi:,.0f} "
                f"— SOGLIA €85.000 SUPERATA. Verifica l'uscita dal regime.",
                azione="Apri cliente", vai="clients",
            ))
        elif ricavi >= SOGLIA_AVVICINAMENTO:
            out.append(_avviso(
                "media", "forfettario", "ri-line-chart-line",
                f"{c.cognome} {c.nome} (forfettario): ricavi stimati €{ricavi:,.0f} "
                f"— vicino alla soglia €85.000. Tienilo d'occhio.",
                azione="Apri cliente", vai="clients",
            ))
    return out


def _dati_mancanti(db):
    out = []
    senza_email = db.query(Client).filter((Client.email.is_(None)) | (Client.email == "")).count()
    senza_cf = db.query(Client).filter((Client.codice_fiscale.is_(None)) | (Client.codice_fiscale == "")).count()
    if senza_email:
        out.append(_avviso("bassa", "anagrafica", "ri-mail-line",
                           f"{senza_email} clienti senza email (non potrai inviare promemoria)",
                           azione="Vai ai clienti", vai="clients"))
    if senza_cf:
        out.append(_avviso("bassa", "anagrafica", "ri-id-card-line",
                           f"{senza_cf} clienti senza codice fiscale",
                           azione="Vai ai clienti", vai="clients"))
    return out


_ORDINE = {"alta": 0, "media": 1, "bassa": 2}


def genera_avvisi(db) -> dict:
    """Produce la lista di avvisi ordinata per gravità + un piccolo riepilogo."""
    oggi = datetime.now()
    avvisi = []
    # Ogni controllo è isolato: se uno fallisce, gli altri vanno avanti.
    for fn in (lambda: _scadute(db, oggi),
               lambda: _imminenti(db, oggi),
               lambda: _documenti_da_assegnare(db),
               lambda: _forfettari_soglia(db, oggi),
               lambda: _dati_mancanti(db)):
        try:
            avvisi.extend(fn())
        except Exception:
            continue
    avvisi.sort(key=lambda a: _ORDINE.get(a["gravita"], 3))
    return {
        "avvisi": avvisi,
        "totale": len(avvisi),
        "urgenti": sum(1 for a in avvisi if a["gravita"] == "alta"),
        "aggiornato": oggi.isoformat(),
    }
