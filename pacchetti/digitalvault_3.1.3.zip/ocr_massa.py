"""
DigitalVault - OCR DI MASSA per le scansioni mute.
(c) 2026 DigitalVault Team - Dr. Falsone Giuseppe

Il problema: meta' dell'archivio di uno studio sono PDF SCANSIONATI
(fotocopie). Dentro non c'e' testo: il cervello documenti non li vede.

La soluzione: questo modulo trova da solo i documenti "muti" (senza testo
estratto), tira fuori le pagine, le fa leggere all'AI vision e salva il testo
nell'archivio. Da quel momento anche le scansioni sono interrogabili.

Funziona in sottofondo, un documento alla volta, con stato consultabile.
Limiti prudenti per non bruciare credito AI: max pagine per documento e
max documenti per esecuzione (configurabili dalla chiamata).
"""
import asyncio
import base64
import threading
from datetime import datetime
from pathlib import Path

from config import UPLOAD_DIR
from ai_client import chat_with_ai

_PROMPT_OCR = (
    "Trascrivi FEDELMENTE tutto il testo presente in questa pagina di documento "
    "(e' un documento fiscale/amministrativo italiano: fattura, F24, CU, contratto, "
    "ricevuta o simile). Mantieni numeri, importi, date, codici e intestazioni ESATTI. "
    "Non riassumere, non commentare: solo il testo letto, in ordine di lettura."
)

_IMG_EXT = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp"}

# Stato globale del processo (consultabile dall'interfaccia)
stato = {
    "in_corso": False,
    "totale": 0,
    "fatti": 0,
    "ok": 0,
    "errori": 0,
    "ultimo_documento": "",
    "avviato": None,
    "finito": None,
    "dettagli": [],
}


def trova_scansioni(db) -> list:
    """Documenti dell'archivio SENZA testo utile (scansioni mute)."""
    from database import Document
    muti = []
    for d in db.query(Document).all():
        testo = (d.testo_estratto or "").strip()
        if len(testo) >= 80:
            continue  # ha gia' testo: non serve OCR
        ext = Path(d.nome_file).suffix.lower()
        if ext == ".pdf" or ext in _IMG_EXT:
            percorso = UPLOAD_DIR / d.nome_file
            if percorso.exists():
                muti.append(d)
    return muti


def _immagini_da_pdf(percorso: Path, max_pagine: int) -> list:
    """Estrae le immagini-pagina da un PDF scansionato.
    I PDF da scanner contengono una foto JPEG per pagina (DCTDecode):
    la tiriamo fuori cosi' com'e', senza renderizzare nulla."""
    import pdfplumber
    risultato = []
    with pdfplumber.open(percorso) as pdf:
        for pagina in pdf.pages[:max_pagine]:
            for img in pagina.images:
                stream = img.get("stream")
                if stream is None:
                    continue
                filtro = str(stream.attrs.get("Filter", ""))
                try:
                    if "DCTDecode" in filtro:
                        risultato.append(("image/jpeg", stream.rawdata))
                        break  # una foto per pagina basta
                    elif "FlateDecode" in filtro:
                        # Scansione PNG-style: ricostruisci con Pillow
                        from PIL import Image
                        import io as _io
                        larghezza = int(stream.attrs.get("Width", 0))
                        altezza = int(stream.attrs.get("Height", 0))
                        if not larghezza or not altezza:
                            continue
                        dati = stream.get_data()
                        spazio = str(stream.attrs.get("ColorSpace", ""))
                        mode = "RGB" if "RGB" in spazio else "L"
                        attesi = larghezza * altezza * (3 if mode == "RGB" else 1)
                        if len(dati) < attesi:
                            continue
                        im = Image.frombytes(mode, (larghezza, altezza), dati[:attesi])
                        buf = _io.BytesIO()
                        im.save(buf, format="JPEG", quality=82)
                        risultato.append(("image/jpeg", buf.getvalue()))
                        break
                except Exception:
                    continue
    return risultato


def _immagini_documento(d, max_pagine: int) -> list:
    """Lista (media_type, bytes) delle pagine del documento."""
    percorso = UPLOAD_DIR / d.nome_file
    ext = percorso.suffix.lower()
    if ext in _IMG_EXT:
        return [(_IMG_EXT[ext], percorso.read_bytes())]
    if ext == ".pdf":
        return _immagini_da_pdf(percorso, max_pagine)
    return []


async def _leggi_pagina(media_type: str, dati: bytes) -> str:
    b64 = base64.b64encode(dati).decode()
    messages = [{
        "role": "user",
        "content": [
            {"type": "image_url", "image_url": {"url": f"data:{media_type};base64,{b64}"}},
            {"type": "text", "text": _PROMPT_OCR},
        ],
    }]
    return await chat_with_ai(messages)


def _lavora(ids: list, max_pagine: int):
    """Corpo del lavoro, eseguito in un thread separato."""
    from database import SessionLocal, Document
    db = SessionLocal()
    try:
        for doc_id in ids:
            d = db.query(Document).filter(Document.id == doc_id).first()
            if not d:
                stato["fatti"] += 1
                continue
            stato["ultimo_documento"] = d.nome_originale
            try:
                pagine = _immagini_documento(d, max_pagine)
                if not pagine:
                    raise RuntimeError("nessuna immagine leggibile nel file")
                testi = []
                for media, dati in pagine:
                    if len(dati) > 8_000_000:
                        continue  # pagina enorme: salta
                    testi.append(asyncio.run(_leggi_pagina(media, dati)))
                testo = "\n\n".join(t for t in testi if t).strip()
                if not testo:
                    raise RuntimeError("l'AI non ha restituito testo")
                d.testo_estratto = (f"[TESTO LETTO CON OCR AI il {datetime.now():%d/%m/%Y} "
                                    f"da {len(testi)} pagine]\n{testo}")
                db.commit()
                stato["ok"] += 1
                stato["dettagli"].append({"documento": d.nome_originale, "esito": "ok",
                                          "pagine": len(testi), "caratteri": len(testo)})
            except Exception as e:
                stato["errori"] += 1
                stato["dettagli"].append({"documento": d.nome_originale, "esito": f"errore: {e}"})
            stato["fatti"] += 1
    finally:
        db.close()
        stato["in_corso"] = False
        stato["finito"] = datetime.now().isoformat()


def avvia(db, max_documenti: int = 20, max_pagine: int = 6) -> dict:
    """Avvia l'OCR di massa in sottofondo. Ritorna subito lo stato."""
    if stato["in_corso"]:
        return {"ok": False, "errore": "Un OCR e' gia' in corso: attendi che finisca."}
    muti = trova_scansioni(db)[:max_documenti]
    if not muti:
        return {"ok": True, "da_leggere": 0,
                "nota": "Nessuna scansione muta trovata: tutto l'archivio e' gia' leggibile."}
    stato.update({"in_corso": True, "totale": len(muti), "fatti": 0, "ok": 0,
                  "errori": 0, "ultimo_documento": "", "dettagli": [],
                  "avviato": datetime.now().isoformat(), "finito": None})
    ids = [d.id for d in muti]
    threading.Thread(target=_lavora, args=(ids, max_pagine), daemon=True).start()
    return {"ok": True, "da_leggere": len(muti)}
