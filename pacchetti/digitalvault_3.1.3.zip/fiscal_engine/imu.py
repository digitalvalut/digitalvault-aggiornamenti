"""
DigitalVault — Calcolatore IMU deterministico.
(c) 2026 DigitalVault - Capo Team del Progetto: Dr. Falsone Giuseppe

Calcolo IMU per fabbricati secondo Art. 1 L. 160/2019.
Fonte dati: fiscal_reference/imu.yaml (dati versionati).

Questo modulo è l'UNICA fonte di verità per i calcoli IMU.
Niente numeri vengono inventati: tutto legge dai dati di riferimento.
"""
import json
from decimal import Decimal, ROUND_HALF_UP
from dataclasses import dataclass, asdict
from datetime import date
from pathlib import Path
from typing import Optional, List, Dict, Any
import yaml

# Percorso dati di riferimento
REFERENCE_DIR = Path(__file__).parent.parent / "fiscal_reference"
IMU_REFERENCE = REFERENCE_DIR / "imu.yaml"


class FiscalValidationError(Exception):
    """Errore di validazione dei dati di input (es. manca l'aliquota comunale)."""
    pass


class MissingInputError(Exception):
    """Errore: input determinante mancante (il calcolatore non può procedere)."""
    def __init__(self, fields: List[str]):
        self.fields = fields
        super().__init__(f"Dati mancanti: {', '.join(fields)}")


@dataclass
class IMUResult:
    """Risultato di un calcolo IMU."""
    categoria_catastale: str
    rendita_catastale: Decimal
    moltiplicatore_usato: int
    base_imponibile: Decimal
    aliquota_per_mille: Decimal
    mesi_possesso: int
    imponibile_rata: Decimal
    imu_annua: Decimal
    imu_rata: Decimal
    acconto: Decimal
    saldo: Decimal
    constants_used: Dict[str, Any]
    legal_source: str
    warnings: List[str]
    assumptions: List[str]

    def to_dict(self) -> dict:
        """Converte in dict, preservando Decimal come numero."""
        d = asdict(self)
        for key in ["rendita_catastale", "base_imponibile", "aliquota_per_mille",
                    "imponibile_rata", "imu_annua", "imu_rata", "acconto", "saldo"]:
            d[key] = float(d[key])
        return d


def _load_imu_reference() -> dict:
    """Carica dati di riferimento IMU da YAML."""
    if not IMU_REFERENCE.exists():
        raise FileNotFoundError(f"Dati di riferimento IMU non trovati: {IMU_REFERENCE}")
    with open(IMU_REFERENCE, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _get_moltiplicatore(ref: dict, categoria: str) -> int:
    """Estrae il moltiplicatore corretto per una categoria catastale."""
    for entry in ref.get("moltiplicatori", []):
        if categoria in entry.get("categorie", []):
            return entry["valore"]
    raise FiscalValidationError(f"Categoria catastale {categoria} non riconosciuta nei dati di riferimento")


def calcola_imu_fabbricato(
    categoria_catastale: str,
    rendita_catastale: Decimal,
    aliquota_per_mille: Decimal,
    mesi_possesso: int = 12,
    comune_delibera_max: Optional[Decimal] = None,
) -> IMUResult:
    """
    Calcola l'IMU per un fabbricato.

    Args:
        categoria_catastale: es. "A/3", "B", "C/1", "D/2"
        rendita_catastale: rendita accertata dall'Agenzia delle Entrate (in euro)
        aliquota_per_mille: aliquota comunale (es. 8.6 per seconde case)
        mesi_possesso: numero di mesi di possesso nel periodo d'imposta (1-12)
        comune_delibera_max: limite massimo deliberato dal Comune (non usato qui, informativo)

    Returns:
        IMUResult strutturato con breakdown completo.

    Raises:
        FiscalValidationError: se dati non validi
        MissingInputError: se input determinante manca
    """
    ref = _load_imu_reference()
    warnings = []
    assumptions = []

    # Validazione input
    if mesi_possesso < 1 or mesi_possesso > 12:
        raise FiscalValidationError(f"Mesi di possesso deve essere tra 1 e 12, ricevuto: {mesi_possesso}")

    if rendita_catastale <= 0:
        raise FiscalValidationError(f"Rendita catastale deve essere > 0, ricevuto: {rendita_catastale}")

    if aliquota_per_mille <= 0:
        raise MissingInputError(["aliquota_per_mille"])

    # Carica costanti da riferimento
    moltiplicatore = _get_moltiplicatore(ref, categoria_catastale)
    rivalutazione = Decimal(str(ref["rivalutazione_rendita"]))

    # Calcolo
    rendita_dec = Decimal(str(rendita_catastale))
    aliquota_dec = Decimal(str(aliquota_per_mille))

    # Base imponibile = rendita * 1.05 * moltiplicatore
    base_imponibile = rendita_dec * rivalutazione * Decimal(str(moltiplicatore))

    # IMU annua = base * aliquota / 1000
    imu_annua = (base_imponibile * aliquota_dec / Decimal(1000)).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP
    )

    # IMU per il periodo (proporzione mesi)
    if mesi_possesso < 12:
        imponibile_rata = (base_imponibile * Decimal(str(mesi_possesso)) / Decimal(12)).quantize(
            Decimal("0.01"), rounding=ROUND_HALF_UP
        )
        imu_rata = (imu_annua * Decimal(str(mesi_possesso)) / Decimal(12)).quantize(
            Decimal("0.01"), rounding=ROUND_HALF_UP
        )
        assumptions.append(f"Possesso parziale: {mesi_possesso} mesi. IMU annua ridotta proporzione.")
    else:
        imponibile_rata = base_imponibile
        imu_rata = imu_annua

    # Acconto (50% della stima IMU annua) e saldo
    acconto = (imu_annua / Decimal(2)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    saldo = (imu_annua - acconto).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    constants_used = {
        "rivalutazione_rendita": float(rivalutazione),
        "moltiplicatore": moltiplicatore,
        "categoria": categoria_catastale,
        "mesi_possesso": mesi_possesso,
        "schema_version": ref.get("schema_version"),
        "formula": "base = rendita * 1.05 * moltiplicatore; imu = base * aliquota / 1000",
    }

    return IMUResult(
        categoria_catastale=categoria_catastale,
        rendita_catastale=rendita_dec,
        moltiplicatore_usato=moltiplicatore,
        base_imponibile=base_imponibile,
        aliquota_per_mille=aliquota_dec,
        mesi_possesso=mesi_possesso,
        imponibile_rata=imponibile_rata,
        imu_annua=imu_annua,
        imu_rata=imu_rata,
        acconto=acconto,
        saldo=saldo,
        constants_used=constants_used,
        legal_source="Art. 1, commi 739-783, L. 160/2019 (Bilancio 2020)",
        warnings=warnings,
        assumptions=assumptions,
    )


if __name__ == "__main__":
    # Test rapido
    try:
        res = calcola_imu_fabbricato(
            categoria_catastale="A/3",
            rendita_catastale=Decimal("232.41"),
            aliquota_per_mille=Decimal("10.6"),
            mesi_possesso=9,
        )
        print("=== Test IMU ===")
        print(f"Base imponibile: €{res.base_imponibile}")
        print(f"IMU annua: €{res.imu_annua}")
        print(f"IMU rata ({res.mesi_possesso} mesi): €{res.imu_rata}")
        print(f"Acconto: €{res.acconto}")
        print(f"Saldo: €{res.saldo}")
        print(f"Moltiplicatore usato: {res.moltiplicatore_usato}")
        assert res.moltiplicatore_usato == 160, "Moltiplicatore A/3 deve essere 160!"
        print("✅ Test passed")
    except Exception as e:
        print(f"❌ Test failed: {e}")
