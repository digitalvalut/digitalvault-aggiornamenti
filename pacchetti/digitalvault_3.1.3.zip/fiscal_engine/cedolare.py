"""
FiscoSicuro — Cedolare secca sulle locazioni (deterministico).
(c) 2026 DigitalVault - Capo Team del Progetto: Dr. Falsone Giuseppe

Imposta = canone annuo INTERO (100%) × aliquota.
  21% canone libero · 10% canone concordato · 26% locazioni brevi (dal 2° immobile).
Aliquote da fiscal_reference/cedolare.yaml.
"""
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import yaml

from fiscal_engine.common import verifica_anno

REFERENCE = Path(__file__).parent.parent / "fiscal_reference" / "cedolare.yaml"


def _load() -> dict:
    if not REFERENCE.exists():
        raise FileNotFoundError(f"Dati di riferimento cedolare non trovati: {REFERENCE}")
    with open(REFERENCE, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _q(n: Decimal) -> float:
    return float(n.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def calcola_cedolare(canone_annuo, tipo="ordinario", aliquota=None, anno: int = None) -> dict:
    """`tipo`: 'ordinario' (21%) | 'concordato' (10%) | 'breve' (26%).
    `aliquota` esplicita (%) ha la precedenza se indicata."""
    ref = _load()
    verifica_anno(ref, anno)
    canone = Decimal(str(max(0.0, float(canone_annuo))))
    if aliquota is not None:
        al = Decimal(str(aliquota)); tipo_lbl = f"{aliquota}% (indicata)"
    else:
        t = str(tipo or "ordinario").lower()
        if t.startswith("concord"):
            al = Decimal(str(ref["aliquota_concordato"])); tipo_lbl = "concordato 10%"
        elif t.startswith("brev"):
            al = Decimal(str(ref["aliquota_breve_oltre"])); tipo_lbl = "locazione breve 26%"
        else:
            al = Decimal(str(ref["aliquota_ordinaria"])); tipo_lbl = "ordinario 21%"
    imposta = (canone * al / Decimal("100")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    netto = canone - imposta
    return {
        "canone_annuo": _q(canone),
        "aliquota": float(al),
        "tipo": tipo_lbl,
        "imposta": _q(imposta),
        "netto": _q(netto),
        "anno_imposta": ref.get("anno_imposta"),
        "schema_version": ref.get("schema_version"),
        "legal_source": ref.get("legal_source"),
        "scadenze": ref.get("scadenze", {}),
        "warnings": [],
    }


if __name__ == "__main__":
    print(calcola_cedolare(12000, "ordinario", anno=2026))
    print(calcola_cedolare(12000, "concordato", anno=2026))
