"""
DigitalVault — Calcolatore IRPEF deterministico (Parte 2).
(c) 2026 DigitalVault - Capo Team del Progetto: Dr. Falsone Giuseppe

Calcola l'IRPEF lorda per scaglioni progressivi, leggendo aliquote e scaglioni
da fiscal_reference/irpef.yaml (dati versionati, NON costanti nel codice).
Include il data-freshness guard: se i dati per l'anno richiesto mancano, blocca.
"""
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import yaml

from fiscal_engine.common import verifica_anno  # noqa: F401 (re-export utile)

REFERENCE = Path(__file__).parent.parent / "fiscal_reference" / "irpef.yaml"


def _load() -> dict:
    if not REFERENCE.exists():
        raise FileNotFoundError(f"Dati di riferimento IRPEF non trovati: {REFERENCE}")
    with open(REFERENCE, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _fmt(n: Decimal) -> str:
    return f"{n:,.0f}".replace(",", ".")


def calcola_irpef(reddito_imponibile, anno: int = None) -> dict:
    """IRPEF lorda per scaglioni. Se `anno` è indicato, verifica che i dati di
    riferimento siano per quell'anno (altrimenti DataNotFreshError).
    Ritorna un dict compatibile con il frontend + campi di tracciabilità."""
    ref = _load()
    verifica_anno(ref, anno)

    reddito = Decimal(str(max(0.0, float(reddito_imponibile))))
    imposta = Decimal("0")
    precedente = Decimal("0")
    dettaglio = []
    aliquote_usate = []
    for s in ref["scaglioni"]:
        aliquota = Decimal(str(s["aliquota"]))
        limite = Decimal(str(s["a"])) if s["a"] is not None else None
        if limite is not None and reddito <= precedente:
            break
        top = reddito if limite is None else min(reddito, limite)
        base = top - precedente
        if base <= 0:
            break
        quota = (base * aliquota).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        imposta += quota
        aliquote_usate.append(float(aliquota))
        dettaglio.append({
            "scaglione": f"{_fmt(precedente)} - {('oltre' if limite is None else _fmt(limite))}",
            "aliquota": f"{int(aliquota * 100)}%",
            "base_imponibile": float(base),
            "imposta": float(quota),
        })
        if limite is None:
            break
        precedente = limite

    imposta = imposta.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    aliquota_media = (imposta / reddito * 100) if reddito > 0 else Decimal("0")

    return {
        # --- chiavi compatibili col frontend esistente ---
        "reddito_imponibile": float(reddito),
        "irpef_lorda": float(imposta),
        "aliquota_media": float(aliquota_media.quantize(Decimal("0.01"))),
        "dettaglio_scaglioni": dettaglio,
        "netto_stimato": float((reddito - imposta).quantize(Decimal("0.01"))),
        # --- tracciabilità (Parte 2) ---
        "anno_imposta": ref.get("anno_imposta"),
        "schema_version": ref.get("schema_version"),
        "legal_source": ref.get("legal_source"),
        "constants_used": {"aliquote": aliquote_usate, "schema_version": ref.get("schema_version"),
                           "anno_imposta": ref.get("anno_imposta")},
    }


def detrazione_lavoro_dipendente(reddito_imponibile, anno: int = None) -> dict:
    """Detrazione da lavoro dipendente (art. 13 c.1 TUIR). STIMA: costanti dal YAML,
    formula a scaglioni. Non include ulteriore detrazione/familiari/spese."""
    ref = _load()
    verifica_anno(ref, anno)
    d = ref.get("detrazione_lavoro_dipendente")
    if not d:
        return {"detrazione": 0.0, "stima": True, "da_verificare": True,
                "legal_source": None, "disponibile": False}
    R = Decimal(str(max(0.0, float(reddito_imponibile))))
    s1, s2, s3 = (Decimal(str(d["soglia1"])), Decimal(str(d["soglia2"])), Decimal(str(d["soglia3"])))
    if R <= s1:
        det = Decimal(str(d["importo_soglia1"]))
    elif R <= s2:
        det = Decimal(str(d["base2"])) + Decimal(str(d["extra2"])) * (s2 - R) / Decimal(str(d["divisore2"]))
    elif R <= s3:
        det = Decimal(str(d["base3"])) * (s3 - R) / Decimal(str(d["divisore3"]))
    else:
        det = Decimal("0")
    det = max(Decimal("0"), det).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return {"detrazione": float(det), "stima": True, "da_verificare": bool(d.get("da_verificare", True)),
            "legal_source": d.get("legal_source"), "disponibile": True}


if __name__ == "__main__":
    for r in (28000, 35000, 38000, 60000):
        res = calcola_irpef(r, anno=2026)
        print(f"Reddito {r}: IRPEF lorda € {res['irpef_lorda']}  (aliquote {res['constants_used']['aliquote']})")
    for r in (12000, 20000, 35000, 60000):
        print(f"Detrazione lav.dip. {r}: € {detrazione_lavoro_dipendente(r, anno=2026)['detrazione']}")
