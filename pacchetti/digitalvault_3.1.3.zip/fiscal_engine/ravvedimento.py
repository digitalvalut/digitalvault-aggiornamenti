"""
FiscoSicuro — Ravvedimento operoso (deterministico, STIMA da verificare).
(c) 2026 DigitalVault - Capo Team del Progetto: Dr. Falsone Giuseppe

Dato il tributo non versato e i giorni di ritardo, stima sanzione ridotta +
interessi legali. Costanti (sanzione base, frazioni, tasso legale) dal YAML,
TUTTE marcate da verificare: la norma varia per anno/tributo/data.
"""
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import yaml

from fiscal_engine.common import verifica_anno

REFERENCE = Path(__file__).parent.parent / "fiscal_reference" / "ravvedimento.yaml"


def _load() -> dict:
    if not REFERENCE.exists():
        raise FileNotFoundError(f"Dati di riferimento ravvedimento non trovati: {REFERENCE}")
    with open(REFERENCE, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _q(n: Decimal) -> float:
    return float(n.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def calcola_ravvedimento(imposta, giorni_ritardo, anno: int = None) -> dict:
    ref = _load()
    verifica_anno(ref, anno)
    imp = Decimal(str(max(0.0, float(imposta))))
    g = max(0, int(giorni_ritardo))
    base = Decimal(str(ref["sanzione_base_percent"])) / Decimal("100")
    tasso = Decimal(str(ref["tasso_legale_percent"])) / Decimal("100")

    if g <= 14:
        perc_giorno = Decimal(str(ref["sprint_percent_giorno"])) / Decimal("100")
        sanzione = imp * perc_giorno * Decimal(g)
        regola = f"ravvedimento sprint: {ref['sprint_percent_giorno']}%/giorno × {g} gg"
    else:
        frazione, desc = None, None
        for r in ref["riduzioni"]:
            mg = r.get("max_giorni")
            if mg is None or g <= int(mg):
                frazione = Decimal(str(r["frazione_su_base"])); desc = r["desc"]; break
        sanzione = imp * base * frazione
        regola = f"sanzione base {ref['sanzione_base_percent']}% ridotta a {desc}"

    sanzione = sanzione.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    interessi = (imp * tasso * Decimal(g) / Decimal("365")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    totale = imp + sanzione + interessi

    return {
        "imposta": _q(imp),
        "giorni_ritardo": g,
        "regola": regola,
        "sanzione": _q(sanzione),
        "interessi": _q(interessi),
        "totale_da_versare": _q(totale),
        "tasso_legale": float(ref["tasso_legale_percent"]),
        "anno_imposta": ref.get("anno_imposta"),
        "schema_version": ref.get("schema_version"),
        "legal_source": ref.get("legal_source"),
        "warnings": ["STIMA INDICATIVA: sanzioni e tasso legale variano per anno, tributo e data. "
                     "Verifica sempre la norma vigente prima del versamento."],
    }


if __name__ == "__main__":
    print(calcola_ravvedimento(1000, 10, anno=2026))
    print(calcola_ravvedimento(1000, 20, anno=2026))
    print(calcola_ravvedimento(1000, 200, anno=2026))
