"""
FiscoSicuro — Modello 730: calcolo dell'ESITO (rimborso o a debito).
(c) 2026 DigitalVault - Capo Team del Progetto: Dr. Falsone Giuseppe

Deterministico: confronta l'IRPEF NETTA con le ritenute già subite (CU).
  IRPEF lorda  = motore IRPEF (scaglioni da irpef.yaml)
  IRPEF netta  = max(0, lorda − detrazioni)            [detrazioni = dato d'ingresso]
  Esito        = ritenute − netta   ( >0 rimborso ; <0 a debito )

Le DETRAZIONI sono un INPUT (dalla CU/precompilata): non vengono stimate qui,
per non introdurre costanti non verificate.
"""
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import yaml

from fiscal_engine.common import verifica_anno
from fiscal_engine import irpef as _irpef

REFERENCE = Path(__file__).parent.parent / "fiscal_reference" / "dichiarativo_730.yaml"


def _load() -> dict:
    if not REFERENCE.exists():
        raise FileNotFoundError(f"Dati di riferimento 730 non trovati: {REFERENCE}")
    with open(REFERENCE, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _q(n: Decimal) -> float:
    return float(n.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def esito_730(reddito_imponibile, ritenute, detrazioni=None, tipo_reddito=None,
              anno: int = None) -> dict:
    """Esito del 730.
    - `detrazioni` fornite (anche 0) -> usate così come sono (fonte 'indicata').
    - `detrazioni` None e `tipo_reddito` in {lavoro_dipendente, pensione} -> la
      detrazione da lavoro viene STIMATA (art. 13 TUIR) e marcata 'stimata'.
    - altrimenti -> 0 con avviso (fonte 'assente')."""
    ref = _load()
    verifica_anno(ref, anno)

    lorda = Decimal(str(_irpef.calcola_irpef(reddito_imponibile, anno=anno)["irpef_lorda"]))
    rit = Decimal(str(max(0.0, float(ritenute or 0))))

    warnings = []
    if detrazioni is not None:
        detr = Decimal(str(max(0.0, float(detrazioni))))
        fonte = "indicata"
        if detr == 0:
            warnings.append("Calcolo SENZA detrazioni: indica il totale detrazioni (CU/precompilata) per l'esito reale.")
    elif str(tipo_reddito or "").lower() in ("lavoro_dipendente", "dipendente", "pensione", "pensionato"):
        stima = _irpef.detrazione_lavoro_dipendente(reddito_imponibile, anno=anno)
        detr = Decimal(str(stima["detrazione"]))
        fonte = "stimata"
        warnings.append("Detrazione da lavoro dipendente STIMATA (art. 13 TUIR): "
                        "verifica con la CU/precompilata. Non include familiari, spese, ulteriori detrazioni.")
    else:
        detr = Decimal("0")
        fonte = "assente"
        warnings.append("Calcolo SENZA detrazioni: indica il totale detrazioni (CU/precompilata) per l'esito reale.")

    netta = max(Decimal("0"), lorda - detr)
    saldo = rit - netta                      # >0 rimborso ; <0 a debito
    a_rimborso = saldo > 0

    return {
        "reddito_imponibile": _q(Decimal(str(max(0.0, float(reddito_imponibile))))),
        "irpef_lorda": _q(lorda),
        "detrazioni": _q(detr),
        "detrazione_fonte": fonte,
        "irpef_netta": _q(netta),
        "ritenute": _q(rit),
        "esito": "rimborso" if a_rimborso else "a debito",
        "importo": _q(abs(saldo)),
        "saldo": _q(saldo),
        "anno_imposta": ref.get("anno_imposta"),
        "schema_version": ref.get("schema_version"),
        "legal_source": ref.get("legal_source"),
        "scadenze": ref.get("scadenze", {}),
        "warnings": warnings,
    }


if __name__ == "__main__":
    print(esito_730(35000, ritenute=9000, detrazioni=1910, anno=2026))
    print(esito_730(35000, ritenute=5000, detrazioni=1910, anno=2026))
