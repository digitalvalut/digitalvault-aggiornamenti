"""
DigitalVault Fiscal Engine — Motore di calcolo fiscale deterministico.

Questo pacchetto contiene funzioni PURE di calcolo tributario, senza dipendenze da LLM.
Ogni numero fiscalmente rilevante è calcolato da funzioni testate e fondate su norme.

Moduli:
  - imu.py: Calcolo IMU per fabbricati (Art. 1 L. 160/2019)
  - f24.py: Calcolo F24 (importi, termini di versamento)
  - [future] irpef.py, forfettario.py, inps.py, ecc.

Uso:
  from fiscal_engine.imu import calcola_imu_fabbricato
  from decimal import Decimal

  res = calcola_imu_fabbricato(
      categoria_catastale="A/3",
      rendita_catastale=Decimal("232.41"),
      aliquota_per_mille=Decimal("10.6"),
      mesi_possesso=9,
  )
  print(f"IMU annua: € {res.imu_annua}")
  print(f"Fonte: {res.legal_source}")
"""

__version__ = "1.0.0"
__all__ = ["imu"]
