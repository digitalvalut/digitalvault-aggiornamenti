"""
FiscoSicuro — Calcolatore IVA deterministico.
(c) 2026 DigitalVault - Capo Team del Progetto: Dr. Falsone Giuseppe

Tre operazioni:
  - calcola_iva(imponibile, aliquota): da NETTO  -> IVA + totale
  - scorpora_iva(totale, aliquota):    da LORDO  -> imponibile + IVA
  - liquidazione_iva(vendite, acquisti): IVA a debito/credito del periodo

Le aliquote ammesse vengono da fiscal_reference/iva.yaml (mai inventate).
"""
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import yaml

from fiscal_engine.common import verifica_anno

REFERENCE = Path(__file__).parent.parent / "fiscal_reference" / "iva.yaml"


def _load() -> dict:
    if not REFERENCE.exists():
        raise FileNotFoundError(f"Dati di riferimento IVA non trovati: {REFERENCE}")
    with open(REFERENCE, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _q(n: Decimal) -> float:
    return float(n.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def _aliquota(ref: dict, aliquota) -> Decimal:
    """Valida l'aliquota: se None usa l'ordinaria del YAML; se fuori dall'elenco
    ammesso, segnala (warning gestito dal chiamante via lista 'ammesse')."""
    if aliquota is None:
        return Decimal(str(ref.get("aliquota_ordinaria", 22)))
    return Decimal(str(aliquota))


def _aliquota_anomala(ref: dict, aliquota: Decimal) -> bool:
    ammesse = [Decimal(str(a)) for a in (ref.get("aliquote_ammesse") or [])]
    return ammesse and aliquota not in ammesse


def calcola_iva(imponibile, aliquota=None, anno: int = None) -> dict:
    """Da imponibile (netto) -> IVA e totale."""
    ref = _load()
    verifica_anno(ref, anno)
    imp = Decimal(str(max(0.0, float(imponibile))))
    al = _aliquota(ref, aliquota)
    iva = (imp * al / Decimal("100")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    totale = imp + iva
    warnings = []
    if _aliquota_anomala(ref, al):
        warnings.append(f"Aliquota {al}% non è tra quelle ordinarie ({ref.get('aliquote_ammesse')}): verifica.")
    return {
        "operazione": "calcolo",
        "imponibile": _q(imp), "aliquota": float(al), "iva": _q(iva), "totale": _q(totale),
        "anno_imposta": ref.get("anno_imposta"), "schema_version": ref.get("schema_version"),
        "legal_source": ref.get("legal_source"), "warnings": warnings,
    }


def scorpora_iva(totale, aliquota=None, anno: int = None) -> dict:
    """Da totale (lordo) -> imponibile e IVA (scorporo)."""
    ref = _load()
    verifica_anno(ref, anno)
    tot = Decimal(str(max(0.0, float(totale))))
    al = _aliquota(ref, aliquota)
    imponibile = (tot / (Decimal("1") + al / Decimal("100"))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    iva = tot - imponibile
    warnings = []
    if _aliquota_anomala(ref, al):
        warnings.append(f"Aliquota {al}% non è tra quelle ordinarie ({ref.get('aliquote_ammesse')}): verifica.")
    return {
        "operazione": "scorporo",
        "totale": _q(tot), "aliquota": float(al), "imponibile": _q(imponibile), "iva": _q(iva),
        "anno_imposta": ref.get("anno_imposta"), "schema_version": ref.get("schema_version"),
        "legal_source": ref.get("legal_source"), "warnings": warnings,
    }


def liquidazione_iva(iva_vendite, iva_acquisti, anno: int = None) -> dict:
    """IVA a debito (su vendite) − IVA a credito (su acquisti) del periodo."""
    ref = _load()
    verifica_anno(ref, anno)
    ven = Decimal(str(max(0.0, float(iva_vendite))))
    acq = Decimal(str(max(0.0, float(iva_acquisti))))
    saldo = ven - acq
    a_debito = saldo > 0
    return {
        "operazione": "liquidazione",
        "iva_vendite": _q(ven), "iva_acquisti": _q(acq),
        "saldo": _q(saldo), "tipo": "a debito (da versare)" if a_debito else "a credito (riportabile)",
        "importo": _q(abs(saldo)),
        "anno_imposta": ref.get("anno_imposta"), "schema_version": ref.get("schema_version"),
        "legal_source": ref.get("legal_source"),
        "scadenze": ref.get("liquidazione", {}), "warnings": [],
    }


if __name__ == "__main__":
    print(calcola_iva(1000, 22, anno=2026))
    print(scorpora_iva(1220, 22, anno=2026))
    print(liquidazione_iva(5000, 3000, anno=2026))
