"""
DigitalVault - Cambio automatico della chiave OpenRouter.
Uso riservato al titolare (DigitalVault — Capo Team del Progetto: Dr. Falsone Giuseppe) per preparare un nuovo SSD.
"""
import re
import shutil
from pathlib import Path
from datetime import datetime

CONFIG = Path(__file__).parent / "config.py"


def chiave_attuale(testo: str) -> str:
    m = re.search(r'OPENROUTER_API_KEY\s*=\s*"([^"]*)"', testo)
    return m.group(1) if m else "(non trovata)"


def main():
    print("=" * 60)
    print("  DIGITALVAULT - CONFIGURAZIONE CHIAVE AI (OpenRouter)")
    print("  Riservato al titolare - DigitalVault")
    print("=" * 60)
    print()

    if not CONFIG.exists():
        print("  [ERRORE] File config.py non trovato accanto a questo programma.")
        input("  Premi Invio per uscire...")
        return

    testo = CONFIG.read_text(encoding="utf-8")
    attuale = chiave_attuale(testo)
    print("  Chiave attualmente impostata su questo SSD:")
    print(f"  {attuale[:18]}...{attuale[-6:]}" if len(attuale) > 30 else f"  {attuale}")
    print()
    print("  Incolla qui la NUOVA chiave OpenRouter per questo commercialista")
    print("  (clic destro per incollare). Deve iniziare con 'sk-or-v1-'")
    print()

    try:
        nuova = input("  Nuova chiave: ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\n  Annullato.")
        return

    if not nuova:
        print("\n  Nessuna chiave inserita. Niente modificato.")
        input("  Premi Invio per uscire...")
        return

    if not nuova.startswith("sk-or-"):
        print()
        print("  [ATTENZIONE] La chiave non inizia con 'sk-or-'.")
        conferma = input("  Sei sicuro di volerla usare comunque? (s/n): ").strip().lower()
        if conferma != "s":
            print("  Annullato. Niente modificato.")
            input("  Premi Invio per uscire...")
            return

    # Backup di sicurezza
    backup = CONFIG.parent / f"config_backup_{datetime.now():%Y%m%d_%H%M%S}.py"
    shutil.copy(CONFIG, backup)

    # Sostituisce la riga della chiave
    nuovo_testo, n = re.subn(
        r'OPENROUTER_API_KEY\s*=\s*"[^"]*"',
        f'OPENROUTER_API_KEY = "{nuova}"',
        testo,
    )

    if n == 0:
        print("\n  [ERRORE] Non ho trovato la riga della chiave nel file.")
        input("  Premi Invio per uscire...")
        return

    CONFIG.write_text(nuovo_testo, encoding="utf-8")

    print()
    print("  " + "=" * 56)
    print("  ✓ CHIAVE AGGIORNATA CON SUCCESSO!")
    print("  " + "=" * 56)
    print(f"  Nuova chiave: {nuova[:18]}...{nuova[-6:]}")
    print(f"  Backup salvato: {backup.name}")
    print()
    print("  Questo SSD ora usa la nuova chiave.")
    print("  Puoi consegnarlo al commercialista.")
    print()
    input("  Premi Invio per chiudere...")


if __name__ == "__main__":
    main()
