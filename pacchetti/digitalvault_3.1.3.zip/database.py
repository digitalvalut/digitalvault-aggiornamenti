from sqlalchemy import create_engine, event, Column, Integer, String, Text, DateTime, Float, Boolean
from sqlalchemy.orm import declarative_base, sessionmaker
from datetime import datetime
from config import DB_PATH

engine = create_engine(f"sqlite:///{DB_PATH}", connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Cifratura trasparente dei campi sensibili a riposo (Tier 1.1).
from db_crypto import EncryptedText
_ENC = EncryptedText if EncryptedText is not None else Text


@event.listens_for(engine, "connect")
def _sqlite_pragmas(dbapi_conn, _):
    # WAL: piu' robusto contro corruzioni se il PC si spegne di colpo
    cur = dbapi_conn.cursor()
    cur.execute("PRAGMA journal_mode=WAL")
    cur.execute("PRAGMA synchronous=NORMAL")
    cur.close()


class Client(Base):
    __tablename__ = "clients"
    id = Column(Integer, primary_key=True, index=True)
    nome = Column(String(100), nullable=False)
    cognome = Column(String(100), nullable=False)
    codice_fiscale = Column(String(16), unique=True, index=True)
    partita_iva = Column(String(11), nullable=True)
    email = Column(_ENC, nullable=True)        # cifrato a riposo
    telefono = Column(_ENC, nullable=True)     # cifrato a riposo
    indirizzo = Column(_ENC, nullable=True)    # cifrato a riposo
    note = Column(_ENC, nullable=True)         # cifrato a riposo
    tipo = Column(String(50), default="persona_fisica")  # persona_fisica, societa
    # Regime fiscale: guida la generazione dello scadenzario su misura
    # (forfettario, ordinario_pf, societa, datore_lavoro, privato)
    regime = Column(String(40), nullable=True)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)


class FiscalAudit(Base):
    """Traccia ogni calcolo fiscale deterministico (Fase H del Brief affidabilità).
    Serve per tracciabilità e per rispondere a eventuali contestazioni: con quali
    input, quali costanti e quale versione dei dati di riferimento è stato prodotto
    un certo numero, e quando."""
    __tablename__ = "fiscal_audit"
    id = Column(Integer, primary_key=True, index=True)
    created_at = Column(DateTime, default=datetime.now, index=True)
    funzione = Column(String(60), nullable=False)        # es. "imu_fabbricato"
    esito = Column(String(20), default="ok")             # ok | errore
    input_json = Column(Text, nullable=True)             # input ricevuti (JSON)
    output_json = Column(Text, nullable=True)            # risultato sintetico (JSON)
    costanti_json = Column(Text, nullable=True)          # costanti usate (JSON)
    fonte = Column(String(200), nullable=True)           # riferimento normativo
    versione_dati = Column(String(40), nullable=True)    # versione fiscal_reference
    modello_ai = Column(String(60), nullable=True)       # modello AI coinvolto (se presente)


class Document(Base):
    __tablename__ = "documents"
    id = Column(Integer, primary_key=True, index=True)
    nome_file = Column(String(255), nullable=False)
    nome_originale = Column(String(255), nullable=False)
    tipo = Column(String(100), nullable=True)  # 730, CU, F24, contratto, etc.
    client_id = Column(Integer, nullable=True, index=True)
    client_nome = Column(String(200), nullable=True)
    anno_riferimento = Column(Integer, nullable=True)
    testo_estratto = Column(Text, nullable=True)
    dimensione = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=datetime.now)
    note = Column(_ENC, nullable=True)                   # cifrato a riposo
    # Auto-classificazione AI ("butta dentro qualsiasi documento -> si sistema da solo")
    dati_estratti = Column(_ENC, nullable=True)          # JSON dei campi estratti (cifrato)
    stato_classifica = Column(String(30), nullable=True) # auto / da_assegnare / manuale / non_classificato
    importo = Column(Float, nullable=True)               # importo principale, se presente
    controparte = Column(_ENC, nullable=True)            # fornitore/controparte (cifrato)
    confidenza = Column(String(20), nullable=True)       # alta / media / bassa


class ChatMessage(Base):
    __tablename__ = "chat_messages"
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String(100), nullable=False, index=True)
    role = Column(String(20), nullable=False)  # user, assistant
    content = Column(_ENC, nullable=False)     # cifrato a riposo (chat fiscale sensibile)
    created_at = Column(DateTime, default=datetime.now)
    client_id = Column(Integer, nullable=True)


class Scadenza(Base):
    __tablename__ = "scadenze"
    id = Column(Integer, primary_key=True, index=True)
    titolo = Column(String(200), nullable=False)
    descrizione = Column(Text, nullable=True)
    data_scadenza = Column(DateTime, nullable=False)
    tipo = Column(String(100), nullable=True)
    client_id = Column(Integer, nullable=True)
    client_nome = Column(String(200), nullable=True)
    completata = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.now)


class ClientEvent(Base):
    """Timeline CRM: storia completa di ogni cliente."""
    __tablename__ = "client_events"
    id = Column(Integer, primary_key=True, index=True)
    client_id = Column(Integer, nullable=False, index=True)
    tipo = Column(String(50), nullable=False)  # nota, documento, consulenza, scadenza, contatto, pagamento
    titolo = Column(String(200), nullable=False)
    descrizione = Column(Text, nullable=True)
    importo = Column(Float, nullable=True)  # per eventi di pagamento/fattura
    created_at = Column(DateTime, default=datetime.now)


class Setting(Base):
    """Impostazioni dello studio (dati studio, configurazione email SMTP)."""
    __tablename__ = "settings"
    id = Column(Integer, primary_key=True, index=True)
    chiave = Column(String(100), unique=True, nullable=False, index=True)
    # Cifrato a riposo: qui finiscono anche le password SMTP/PEC (in JSON).
    # Migrazione indolore: i valori legacy in chiaro restano leggibili.
    valore = Column(_ENC, nullable=True)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def _migra_colonne():
    """Aggiunge colonne nuove a database già esistenti, senza perdere dati."""
    from sqlalchemy import text
    nuove = {
        "clients": [("regime", "VARCHAR(40)")],
        # Auto-classificazione documenti (feature "butta dentro e si sistema da solo")
        "documents": [
            ("dati_estratti", "TEXT"),          # JSON con i campi estratti dall'AI
            ("stato_classifica", "VARCHAR(30)"),# auto / da_assegnare / manuale / non_classificato
            ("importo", "FLOAT"),               # importo principale del documento, se presente
            ("controparte", "VARCHAR(200)"),    # fornitore/cliente/controparte sul documento
            ("confidenza", "VARCHAR(20)"),      # alta / media / bassa
        ],
    }
    with engine.connect() as conn:
        for tabella, colonne in nuove.items():
            esistenti = {r[1] for r in conn.execute(text(f"PRAGMA table_info({tabella})"))}
            for nome, tipo in colonne:
                if nome not in esistenti:
                    conn.execute(text(f"ALTER TABLE {tabella} ADD COLUMN {nome} {tipo}"))
        conn.commit()


# Campi cifrati a riposo (devono combaciare con i Column(_ENC) dei modelli sopra).
_CAMPI_CIFRATI = {
    "clients": ["email", "telefono", "indirizzo", "note"],
    "documents": ["note", "dati_estratti", "controparte"],
    "chat_messages": ["content"],
}
_MARKER_CIFRATURA = DB_PATH.parent / ".campi_cifrati"


def migra_cifra_campi():
    """One-shot: cifra i valori legacy in chiaro nei campi sensibili (Tier 1.1).
    Opera a livello SQL grezzo (bypassa il TypeDecorator) ed è IDEMPOTENTE:
    `db_crypto.cifra` non ri-cifra ciò che è già cifrato. Marker per non
    riscansionare a ogni avvio."""
    import db_crypto
    from sqlalchemy import text
    if not db_crypto.attivo() or _MARKER_CIFRATURA.exists():
        return
    try:
        with engine.begin() as conn:
            for tab, cols in _CAMPI_CIFRATI.items():
                presenti = {r[1] for r in conn.execute(text(f"PRAGMA table_info({tab})"))}
                for col in cols:
                    if col not in presenti:
                        continue
                    righe = conn.execute(
                        text(f"SELECT id, {col} FROM {tab} WHERE {col} IS NOT NULL AND {col} <> ''")
                    ).fetchall()
                    for rid, val in righe:
                        nuovo = db_crypto.cifra(val)
                        if nuovo != val:
                            conn.execute(text(f"UPDATE {tab} SET {col} = :v WHERE id = :i"),
                                         {"v": nuovo, "i": rid})
        _MARKER_CIFRATURA.write_text("ok", encoding="utf-8")
        print(">>> [Sicurezza] Campi sensibili del database cifrati a riposo.")
    except Exception as e:
        print(f">>> [Sicurezza] Cifratura campi non completata ({e}). Il programma prosegue.")


def _crea_indici_fts():
    """Indice full-text FTS5 sui documenti + indici sui filtri (scala/velocità).
    Idempotente. La ricerca testo passa da scansione totale (~160 ms su 30k doc)
    a sub-millisecondo. I trigger tengono l'indice sincronizzato in automatico."""
    from sqlalchemy import text
    try:
        with engine.begin() as conn:
            conn.execute(text("CREATE INDEX IF NOT EXISTS idx_doc_anno ON documents(anno_riferimento)"))
            conn.execute(text("CREATE INDEX IF NOT EXISTS idx_doc_tipo ON documents(tipo)"))
            conn.execute(text("CREATE INDEX IF NOT EXISTS idx_doc_created ON documents(created_at)"))
            # FTS5 su campi IN CHIARO (testo, nome file, nome cliente) — non sui cifrati.
            conn.execute(text(
                "CREATE VIRTUAL TABLE IF NOT EXISTS documents_fts USING fts5("
                "testo_estratto, nome_originale, client_nome, "
                "content='documents', content_rowid='id')"))
            conn.execute(text(
                "CREATE TRIGGER IF NOT EXISTS documents_ai AFTER INSERT ON documents BEGIN "
                "INSERT INTO documents_fts(rowid,testo_estratto,nome_originale,client_nome) "
                "VALUES(new.id,new.testo_estratto,new.nome_originale,new.client_nome); END"))
            conn.execute(text(
                "CREATE TRIGGER IF NOT EXISTS documents_ad AFTER DELETE ON documents BEGIN "
                "INSERT INTO documents_fts(documents_fts,rowid,testo_estratto,nome_originale,client_nome) "
                "VALUES('delete',old.id,old.testo_estratto,old.nome_originale,old.client_nome); END"))
            conn.execute(text(
                "CREATE TRIGGER IF NOT EXISTS documents_au AFTER UPDATE ON documents BEGIN "
                "INSERT INTO documents_fts(documents_fts,rowid,testo_estratto,nome_originale,client_nome) "
                "VALUES('delete',old.id,old.testo_estratto,old.nome_originale,old.client_nome); "
                "INSERT INTO documents_fts(rowid,testo_estratto,nome_originale,client_nome) "
                "VALUES(new.id,new.testo_estratto,new.nome_originale,new.client_nome); END"))
            nd = conn.execute(text("SELECT count(*) FROM documents")).scalar() or 0
            nf = conn.execute(text("SELECT count(*) FROM documents_fts")).scalar() or 0
            if nd != nf:   # primo popolamento o riallineamento
                conn.execute(text("INSERT INTO documents_fts(documents_fts) VALUES('rebuild')"))
    except Exception as e:
        print(f">>> [Ricerca] Indice full-text non disponibile ({e}). Si usa la ricerca classica.")


def _fts_query(termine: str):
    """Trasforma il testo cercato in una query FTS5 sicura (prefix match, AND)."""
    import re
    toks = re.findall(r"\w+", termine or "", flags=re.UNICODE)
    if not toks:
        return None
    return " ".join(t + "*" for t in toks)


def cerca_documenti_fts(db, termine: str, limite: int = 1000):
    """Ritorna gli id dei documenti che matchano, ordinati per rilevanza (bm25).
    None se FTS non è utilizzabile (→ il chiamante usa la ricerca classica)."""
    from sqlalchemy import text
    fq = _fts_query(termine)
    if not fq:
        return None
    try:
        rows = db.execute(text(
            "SELECT f.rowid FROM documents_fts f "
            "WHERE documents_fts MATCH :q ORDER BY rank LIMIT :lim"),
            {"q": fq, "lim": int(limite)}).fetchall()
        return [r[0] for r in rows]
    except Exception:
        return None


def _ripara_wal():
    """Auto-riparazione all'avvio: se l'SSD è stato staccato male mentre il
    programma scriveva, può restare un file -wal "appeso" che provoca
    'disk I/O error' su ogni richiesta. Qui consolidiamo quelle scritture
    nel database e azzeriamo il WAL, così il programma riparte pulito da solo.
    Non blocca mai l'avvio: se qualcosa va storto, lo segnala e prosegue."""
    import sqlite3
    from pathlib import Path
    wal = Path(f"{DB_PATH}-wal")
    if not wal.exists() or wal.stat().st_size == 0:
        return  # niente di appeso, nulla da fare
    try:
        con = sqlite3.connect(str(DB_PATH), timeout=10)
        try:
            integro = con.execute("PRAGMA quick_check").fetchone()[0]
            esito = con.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
            con.commit()
            if esito and esito[0] == 0:
                print(f">>> [Auto-riparazione] Dati in sospeso recuperati dopo "
                      f"scollegamento dell'SSD (integrità: {integro}).")
            else:
                print(f">>> [Auto-riparazione] WAL non completamente consolidato "
                      f"{esito}: il programma funziona comunque.")
        finally:
            con.close()
    except Exception as e:
        print(f">>> [Auto-riparazione] Impossibile consolidare il WAL ({e}). "
              f"Il programma prova comunque ad avviarsi.")


def init_db():
    _ripara_wal()
    Base.metadata.create_all(bind=engine)
    _migra_colonne()
    _crea_indici_fts()    # indice full-text + indici filtri (ricerca veloce su masse di doc)
    migra_cifra_campi()   # cifra i valori sensibili esistenti (one-shot, idempotente)
    try:
        import config as _config
        _config.migra_chiave_ai()   # cifra la chiave AI a riposo (Tier 2.1)
    except Exception as e:
        print(f">>> [Sicurezza] Cifratura chiave AI non completata ({e}). Il programma prosegue.")
    db = SessionLocal()
    # Inserisce scadenze fiscali 2025/2026 di default
    if db.query(Scadenza).count() == 0:
        scadenze_default = [
            Scadenza(titolo="Modello 730 - Invio telematico", data_scadenza=datetime(2026, 9, 30), tipo="730", descrizione="Termine invio modello 730/2026 per anno 2025"),
            Scadenza(titolo="IVA - Dichiarazione annuale", data_scadenza=datetime(2026, 4, 30), tipo="IVA", descrizione="Dichiarazione IVA annuale 2025"),
            Scadenza(titolo="IRPEF - Acconto I rata", data_scadenza=datetime(2026, 6, 30), tipo="IRPEF", descrizione="Primo acconto IRPEF 2026"),
            Scadenza(titolo="IRPEF - Acconto II rata", data_scadenza=datetime(2026, 11, 30), tipo="IRPEF", descrizione="Secondo acconto IRPEF 2026"),
            Scadenza(titolo="F24 - INPS artigiani/commercianti", data_scadenza=datetime(2026, 5, 16), tipo="INPS", descrizione="Versamento contributi INPS I trimestre"),
            Scadenza(titolo="CU - Certificazione Unica", data_scadenza=datetime(2026, 3, 16), tipo="CU", descrizione="Trasmissione Certificazioni Uniche all'Agenzia delle Entrate"),
            Scadenza(titolo="IMU - Prima rata", data_scadenza=datetime(2026, 6, 16), tipo="IMU", descrizione="Prima rata IMU 2026"),
            Scadenza(titolo="IMU - Seconda rata (saldo)", data_scadenza=datetime(2026, 12, 16), tipo="IMU", descrizione="Seconda rata e saldo IMU 2026"),
            Scadenza(titolo="Dichiarazione Redditi - Persone Fisiche", data_scadenza=datetime(2026, 11, 30), tipo="REDDITI", descrizione="Modello Redditi PF 2026 (anno 2025)"),
            Scadenza(titolo="TARI - Scadenza comunale", data_scadenza=datetime(2026, 7, 31), tipo="TARI", descrizione="Versamento TARI (verificare scadenze comunali)"),
        ]
        db.add_all(scadenze_default)
        db.commit()
    db.close()
