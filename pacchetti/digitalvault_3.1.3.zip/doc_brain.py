"""
DigitalVault - "Cervello documenti": cerca tra TUTTI i documenti archiviati
dello studio e fa rispondere l'AI citando le fonti.
(c) 2026 DigitalVault Team - Dr. Falsone Giuseppe

Come funziona (tutto in locale, nessun dato esce dall'SSD se non i passaggi
necessari alla domanda):
1. Da una domanda estrae le parole chiave significative.
2. Assegna un punteggio a ogni documento in base a quante parole chiave
   compaiono nel testo estratto (con bonus se citano un cliente nominato).
3. Prende i documenti piu' pertinenti e passa solo quei testi all'AI.
4. L'AI risponde citando i documenti usati (nome, tipo, anno, cliente).
"""
import re
from datetime import datetime

# Parole troppo comuni: non aiutano a distinguere i documenti
_STOPWORDS = {
    "il", "lo", "la", "i", "gli", "le", "un", "uno", "una", "di", "a", "da",
    "in", "con", "su", "per", "tra", "fra", "e", "o", "ma", "se", "che", "chi",
    "cosa", "come", "quando", "dove", "quanto", "quale", "quali", "non", "del",
    "dello", "della", "dei", "degli", "delle", "al", "allo", "alla", "ai",
    "agli", "alle", "nel", "nello", "nella", "nei", "negli", "nelle", "sul",
    "sulla", "mi", "ti", "ci", "vi", "si", "ha", "ho", "hai", "hanno", "anno",
    "sono", "essere", "stato", "questo", "questa", "mio", "mia", "suo", "sua",
    "dottore", "dimmi", "vorrei", "puoi", "fammi", "voglio", "tutti", "tutto",
}


# Gruppi di SINONIMI fiscali: se la domanda usa una parola del gruppo, la
# ricerca cerca anche le altre. Cosi' "quanto ha SPESO" trova "importo VERSATO".
_GRUPPI_SINONIMI = [
    {"versato", "versamento", "pagato", "pagamento", "corrisposto", "saldato", "versati"},
    {"importo", "cifra", "somma", "ammontare", "totale", "euro", "imponibile"},
    {"speso", "spesa", "spese", "costo", "costi", "uscita", "uscite", "esborso"},
    {"acconto", "anticipo", "rata", "acconti"},
    {"saldo", "conguaglio", "residuo"},
    {"reddito", "redditi", "guadagno", "ricavo", "ricavi", "incasso", "incassi"},
    {"iva", "imposta", "imposte", "tributo", "tributi"},
    {"scadenza", "scadenze", "termine", "termini", "entro"},
    {"fattura", "fatture", "fatturazione", "parcella", "parcelle"},
    {"dipendente", "dipendenti", "lavoratore", "busta", "cedolino", "stipendio", "paga"},
    {"detrazione", "detrazioni", "deduzione", "deduzioni", "sgravio", "bonus"},
    {"contributo", "contributi", "inps", "previdenza", "previdenziale", "contributiva"},
    {"ritenuta", "ritenute", "trattenuta", "trattenute"},
    {"dichiarazione", "dichiarazioni", "730", "redditi", "unico", "modello"},
    {"cliente", "contribuente", "intestatario", "titolare"},
    {"immobile", "immobili", "casa", "fabbricato", "abitazione", "imu"},
    {"mutuo", "finanziamento", "prestito", "interessi"},
]

# Indice rapido parola -> tutti i suoi sinonimi
_SINONIMI = {}
for _g in _GRUPPI_SINONIMI:
    for _w in _g:
        _SINONIMI.setdefault(_w, set()).update(_g)


def _tokenizza(testo: str) -> list:
    parole = re.findall(r"[a-zàèéìòóùA-Z0-9]{3,}", (testo or "").lower())
    return [p for p in parole if p not in _STOPWORDS]


def _espandi_sinonimi(chiavi: set) -> set:
    """Aggiunge alle parole della domanda i loro sinonimi fiscali."""
    espanse = set(chiavi)
    for k in chiavi:
        if k in _SINONIMI:
            espanse |= _SINONIMI[k]
    return espanse


def _candidati_fts(db, chiavi, limite_cand=400):
    """Id dei documenti candidati via FTS5 (OR delle parole+sinonimi, per rilevanza).
    None se FTS non è utilizzabile → il chiamante ricade sul caricamento completo."""
    from sqlalchemy import text
    toks = [re.sub(r"\W", "", k) for k in chiavi if k and len(k) >= 3]
    toks = [t for t in toks if t]
    if not toks:
        return None
    fq = " OR ".join(t + "*" for t in toks)
    try:
        rows = db.execute(text(
            "SELECT f.rowid FROM documents_fts f "
            "WHERE documents_fts MATCH :q ORDER BY rank LIMIT :lim"),
            {"q": fq, "lim": int(limite_cand)}).fetchall()
        return [r[0] for r in rows]
    except Exception:
        return None


def cerca_documenti(db, domanda: str, client_id=None, limite=6):
    """Ritorna i documenti piu' pertinenti alla domanda.
    Lista di dict: {doc, punteggio}."""
    from database import Document, Client

    chiavi_originali = set(_tokenizza(domanda))
    chiavi = _espandi_sinonimi(chiavi_originali)
    # Nomi dei clienti citati nella domanda (bonus di pertinenza)
    nomi_clienti = {}
    for c in db.query(Client).all():
        for parte in (c.cognome, c.nome):
            if parte and len(parte) >= 3:
                nomi_clienti[parte.lower()] = c.id

    # Recupero CANDIDATI con FTS5 (veloce, poca RAM) invece di caricare TUTTO.
    # Sui candidati gira poi il punteggio fine (sinonimi, bonus cliente).
    cand_ids = _candidati_fts(db, chiavi)
    q = db.query(Document).filter(Document.testo_estratto.isnot(None))
    if client_id:
        q = q.filter(Document.client_id == client_id)
    if cand_ids is not None:
        if not cand_ids:
            return []
        q = q.filter(Document.id.in_(cand_ids))
    documenti = q.all()

    # Raggruppa le parole per CONCETTO (parola originale + suoi sinonimi),
    # cosi' il bonus "piu' concetti diversi" non si gonfia con i sinonimi.
    concetti = [_SINONIMI.get(k, {k}) for k in chiavi_originali]

    dom_lower = domanda.lower()
    risultati = []
    for d in documenti:
        testo = (d.testo_estratto or "").lower()
        if not testo:
            continue
        meta = f"{d.tipo or ''} {d.nome_originale or ''} {d.client_nome or ''}".lower()
        punteggio = 0
        concetti_trovati = 0
        for gruppo in concetti:
            trovato_qui = False
            for k in gruppo:
                if k in testo:
                    # Conta poco la ripetizione: max 3 per parola, così un
                    # documento non vince solo perché ripete "2025" cento volte.
                    punteggio += min(testo.count(k), 3)
                    trovato_qui = True
                if k in meta:
                    punteggio += 5
            if trovato_qui:
                concetti_trovati += 1
        # Bonus forte se trova PIU' concetti diversi (pertinenza vera)
        if concetti_trovati >= 2:
            punteggio += concetti_trovati * 3
        # Bonus se la domanda nomina il cliente del documento
        for nome, cid in nomi_clienti.items():
            if nome in dom_lower and d.client_id == cid:
                punteggio += 15
        if punteggio > 0:
            risultati.append({"doc": d, "punteggio": punteggio})

    risultati.sort(key=lambda x: x["punteggio"], reverse=True)
    return risultati[:limite]


def _estratto_mirato(testo: str, chiavi, max_caratteri: int) -> str:
    """Ritorna una finestra di testo CENTRATA sulla prima parola chiave trovata
    (così la parte rilevante c'è anche se è in fondo al documento), invece dei
    soliti primi N caratteri. Meno token, risposta più pertinente."""
    testo = testo or ""
    if len(testo) <= max_caratteri:
        return testo
    low = testo.lower()
    pos = -1
    for k in (chiavi or ()):
        i = low.find(k)
        if i != -1 and (pos == -1 or i < pos):
            pos = i
    if pos == -1:
        return testo[:max_caratteri]            # nessuna chiave nel testo: testa
    start = max(0, pos - max_caratteri // 2)
    end = min(len(testo), start + max_caratteri)
    start = max(0, end - max_caratteri)
    return ("…" if start > 0 else "") + testo[start:end] + ("…" if end < len(testo) else "")


def costruisci_contesto(risultati, chiavi=None, max_caratteri_per_doc=1600) -> str:
    """Prepara il testo dei documenti trovati da dare all'AI (estratto MIRATO
    sulle parole della domanda → più corto e più pertinente)."""
    if not risultati:
        return ""
    blocchi = []
    for i, r in enumerate(risultati, 1):
        d = r["doc"]
        testo = _estratto_mirato(d.testo_estratto or "", chiavi, max_caratteri_per_doc)
        intestazione = (
            f"[DOCUMENTO {i}] "
            f"Nome: {d.nome_originale} | Tipo: {d.tipo or '-'} | "
            f"Anno: {d.anno_riferimento or '-'} | Cliente: {d.client_nome or '-'}"
        )
        blocchi.append(f"{intestazione}\n{testo}")
    return "\n\n".join(blocchi)


def costruisci_prompt(domanda: str, risultati) -> str:
    """Prompt completo per l'AI con i documenti pertinenti."""
    oggi = datetime.now().strftime("%d/%m/%Y")
    if not risultati:
        return (
            f"Data odierna: {oggi}.\n"
            "Il commercialista ha fatto questa domanda sull'archivio documenti, "
            "ma NON e' stato trovato alcun documento pertinente nell'archivio:\n\n"
            f"DOMANDA: {domanda}\n\n"
            "Spiega gentilmente che non hai trovato documenti che corrispondono e "
            "suggerisci come cercare meglio (es. nominare il cliente, il tipo di "
            "documento o l'anno), oppure di caricare il documento se manca."
        )
    chiavi = _espandi_sinonimi(set(_tokenizza(domanda)))
    contesto = costruisci_contesto(risultati, chiavi=chiavi)
    return (
        f"Data odierna: {oggi}.\n"
        "Sei il consulente AI dello studio. Rispondi alla domanda del commercialista "
        "basandoti ESCLUSIVAMENTE sui documenti dell'archivio qui sotto, numerati "
        "[DOCUMENTO 1], [DOCUMENTO 2], ... \n"
        "REGOLE:\n"
        "- Per OGNI informazione che usi, CITA la fonte col numero tra parentesi "
        "quadre subito dopo l'affermazione, es. [1] oppure [2][3].\n"
        "- Usa SOLO numeri di documenti realmente presenti qui sotto.\n"
        "- Se i documenti non bastano a rispondere, DILLO chiaramente e indica cosa "
        "manca: NON inventare dati non presenti nei documenti.\n\n"
        f"=== DOCUMENTI DELL'ARCHIVIO PERTINENTI ===\n{contesto}\n\n"
        f"=== DOMANDA DEL COMMERCIALISTA ===\n{domanda}"
    )


def fonti_numerate(risultati) -> list:
    """Elenco fonti NUMERATO ([n] usato nelle citazioni), per la UI."""
    out = []
    for i, r in enumerate(risultati, 1):
        d = r["doc"]
        out.append({
            "numero": i, "id": d.id, "nome": d.nome_originale, "tipo": d.tipo,
            "anno": d.anno_riferimento, "cliente": d.client_nome,
        })
    return out


def citazioni_in(risposta: str, n_docs: int) -> set:
    """Numeri [n] effettivamente citati nella risposta (validati 1..n_docs)."""
    nums = set()
    for m in re.findall(r"\[(\d{1,2})\]", risposta or ""):
        v = int(m)
        if 1 <= v <= n_docs:
            nums.add(v)
    return nums
