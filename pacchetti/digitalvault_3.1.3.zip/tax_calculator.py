"""
DigitalVault - Motore di calcolo fiscale REALE (deterministico).
Non sono stime dell'AI: sono calcoli esatti secondo la normativa italiana.

NB (Parte 2 affidabilità): per IRPEF e Forfettario la fonte di verità è ora il
motore versionato `fiscal_engine/` che legge `fiscal_reference/*.yaml`. Gli
endpoint usano quello. Le funzioni qui sotto restano per compatibilità, con le
costanti allineate al 2026 (2° scaglione 33%, non più 35%).
"""

# ─── IRPEF 2026 (3 scaglioni; 2° scaglione 33% dal 2026) ──────────────────────
# Fonte di verità: fiscal_reference/irpef.yaml. Qui allineato per coerenza.
SCAGLIONI_IRPEF_2025 = [
    (28000, 0.23),    # fino a 28.000 -> 23%
    (50000, 0.33),    # da 28.000 a 50.000 -> 33% (2026; era 35% nel 2024)
    (float("inf"), 0.43),  # oltre 50.000 -> 43%
]

# Coefficienti di redditività regime forfettario per gruppo ATECO
COEFFICIENTI_FORFETTARIO = {
    "Industrie alimentari e bevande (10-11)": 0.40,
    "Commercio ingrosso e dettaglio (45-46-47)": 0.40,
    "Commercio ambulante alimentari": 0.40,
    "Commercio ambulante altri prodotti": 0.54,
    "Costruzioni e immobiliare (41-42-43-68)": 0.86,
    "Intermediari del commercio (46.1)": 0.62,
    "Servizi alloggio e ristorazione (55-56)": 0.40,
    "Attivita' professionali e tecniche (64-65-66-69-70...)": 0.78,
    "Altre attivita' economiche": 0.67,
}


def calcola_irpef(reddito_imponibile: float) -> dict:
    """Calcola l'IRPEF lorda per scaglioni. Ritorna dettaglio completo."""
    reddito = max(0.0, float(reddito_imponibile))
    imposta = 0.0
    dettaglio = []
    precedente = 0.0
    for limite, aliquota in SCAGLIONI_IRPEF_2025:
        if reddito > precedente:
            base = min(reddito, limite) - precedente
            quota = base * aliquota
            imposta += quota
            dettaglio.append({
                "scaglione": f"{precedente:,.0f} - {('oltre' if limite==float('inf') else format(limite, ',.0f'))}".replace(",", "."),
                "aliquota": f"{int(aliquota*100)}%",
                "base_imponibile": round(base, 2),
                "imposta": round(quota, 2),
            })
            precedente = limite
        else:
            break
    aliquota_media = (imposta / reddito * 100) if reddito > 0 else 0
    return {
        "reddito_imponibile": round(reddito, 2),
        "irpef_lorda": round(imposta, 2),
        "aliquota_media": round(aliquota_media, 2),
        "dettaglio_scaglioni": dettaglio,
        "netto_stimato": round(reddito - imposta, 2),
    }


def calcola_forfettario(fatturato: float, coefficiente: float,
                        nuova_attivita: bool = False,
                        contributi_versati: float = 0.0) -> dict:
    """
    Calcola imposta sostitutiva regime forfettario.
    - coefficiente: redditivita' (es. 0.78 per professionisti)
    - nuova_attivita: True = 5% (primi 5 anni), False = 15%
    Il reddito forfettario (fatturato x coefficiente) serve SOLO per
    calcolare l'imposta: il netto reale si calcola sul fatturato incassato.
    """
    fatturato = max(0.0, float(fatturato))
    coefficiente = float(coefficiente)
    contributi = max(0.0, contributi_versati)
    reddito_forfettario = fatturato * coefficiente
    # I contributi previdenziali versati sono deducibili dall'imponibile
    imponibile = max(0.0, reddito_forfettario - contributi)
    aliquota = 0.05 if nuova_attivita else 0.15
    imposta = imponibile * aliquota
    return {
        "fatturato": round(fatturato, 2),
        "coefficiente_redditivita": coefficiente,
        "reddito_forfettario": round(reddito_forfettario, 2),
        # mantenuto per compatibilita' col vecchio nome
        "reddito_lordo": round(reddito_forfettario, 2),
        "contributi_dedotti": round(contributi, 2),
        "imponibile": round(imponibile, 2),
        "aliquota": f"{int(aliquota*100)}%",
        "imposta_sostitutiva": round(imposta, 2),
        # Netto reale: cio' che resta del fatturato dopo imposta e contributi
        "netto_stimato": round(fatturato - imposta - contributi, 2),
        "tipo": "Nuova attivita' (5%)" if nuova_attivita else "Regime ordinario forfettario (15%)",
    }


def calcola_inps_gestione_separata(reddito: float, aliquota: float = 0.2607) -> dict:
    """Contributi INPS Gestione Separata (professionisti senza cassa). Aliquota 2025 ~26,07%."""
    reddito = max(0.0, float(reddito))
    contributi = reddito * aliquota
    return {
        "reddito": round(reddito, 2),
        "aliquota": f"{aliquota*100:.2f}%",
        "contributi_inps": round(contributi, 2),
    }


def simulazione_completa_forfettario(fatturato: float, coefficiente: float,
                                     nuova_attivita: bool = False) -> dict:
    """Simulazione completa: reddito forfettario, INPS, imposta, netto finale.
    Il 'netto in tasca' e' il fatturato meno contributi e imposta: la parte di
    fatturato oltre il coefficiente non e' tassata ma resta comunque incassata."""
    fatturato = max(0.0, float(fatturato))
    reddito_forfettario = fatturato * coefficiente
    inps = calcola_inps_gestione_separata(reddito_forfettario)
    forf = calcola_forfettario(fatturato, coefficiente, nuova_attivita,
                               contributi_versati=inps["contributi_inps"])
    netto_finale = fatturato - inps["contributi_inps"] - forf["imposta_sostitutiva"]
    return {
        "fatturato": round(fatturato, 2),
        "reddito_forfettario": round(reddito_forfettario, 2),
        "reddito_lordo": round(reddito_forfettario, 2),
        "contributi_inps": inps["contributi_inps"],
        "imposta_sostitutiva": forf["imposta_sostitutiva"],
        "netto_in_tasca": round(netto_finale, 2),
        "percentuale_netto": round(netto_finale / fatturato * 100, 1) if fatturato > 0 else 0,
        "dettaglio": {"inps": inps, "imposta": forf},
    }
