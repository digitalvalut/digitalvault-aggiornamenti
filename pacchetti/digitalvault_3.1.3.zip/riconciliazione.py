"""
DigitalVault - Riconciliazione bancaria.
(c) 2026 DigitalVault - Capo Team del Progetto: Dr. Falsone Giuseppe

Confronta le FATTURE (importi attesi) con i MOVIMENTI di un estratto conto e
segnala cosa NON risulta incassato e i movimenti non abbinati ad alcuna
fattura. Fa risparmiare ore di controllo manuale al commercialista.

- L'estratto conto (testo, anche da scansione OCR) viene letto dall'AI che ne
  estrae i movimenti (data, importo con segno, descrizione).
- L'abbinamento fattura<->movimento è DETERMINISTICO (per importo, con
  tolleranza, premiando la corrispondenza del nome controparte): affidabile e
  spiegabile, niente "magia" dell'AI sui numeri.
"""
import re

import ai_client
from validazione_importi import numeri_nel_testo, MAX_IMPORTO

_SYSTEM = ("Sei un estrattore di movimenti bancari da estratti conto italiani. "
           "Rispondi ESCLUSIVAMENTE con JSON valido, senza testo attorno.")


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


async def estrai_movimenti(testo_estratto: str) -> list:
    """Legge l'estratto conto e restituisce la lista dei movimenti:
    [{data, importo (segno: + accredito / - addebito), descrizione}]."""
    if not testo_estratto or len(testo_estratto.strip()) < 15:
        return []
    prompt = (
        "Estrai TUTTI i movimenti da questo estratto conto bancario. "
        'Restituisci JSON: {"movimenti": [{"data": "GG/MM/AAAA", '
        '"importo": numero con segno (positivo se ACCREDITO/entrata, negativo '
        'se ADDEBITO/uscita), "descrizione": "causale"}]}. '
        "Usa il punto come separatore decimale. Niente testo fuori dal JSON.\n\n"
        f"[ESTRATTO CONTO]\n{testo_estratto[:8000]}"
    )
    try:
        d = await ai_client.chat_json(prompt, system=_SYSTEM)
    except Exception:
        return []
    movimenti = d.get("movimenti") if isinstance(d, dict) else None
    if not isinstance(movimenti, list):
        return []
    # Cross-check (Fase D): i numeri realmente presenti nell'estratto conto.
    nums = numeri_nel_testo(testo_estratto)
    puliti = []
    for m in movimenti:
        try:
            imp = float(str(m.get("importo")).replace(",", ".").replace("€", "").strip())
        except (ValueError, TypeError, AttributeError):
            continue
        # Un movimento è "da verificare" se il suo importo (in valore assoluto)
        # non compare nell'estratto o è fuori scala: possibile errore di lettura AI.
        absimp = abs(imp)
        da_verificare = absimp > MAX_IMPORTO
        if nums and not any(abs(n - absimp) <= max(0.02, absimp * 0.001) for n in nums):
            da_verificare = True
        puliti.append({"data": m.get("data") or "", "importo": imp,
                       "descrizione": m.get("descrizione") or "",
                       "da_verificare": da_verificare})
    return puliti


def riconcilia(fatture: list, movimenti: list, tolleranza: float = 0.02) -> dict:
    """Abbina le fatture ai movimenti in ENTRATA (accrediti).
    `fatture`   = [{id, nome, controparte, importo, anno}]
    `movimenti` = [{data, importo, descrizione}]
    Ritorna report con fatture incassate/non incassate e movimenti non abbinati.
    """
    accrediti = [dict(m, _usato=False) for m in movimenti if (m.get("importo") or 0) > 0]
    risultati = []
    n_incassate = 0
    tot_fatturato = 0.0
    tot_incassato = 0.0

    for f in fatture:
        imp = f.get("importo")
        if imp is None:
            continue
        tot_fatturato += imp
        contro = _norm(f.get("controparte") or "")
        candidato = None
        # 1) match per importo + nome controparte nella causale (più sicuro)
        for m in accrediti:
            if m["_usato"]:
                continue
            if abs(m["importo"] - imp) <= max(tolleranza, imp * 0.01):
                if contro and contro in _norm(m["descrizione"]):
                    candidato = m
                    break
        # 2) altrimenti match solo per importo
        if candidato is None:
            for m in accrediti:
                if not m["_usato"] and abs(m["importo"] - imp) <= max(tolleranza, imp * 0.01):
                    candidato = m
                    break
        if candidato is not None:
            candidato["_usato"] = True
            n_incassate += 1
            tot_incassato += imp
            risultati.append({**{k: f.get(k) for k in ("id", "nome", "controparte", "importo", "anno")},
                              "stato": "incassata",
                              "movimento": {"data": candidato["data"],
                                            "descrizione": candidato["descrizione"]}})
        else:
            risultati.append({**{k: f.get(k) for k in ("id", "nome", "controparte", "importo", "anno")},
                              "stato": "non_incassata", "movimento": None})

    non_abbinati = [{"data": m["data"], "importo": m["importo"], "descrizione": m["descrizione"]}
                    for m in accrediti if not m["_usato"]]
    movimenti_da_verificare = sum(1 for m in movimenti if m.get("da_verificare"))
    return {
        "fatture": risultati,
        "totale_fatture": len(fatture),
        "incassate": n_incassate,
        "non_incassate": len(risultati) - n_incassate,
        "totale_fatturato": round(tot_fatturato, 2),
        "totale_incassato": round(tot_incassato, 2),
        "da_incassare": round(tot_fatturato - tot_incassato, 2),
        "movimenti_non_abbinati": non_abbinati,
        "movimenti_da_verificare": movimenti_da_verificare,
    }
