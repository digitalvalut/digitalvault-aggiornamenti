"""
DigitalVault - Sistema di BACKUP automatico (i dati non si perdono MAI).
(c) 2026 DigitalVault Team - Dr. Falsone Giuseppe

Cosa fa:
- Salva una copia COMPLETA di: database (clienti, documenti, chat, scadenze,
  impostazioni) + tutti i file caricati (uploads/).
- La copia e' CIFRATA (AES tramite Fernet): chi trova lo zip senza la chiave
  non legge nulla.
- DOPPIA DESTINAZIONE: una copia sull'SSD e una sul computer del
  commercialista. Se muore l'SSD, i dati sono sul PC; se muore il PC, sono
  sull'SSD.
- QUANDO: all'avvio del programma E automaticamente ogni poche ore mentre
  e' aperto (cosi' chi non riavvia mai ha comunque copie fresche).
- ROTAZIONE: tiene le ultime 10 copie per destinazione (le piu' vecchie
  vengono cancellate da sole).
- RIPRISTINO: si sceglie una data e si torna indietro nel tempo.

Sicurezza del database: si usa l'API di backup di SQLite (copia a caldo
coerente), quindi il file non si corrompe nemmeno se l'app sta scrivendo.

Sicurezza della chiave: la chiave di cifratura e' DERIVATA dal numero di
serie dell'SSD (non viene salvata in chiaro accanto ai backup). Un backup
copiato su un altro disco/PC non e' leggibile. Il ripristino funziona
comunque cambiando solo il computer, perche' la chiave dipende dall'SSD.
"""
import io
import json
import os
import shutil
import sqlite3
import zipfile
from datetime import datetime
from pathlib import Path

from config import BASE_DIR, DATA_DIR, DB_PATH, UPLOAD_DIR

try:
    import base64
    import hashlib
    from cryptography.fernet import Fernet
    _CRYPTO = True
except Exception:
    _CRYPTO = False

# Destinazioni dei backup
SSD_BACKUP_DIR = BASE_DIR / "backups"
PC_BACKUP_DIR = Path.home() / "DigitalVault_Backup"
KEY_FILE = DATA_DIR / "backup.key"          # vecchia chiave casuale (solo per migrazione)
STATUS_FILE = DATA_DIR / "backup_status.json"

EXT = ".dvb"          # DigitalVault Backup
MAX_PER_DEST = 10     # quante copie tenere per destinazione
ORE_TRA_BACKUP = 3    # ogni quante ore fare il backup automatico mentre e' aperto


def _destinazioni() -> list:
    dirs = []
    for d in (SSD_BACKUP_DIR, PC_BACKUP_DIR):
        try:
            d.mkdir(parents=True, exist_ok=True)
            dirs.append(d)
        except Exception:
            pass
    return dirs


def _derived_key() -> bytes:
    """Chiave di cifratura DERIVATA dal numero di serie dell'SSD (+ segreto del
    titolare). NON viene salvata da nessuna parte: si ricalcola ogni volta.

    Conseguenze:
    - Un backup copiato su un ALTRO disco/PC NON e' decifrabile (serial diverso).
    - Il recupero funziona comunque se cambi solo il PC: la chiave dipende
      dall'SSD, non dal computer. Basta l'SSD per ripristinare ovunque.
    """
    if not _CRYPTO:
        return None
    try:
        import license_manager
        serial = license_manager.get_volume_id()
        if not serial or serial == "NOVOLUME":
            return None  # serial non rilevabile: si usa la chiave di scorta
        # Derivazione DETERMINISTICA dal solo serial dell'SSD (KDF scrypt).
        # Niente dipendenze da segreti rimossi: la chiave si ricalcola sempre,
        # quindi i backup restano ripristinabili finché si ha l'SSD (anche se
        # il file backup.key viene perso o rigenerato).
        material = serial.encode() + b"|DGV-BACKUP-v2"
        dk = hashlib.scrypt(material, salt=b"DGV-BACKUP-v2", n=2 ** 14, r=8, p=1, dklen=32)
        return base64.urlsafe_b64encode(dk)
    except Exception:
        return None


def _legacy_key() -> bytes:
    """Vecchia chiave casuale salvata su file: serve SOLO a leggere i backup
    creati prima di questo aggiornamento (migrazione trasparente)."""
    if not _CRYPTO:
        return None
    if KEY_FILE.exists():
        try:
            return KEY_FILE.read_bytes().strip()
        except Exception:
            return None
    return None


def _fallback_key() -> bytes:
    """Chiave di scorta su file, usata solo se il serial dell'SSD non e'
    rilevabile (es. alcune chiavette). Resta sull'SSD, non viene replicata."""
    if not _CRYPTO:
        return None
    if KEY_FILE.exists():
        return _legacy_key()
    key = Fernet.generate_key()
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    KEY_FILE.write_bytes(key)
    return key


def _encryption_key() -> bytes:
    """Chiave con cui CIFRARE i nuovi backup: prima quella legata all'SSD,
    altrimenti la chiave di scorta su file."""
    return _derived_key() or _fallback_key()


def _candidate_keys() -> list:
    """Chiavi da provare per DECIFRARE (nuova derivata + eventuale vecchia),
    cosi' i backup creati prima dell'aggiornamento restano leggibili."""
    keys = []
    for k in (_derived_key(), _legacy_key()):
        if k and k not in keys:
            keys.append(k)
    return keys


def _pulisci_chiavi_esposte():
    """Rimuove eventuali copie della chiave finite ACCANTO ai backup dalla
    vecchia versione: la' erano un rischio (chiave + backup nello stesso posto)."""
    for d in (SSD_BACKUP_DIR, PC_BACKUP_DIR):
        kf = d / "backup.key"
        try:
            if kf.exists():
                kf.unlink()
        except Exception:
            pass


def _snapshot_db() -> bytes:
    """Copia COERENTE del database usando l'API di backup di SQLite,
    sicura anche se l'app sta scrivendo (gestisce il WAL)."""
    if not Path(DB_PATH).exists():
        return b""
    tmp = DATA_DIR / "_snap_tmp.db"
    src = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True)
    dst = sqlite3.connect(str(tmp))
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    data = tmp.read_bytes()
    tmp.unlink(missing_ok=True)
    return data


def _crea_zip() -> bytes:
    """Crea in memoria lo zip con database + uploads + manifest."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        db_bytes = _snapshot_db()
        if db_bytes:
            z.writestr("digitalvault.db", db_bytes)
        if UPLOAD_DIR.exists():
            for f in UPLOAD_DIR.rglob("*"):
                if f.is_file() and not f.name.startswith("temp_ocr_"):
                    z.write(f, arcname=f"uploads/{f.relative_to(UPLOAD_DIR)}")
        manifest = {
            "creato_il": datetime.now().isoformat(),
            "app": "FiscoSicuro by DigitalVault",
            "versione_backup": 1,
        }
        z.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    return buf.getvalue()


def _leggi_status() -> dict:
    if STATUS_FILE.exists():
        try:
            return json.loads(STATUS_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def _scrivi_status(d: dict):
    try:
        STATUS_FILE.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def _ruota(dest: Path):
    """Tiene solo gli ultimi MAX_PER_DEST backup nella cartella."""
    files = sorted(dest.glob(f"*{EXT}"), key=lambda p: p.stat().st_mtime, reverse=True)
    for vecchio in files[MAX_PER_DEST:]:
        try:
            vecchio.unlink()
        except Exception:
            pass


def esegui_backup(motivo: str = "manuale") -> dict:
    """Crea un backup e lo salva in tutte le destinazioni disponibili."""
    nome = f"digitalvault_backup_{datetime.now():%Y%m%d_%H%M%S}{EXT}"
    try:
        _pulisci_chiavi_esposte()
        raw = _crea_zip()
        key = _encryption_key()
        blob = Fernet(key).encrypt(raw) if (_CRYPTO and key) else raw
    except Exception as e:
        status = _leggi_status()
        status["ultimo_esito"] = {"ok": False, "errore": str(e),
                                  "quando": datetime.now().isoformat(), "motivo": motivo}
        _scrivi_status(status)
        return {"ok": False, "errore": str(e)}

    salvati = []
    for dest in _destinazioni():
        try:
            (dest / nome).write_bytes(blob)
            _ruota(dest)
            salvati.append(str(dest))
        except Exception:
            pass

    esito = {
        "ok": bool(salvati),
        "nome": nome,
        "destinazioni": salvati,
        "cifrato": bool(_CRYPTO),
        "dimensione": len(blob),
        "quando": datetime.now().isoformat(),
        "motivo": motivo,
    }
    status = _leggi_status()
    status["ultimo_esito"] = esito
    status["ultimo_ok"] = esito["quando"] if esito["ok"] else status.get("ultimo_ok")
    _scrivi_status(status)
    return esito


def elenco_backup() -> list:
    """Tutti i backup disponibili (uniti dalle due destinazioni, senza duplicati)."""
    visti = {}
    for dest in _destinazioni():
        for f in dest.glob(f"*{EXT}"):
            info = visti.get(f.name)
            posizione = "SSD" if dest == SSD_BACKUP_DIR else "PC"
            if info:
                info["posizioni"].append(posizione)
            else:
                visti[f.name] = {
                    "nome": f.name,
                    "data": datetime.fromtimestamp(f.stat().st_mtime).isoformat(),
                    "dimensione": f.stat().st_size,
                    "posizioni": [posizione],
                }
    return sorted(visti.values(), key=lambda x: x["data"], reverse=True)


def _trova_file(nome: str) -> Path:
    for dest in _destinazioni():
        p = dest / nome
        if p.exists():
            return p
    return None


def _ripristina_zip(raw: bytes):
    """Estrae database + uploads da uno zip di backup (logica condivisa fra il
    ripristino normale e quello da backup protetto-password)."""
    with zipfile.ZipFile(io.BytesIO(raw), "r") as z:
        names = z.namelist()
        if "digitalvault.db" in names:
            for ext in ("", "-wal", "-shm"):
                f = Path(str(DB_PATH) + ext)
                if f.exists():
                    try:
                        f.unlink()
                    except Exception:
                        pass
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            Path(DB_PATH).write_bytes(z.read("digitalvault.db"))
        if UPLOAD_DIR.exists():
            for f in UPLOAD_DIR.iterdir():
                try:
                    if f.is_file():
                        f.unlink()
                    elif f.is_dir():
                        shutil.rmtree(f)
                except Exception:
                    pass
        UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
        for n in names:
            if n.startswith("uploads/") and not n.endswith("/"):
                target = UPLOAD_DIR / n[len("uploads/"):]
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(z.read(n))


def ripristina_backup(nome: str) -> dict:
    """Ripristina i dati da un backup. Prima salva lo stato attuale in un
    backup di emergenza, cosi' anche un ripristino sbagliato e' annullabile."""
    p = _trova_file(nome)
    if not p:
        return {"ok": False, "errore": "Backup non trovato."}

    # Rete di sicurezza: salva lo stato attuale prima di sovrascrivere
    try:
        esegui_backup(motivo="pre-ripristino")
    except Exception:
        pass

    try:
        blob = p.read_bytes()
        if _CRYPTO:
            raw = None
            # Prova le chiavi disponibili (nuova legata all'SSD + vecchia)
            for key in _candidate_keys():
                try:
                    raw = Fernet(key).decrypt(blob)
                    break
                except Exception:
                    continue
            if raw is None:
                # Non decifrabile con nessuna chiave: o e' un backup di un
                # ALTRO SSD, oppure un vecchio backup non cifrato.
                try:
                    zipfile.ZipFile(io.BytesIO(blob)).namelist()
                    raw = blob  # era gia' uno zip in chiaro (vecchissimo formato)
                except Exception:
                    return {"ok": False, "errore":
                            "Questo backup non appartiene a questo SSD e non puo' essere "
                            "decifrato qui (protezione anti-copia)."}
        else:
            raw = blob

        _ripristina_zip(raw)
        return {"ok": True, "nome": nome,
                "nota": "Dati ripristinati. Riavvia il programma per essere sicuro che tutto sia ricaricato."}
    except Exception as e:
        return {"ok": False, "errore": str(e)}


# ============================================================================
#  COPIA IN CHIARO SUL PC — la rete di salvataggio "copia e incolla".
#  Nessuna password, nessuna dipendenza dall'SSD: si copia su un disco nuovo
#  e i dati ci sono SUBITO. (Il commercialista sceglie di tenerla sul SUO PC.)
# ============================================================================
PC_PLAIN_DIR = Path.home() / "DigitalVault_DatiPC"

# Campi cifrati a riposo, da DECIFRARE nella copia in chiaro (tabella -> colonne)
_CAMPI_CIFRATI = {
    "clients": ["email", "telefono", "indirizzo", "note"],
    "documents": ["note", "dati_estratti", "controparte"],
    "chat_messages": ["content"],
}


def esporta_chiaro(dest_dir=None) -> dict:
    """Copia COMPLETA e IN CHIARO dei dati sul PC: database coi campi DECIFRATI
    + tutti i file caricati. Serve come recupero a prova di disastro: se l'SSD
    si rompe, si copia questa cartella in un SSD nuovo e i dati sono già lì
    (nessuna password, nessun serial: 'copia e incolla' funziona ovunque)."""
    import db_crypto
    dest = Path(dest_dir) if dest_dir else PC_PLAIN_DIR
    try:
        dest.mkdir(parents=True, exist_ok=True)
        # 1) snapshot coerente del database (gestisce il WAL)
        snap = DATA_DIR / "_plain_tmp.db"
        src = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True)
        dst = sqlite3.connect(str(snap))
        try:
            src.backup(dst)
        finally:
            dst.close(); src.close()
        # 2) decifra i campi sensibili NELLA COPIA (l'originale non si tocca)
        con = sqlite3.connect(str(snap))
        try:
            for tabella, colonne in _CAMPI_CIFRATI.items():
                try:
                    righe = con.execute(
                        f"SELECT id, {', '.join(colonne)} FROM {tabella}").fetchall()
                except Exception:
                    continue  # tabella/colonna assente: salta
                set_ = ", ".join(f"{c}=?" for c in colonne)
                for r in righe:
                    valori = [db_crypto.decifra(v) for v in r[1:]]
                    con.execute(f"UPDATE {tabella} SET {set_} WHERE id=?", (*valori, r[0]))
            con.commit()
        finally:
            con.close()
        # 3) scrivi il db in chiaro nella destinazione + copia gli uploads
        (dest / "digitalvault.db").write_bytes(snap.read_bytes())
        snap.unlink(missing_ok=True)
        up_dest = dest / "uploads"
        if up_dest.exists():
            shutil.rmtree(up_dest, ignore_errors=True)
        if UPLOAD_DIR.exists():
            shutil.copytree(UPLOAD_DIR, up_dest,
                            ignore=shutil.ignore_patterns("temp_ocr_*"))
        # 4) istruzioni semplici per il commercialista
        (dest / "LEGGIMI.txt").write_text(
            "COPIA COMPLETA E IN CHIARO DEI TUOI DATI DIGITALVAULT\n"
            "=====================================================\n\n"
            "Se l'SSD si rompe o si perde:\n"
            "  1) Procurati un nuovo SSD con DigitalVault.\n"
            "  2) Copia il file 'digitalvault.db' qui dentro nella cartella\n"
            "     MOTORE\\data del nuovo SSD (sovrascrivi quello vuoto).\n"
            "  3) Copia la cartella 'uploads' qui dentro dentro MOTORE.\n"
            "  4) Avvia DigitalVault: tutti i tuoi clienti e documenti sono lì.\n\n"
            "Questa copia NON ha password: tienila in un posto tuo e sicuro.\n",
            encoding="utf-8")
        return {"ok": True, "cartella": str(dest),
                "db_presente": (dest / "digitalvault.db").exists(),
                "quando": datetime.now().isoformat()}
    except Exception as e:
        return {"ok": False, "errore": str(e)}


def ripristina_da_cartella(src_dir) -> dict:
    """Ripristina i dati da una copia IN CHIARO (cartella creata da esporta_chiaro
    o copiata a mano). Prima salva lo stato attuale (annullabile)."""
    src = Path(src_dir)
    db_file = src / "digitalvault.db"
    if not db_file.exists():
        return {"ok": False, "errore": "Nella cartella manca 'digitalvault.db'."}
    try:
        esegui_backup(motivo="pre-ripristino")
    except Exception:
        pass
    try:
        for ext in ("", "-wal", "-shm"):
            f = Path(str(DB_PATH) + ext)
            if f.exists():
                try:
                    f.unlink()
                except Exception:
                    pass
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        Path(DB_PATH).write_bytes(db_file.read_bytes())
        up_src = src / "uploads"
        if up_src.exists():
            if UPLOAD_DIR.exists():
                shutil.rmtree(UPLOAD_DIR, ignore_errors=True)
            shutil.copytree(up_src, UPLOAD_DIR,
                            ignore=shutil.ignore_patterns("temp_ocr_*"))
        return {"ok": True,
                "nota": "Dati ripristinati dalla copia. Riavvia il programma."}
    except Exception as e:
        return {"ok": False, "errore": str(e)}


# ============================================================================
#  BACKUP PORTATILE PROTETTO DA PASSWORD (la password del commercialista).
#  Si ripristina su QUALSIASI dispositivo conoscendo la password: la chiave
#  NON dipende dall'SSD. Il file porta con sé il proprio 'sale' crittografico.
# ============================================================================
_PW_MAGIC = b"DGVPWB1\n"


def _key_da_password(password: str, salt: bytes) -> bytes:
    dk = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2 ** 14, r=8, p=1, dklen=32)
    return base64.urlsafe_b64encode(dk)


def esporta_protetto(password: str, dest_file=None) -> dict:
    """Crea un backup PORTATILE protetto dalla password del commercialista."""
    if not _CRYPTO:
        return {"ok": False, "errore": "Cifratura non disponibile."}
    if not password or len(password) < 4:
        return {"ok": False, "errore": "Password troppo corta (minimo 4 caratteri)."}
    try:
        raw = _crea_zip()
        salt = os.urandom(16)
        key = _key_da_password(password, salt)
        blob = _PW_MAGIC + salt + Fernet(key).encrypt(raw)
        if dest_file is None:
            PC_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            dest_file = PC_BACKUP_DIR / f"digitalvault_protetto_{datetime.now():%Y%m%d_%H%M%S}{EXT}"
        dest_file = Path(dest_file)
        dest_file.write_bytes(blob)
        return {"ok": True, "file": str(dest_file), "dimensione": len(blob)}
    except Exception as e:
        return {"ok": False, "errore": str(e)}


def ripristina_protetto(file_path, password: str) -> dict:
    """Ripristina da un backup protetto-password (anche di un ALTRO SSD/PC)."""
    if not _CRYPTO:
        return {"ok": False, "errore": "Cifratura non disponibile."}
    p = Path(file_path)
    if not p.exists():
        return {"ok": False, "errore": "File non trovato."}
    try:
        data = p.read_bytes()
        if not data.startswith(_PW_MAGIC):
            return {"ok": False, "errore": "Questo non è un backup protetto da password."}
        off = len(_PW_MAGIC)
        salt, blob = data[off:off + 16], data[off + 16:]
        key = _key_da_password(password, salt)
        try:
            raw = Fernet(key).decrypt(blob)
        except Exception:
            return {"ok": False, "errore": "Password errata: impossibile aprire il backup."}
        try:
            esegui_backup(motivo="pre-ripristino")
        except Exception:
            pass
        _ripristina_zip(raw)
        return {"ok": True, "nota": "Dati ripristinati dal backup protetto. Riavvia il programma."}
    except Exception as e:
        return {"ok": False, "errore": str(e)}


def stato_backup() -> dict:
    status = _leggi_status()
    backups = elenco_backup()
    ultimo = backups[0] if backups else None
    legata_ssd = _derived_key() is not None
    return {
        "cifratura_attiva": bool(_CRYPTO),
        "ogni_ore": ORE_TRA_BACKUP,
        "chiave_legata_ssd": legata_ssd,
        "protezione": "Backup cifrati e legati a questo SSD: una copia su un altro disco non e' leggibile."
                      if legata_ssd else
                      "Backup cifrati con chiave su questo SSD.",
        "numero_backup": len(backups),
        "ultimo_backup": ultimo,
        "ultimo_esito": status.get("ultimo_esito"),
        "destinazioni": {
            "ssd": str(SSD_BACKUP_DIR),
            "pc": str(PC_BACKUP_DIR),
            "pc_chiaro": str(PC_PLAIN_DIR),
        },
    }


def avvia_backup_automatico():
    """Fa subito un backup all'avvio, poi lo ripete ogni ORE_TRA_BACKUP ore
    finche' il programma resta aperto. Gira in un thread separato, in
    silenzio: non disturba mai l'uso del programma."""
    import threading
    import time

    def _loop():
        # Primo backup poco dopo l'avvio (cifrato sull'SSD/PC + copia in chiaro sul PC)
        try:
            esegui_backup("avvio")
        except Exception:
            pass
        try:
            esporta_chiaro()       # rete "copia e incolla" sempre aggiornata sul PC
        except Exception:
            pass
        # Poi a intervalli regolari
        while True:
            time.sleep(ORE_TRA_BACKUP * 3600)
            try:
                esegui_backup("automatico")
            except Exception:
                pass
            try:
                esporta_chiaro()
            except Exception:
                pass

    threading.Thread(target=_loop, daemon=True).start()
