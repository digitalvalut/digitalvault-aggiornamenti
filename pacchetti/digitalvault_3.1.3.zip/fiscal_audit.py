"""
DigitalVault - Audit log dei calcoli fiscali (Fase H del Brief affidabilità).
(c) 2026 DigitalVault - Capo Team del Progetto: Dr. Falsone Giuseppe

Persiste ogni calcolo deterministico del motore fiscale, così che ogni numero
prodotto sia ricostruibile a posteriori: con quali input, quali costanti, quale
versione dei dati di riferimento e quando. Non blocca mai il calcolo: se la
scrittura dell'audit fallisce, si limita a loggare e prosegue.
"""
import json


def registra(db, funzione: str, input_dati: dict, output_dati: dict,
             fonte: str = None, versione_dati: str = None,
             costanti: dict = None, esito: str = "ok", modello_ai: str = None) -> None:
    """Scrive una riga di audit per un calcolo fiscale. Robusto: non solleva."""
    try:
        from database import FiscalAudit
        riga = FiscalAudit(
            funzione=funzione[:60],
            esito=(esito or "ok")[:20],
            input_json=json.dumps(input_dati, ensure_ascii=False, default=str) if input_dati is not None else None,
            output_json=json.dumps(output_dati, ensure_ascii=False, default=str) if output_dati is not None else None,
            costanti_json=json.dumps(costanti, ensure_ascii=False, default=str) if costanti else None,
            fonte=(fonte or "")[:200] or None,
            versione_dati=(versione_dati or "")[:40] or None,
            modello_ai=(modello_ai or "")[:60] or None,
        )
        db.add(riga)
        db.commit()
    except Exception as e:
        try:
            db.rollback()
        except Exception:
            pass
        print(f"[fiscal_audit] impossibile registrare il calcolo '{funzione}': {e}")


def ultimi(db, limite: int = 100) -> list:
    """Ritorna le ultime righe di audit (per consultazione/contestazioni)."""
    from database import FiscalAudit
    righe = db.query(FiscalAudit).order_by(FiscalAudit.created_at.desc()).limit(limite).all()
    out = []
    for r in righe:
        out.append({
            "id": r.id, "created_at": r.created_at.isoformat() if r.created_at else None,
            "funzione": r.funzione, "esito": r.esito,
            "fonte": r.fonte, "versione_dati": r.versione_dati,
            "modello_ai": r.modello_ai,
            "input": json.loads(r.input_json) if r.input_json else None,
            "output": json.loads(r.output_json) if r.output_json else None,
            "costanti": json.loads(r.costanti_json) if r.costanti_json else None,
        })
    return out
