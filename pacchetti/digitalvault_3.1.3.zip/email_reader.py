"""
DigitalVault - Lettura automatica della posta in entrata (PEC / email).
(c) 2026 DigitalVault - Capo Team del Progetto: Dr. Falsone Giuseppe

Si collega alla casella (IMAP), scarica gli ALLEGATI utili (PDF, immagini,
fatture) e li inserisce nell'archivio come documenti. Da lì il motore di
classificazione in background (vedi classifica_coda) li riconosce e li abbina
al cliente da solo. Risultato: la posta si "svuota" nell'archivio senza lavoro
manuale.

Sicurezza: salva SOLO allegati con estensioni consentite; non esegue nulla.
La password della casella resta nelle impostazioni locali, sul disco dello
studio (come la configurazione email per l'invio).
"""
import imaplib
import email
import uuid
from email.header import decode_header, make_header
from pathlib import Path

from config import UPLOAD_DIR

# Estensioni di allegati che ha senso archiviare
_ALLOWED = {".pdf", ".png", ".jpg", ".jpeg", ".txt", ".csv", ".xlsx", ".docx", ".xml", ".p7m"}


def _decodifica(intestazione: str) -> str:
    try:
        return str(make_header(decode_header(intestazione or "")))
    except Exception:
        return intestazione or ""


def _estrai_testo(percorso: Path, ext: str) -> str:
    try:
        if ext == ".pdf":
            from pdf_processor import extract_text_from_pdf
            return extract_text_from_pdf(str(percorso)) or ""
        if ext in (".txt", ".csv"):
            return percorso.read_text(encoding="utf-8", errors="replace")
    except Exception:
        pass
    return ""


def salva_allegati(db, msg, mittente: str, oggetto: str) -> list:
    """Salva gli allegati utili di UN messaggio come documenti dell'archivio.
    Ritorna la lista dei documenti creati. Non blocca su un allegato difettoso."""
    from database import Document
    from pdf_processor import detect_document_type

    creati = []
    for part in msg.walk():
        if part.get_content_maintype() == "multipart":
            continue
        if part.get("Content-Disposition") is None and not part.get_filename():
            continue
        nome = _decodifica(part.get_filename() or "")
        if not nome:
            continue
        ext = Path(nome).suffix.lower()
        if ext not in _ALLOWED:
            continue
        try:
            dati = part.get_payload(decode=True)
            if not dati:
                continue
            unique = f"{uuid.uuid4()}{ext}"
            percorso = UPLOAD_DIR / unique
            percorso.write_bytes(dati)
            testo = _estrai_testo(percorso, ext)
            tipo = detect_document_type(testo, nome)
            stato = "in_coda" if (testo and testo.strip()) else "non_classificato"
            doc = Document(
                nome_file=unique, nome_originale=nome, tipo=tipo,
                testo_estratto=testo, dimensione=len(dati),
                note=f"Da posta: {mittente} — {oggetto}"[:500],
                stato_classifica=stato,
            )
            db.add(doc)
            db.commit()
            db.refresh(doc)
            creati.append({"id": doc.id, "nome": nome, "tipo": tipo, "in_coda": stato == "in_coda"})
        except Exception as e:
            db.rollback()
            print(f"[email_reader] allegato '{nome}' saltato: {e}")
    return creati


def _connetti(cfg: dict):
    host = cfg.get("imap_host") or cfg.get("host")
    port = int(cfg.get("imap_port") or 993)
    user = cfg.get("user") or cfg.get("email")
    pwd = cfg.get("password")
    if not (host and user and pwd):
        raise ValueError("Configurazione PEC incompleta (host, utente, password).")
    M = imaplib.IMAP4_SSL(host, port)
    M.login(user, pwd)
    return M


def prova_connessione(cfg: dict) -> dict:
    """Verifica che i dati della casella siano corretti, senza scaricare nulla."""
    try:
        M = _connetti(cfg)
        M.select(cfg.get("cartella") or "INBOX")
        M.logout()
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "errore": str(e)}


def leggi(cfg: dict, max_messaggi: int = 30, solo_non_letti: bool = True) -> dict:
    """Si collega alla casella e archivia gli allegati dei messaggi.
    Apre una propria sessione DB. Ritorna un riepilogo."""
    from database import SessionLocal
    import classifica_coda

    try:
        M = _connetti(cfg)
    except Exception as e:
        return {"ok": False, "errore": str(e)}

    salvati_tot = 0
    messaggi_letti = 0
    db = SessionLocal()
    try:
        M.select(cfg.get("cartella") or "INBOX")
        criterio = "(UNSEEN)" if solo_non_letti else "ALL"
        tipo, dati = M.search(None, criterio)
        ids = dati[0].split() if dati and dati[0] else []
        ids = ids[-max_messaggi:]  # i più recenti
        for num in ids:
            tipo, raw = M.fetch(num, "(RFC822)")
            if tipo != "OK" or not raw or not raw[0]:
                continue
            msg = email.message_from_bytes(raw[0][1])
            mittente = _decodifica(msg.get("From"))
            oggetto = _decodifica(msg.get("Subject"))
            creati = salva_allegati(db, msg, mittente, oggetto)
            salvati_tot += len(creati)
            messaggi_letti += 1
        if salvati_tot:
            classifica_coda.assicura_avvio()  # avvia la classificazione in background
    finally:
        db.close()
        try:
            M.logout()
        except Exception:
            pass
    return {"ok": True, "messaggi_letti": messaggi_letti, "documenti_salvati": salvati_tot}
