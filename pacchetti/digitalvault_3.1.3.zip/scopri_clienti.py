"""
DigitalVault - SCOPRI CLIENTI nei documenti (anagrafiche automatiche).
(c) 2026 DigitalVault Team - Dr. Falsone Giuseppe

Il programma ha gia' letto fatture elettroniche, scansioni e PDF: dentro ci
sono nomi, codici fiscali, P.IVA, email e telefoni. Questo modulo li tira
fuori e li propone al commercialista:

    "Ho trovato N possibili clienti nei tuoi documenti.
     Spunta quelli da inserire: si compilano da soli."

NIENTE viene inserito senza conferma (revisione umana sempre).
Bonus: quando un cliente viene creato, i documenti da cui e' saltato fuori
vengono AGGANCIATI a lui automaticamente.
"""
import re

import validators

# Codice fiscale persona fisica (tollera i caratteri-mese delle omocodie)
_RE_CF = re.compile(r"\b[A-Z]{6}[0-9LMNPQRSTUV]{2}[A-Z][0-9LMNPQRSTUV]{2}[A-Z][0-9LMNPQRSTUV]{3}[A-Z]\b")
_RE_PIVA = re.compile(r"\b\d{11}\b")
_RE_EMAIL = re.compile(r"\b[\w.\-+]+@[\w.\-]+\.[a-zA-Z]{2,}\b")
# Telefono: richiede un separatore (spazio/punto/trattino) o il prefisso +39,
# così NON cattura le Partite IVA (11 cifre tutte attaccate).
_RE_TEL = re.compile(
    r"\+39[\s.]?\d[\d\s./-]{7,12}\d"
    r"|\b0\d{1,3}[\s./-]\d{5,8}\b"
    r"|\b3\d{2}[\s./-]\d{6,7}\b"
)


def _tel_valido(s: str, cf: str = "", piva: str = "") -> str:
    """Ripulisce un telefono e lo scarta se in realta' e' un CF/P.IVA."""
    if not s:
        return ""
    cifre = re.sub(r"\D", "", s)
    # Una P.IVA/CF non e' un telefono
    if len(cifre) == 11 and validators.valida_partita_iva(cifre)["valido"] is True:
        return ""
    if piva and cifre == re.sub(r"\D", "", piva):
        return ""
    if cf and cifre.upper() in cf.upper():
        return ""
    if not (6 <= len(cifre) <= 13):
        return ""
    return s.strip()

# Etichette tipiche che precedono un nominativo nei documenti fiscali
_ETICHETTE = (
    "contribuente", "cliente", "intestatario", "denominazione", "ragione sociale",
    "locatore", "conduttore", "cedente", "cessionario", "committente", "prestatore",
    "dipendente", "datore di lavoro", "sostituto", "fornitore", "destinatario",
    "emessa da (cedente/prestatore)", "intestata a (cessionario/committente)",
)

_PAROLE_SOCIETA = (" srl", " s.r.l", " spa", " s.p.a", " snc", " s.n.c", " sas",
                   " s.a.s", " societa", " soc.", " coop", " condominio", " studio ",
                   " associazione", " fondazione", " sc ", " scarl", " aps", " onlus")

_PAROLE_VIETATE_NOME = ("via ", "piazza ", "corso ", "c.da ", "zona ", "euro",
                        "importo", "totale", "pagamento", "fattura", "documento",
                        "codice", "aliquota", "iva ", "data ")


def _pulisci_nome(s: str) -> str:
    s = re.sub(r"\s+", " ", (s or "")).strip(" -–—:;,.|")
    # taglia a eventuali separatori di campi successivi
    for sep in (" - P.IVA", " - CF", " - p.iva", " P.IVA", " PIVA", " C.F.", " CF ", "  "):
        i = s.find(sep)
        if i > 2:
            s = s[:i]
    return s.strip(" -–—:;,.|")[:120]


def _nome_plausibile(s: str) -> bool:
    if not s or len(s) < 5 or len(s) > 90:
        return False
    low = " " + s.lower()
    if any(p in low for p in _PAROLE_VIETATE_NOME):
        return False
    # almeno due parole alfabetiche
    parole = [p for p in re.split(r"[\s']+", s) if p.isalpha()]
    return len(parole) >= 2


def _spezza(nominativo: str):
    """Ritorna (nome, cognome, tipo). Nei documenti fiscali l'ordine e'
    quasi sempre COGNOME NOME per le persone fisiche."""
    low = " " + nominativo.lower() + " "
    if any(p in low for p in _PAROLE_SOCIETA):
        return "", nominativo, "societa"
    parole = nominativo.split()
    if len(parole) == 2:
        return parole[1].title(), parole[0].title(), "persona_fisica"
    if len(parole) == 3:
        # es. LO BRUTTO GIUSEPPINA -> cognome "Lo Brutto"
        return parole[2].title(), f"{parole[0]} {parole[1]}".title(), "persona_fisica"
    return "", nominativo.title(), "persona_fisica"


def scopri(db) -> list:
    """Scansiona tutti i documenti e ritorna i possibili NUOVI clienti."""
    from database import Document, Client

    # gia' presenti in anagrafica: da escludere
    cf_noti, piva_note, nomi_noti = set(), set(), set()
    for c in db.query(Client).all():
        if c.codice_fiscale:
            cf_noti.add(c.codice_fiscale.upper())
        if c.partita_iva:
            piva_note.add(c.partita_iva)
        nomi_noti.add(f"{c.cognome} {c.nome}".strip().lower())
        nomi_noti.add(f"{c.nome} {c.cognome}".strip().lower())

    candidati = {}  # chiave: cf o piva

    def _cf_in(testo):
        m = _RE_CF.search(testo.upper())
        if m and validators.valida_codice_fiscale(m.group(0))["valido"] is True:
            return m.group(0)
        return ""

    def _piva_in(testo):
        for m in _RE_PIVA.finditer(testo):
            if validators.valida_partita_iva(m.group(0))["valido"] is True:
                return m.group(0)
        return ""

    for d in db.query(Document).filter(Document.testo_estratto.isnot(None)).all():
        testo = d.testo_estratto or ""
        righe = testo.splitlines()
        for n, riga in enumerate(righe):
            riga_pulita = riga.strip()
            if len(riga_pulita) < 8:
                continue
            low = riga_pulita.lower()

            # il nominativo c'e' solo nelle righe con un'etichetta nota
            nominativo = ""
            for et in _ETICHETTE:
                i = low.find(et + ":")
                if i != -1:
                    nominativo = _pulisci_nome(riga_pulita[i + len(et) + 1:])
                    break
            if not _nome_plausibile(nominativo):
                continue

            # Cerca CF/P.IVA/email/tel sulla STESSA riga e, se non bastano,
            # nella FINESTRA di righe vicine (tipico delle schede anagrafiche:
            # nome su una riga, codice fiscale sotto, email sotto, ecc.)
            finestra = "\n".join(righe[n:n + 7])
            cf = _cf_in(riga_pulita) or _cf_in(finestra)
            piva = _piva_in(riga_pulita) or _piva_in(finestra)

            if not (cf or piva):
                continue            # senza un codice certo non proponiamo niente
            if cf and cf in cf_noti:
                continue            # gia' cliente
            if piva and piva in piva_note:
                continue
            if nominativo.lower() in nomi_noti:
                continue

            email_m = _RE_EMAIL.search(finestra)
            tel_m = _RE_TEL.search(finestra)

            chiave = cf or piva
            voce = candidati.setdefault(chiave, {
                "nominativo": nominativo, "codice_fiscale": cf or None,
                "partita_iva": piva or None, "email": None, "telefono": None,
                "doc_ids": [], "documenti": [],
            })
            if cf and not voce["codice_fiscale"]:
                voce["codice_fiscale"] = cf
            if piva and not voce["partita_iva"]:
                voce["partita_iva"] = piva
            if email_m and not voce["email"]:
                voce["email"] = email_m.group(0)
            if tel_m and not voce["telefono"]:
                voce["telefono"] = _tel_valido(tel_m.group(0), cf, piva) or None
            if d.id not in voce["doc_ids"]:
                voce["doc_ids"].append(d.id)
                voce["documenti"].append(d.nome_originale)

        # passata extra: email/telefono possono stare su righe vicine al nome
        # (le cerchiamo nel documento intero solo se il candidato ne e' privo)
    for voce in candidati.values():
        if voce["email"] and voce["telefono"]:
            continue
        from database import Document as _D
        for did in voce["doc_ids"]:
            d = db.query(_D).filter(_D.id == did).first()
            if not d:
                continue
            t = d.testo_estratto or ""
            if not voce["email"]:
                m = _RE_EMAIL.search(t)
                if m:
                    voce["email"] = m.group(0)
            if not voce["telefono"]:
                m = _RE_TEL.search(t)
                if m:
                    voce["telefono"] = _tel_valido(
                        m.group(0), voce.get("codice_fiscale") or "",
                        voce.get("partita_iva") or "") or None

    risultato = []
    for chiave, voce in candidati.items():
        nome, cognome, tipo = _spezza(voce["nominativo"])
        risultato.append({
            "chiave": chiave,
            "nominativo": voce["nominativo"],
            "nome": nome, "cognome": cognome, "tipo": tipo,
            "codice_fiscale": voce["codice_fiscale"],
            "partita_iva": voce["partita_iva"],
            "email": voce["email"], "telefono": voce["telefono"],
            "doc_ids": voce["doc_ids"],
            "documenti": voce["documenti"][:5],
            "n_documenti": len(voce["doc_ids"]),
        })
    risultato.sort(key=lambda x: -x["n_documenti"])
    return risultato


def inserisci(db, selezionati: list) -> dict:
    """Crea i clienti scelti e AGGANCIA loro i documenti di provenienza."""
    from database import Document, Client

    creati, agganciati = 0, 0
    for s in selezionati:
        cl = Client(
            nome=s.get("nome") or "",
            cognome=s.get("cognome") or s.get("nominativo") or "?",
            codice_fiscale=s.get("codice_fiscale"),
            partita_iva=s.get("partita_iva"),
            email=s.get("email"), telefono=s.get("telefono"),
            tipo=s.get("tipo") or "persona_fisica",
            note="Inserito automaticamente dai documenti (Scopri clienti)",
        )
        db.add(cl)
        db.flush()  # serve l'id per l'aggancio
        creati += 1
        nome_completo = f"{cl.cognome} {cl.nome}".strip()
        for did in s.get("doc_ids", []):
            d = db.query(Document).filter(Document.id == did).first()
            if d and not d.client_id:
                d.client_id = cl.id
                d.client_nome = nome_completo
                agganciati += 1
    db.commit()
    return {"ok": True, "creati": creati, "documenti_agganciati": agganciati}
