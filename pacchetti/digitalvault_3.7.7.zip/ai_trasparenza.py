"""
FiscoSicuro - Registro Trasparenza AI + Informativa cliente (L. 132/2025).
(c) 2026 DigitalValut - Capo Team del Progetto: Dr. Falsone Giuseppe

La Legge 10 ottobre 2025, n. 132 (art. 13) impone al professionista di informare
il cliente, per iscritto e con linguaggio chiaro, sull'utilizzo di sistemi di
intelligenza artificiale: quali sistemi, per quali attività, con quale grado di
automazione e con quali garanzie di supervisione umana. Principio cardine della
norma: «l'AI propone, il professionista dispone» — il giudizio critico e la
responsabilità restano umani.

Questo modulo:
  1. REGISTRA ogni uso dell'AI (registra) — prova di supervisione umana.
  2. GENERA l'informativa personalizzata per il cliente (genera_informativa),
     coerente con l'architettura del prodotto (numeri dal motore deterministico,
     mai inventati dall'AI).

PALETTO: nessun numero fiscalmente rilevante è prodotto dall'AI. L'informativa
lo dichiara esplicitamente, perché è vero per costruzione (vedi CLAUDE.md).
"""
from datetime import datetime

SCHEMA_VERSION = 1
FONTE_LEGALE = ("Legge 23 settembre 2025, n. 132, art. 13 — obbligo di informativa "
                "al cliente sull'utilizzo di sistemi di intelligenza artificiale")

# Attività in cui il software impiega l'AI, con le GARANZIE per l'informativa.
# 'funzione' combacia con quella scritta nel registro (AiUso.funzione).
ATTIVITA_AI = [
    {
        "funzione": "chat_consulenza",
        "attivita": "Assistenza alla consulenza: risposte a quesiti, ricerche e sintesi sull'archivio dello studio.",
        "automazione": "L'AI propone testi e sintesi; ogni contenuto è letto e validato dal professionista prima dell'uso.",
        "numeri": "I calcoli fiscali (imposte, aliquote, soglie, scadenze) NON sono prodotti dall'AI: provengono da un motore di calcolo deterministico e collaudato.",
    },
    {
        "funzione": "ocr_lettura",
        "attivita": "Lettura di documenti fotografati o scansionati (riconoscimento del testo).",
        "automazione": "L'AI trascrive il testo delle immagini; gli importi estratti sono marcati «da verificare» e controllati sull'originale dal professionista.",
        "numeri": "Gli importi letti dall'AI non sono mai usati come valori definitivi senza verifica umana.",
    },
    {
        "funzione": "classificazione_doc",
        "attivita": "Classificazione e ordinamento automatico dei documenti caricati.",
        "automazione": "L'AI propone tipo e categoria del documento; l'abbinamento al cliente è deterministico ed è sempre rivedibile.",
        "numeri": "Nessun valore fiscale definitivo è prodotto dall'AI in questa fase.",
    },
    {
        "funzione": "riconciliazione",
        "attivita": "Ausilio alla riconciliazione dei movimenti bancari con i documenti.",
        "automazione": "L'AI propone gli abbinamenti; i movimenti con importi non riscontrati sono segnalati «da verificare».",
        "numeri": "Gli importi sono confrontati con i documenti originali; quelli non riscontrati sono evidenziati al professionista.",
    },
    {
        "funzione": "rifinitura_atto",
        "attivita": "Rifinitura della forma linguistica di atti, contratti e documenti.",
        "automazione": "L'AI migliora soltanto la forma del testo; dati, numeri, quote e riferimenti normativi restano quelli del modello versionato.",
        "numeri": "All'AI è inibito modificare o introdurre numeri, importi, percentuali o riferimenti normativi.",
    },
]

_ATTIVITA_BY_FUNZIONE = {a["funzione"]: a for a in ATTIVITA_AI}


def registra(db, funzione: str, descrizione: str = None, client_id: int = None,
             automazione: str = "supporto", fonte_numeri: str = "deterministico") -> None:
    """Scrive una riga nel registro d'uso dell'AI. Robusto: non solleva mai
    (l'eventuale errore non deve mai bloccare la funzione dell'utente)."""
    try:
        from database import AiUso
        db.add(AiUso(
            funzione=(funzione or "")[:40],
            descrizione=(descrizione[:200] if descrizione else None),
            client_id=client_id,
            automazione=(automazione or "supporto")[:20],
            fonte_numeri=(fonte_numeri or "deterministico")[:20],
        ))
        db.commit()
    except Exception as e:
        try:
            db.rollback()
        except Exception:
            pass
        print(f"[ai_trasparenza] impossibile registrare uso AI '{funzione}': {e}")


def registro(db, client_id: int = None, limite: int = 200) -> list:
    """Ritorna le righe del registro d'uso AI (col nome del cliente risolto)."""
    from database import AiUso, Client
    q = db.query(AiUso)
    if client_id:
        q = q.filter(AiUso.client_id == client_id)
    righe = q.order_by(AiUso.created_at.desc()).limit(limite).all()
    # Risolve i nomi dei clienti in un colpo solo
    ids = {r.client_id for r in righe if r.client_id}
    nomi = {}
    if ids:
        for c in db.query(Client).filter(Client.id.in_(ids)).all():
            nomi[c.id] = f"{c.cognome or ''} {c.nome or ''}".strip() or f"Cliente {c.id}"
    out = []
    for r in righe:
        att = _ATTIVITA_BY_FUNZIONE.get(r.funzione, {})
        out.append({
            "id": r.id,
            "created_at": r.created_at.isoformat() if r.created_at else None,
            "funzione": r.funzione,
            "attivita": att.get("attivita") or r.descrizione or r.funzione,
            "descrizione": r.descrizione,
            "automazione": r.automazione,
            "fonte_numeri": r.fonte_numeri,
            "client_id": r.client_id,
            "cliente": nomi.get(r.client_id) if r.client_id else None,
        })
    return out


def funzioni_usate(db, client_id: int = None) -> set:
    """Insieme delle funzioni AI effettivamente registrate (per un cliente o in totale)."""
    from database import AiUso
    q = db.query(AiUso.funzione)
    if client_id:
        q = q.filter(AiUso.client_id == client_id)
    return {r[0] for r in q.all()}


def _riga_anagrafica(cliente: dict) -> str:
    nome = f"{(cliente or {}).get('cognome','')} {(cliente or {}).get('nome','')}".strip()
    parti = [nome] if nome else []
    if (cliente or {}).get("codice_fiscale"):
        parti.append(f"C.F. {cliente['codice_fiscale']}")
    if (cliente or {}).get("partita_iva"):
        parti.append(f"P.IVA {cliente['partita_iva']}")
    return ", ".join(parti) if parti else "[Cliente]"


def genera_informativa(cliente: dict, studio: dict, usate: set = None) -> dict:
    """Genera il testo dell'informativa L. 132/2025 art. 13, personalizzata sul
    cliente e sullo studio. Elenca TUTTE le attività in cui il software può usare
    l'AI (l'informativa dev'essere completa) e, se `usate` è fornito, evidenzia
    quelle effettivamente registrate per questo cliente.

    I numeri restano una questione del motore deterministico: l'informativa lo
    dichiara, ed è vero per costruzione — nessun numero è generato qui."""
    studio = studio or {}
    cliente = cliente or {}
    nome_studio = studio.get("nome_studio") or "lo Studio"
    anagr_cliente = _riga_anagrafica(cliente)
    oggi = datetime.now().strftime("%d/%m/%Y")
    usate = usate or set()

    R = []
    R.append("INFORMATIVA SULL'UTILIZZO DI SISTEMI DI INTELLIGENZA ARTIFICIALE")
    R.append("(ai sensi dell'art. 13 della Legge 23 settembre 2025, n. 132 — «L. 132/2025»)")
    R.append("")
    R.append(f"Spett.le Cliente: {anagr_cliente}")
    R.append(f"Studio: {nome_studio}")
    R.append(f"Data: {oggi}")
    R.append("")
    R.append("Gentile Cliente,")
    R.append(
        f"nell'adempimento dell'incarico professionale, {nome_studio} si avvale, come SUPPORTO "
        "strumentale, di sistemi di intelligenza artificiale (IA). La presente informativa Le "
        "illustra, con linguaggio chiaro, per quali attività tali sistemi sono impiegati, con "
        "quale grado di automazione e con quali garanzie, come richiesto dalla legge."
    )
    R.append("")
    R.append("1. PRINCIPIO GENERALE — «l'IA propone, il professionista dispone»")
    R.append(
        "L'intelligenza artificiale è utilizzata unicamente come ausilio ad attività strumentali "
        "e di supporto. Il lavoro intellettuale, il giudizio critico e la decisione finale restano "
        "sempre del professionista, che supervisiona, valida e assume la piena responsabilità di "
        "ogni risultato. Nessuna attività di consulenza è delegata in modo automatico all'IA."
    )
    R.append("")
    R.append("2. GARANZIA SUI DATI NUMERICI E FISCALI")
    R.append(
        "I valori fiscalmente rilevanti (imposte, aliquote, coefficienti, soglie, scadenze) NON "
        "sono prodotti dall'intelligenza artificiale. Sono calcolati da un motore di calcolo "
        "deterministico e collaudato, che applica dati normativi versionati e tracciabili. Ogni "
        "calcolo è registrato e ricostruibile. In questo modo è esclusa alla radice la possibilità "
        "che un sistema di IA generi autonomamente un numero non verificato."
    )
    R.append("")
    R.append("3. ATTIVITÀ PER LE QUALI È IMPIEGATA L'IA")
    for i, a in enumerate(ATTIVITA_AI, 1):
        segno = "  [attività registrata per il rapporto in essere]" if a["funzione"] in usate else ""
        R.append(f"  {i}) {a['attivita']}{segno}")
        R.append(f"     - Grado di automazione: {a['automazione']}")
        R.append(f"     - Numeri e dati: {a['numeri']}")
    R.append("")
    R.append("4. SUPERVISIONE UMANA E RESPONSABILITÀ")
    R.append(
        "Ogni risultato prodotto con l'ausilio dell'IA è sottoposto a verifica e validazione "
        "umana prima di essere utilizzato o comunicato. La responsabilità civile e deontologica "
        "dell'attività professionale resta interamente in capo al professionista incaricato."
    )
    R.append("")
    R.append("5. PROTEZIONE DEI DATI (GDPR)")
    R.append(
        "I dati sono trattati in locale, sul dispositivo dello Studio, con cifratura a riposo dei "
        "campi sensibili; non sono ceduti a terzi per l'addestramento di modelli. Restano fermi i "
        "diritti riconosciuti dal Regolamento (UE) 2016/679 e dalla normativa nazionale."
    )
    R.append("")
    R.append("Per presa visione e ricevuta informativa:")
    R.append("")
    R.append("Il Cliente _______________________      Data ____________")
    R.append("")
    R.append(f"Il Professionista / {nome_studio} _______________________")

    return {
        "ok": True,
        "titolo": "Informativa sull'utilizzo di sistemi di IA (art. 13, L. 132/2025)",
        "testo": "\n".join(R),
        "fonte": FONTE_LEGALE,
        "schema_version": SCHEMA_VERSION,
        "disclaimer": ("Modello di informativa conforme all'impianto dell'art. 13 L. 132/2025. "
                       "Da consegnare al cliente al conferimento dell'incarico; adattare ai sistemi "
                       "effettivamente in uso nello Studio e far sottoscrivere per presa visione."),
    }
