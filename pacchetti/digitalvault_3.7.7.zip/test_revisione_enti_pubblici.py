"""Test del motore Revisione Enti Pubblici (equilibri di bilancio, deterministico)."""
import revisione_enti_pubblici as rep


# ── Equilibrio di parte corrente ─────────────────────────────────────────

def test_equilibrio_corrente_positivo():
    r = rep.equilibrio_parte_corrente(entrate_correnti=1_000_000, spese_correnti=850_000,
                                       rimborso_prestiti=100_000)
    assert r["saldo"] == 50_000.0
    assert r["in_equilibrio"] is True


def test_equilibrio_corrente_negativo():
    r = rep.equilibrio_parte_corrente(entrate_correnti=1_000_000, spese_correnti=950_000,
                                       rimborso_prestiti=100_000)
    assert r["saldo"] == -50_000.0
    assert r["in_equilibrio"] is False


def test_equilibrio_corrente_con_avanzo_lo_riporta_in_equilibrio():
    base = rep.equilibrio_parte_corrente(entrate_correnti=1_000_000, spese_correnti=950_000,
                                          rimborso_prestiti=100_000)
    assert base["in_equilibrio"] is False
    con_avanzo = rep.equilibrio_parte_corrente(entrate_correnti=1_000_000, spese_correnti=950_000,
                                                rimborso_prestiti=100_000, utilizzo_avanzo_corrente=60_000)
    assert con_avanzo["saldo"] == 10_000.0
    assert con_avanzo["in_equilibrio"] is True


# ── Equilibrio di parte capitale ─────────────────────────────────────────

def test_equilibrio_capitale_pareggiato():
    r = rep.equilibrio_parte_capitale(entrate_capitale=500_000, spese_capitale=500_000)
    assert r["saldo"] == 0.0
    assert r["in_equilibrio"] is True


def test_equilibrio_capitale_negativo():
    r = rep.equilibrio_parte_capitale(entrate_capitale=300_000, spese_capitale=500_000)
    assert r["saldo"] == -200_000.0
    assert r["in_equilibrio"] is False


# ── Equilibrio di cassa ───────────────────────────────────────────────────

def test_equilibrio_cassa_regolare():
    r = rep.equilibrio_cassa(fondo_cassa_iniziale=100_000, incassi_totali=1_500_000,
                              pagamenti_totali=1_400_000)
    assert r["fondo_cassa_finale"] == 200_000.0
    assert r["in_equilibrio"] is True


def test_equilibrio_cassa_negativo():
    r = rep.equilibrio_cassa(fondo_cassa_iniziale=50_000, incassi_totali=1_000_000,
                              pagamenti_totali=1_200_000)
    assert r["fondo_cassa_finale"] == -150_000.0
    assert r["in_equilibrio"] is False


# ── Pareggio complessivo ──────────────────────────────────────────────────

def test_pareggio_complessivo_ok():
    r = rep.pareggio_complessivo(totale_entrate=2_000_000, totale_spese=2_000_000)
    assert r["in_pareggio"] is True


def test_pareggio_complessivo_squilibrato():
    r = rep.pareggio_complessivo(totale_entrate=2_000_000, totale_spese=2_050_000)
    assert r["in_pareggio"] is False
    assert r["differenza"] == -50_000.0


# ── Analisi completa (orchestratore) ─────────────────────────────────────

def test_analizza_bilancio_tutto_regolare():
    dati = {
        "entrate_correnti": 1_000_000, "spese_correnti": 850_000, "rimborso_prestiti": 100_000,
        "entrate_capitale": 400_000, "spese_capitale": 400_000,
        "totale_entrate": 1_400_000, "totale_spese": 1_400_000,
    }
    r = rep.analizza_bilancio(dati)
    assert r["esito"] == "regolare"
    assert r["rilievi"] == []
    assert r["legal_source"] and "118/2011" in r["legal_source"]


def test_analizza_bilancio_irregolare_su_corrente():
    dati = {
        "entrate_correnti": 1_000_000, "spese_correnti": 980_000, "rimborso_prestiti": 100_000,
        "entrate_capitale": 400_000, "spese_capitale": 400_000,
        "totale_entrate": 1_400_000, "totale_spese": 1_400_000,
    }
    r = rep.analizza_bilancio(dati)
    assert r["esito"] == "irregolare"
    categorie = [x["categoria"] for x in r["rilievi"]]
    assert "equilibrio_corrente" in categorie


def test_analizza_bilancio_critico_su_cassa():
    dati = {
        "entrate_correnti": 1_000_000, "spese_correnti": 850_000, "rimborso_prestiti": 100_000,
        "entrate_capitale": 400_000, "spese_capitale": 400_000,
        "totale_entrate": 1_400_000, "totale_spese": 1_400_000,
        "fondo_cassa_iniziale": 10_000, "incassi_totali": 500_000, "pagamenti_totali": 600_000,
    }
    r = rep.analizza_bilancio(dati)
    assert r["esito"] == "critico"
    categorie = [x["categoria"] for x in r["rilievi"]]
    assert "equilibrio_cassa" in categorie


def test_analizza_bilancio_cassa_assente_se_non_fornita():
    dati = {
        "entrate_correnti": 1_000_000, "spese_correnti": 850_000, "rimborso_prestiti": 100_000,
        "entrate_capitale": 400_000, "spese_capitale": 400_000,
        "totale_entrate": 1_400_000, "totale_spese": 1_400_000,
    }
    r = rep.analizza_bilancio(dati)
    assert r["equilibrio_cassa"] is None


# ── Generazione parere ───────────────────────────────────────────────────

def test_genera_parere_favorevole():
    dati = {
        "entrate_correnti": 1_000_000, "spese_correnti": 850_000, "rimborso_prestiti": 100_000,
        "entrate_capitale": 400_000, "spese_capitale": 400_000,
        "totale_entrate": 1_400_000, "totale_spese": 1_400_000,
    }
    p = rep.genera_parere("Comune di Prova", dati)
    assert p["ok"] and p["esito"] == "regolare"
    assert "Comune di Prova" in p["testo"]
    assert "PARERE FAVOREVOLE" in p["testo"]
    assert "239" in p["testo"]  # riferimento normativo TUEL


def test_genera_parere_con_rilievi():
    dati = {
        "entrate_correnti": 1_000_000, "spese_correnti": 980_000, "rimborso_prestiti": 100_000,
        "entrate_capitale": 400_000, "spese_capitale": 400_000,
        "totale_entrate": 1_400_000, "totale_spese": 1_400_000,
    }
    p = rep.genera_parere("Comune di Prova", dati)
    assert p["esito"] == "irregolare"
    assert "PARERE CON RILIEVI" in p["testo"]
    assert "RILIEVI" in p["testo"]


def test_genera_parere_riusa_risultato_gia_calcolato():
    dati = {
        "entrate_correnti": 1_000_000, "spese_correnti": 850_000, "rimborso_prestiti": 100_000,
        "entrate_capitale": 400_000, "spese_capitale": 400_000,
        "totale_entrate": 1_400_000, "totale_spese": 1_400_000,
    }
    risultato = rep.analizza_bilancio(dati)
    p = rep.genera_parere("Comune di Prova", dati, risultato=risultato)
    assert p["esito"] == risultato["esito"]
