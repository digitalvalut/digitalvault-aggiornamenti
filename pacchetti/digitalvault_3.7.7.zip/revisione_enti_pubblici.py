"""
FiscoSicuro - Motore di Revisione per Enti Pubblici (Comuni ed enti locali).
Fase 1 della linea "Revisione" (dopo Revisione Società private).
(c) 2026 DigitalValut - Capo Team del Progetto: Dr. Falsone Giuseppe

Supporta l'organo di revisione economico-finanziaria (art. 239 TUEL, D.Lgs.
267/2000) nella verifica degli EQUILIBRI DI BILANCIO secondo la contabilità
armonizzata (D.Lgs. 118/2011, Allegato 9).

REGOLA D'ORO (non negoziabile): ogni NUMERO è calcolato in modo deterministico
dai dati inseriti dall'utente, MAI dall'AI. Il giudizio finale sulla
regolarità del bilancio resta del revisore incaricato.

ATTENZIONE — dominio DIVERSO dalla fiscalità privata (IRPEF/forfettario/IMU):
qui si verificano gli equilibri STRUTTURALI di bilancio pubblico, definiti
direttamente dalla legge. Gli "indicatori di deficitarietà strutturale"
(parametri ministeriali che cambiano ogni anno con decreto) NON sono ancora
implementati in questa fase: richiederebbero una fonte normativa annuale
verificata puntualmente, da aggiungere in una fase successiva — non si inventa
un valore senza fonte, come da regola d'oro del progetto.
"""
from decimal import Decimal, ROUND_HALF_UP

import yaml

from config import BASE_DIR

_REF = BASE_DIR / "public_finance_reference" / "equilibri_bilancio.yaml"


def _load() -> dict:
    return yaml.safe_load(_REF.read_text(encoding="utf-8"))


def _q2(x) -> float:
    return float(Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def equilibrio_parte_corrente(entrate_correnti, spese_correnti, rimborso_prestiti,
                               quota_capitale_a_correnti=0, utilizzo_avanzo_corrente=0) -> dict:
    """Equilibrio di parte corrente (Allegato 9, D.Lgs. 118/2011)."""
    ec, sc = Decimal(str(entrate_correnti)), Decimal(str(spese_correnti))
    rp = Decimal(str(rimborso_prestiti))
    qc = Decimal(str(quota_capitale_a_correnti))
    ua = Decimal(str(utilizzo_avanzo_corrente))
    saldo = ec + qc + ua - sc - rp
    return {
        "saldo": _q2(saldo), "in_equilibrio": saldo >= 0,
        "dettaglio": {"entrate_correnti": _q2(ec), "spese_correnti": _q2(sc),
                      "rimborso_prestiti": _q2(rp), "quota_capitale_a_correnti": _q2(qc),
                      "utilizzo_avanzo_corrente": _q2(ua)},
    }


def equilibrio_parte_capitale(entrate_capitale, spese_capitale, utilizzo_avanzo_capitale=0,
                               quota_capitale_a_correnti=0) -> dict:
    """Equilibrio di parte capitale (Allegato 9, D.Lgs. 118/2011)."""
    en, sp = Decimal(str(entrate_capitale)), Decimal(str(spese_capitale))
    ua = Decimal(str(utilizzo_avanzo_capitale))
    qc = Decimal(str(quota_capitale_a_correnti))
    saldo = en + ua - qc - sp
    return {
        "saldo": _q2(saldo), "in_equilibrio": saldo >= 0,
        "dettaglio": {"entrate_capitale": _q2(en), "spese_capitale": _q2(sp),
                      "utilizzo_avanzo_capitale": _q2(ua), "quota_capitale_a_correnti": _q2(qc)},
    }


def equilibrio_cassa(fondo_cassa_iniziale, incassi_totali, pagamenti_totali) -> dict:
    """Equilibrio di cassa (art. 195 TUEL): il fondo cassa finale non deve essere negativo."""
    fi = Decimal(str(fondo_cassa_iniziale))
    inc, pag = Decimal(str(incassi_totali)), Decimal(str(pagamenti_totali))
    fondo_finale = fi + inc - pag
    return {
        "fondo_cassa_finale": _q2(fondo_finale), "in_equilibrio": fondo_finale >= 0,
        "dettaglio": {"fondo_cassa_iniziale": _q2(fi), "incassi_totali": _q2(inc),
                      "pagamenti_totali": _q2(pag)},
    }


def pareggio_complessivo(totale_entrate, totale_spese) -> dict:
    """Pareggio finanziario complessivo (art. 162, c.6, TUEL)."""
    te, ts = Decimal(str(totale_entrate)), Decimal(str(totale_spese))
    diff = te - ts
    return {
        "differenza": _q2(diff), "in_pareggio": diff == 0,
        "dettaglio": {"totale_entrate": _q2(te), "totale_spese": _q2(ts)},
    }


def analizza_bilancio(dati: dict) -> dict:
    """Analisi completa degli equilibri di bilancio, a supporto del parere
    dell'organo di revisione sul bilancio di previsione (art. 239 TUEL).
    `dati`: entrate_correnti, spese_correnti, rimborso_prestiti,
    quota_capitale_a_correnti, utilizzo_avanzo_corrente, entrate_capitale,
    spese_capitale, utilizzo_avanzo_capitale, totale_entrate, totale_spese,
    e opzionalmente fondo_cassa_iniziale/incassi_totali/pagamenti_totali."""
    ref = _load()

    corrente = equilibrio_parte_corrente(
        dati.get("entrate_correnti", 0), dati.get("spese_correnti", 0),
        dati.get("rimborso_prestiti", 0), dati.get("quota_capitale_a_correnti", 0),
        dati.get("utilizzo_avanzo_corrente", 0))
    capitale = equilibrio_parte_capitale(
        dati.get("entrate_capitale", 0), dati.get("spese_capitale", 0),
        dati.get("utilizzo_avanzo_capitale", 0), dati.get("quota_capitale_a_correnti", 0))
    cassa = None
    if dati.get("incassi_totali") is not None and dati.get("pagamenti_totali") is not None:
        cassa = equilibrio_cassa(
            dati.get("fondo_cassa_iniziale", 0), dati.get("incassi_totali", 0),
            dati.get("pagamenti_totali", 0))
    pareggio = pareggio_complessivo(dati.get("totale_entrate", 0), dati.get("totale_spese", 0))

    rilievi = []
    if not corrente["in_equilibrio"]:
        rilievi.append({"categoria": "equilibrio_corrente", "gravita": "alta",
                         "messaggio": f"Equilibrio di parte corrente NON rispettato: saldo {corrente['saldo']:.2f} € (negativo)."})
    if not capitale["in_equilibrio"]:
        rilievi.append({"categoria": "equilibrio_capitale", "gravita": "alta",
                         "messaggio": f"Equilibrio di parte capitale NON rispettato: saldo {capitale['saldo']:.2f} € (negativo)."})
    if cassa is not None and not cassa["in_equilibrio"]:
        rilievi.append({"categoria": "equilibrio_cassa", "gravita": "critica",
                         "messaggio": f"Fondo cassa finale NEGATIVO: {cassa['fondo_cassa_finale']:.2f} €."})
    if not pareggio["in_pareggio"]:
        rilievi.append({"categoria": "pareggio_complessivo", "gravita": "alta",
                         "messaggio": f"Il bilancio non è in pareggio: differenza {pareggio['differenza']:.2f} € tra entrate e spese complessive (art. 162, c.6, TUEL)."})

    esito = "regolare"
    if any(r["gravita"] == "critica" for r in rilievi):
        esito = "critico"
    elif rilievi:
        esito = "irregolare"

    return {
        "equilibrio_corrente": corrente, "equilibrio_capitale": capitale,
        "equilibrio_cassa": cassa, "pareggio_complessivo": pareggio,
        "rilievi": rilievi, "esito": esito,
        "legal_source": ref.get("legal_source"), "schema_version": ref.get("schema_version"),
        "disclaimer": ref.get("disclaimer"),
    }


_GIUDIZIO_TESTO = {
    "regolare": "Il Collegio/Organo di revisione esprime PARERE FAVOREVOLE, non essendo emersi rilievi sugli equilibri di bilancio verificati.",
    "irregolare": "Il Collegio/Organo di revisione esprime PARERE CON RILIEVI, in relazione a quanto evidenziato nella presente relazione.",
    "critico": "Il Collegio/Organo di revisione esprime PARERE NON FAVOREVOLE, per le criticità di seguito indicate, che compromettono la sostenibilità finanziaria dell'ente.",
}


def genera_parere(ente: str, dati: dict, risultato: dict = None) -> dict:
    """Genera la bozza di parere/relazione dell'organo di revisione sulla
    verifica degli equilibri di bilancio (art. 239 TUEL). I numeri vengono
    SEMPRE da `analizza_bilancio` (motore deterministico); questa funzione
    assembla solo il testo, senza AI e senza inventare alcun valore."""
    r = risultato if risultato is not None else analizza_bilancio(dati)
    ente = ente or "[Denominazione Ente]"
    oggi = __import__("datetime").datetime.now().strftime("%d/%m/%Y")

    R = []
    R.append(f"RELAZIONE E PARERE DELL'ORGANO DI REVISIONE ECONOMICO-FINANZIARIA")
    R.append(f"sulla verifica degli equilibri di bilancio (art. 239 D.Lgs. 267/2000 — TUEL)")
    R.append("")
    R.append(f"Ente: {ente}")
    R.append(f"Data: {oggi}")
    R.append("")
    R.append("1. OGGETTO")
    R.append(
        "Il sottoscritto Organo di revisione economico-finanziaria, nell'esercizio delle "
        "funzioni di cui all'art. 239 del D.Lgs. 267/2000 (TUEL), ha verificato gli equilibri "
        "di bilancio dell'Ente secondo lo schema previsto dall'Allegato 9 al D.Lgs. 118/2011."
    )
    R.append("")
    R.append("2. EQUILIBRIO DI PARTE CORRENTE")
    c = r["equilibrio_corrente"]
    R.append(f"   Entrate correnti: € {c['dettaglio']['entrate_correnti']:,.2f}".replace(",", "."))
    R.append(f"   Spese correnti: € {c['dettaglio']['spese_correnti']:,.2f}".replace(",", "."))
    R.append(f"   Rimborso prestiti (quota capitale): € {c['dettaglio']['rimborso_prestiti']:,.2f}".replace(",", "."))
    R.append(f"   Saldo di parte corrente: € {c['saldo']:,.2f} — {'EQUILIBRIO RISPETTATO' if c['in_equilibrio'] else 'EQUILIBRIO NON RISPETTATO'}".replace(",", "."))
    R.append("")
    R.append("3. EQUILIBRIO DI PARTE CAPITALE")
    k = r["equilibrio_capitale"]
    R.append(f"   Entrate in conto capitale: € {k['dettaglio']['entrate_capitale']:,.2f}".replace(",", "."))
    R.append(f"   Spese in conto capitale: € {k['dettaglio']['spese_capitale']:,.2f}".replace(",", "."))
    R.append(f"   Saldo di parte capitale: € {k['saldo']:,.2f} — {'EQUILIBRIO RISPETTATO' if k['in_equilibrio'] else 'EQUILIBRIO NON RISPETTATO'}".replace(",", "."))
    R.append("")
    if r.get("equilibrio_cassa"):
        R.append("4. EQUILIBRIO DI CASSA")
        cs = r["equilibrio_cassa"]
        R.append(f"   Fondo cassa finale previsto: € {cs['fondo_cassa_finale']:,.2f} — {'REGOLARE' if cs['in_equilibrio'] else 'NEGATIVO'}".replace(",", "."))
        R.append("")
    R.append("5. PAREGGIO FINANZIARIO COMPLESSIVO (art. 162, c. 6, TUEL)")
    p = r["pareggio_complessivo"]
    R.append(f"   Totale entrate: € {p['dettaglio']['totale_entrate']:,.2f}".replace(",", "."))
    R.append(f"   Totale spese: € {p['dettaglio']['totale_spese']:,.2f}".replace(",", "."))
    R.append(f"   Differenza: € {p['differenza']:,.2f} — {'BILANCIO IN PAREGGIO' if p['in_pareggio'] else 'BILANCIO NON IN PAREGGIO'}".replace(",", "."))
    R.append("")
    if r["rilievi"]:
        R.append("6. RILIEVI")
        for i, rl in enumerate(r["rilievi"], 1):
            R.append(f"   {i}) [{rl['gravita'].upper()}] {rl['messaggio']}")
        R.append("")
    R.append("7. PARERE")
    R.append(_GIUDIZIO_TESTO[r["esito"]])
    R.append("")
    R.append("L'Organo di revisione economico-finanziaria")
    R.append("_______________________")

    return {
        "ok": True,
        "titolo": "Relazione e parere dell'Organo di revisione — equilibri di bilancio",
        "testo": "\n".join(R),
        "esito": r["esito"],
        "fonte": r["legal_source"],
        "schema_version": r["schema_version"],
        "disclaimer": (r["disclaimer"] + " La presente bozza non sostituisce la firma e "
                       "l'assunzione di responsabilità dell'organo di revisione incaricato."),
    }
