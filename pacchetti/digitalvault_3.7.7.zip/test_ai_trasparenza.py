"""Test del modulo Trasparenza AI (L. 132/2025). DB SQLite in-memory, dati finti."""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import database as dbmod
import ai_trasparenza as tr


def _sess():
    eng = create_engine("sqlite:///:memory:")
    dbmod.Base.metadata.create_all(eng)
    return sessionmaker(bind=eng)()


def _cli(db, **kw):
    c = dbmod.Client(nome=kw.pop("nome", "Mario"), cognome=kw.pop("cognome", "Rossi"), **kw)
    db.add(c); db.commit(); db.refresh(c)
    return c


# ── Registro ────────────────────────────────────────────────────────────────

def test_registra_e_registro_roundtrip():
    db = _sess()
    c = _cli(db, codice_fiscale="RSSMRA80A01H501U")
    tr.registra(db, "chat_consulenza", "Risposta AI", client_id=c.id, fonte_numeri="ai")
    tr.registra(db, "ocr_lettura", "Letto un 730", client_id=c.id, fonte_numeri="deterministico")
    reg = tr.registro(db)
    assert len(reg) == 2
    # più recente prima
    assert reg[0]["funzione"] in ("chat_consulenza", "ocr_lettura")
    # il nome cliente è risolto
    assert reg[0]["cliente"] == "Rossi Mario"
    # l'attività leggibile arriva dal catalogo ATTIVITA_AI
    assert "Assistenza" in [r["attivita"] for r in reg if r["funzione"] == "chat_consulenza"][0]


def test_registro_filtrato_per_cliente():
    db = _sess()
    a = _cli(db, nome="Anna", cognome="Bianchi", codice_fiscale="BNCNNA80A41H501U")
    b = _cli(db, nome="Bea", cognome="Verdi", codice_fiscale="VRDBEA80A41H501U")
    tr.registra(db, "chat_consulenza", client_id=a.id, fonte_numeri="ai")
    tr.registra(db, "chat_consulenza", client_id=b.id, fonte_numeri="ai")
    assert len(tr.registro(db, client_id=a.id)) == 1
    assert len(tr.registro(db)) == 2


def test_registra_non_solleva_mai():
    # DB "rotto" (sessione chiusa): non deve propagare eccezioni
    db = _sess()
    db.close()
    tr.registra(db, "chat_consulenza", client_id=1)  # non deve lanciare


def test_funzioni_usate_distinte():
    db = _sess()
    c = _cli(db, codice_fiscale="RSSMRA80A01H501U")
    tr.registra(db, "chat_consulenza", client_id=c.id)
    tr.registra(db, "chat_consulenza", client_id=c.id)
    tr.registra(db, "ocr_lettura", client_id=c.id)
    assert tr.funzioni_usate(db, client_id=c.id) == {"chat_consulenza", "ocr_lettura"}


# ── Informativa ───────────────────────────────────────────────────────────────

def test_informativa_contiene_elementi_di_legge():
    cliente = {"nome": "Mario", "cognome": "Rossi", "codice_fiscale": "RSSMRA80A01H501U"}
    studio = {"nome_studio": "Studio Alfa"}
    r = tr.genera_informativa(cliente, studio, usate=set())
    assert r["ok"]
    t = r["testo"]
    # riferimento normativo corretto
    assert "132/2025" in t and "art. 13" in r["fonte"]
    # principio cardine
    assert "propone" in t and "dispone" in t
    # garanzia numeri deterministici
    assert "NON sono prodotti dall'intelligenza artificiale" in t
    # personalizzazione: nome cliente e studio presenti
    assert "Rossi Mario" in t and "Studio Alfa" in t
    # elenca TUTTE le attività del catalogo
    for a in tr.ATTIVITA_AI:
        assert a["attivita"] in t
    # spazio firma per presa visione
    assert "Il Cliente" in t and "Il Professionista" in t


def test_informativa_generica_senza_cliente():
    r = tr.genera_informativa(None, {"nome_studio": "Studio Beta"}, usate=set())
    assert r["ok"]
    assert "[Cliente]" in r["testo"]
    assert "Studio Beta" in r["testo"]


def test_informativa_evidenzia_attivita_registrate():
    cliente = {"nome": "Mario", "cognome": "Rossi"}
    r = tr.genera_informativa(cliente, {"nome_studio": "Studio"}, usate={"chat_consulenza"})
    # la funzione usata è marcata come registrata per il rapporto in essere
    assert "attività registrata per il rapporto in essere" in r["testo"]
