"""
DigitalVault - Copilota: instrada le richieste di CALCOLO al motore deterministico.
(c) 2026 DigitalVault - Capo Team del Progetto: Dr. Falsone Giuseppe

Differenziazione chiave: il commercialista chiede a PAROLE ("calcola l'IRPEF su
35.000", "quanto IMU su una A/3 con rendita 232 e aliquota 10,6?") e ottiene il
numero ESATTO dal motore fiscale (fiscal_engine), MAI una stima inventata dall'AI.
L'AI serve SOLO a capire la richiesta ed estrarre i parametri; i NUMERI vengono
dal codice deterministico, con fonte di legge e disclaimer.

Economia di token: un filtro a parole chiave (sembra_calcolo) evita di chiamare
l'AI quando il messaggio non è un calcolo → la chat normale non spende di più.
"""
import re
from decimal import Decimal

import ai_client
import sciame
from fiscal_engine import imu as _imu, irpef as _irpef, forfettario as _forf
from fiscal_engine.common import DISCLAIMER, DataNotFreshError

# Indizio "forfettario": instrada allo SCIAME (chiarificatore + revisore) con UN solo giro AI.
_FORF_HINT = re.compile(r"\b(forfettar\w*|forfait|imposta\s+sostitutiva|regime\s+dei\s+minimi)\b",
                        re.IGNORECASE)
# Indizio "IVA": instrada allo SCIAME IVA (scorporo / calcolo / liquidazione).
_IVA_HINT = re.compile(r"\b(iva|scorpor\w*|liquidazione)\b", re.IGNORECASE)
# Indizio "IRPEF": instrada allo SCIAME IRPEF (calcolo per scaglioni).
_IRPEF_HINT = re.compile(r"\birpef\b", re.IGNORECASE)
# Indizio "730": instrada allo SCIAME 730 (esito rimborso / a debito).
_S730_HINT = re.compile(r"\b(730|dichiarazione\s+dei\s+redditi)\b", re.IGNORECASE)

# Gate economico: si attiva solo se c'è un VERBO di calcolo, oppure un TRIBUTO + un NUMERO.
_VERBO = re.compile(r"\b(calcol\w+|quant[oae]\b.{0,25}\b(pag|dev|cost|version))", re.IGNORECASE)
_TASSA = re.compile(r"\b(imu|irpef|forfettar\w*|imposta\s+sostitutiva|cedolare|iva|scorpor\w*|liquidazione|730|dichiarazione)\b", re.IGNORECASE)
_NUM = re.compile(r"\d")


def sembra_calcolo(messaggio: str) -> bool:
    m = messaggio or ""
    return bool(_VERBO.search(m) or (_TASSA.search(m) and _NUM.search(m)))


_ROUTER_SYSTEM = ("Sei un estrattore di parametri per calcoli fiscali italiani. "
                  "Rispondi ESCLUSIVAMENTE con un oggetto JSON valido, senza testo attorno.")

_ROUTER_PROMPT = """Capisci se il messaggio chiede di CALCOLARE imu, irpef o regime forfettario, ed estrai i numeri.
Restituisci SOLO questo JSON:
{{"calcolo": "imu"|"irpef"|"forfettario"|"nessuno", "parametri": {{ ... }}}}
Parametri attesi:
- imu: "categoria_catastale" (es. "A/3"), "rendita_catastale" (numero), "aliquota_per_mille" (numero, es. 10.6), "mesi_possesso" (1-12)
- irpef: "reddito" (numero)
- forfettario: "fatturato" (numero), "coefficiente" (0-1, es. 0.78), "nuova_attivita" (true/false)
Usa null per i parametri non presenti. Se NON è un calcolo: {{"calcolo":"nessuno","parametri":{{}}}}.

MESSAGGIO:
{msg}"""


async def interpreta(messaggio: str):
    """Usa l'AI SOLO per capire intento + parametri. None se non è un calcolo."""
    try:
        d = await ai_client.chat_json(_ROUTER_PROMPT.format(msg=(messaggio or "")[:1500]),
                                      system=_ROUTER_SYSTEM)
    except Exception:
        return None
    calc = str(d.get("calcolo") or "nessuno").lower().strip()
    if calc not in ("imu", "irpef", "forfettario"):
        return None
    return {"calcolo": calc, "parametri": d.get("parametri") or {}}


_REQ = {"imu": ["categoria_catastale", "rendita_catastale", "aliquota_per_mille"],
        "irpef": ["reddito"], "forfettario": ["fatturato"]}

_ETICHETTA = {
    "categoria_catastale": "la categoria catastale (es. A/3)",
    "rendita_catastale": "la rendita catastale (€)",
    "aliquota_per_mille": "l'aliquota IMU per mille del Comune (es. 10,6)",
    "reddito": "il reddito imponibile (€)",
    "fatturato": "il fatturato/ricavi incassati (€)",
}


def _mancanti(p, calcolo):
    return [k for k in _REQ[calcolo] if p.get(k) in (None, "", "null")]


def esegui(calcolo: str, p: dict) -> dict:
    """Esegue il calcolo deterministico. {ok, tipo, dati} | {ok:False, mancanti|errore}."""
    miss = _mancanti(p, calcolo)
    if miss:
        return {"ok": False, "mancanti": miss}
    try:
        if calcolo == "imu":
            res = _imu.calcola_imu_fabbricato(
                categoria_catastale=str(p["categoria_catastale"]).upper().strip(),
                rendita_catastale=Decimal(str(p["rendita_catastale"])),
                aliquota_per_mille=Decimal(str(p["aliquota_per_mille"])),
                mesi_possesso=int(p.get("mesi_possesso") or 12))
            return {"ok": True, "tipo": "imu", "dati": res.to_dict()}
        if calcolo == "irpef":
            return {"ok": True, "tipo": "irpef",
                    "dati": _irpef.calcola_irpef(float(p["reddito"]), anno=2026)}
        if calcolo == "forfettario":
            return {"ok": True, "tipo": "forfettario",
                    "dati": _forf.simula_forfettario(
                        float(p["fatturato"]), float(p.get("coefficiente") or 0.78),
                        bool(p.get("nuova_attivita")), anno=2026)}
    except _imu.MissingInputError as e:
        return {"ok": False, "mancanti": list(getattr(e, "fields", []) or [])}
    except DataNotFreshError as e:
        return {"ok": False, "errore": str(e)}
    except Exception as e:
        return {"ok": False, "errore": str(e)}
    return {"ok": False, "errore": "calcolo non riconosciuto"}


def _eur(x) -> str:
    try:
        return f"{float(x):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    except Exception:
        return str(x)


def formatta(tipo: str, dati: dict) -> str:
    if tipo == "imu":
        return ("**IMU — calcolo dal motore (deterministico)**\n"
                f"- Base imponibile: € {_eur(dati.get('base_imponibile'))}\n"
                f"- IMU annua: € {_eur(dati.get('imu_annua'))}\n"
                f"- Acconto (16 giugno): € {_eur(dati.get('acconto'))}\n"
                f"- Saldo (16 dicembre): € {_eur(dati.get('saldo'))}\n"
                f"- Moltiplicatore catastale: {dati.get('moltiplicatore_usato')}\n\n"
                f"_{DISCLAIMER}_")
    if tipo == "irpef":
        righe = "\n".join(f"  · {s.get('scaglione')} ({s.get('aliquota')}): € {_eur(s.get('imposta'))}"
                          for s in (dati.get("dettaglio_scaglioni") or []))
        return ("**IRPEF 2026 — calcolo dal motore (deterministico)**\n"
                f"- Reddito imponibile: € {_eur(dati.get('reddito_imponibile'))}\n"
                f"- IRPEF lorda: € {_eur(dati.get('irpef_lorda'))}\n"
                f"- Aliquota media: {dati.get('aliquota_media')}%\n"
                f"{righe}\n\n_{DISCLAIMER}_")
    if tipo == "forfettario":
        avvisi = "".join(f"\n⚠️ {w}" for w in (dati.get("warnings") or []))
        return ("**Regime forfettario 2026 — calcolo dal motore (deterministico)**\n"
                f"- Fatturato: € {_eur(dati.get('fatturato'))}\n"
                f"- Reddito imponibile (× coefficiente): € {_eur(dati.get('reddito_forfettario'))}\n"
                f"- Imposta sostitutiva ({dati.get('aliquota_imposta')}): € {_eur(dati.get('imposta_sostitutiva'))}\n"
                f"- Netto stimato in tasca: € {_eur(dati.get('netto_in_tasca'))}"
                f"{avvisi}\n\n_{DISCLAIMER}_")
    return ""


def _chiedi_mancanti(calcolo: str, miss: list) -> str:
    voci = "\n".join(f"- {_ETICHETTA.get(k, k)}" for k in miss)
    return (f"Per calcolare l'{calcolo.upper()} in modo esatto mi servono ancora:\n{voci}\n\n"
            "Scrivimeli e ti do il numero preciso (dal motore di calcolo, non una stima).")


async def rispondi_calcolo(messaggio: str):
    """Se il messaggio è una richiesta di calcolo: ritorna la risposta col numero
    ESATTO dal motore (o la richiesta dei dati mancanti). Altrimenti None →
    il chiamante prosegue con la chat normale."""
    if not sembra_calcolo(messaggio):
        return None
    # SCIAME forfettario (prioritario): chiarificatore (1 giro AI) + motore + revisore.
    if _FORF_HINT.search(messaggio or ""):
        out = await sciame.rispondi_forfettario(messaggio)
        if out is not None:
            return out
    # SCIAME IVA: scorporo / calcolo / liquidazione.
    if _IVA_HINT.search(messaggio or ""):
        out = await sciame.rispondi_iva(messaggio)
        if out is not None:
            return out
    # SCIAME IRPEF: calcolo per scaglioni progressivi.
    if _IRPEF_HINT.search(messaggio or ""):
        out = await sciame.rispondi_irpef(messaggio)
        if out is not None:
            return out
    # SCIAME 730: esito rimborso / a debito.
    if _S730_HINT.search(messaggio or ""):
        out = await sciame.rispondi_730(messaggio)
        if out is not None:
            return out
    interp = await interpreta(messaggio)
    if not interp:
        return None
    r = esegui(interp["calcolo"], interp["parametri"])
    if r.get("ok"):
        return formatta(r["tipo"], r["dati"])
    if r.get("mancanti"):
        return _chiedi_mancanti(interp["calcolo"], r["mancanti"])
    if r.get("errore"):
        return f"Non riesco a completare il calcolo: {r['errore']}"
    return None
