"""Test dello SCIAME forfettario (Chiarificatore mockato, motore+revisore reali)."""
import asyncio
import ai_client
import sciame
from fiscal_engine import forfettario as _forf


def _fake_chiarif(ret):
    async def _f(prompt, system=None):
        return ret
    return _f


def _run(coro):
    return asyncio.run(coro)


def test_happy_professionista(monkeypatch=None):
    ai_client.chat_json = _fake_chiarif({
        "e_forfettario": True, "fatturato": 40000,
        "settore": "Professionali, scientifiche, tecniche, sanita, istruzione",
        "coefficiente": None, "nuova_attivita": None, "anno": None})
    out = _run(sciame.rispondi_forfettario("cliente forfettario ha fatto 40mila e rotti, quanto paga?"))
    atteso = _forf.simula_forfettario(40000, 0.78, False, anno=2026)
    imposta_str = sciame._eur(atteso["imposta_sostitutiva"])
    assert imposta_str in out, f"imposta {imposta_str} non trovata in:\n{out}"
    assert "15%" in out
    assert "Scadenze" in out
    print("OK happy professionista -> imposta", imposta_str)


def test_nuova_attivita_5pct():
    ai_client.chat_json = _fake_chiarif({
        "e_forfettario": True, "fatturato": 30000,
        "settore": "Professionali, scientifiche, tecniche, sanita, istruzione",
        "coefficiente": None, "nuova_attivita": True, "anno": None})
    out = _run(sciame.rispondi_forfettario("forfettario nuova attività 30000 professionista"))
    assert "5%" in out
    print("OK nuova attivita -> 5%")


def test_manca_fatturato_chiede():
    ai_client.chat_json = _fake_chiarif({
        "e_forfettario": True, "fatturato": None, "settore": None,
        "coefficiente": None, "nuova_attivita": None, "anno": None,
        "domanda": "Qual è il fatturato incassato nell'anno?"})
    out = _run(sciame.rispondi_forfettario("un forfettario quanto paga?"))
    assert "fatturato" in out.lower()
    print("OK manca fatturato -> domanda")


def test_non_forfettario_passa():
    ai_client.chat_json = _fake_chiarif({"e_forfettario": False})
    out = _run(sciame.rispondi_forfettario("calcola IMU su A/3"))
    assert out is None
    print("OK non forfettario -> None (passa al flusso esistente)")


def test_revisore_blocca_risultato_corrotto():
    ai_client.chat_json = _fake_chiarif({
        "e_forfettario": True, "fatturato": 50000,
        "settore": "Commercio ingrosso e dettaglio",
        "coefficiente": None, "nuova_attivita": False, "anno": None})
    # Motore "manomesso": netto maggiore del fatturato (impossibile) → il revisore deve bloccare
    orig = _forf.simula_forfettario
    def _corrotto(*a, **k):
        d = orig(50000, 0.40, False, anno=2026)
        d["netto_in_tasca"] = 999999.0
        return d
    sciame._forf.simula_forfettario = _corrotto
    try:
        out = _run(sciame.rispondi_forfettario("forfettario commerciante 50000"))
        assert "non mostro" in out.lower(), f"il revisore non ha bloccato:\n{out}"
        print("OK revisore blocca risultato corrotto")
    finally:
        sciame._forf.simula_forfettario = orig


from fiscal_engine import iva as _iva


def test_iva_scorporo():
    ai_client.chat_json = _fake_chiarif({
        "e_iva": True, "operazione": "scorporo", "importo": 1220, "aliquota": 22})
    out = _run(sciame.rispondi_iva("scorpora l'IVA da 1220 al 22%"))
    assert "1.000,00" in out and "220,00" in out, out
    print("OK IVA scorporo 1220 -> imponibile 1.000,00 / IVA 220,00")


def test_iva_calcolo_default_22():
    ai_client.chat_json = _fake_chiarif({
        "e_iva": True, "operazione": "calcolo", "importo": 1000, "aliquota": None})
    out = _run(sciame.rispondi_iva("quanto fa l'IVA su 1000?"))
    assert "22%" in out and "220,00" in out and "ORDINARIA" in out.upper(), out
    print("OK IVA calcolo default 22% -> 220,00 + nota ipotesi")


def test_iva_liquidazione():
    ai_client.chat_json = _fake_chiarif({
        "e_iva": True, "operazione": "liquidazione", "iva_vendite": 5000, "iva_acquisti": 3000})
    out = _run(sciame.rispondi_iva("liquidazione iva vendite 5000 acquisti 3000"))
    assert "2.000,00" in out and "debito" in out.lower(), out
    print("OK IVA liquidazione -> saldo 2.000,00 a debito")


def test_iva_non_iva_passa():
    ai_client.chat_json = _fake_chiarif({"e_iva": False})
    out = _run(sciame.rispondi_iva("calcola IRPEF su 35000"))
    assert out is None
    print("OK IVA non pertinente -> None")


def test_iva_revisore_blocca():
    ai_client.chat_json = _fake_chiarif({
        "e_iva": True, "operazione": "calcolo", "importo": 1000, "aliquota": 22})
    orig = _iva.calcola_iva
    def _corrotto(*a, **k):
        d = orig(1000, 22, anno=2026)
        d["totale"] = 99999.0  # totale incoerente
        return d
    sciame._iva.calcola_iva = _corrotto
    try:
        out = _run(sciame.rispondi_iva("iva su 1000 al 22"))
        assert "non mostro" in out.lower(), out
        print("OK IVA revisore blocca risultato corrotto")
    finally:
        sciame._iva.calcola_iva = orig


from fiscal_engine import irpef as _irpef


def test_irpef_calcolo():
    ai_client.chat_json = _fake_chiarif({"e_irpef": True, "reddito": 35000, "anno": None})
    out = _run(sciame.rispondi_irpef("calcola l'irpef su 35 mila di reddito"))
    atteso = _irpef.calcola_irpef(35000, anno=2026)
    lorda = sciame._eur(atteso["irpef_lorda"])
    assert lorda in out, f"IRPEF lorda {lorda} non trovata in:\n{out}"
    assert "LORDA" in out.upper()
    print("OK IRPEF 35000 -> lorda", lorda)


def test_irpef_manca_reddito():
    ai_client.chat_json = _fake_chiarif({"e_irpef": True, "reddito": None,
                                         "domanda": "Qual è il reddito imponibile?"})
    out = _run(sciame.rispondi_irpef("quanto paga di irpef?"))
    assert "reddito" in out.lower()
    print("OK IRPEF manca reddito -> domanda")


def test_irpef_non_irpef_passa():
    ai_client.chat_json = _fake_chiarif({"e_irpef": False})
    out = _run(sciame.rispondi_irpef("scorpora iva da 1220"))
    assert out is None
    print("OK IRPEF non pertinente -> None")


def test_irpef_revisore_blocca():
    ai_client.chat_json = _fake_chiarif({"e_irpef": True, "reddito": 35000, "anno": None})
    orig = _irpef.calcola_irpef
    def _corrotto(*a, **k):
        d = orig(35000, anno=2026)
        d["irpef_lorda"] = 1.0  # incoerente con la somma degli scaglioni
        return d
    sciame._irpef.calcola_irpef = _corrotto
    try:
        out = _run(sciame.rispondi_irpef("irpef su 35000"))
        assert "non mostro" in out.lower(), out
        print("OK IRPEF revisore blocca risultato corrotto")
    finally:
        sciame._irpef.calcola_irpef = orig


from fiscal_engine import dichiarativo_730 as _s730


def test_730_rimborso():
    ai_client.chat_json = _fake_chiarif({"e_730": True, "reddito": 35000,
                                         "ritenute": 9000, "detrazioni": 1910, "anno": None})
    out = _run(sciame.rispondi_730("col 730 questo cliente avrà un rimborso? reddito 35000 ritenute 9000 detrazioni 1910"))
    assert "RIMBORSO" in out.upper() and "2.160,00" in out, out
    print("OK 730 rimborso -> 2.160,00")


def test_730_a_debito():
    ai_client.chat_json = _fake_chiarif({"e_730": True, "reddito": 35000,
                                         "ritenute": 5000, "detrazioni": 1910, "anno": None})
    out = _run(sciame.rispondi_730("730 reddito 35000 ritenute 5000 detrazioni 1910"))
    assert "DEBITO" in out.upper() and "1.840,00" in out, out
    print("OK 730 a debito -> 1.840,00")


def test_730_manca_ritenute():
    ai_client.chat_json = _fake_chiarif({"e_730": True, "reddito": 35000, "ritenute": None,
                                         "detrazioni": None, "anno": None,
                                         "domanda": "Quali sono le ritenute IRPEF subite (CU)?"})
    out = _run(sciame.rispondi_730("730 con reddito 35000"))
    assert "ritenute" in out.lower()
    print("OK 730 manca ritenute -> domanda")


def test_730_non_730_passa():
    ai_client.chat_json = _fake_chiarif({"e_730": False})
    out = _run(sciame.rispondi_730("scorpora iva da 1220"))
    assert out is None
    print("OK 730 non pertinente -> None")


def test_730_revisore_blocca():
    ai_client.chat_json = _fake_chiarif({"e_730": True, "reddito": 35000,
                                         "ritenute": 9000, "detrazioni": 1910, "anno": None})
    orig = _s730.esito_730
    def _corrotto(*a, **k):
        d = orig(35000, ritenute=9000, detrazioni=1910, anno=2026)
        d["importo"] = 99999.0  # incoerente col saldo
        return d
    sciame._s730.esito_730 = _corrotto
    try:
        out = _run(sciame.rispondi_730("730 reddito 35000 ritenute 9000 detrazioni 1910"))
        assert "non mostro" in out.lower(), out
        print("OK 730 revisore blocca risultato corrotto")
    finally:
        sciame._s730.esito_730 = orig


def test_730_auto_detrazione_dipendente():
    ai_client.chat_json = _fake_chiarif({"e_730": True, "reddito": 35000, "ritenute": 9000,
                                         "detrazioni": None, "tipo_reddito": "lavoro_dipendente",
                                         "anno": None})
    out = _run(sciame.rispondi_730("cliente dipendente, 35000 di reddito e 9000 di ritenute, col 730 cosa prende?"))
    assert "STIMATE" in out.upper() and "RIMBORSO" in out.upper(), out
    print("OK 730 auto-detrazione dipendente -> stima + rimborso")


if __name__ == "__main__":
    test_happy_professionista()
    test_nuova_attivita_5pct()
    test_manca_fatturato_chiede()
    test_non_forfettario_passa()
    test_revisore_blocca_risultato_corrotto()
    test_iva_scorporo()
    test_iva_calcolo_default_22()
    test_iva_liquidazione()
    test_iva_non_iva_passa()
    test_iva_revisore_blocca()
    test_irpef_calcolo()
    test_irpef_manca_reddito()
    test_irpef_non_irpef_passa()
    test_irpef_revisore_blocca()
    test_730_rimborso()
    test_730_a_debito()
    test_730_manca_ritenute()
    test_730_non_730_passa()
    test_730_revisore_blocca()
    test_730_auto_detrazione_dipendente()
    print("\nTUTTI I TEST SCIAME OK")
