"""
DigitalVault - PREPARA UN SSD NUOVO (per consegnarlo a un nuovo studio).
(c) 2026 DigitalVault - Capo Team del Progetto: Dr. Falsone Giuseppe

Risolve il problema "non riesco a fare la copia dell'SSD": copiare la cartella
a mano mentre il programma è acceso fallisce, perché il database e altri file
sono BLOCCATI (in uso). Questo strumento fa una copia PULITA e funzionante:

  1. consolida e COMPATTA il database (niente file bloccati, niente spazio sprecato);
  2. copia TUTTO il necessario sulla destinazione (programma, Python, manuali);
  3. ESCLUDE ciò che non va copiato (backup cifrati col vecchio SSD, file temporanei);
  4. per un NUOVO cliente AZZERA i dati e toglie licenza/chiave AI, così il nuovo
     studio parte pulito e attiva la propria licenza e la propria chiave.

Va eseguito a PROGRAMMA CHIUSO. Pensato per essere lanciato da
"SOLO PROPRIETARIO/PREPARA SSD NUOVO CLIENTE.bat".
"""
import shutil
import sqlite3
import sys
from pathlib import Path

# Radice dell'SSD = la cartella che CONTIENE MOTORE (es. E:\)
RADICE = Path(__file__).resolve().parent.parent
MOTORE = Path(__file__).resolve().parent

# Cartelle da NON copiare mai (spazzatura, roba di sistema, backup legati al vecchio SSD)
CARTELLE_ESCLUSE = {
    "SOLO PROPRIETARIO",             # 🔴 IL SEGRETO (chiave privata, generatore licenze): NON deve MAI finire al cliente
    "__pycache__", "_aggiornamento", "estratto",
    "backups",                       # backup cifrati col serial del VECCHIO SSD: inutili altrove
    "System Volume Information", "$RECYCLE.BIN",
    ".Spotlight-V100", ".Trashes", ".fseventsd", ".claude",
}
# Singoli file/prefissi da escludere
def _file_da_escludere(nome: str) -> bool:
    n = nome.lower()
    return (
        n.endswith((".pyc", ".db-wal", ".db-shm", ".tmp", ".log"))
        or nome.startswith("._")                 # metadati Mac
        or nome.startswith("_backup_programma_")
        or nome.startswith("_backup_pre_")
        or nome.startswith("_test")
        or nome == "thumbs.db" or nome == ".ds_store"
    )


def _ignora(cartella, contenuti):
    """Funzione 'ignore' per shutil.copytree: salta cartelle e file esclusi."""
    saltati = []
    for c in contenuti:
        if c in CARTELLE_ESCLUSE or _file_da_escludere(c):
            saltati.append(c)
    return set(saltati)


def _compatta_db():
    """Consolida il WAL e compatta il database PRIMA della copia."""
    db = MOTORE / "data" / "digitalvault.db"
    if not db.exists():
        return
    try:
        con = sqlite3.connect(str(db), timeout=15)
        con.isolation_level = None
        con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        con.execute("VACUUM")
        con.close()
        print("  [OK] Database consolidato e compattato.")
    except Exception as e:
        print(f"  [!] Non sono riuscito a compattare il database ({e}). Continuo comunque.")


def _azzera_per_nuovo_cliente(dest_motore: Path):
    """Sulla COPIA (non sull'originale!) toglie i dati e le credenziali del
    vecchio studio, così il nuovo cliente parte pulito."""
    data = dest_motore / "data"
    uploads = dest_motore / "uploads"

    # Database: lo cancello → al primo avvio si ricrea VUOTO (con le sole scadenze standard)
    for nome in ("digitalvault.db", "digitalvault.db-wal", "digitalvault.db-shm"):
        f = data / nome
        if f.exists():
            f.unlink()

    # Credenziali legate al vecchio SSD: il nuovo studio mette le sue
    for nome in ("licenza.dat", "ai_key.enc", "backup.key",
                 "rete_pin.txt", "backup_status.json", ".campi_cifrati"):
        f = data / nome
        if f.exists():
            f.unlink()

    # Vecchie copie/residui dentro data/
    for f in data.glob("_backup_pre_*"):
        shutil.rmtree(f, ignore_errors=True)

    # Documenti caricati dal vecchio studio: via tutti, lasciando la cartella
    if uploads.exists():
        for f in uploads.iterdir():
            if f.is_file():
                f.unlink()
            else:
                shutil.rmtree(f, ignore_errors=True)

    print("  [OK] Copia azzerata: nessun dato, nessuna licenza del vecchio studio.")


def _verifica_sicurezza(dest: Path) -> list:
    """Controllo finale: il SEGRETO non deve MAI essere finito nella copia.
    Se trova qualcosa, lo RIMUOVE e lo segnala (rete di sicurezza)."""
    problemi = []
    sp = dest / "SOLO PROPRIETARIO"
    if sp.exists():
        shutil.rmtree(sp, ignore_errors=True)
        problemi.append("cartella SOLO PROPRIETARIO (rimossa)")
    for nome in ("chiave_privata.pem", "genera_licenza.py", "crea_copia.py", "firma_aggiornamento.py"):
        for p in dest.rglob(nome):
            try:
                p.unlink()
                problemi.append(f"{nome} (rimosso da {p.parent})")
            except Exception:
                problemi.append(f"{nome} TROVATO ma NON rimosso: {p}")
    return problemi


def prepara(destinazione: str, azzera: bool = True) -> dict:
    """Crea la copia pulita su 'destinazione'. Ritorna un riepilogo."""
    dest = Path(destinazione)
    if dest.drive and dest.drive.upper() == RADICE.drive.upper():
        raise ValueError("La destinazione coincide con l'SSD di origine: scegli un disco DIVERSO.")
    dest.mkdir(parents=True, exist_ok=True)

    print(">>> Passo 1/3: preparo il database...")
    _compatta_db()

    print(f">>> Passo 2/3: copio il programma su {dest} (può richiedere qualche minuto)...")
    copiati = 0
    for elemento in RADICE.iterdir():
        if elemento.name in CARTELLE_ESCLUSE or _file_da_escludere(elemento.name):
            continue
        target = dest / elemento.name
        if elemento.is_dir():
            shutil.copytree(elemento, target, ignore=_ignora, dirs_exist_ok=True)
        else:
            shutil.copy2(elemento, target)
        copiati += 1
    print(f"  [OK] Copiati {copiati} elementi principali.")

    if azzera:
        print(">>> Passo 3/3: azzero i dati per il nuovo cliente...")
        _azzera_per_nuovo_cliente(dest / "MOTORE")
    else:
        print(">>> Passo 3/3: CLONE completo (dati mantenuti). Tolgo solo la licenza del vecchio SSD...")
        for nome in ("licenza.dat", "ai_key.enc", "backup.key", "rete_pin.txt"):
            f = dest / "MOTORE" / "data" / nome
            if f.exists():
                f.unlink()

    # Rete di sicurezza: il segreto NON deve mai essere nella copia.
    leak = _verifica_sicurezza(dest)
    if leak:
        print("  [SICUREZZA] Rimosso materiale riservato finito per errore nella copia:")
        for x in leak:
            print(f"     - {x}")
    else:
        print("  [OK] Controllo sicurezza superato: nessun segreto nella copia.")

    return {"destinazione": str(dest), "elementi": copiati, "azzerato": azzera,
            "sicurezza_ok": not leak}


def main():
    print("=" * 60)
    print("  DIGITALVAULT - PREPARA UN SSD NUOVO")
    print("=" * 60)
    if len(sys.argv) < 2:
        print("\nUso: prepara_nuovo_ssd.py <DESTINAZIONE> [--clona]")
        print("Esempio: prepara_nuovo_ssd.py F:\\")
        print("  (senza --clona azzera i dati per un nuovo cliente)")
        return 1
    destinazione = sys.argv[1]
    azzera = "--clona" not in sys.argv
    try:
        esito = prepara(destinazione, azzera=azzera)
    except Exception as e:
        print(f"\n[ERRORE] {e}")
        return 1
    print("\n" + "=" * 60)
    print("  FATTO! L'SSD nuovo e' pronto.")
    print(f"  Destinazione: {esito['destinazione']}")
    if esito["azzerato"]:
        print("  Stato: PULITO per un nuovo cliente (niente dati, niente licenza).")
        print("  Il nuovo studio: avvia, genera la licenza, mette la sua chiave AI.")
    else:
        print("  Stato: COPIA COMPLETA con i dati (serve comunque una nuova licenza).")
    print("=" * 60)
    return 0


if __name__ == "__main__":
    sys.exit(main())
