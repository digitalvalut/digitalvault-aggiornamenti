"""
FiscoSicuro - Risk-Audit: scansione di compliance PROATTIVA e DETERMINISTICA.
(c) 2026 DigitalVault - Capo Team del Progetto: Dr. Falsone Giuseppe

Primo modulo della linea "Evolution". Filosofia identica al resto del prodotto:
  - NIENTE AI: legge i dati GIA' presenti (clienti, documenti, eventi, scadenze)
    e le soglie VERSIONATE (fiscal_reference) e produce "rilievi" azionabili.
  - Nessun numero rilevante è inventato: le soglie arrivano dai .yaml.
  - Isolato (plugin): comunica col sistema solo via la funzione analizza(db);
    nessuna dipendenza circolare, non tocca la contabilità stabile.

Controlli inclusi (Step 1):
  1. Soglie di regime (forfettario vicino/oltre 85k / oltre 100k)
  2. Importi estratti dall'AI ancora da verificare (flag della Fase D)
  3. Possibili doppioni di documenti (stesso fornitore/importo/anno)
  4. Anagrafiche incomplete (CF mancante, società senza P.IVA)
  5. Scadenze scadute non gestite
"""
import json
from datetime import datetime

import yaml
from sqlalchemy import func

from config import BASE_DIR
from database import Client, Document, ClientEvent, Scadenza

_FORF = BASE_DIR / "fiscal_reference" / "forfettario.yaml"

_ORDINE = {"critica": 0, "alta": 1, "media": 2, "bassa": 3}


def _soglie_forfettario():
    """Legge soglia e regole dalla fonte versionata (mai numeri nel codice)."""
    try:
        ref = yaml.safe_load(_FORF.read_text(encoding="utf-8"))
        return (float(ref.get("soglia_ricavi", 85000)),
                ref.get("regole_soglia", {}) or {},
                ref.get("legal_source", ""))
    except Exception:
        return 85000.0, {}, ""


def _rilievo(gravita, categoria, titolo, dettaglio, azione=None, riferimento=None, fonte=None):
    return {"gravita": gravita, "categoria": categoria, "titolo": titolo,
            "dettaglio": dettaglio, "azione": azione,
            "riferimento": riferimento, "fonte": fonte}


def _eur(x) -> str:
    """Formatta in stile italiano: 85.000."""
    return f"{x:,.0f}".replace(",", ".")


def _soglie_regime(db):
    """Forfettari vicini o oltre la soglia di ricavi (stima d'allerta)."""
    out = []
    soglia, regole, fonte = _soglie_forfettario()
    avvicinamento = soglia * 0.82
    anno = datetime.now().year
    for c in db.query(Client).filter(Client.regime == "forfettario").all():
        ric_doc = db.query(func.coalesce(func.sum(Document.importo), 0.0)).filter(
            Document.client_id == c.id, Document.importo.isnot(None),
            Document.anno_riferimento == anno).scalar() or 0.0
        ric_ev = db.query(func.coalesce(func.sum(ClientEvent.importo), 0.0)).filter(
            ClientEvent.client_id == c.id,
            ClientEvent.tipo.in_(["fattura", "pagamento"]),
            ClientEvent.importo.isnot(None)).scalar() or 0.0
        ricavi = max(ric_doc, ric_ev)
        nome = f"{c.cognome} {c.nome}".strip()
        if ricavi >= 100000:
            out.append(_rilievo("critica", "soglia_regime",
                f"{nome}: forfettario oltre €100.000",
                f"Ricavi stimati €{_eur(ricavi)}. {regole.get('oltre_100000', '')}".strip(),
                azione="Verifica l'uscita IMMEDIATA dal regime e l'IVA dalla fattura che supera",
                riferimento={"client_id": c.id}, fonte=fonte))
        elif ricavi >= soglia:
            out.append(_rilievo("alta", "soglia_regime",
                f"{nome}: forfettario oltre la soglia €{_eur(soglia)}",
                f"Ricavi stimati €{_eur(ricavi)}. {regole.get('tra_85000_e_100000', '')}".strip(),
                azione="Pianifica l'uscita dal regime dall'anno successivo",
                riferimento={"client_id": c.id}, fonte=fonte))
        elif ricavi >= avvicinamento:
            out.append(_rilievo("media", "soglia_regime",
                f"{nome}: forfettario vicino alla soglia",
                f"Ricavi stimati €{_eur(ricavi)} su €{_eur(soglia)}. Tienilo d'occhio.",
                azione="Monitora i ricavi nei prossimi mesi",
                riferimento={"client_id": c.id}, fonte=fonte))
    return out


def _importi_non_verificati(db):
    """Documenti il cui importo è stato estratto dall'AI e NON riscontrato nel testo."""
    out = []
    sospetti = []
    for d in db.query(Document).filter(Document.dati_estratti.isnot(None)).all():
        try:
            dati = json.loads(d.dati_estratti) if d.dati_estratti else {}
        except Exception:
            continue
        if isinstance(dati, dict) and dati.get("importo_da_verificare"):
            sospetti.append(d)
    if sospetti:
        esempi = "; ".join((x.nome_originale or "documento")[:30] for x in sospetti[:3])
        out.append(_rilievo("media", "importi_ai",
            f"{len(sospetti)} importi estratti dall'AI da verificare",
            f"Importo non riscontrato nel testo ({esempi}{'…' if len(sospetti) > 3 else ''}). "
            f"Conferma con l'originale prima di usarli per soglie o dichiarazioni.",
            azione="Apri l'archivio e verifica gli originali",
            riferimento={"doc_ids": [x.id for x in sospetti[:20]]}))
    return out


def _documenti_duplicati(db):
    """Possibili doppioni: stesso fornitore + importo + anno (rischio doppio conteggio)."""
    out = []
    gruppi = {}
    for d in db.query(Document).filter(Document.importo.isnot(None)).all():
        cp = str(d.controparte or "").strip().lower()
        if not cp:
            continue                                  # senza controparte è poco affidabile
        chiave = (cp, round(float(d.importo), 2), d.anno_riferimento)
        gruppi.setdefault(chiave, []).append(d)
    for g in (x for x in gruppi.values() if len(x) > 1):
        d0 = g[0]
        out.append(_rilievo("bassa", "duplicati",
            f"{len(g)} documenti identici (possibile doppione)",
            f"Stesso fornitore/importo/anno (€{float(d0.importo):,.2f}). "
            f"Potrebbero essere doppioni o ricorrenze legittime (es. affitto mensile): controlla.",
            azione="Controlla ed elimina eventuali doppioni",
            riferimento={"doc_ids": [x.id for x in g]}))
    return out


def _compliance_anagrafica(db):
    """Anagrafiche incomplete che bloccano adempimenti."""
    out = []
    senza_cf = db.query(Client).filter(
        (Client.codice_fiscale.is_(None)) | (Client.codice_fiscale == "")).count()
    if senza_cf:
        out.append(_rilievo("bassa", "anagrafica",
            f"{senza_cf} clienti senza codice fiscale",
            "Dato necessario per dichiarazioni e adempimenti.",
            azione="Completa le anagrafiche"))
    societa_senza_piva = db.query(Client).filter(
        Client.tipo == "societa",
        (Client.partita_iva.is_(None)) | (Client.partita_iva == "")).count()
    if societa_senza_piva:
        out.append(_rilievo("media", "anagrafica",
            f"{societa_senza_piva} società senza partita IVA",
            "Una società deve avere una P.IVA: verifica il dato.",
            azione="Completa le anagrafiche"))
    return out


def _scadenze_critiche(db):
    """Scadenze oltre il termine non ancora gestite."""
    out = []
    scadute = db.query(Scadenza).filter(
        Scadenza.completata == False, Scadenza.data_scadenza < datetime.now()).count()
    if scadute:
        out.append(_rilievo("alta", "scadenze",
            f"{scadute} scadenze SCADUTE non gestite",
            "Adempimenti oltre il termine: rischio sanzioni.",
            azione="Vai alle scadenze"))
    return out


def _per_categoria(rilievi):
    out = {}
    for r in rilievi:
        out[r["categoria"]] = out.get(r["categoria"], 0) + 1
    return out


def analizza(db) -> dict:
    """Esegue tutti i controlli deterministici e ritorna il report dei rilievi,
    ordinati per gravità. Ogni controllo è isolato: se uno fallisce, gli altri
    proseguono (come motore_proattivo)."""
    rilievi = []
    for fn in (_soglie_regime, _importi_non_verificati, _documenti_duplicati,
               _compliance_anagrafica, _scadenze_critiche):
        try:
            rilievi.extend(fn(db))
        except Exception:
            continue
    rilievi.sort(key=lambda r: _ORDINE.get(r["gravita"], 4))
    return {
        "rilievi": rilievi,
        "totale": len(rilievi),
        "critici": sum(1 for r in rilievi if r["gravita"] in ("critica", "alta")),
        "per_categoria": _per_categoria(rilievi),
        "generato": datetime.now().isoformat(),
        "versione_motore": "risk-audit/1",
    }
