import uuid
import os
import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional, List
from contextlib import asynccontextmanager

from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form, Request
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse, FileResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.orm import Session

from config import (UPLOAD_DIR, DATA_DIR, DB_PATH, APP_NAME, APP_VERSION,
                    PORT_RANGE, TIERS, DEFAULT_TIER, OPENROUTER_API_KEY)
from database import init_db, get_db, SessionLocal, Client, Document, ChatMessage, Scadenza, ClientEvent, Setting, cerca_documenti_fts
from ai_client import chat_with_ai, chat_with_ai_meta, stream_chat_with_ai, help_system_prompt, costi_ai
from pdf_processor import extract_text_from_pdf, detect_document_type, get_document_summary
import doc_brain
from pdf_generator import genera_pdf_consulenza, genera_pdf_scheda_cliente
import email_sender
import license_manager
import tax_calculator
import backup_manager
import validators
import scadenze_cliente
import updater
import fatture_elettroniche as fe
import ocr_massa
import scopri_clienti
import doc_classifier
import motore_proattivo
import classifica_coda
import riconciliazione
import email_reader
import json as _json
import re as _re
import secrets as _secrets
import base64 as _b64


# Rete di sicurezza identita': ripulisce QUALSIASI messaggio d'errore in uscita
# da nomi di modelli o provider, cosi' non trapelano mai verso il browser.
_PAROLE_VIETATE = _re.compile(
    r"(anthropic|claude|openai|gpt|chatgpt|google|gemini|x-ai|grok|deepseek|"
    r"meta-?llama|llama|mistral|qwen|openrouter|opus|sonnet|haiku)[\w.\-/:]*",
    _re.IGNORECASE,
)
_MSG_AI_GENERICO = ("Servizio AI non raggiungibile in questo momento. "
                    "Controlla la connessione e riprova tra poco.")


def errore_ai_sicuro(e) -> str:
    """Messaggio d'errore AI pulito da mostrare all'utente: se contiene nomi
    di modelli/provider, viene sostituito con un messaggio generico."""
    testo = str(e)
    if _PAROLE_VIETATE.search(testo):
        return _MSG_AI_GENERICO
    # Anche se non cita nomi noti, manteniamo un messaggio sobrio
    return testo if testo and "Errore" not in testo[:8] else _MSG_AI_GENERICO


def get_setting(db: Session, chiave: str, default=None):
    s = db.query(Setting).filter(Setting.chiave == chiave).first()
    return s.valore if s else default


def set_setting(db: Session, chiave: str, valore: str):
    s = db.query(Setting).filter(Setting.chiave == chiave).first()
    if s:
        s.valore = valore
    else:
        db.add(Setting(chiave=chiave, valore=valore))
    db.commit()


def get_studio_info(db: Session) -> dict:
    raw = get_setting(db, "studio_info")
    if raw:
        try:
            return _json.loads(raw)
        except Exception:
            return {}
    return {}


def get_email_config(db: Session) -> dict:
    raw = get_setting(db, "email_config")
    if raw:
        try:
            return _json.loads(raw)
        except Exception:
            return {}
    return {}


def log_event(db: Session, client_id: int, tipo: str, titolo: str, descrizione: str = None, importo: float = None):
    """Registra un evento nella timeline del cliente."""
    if not client_id:
        return
    db.add(ClientEvent(client_id=client_id, tipo=tipo, titolo=titolo,
                       descrizione=descrizione, importo=importo))
    db.commit()

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    # Backup automatico: subito all'avvio e poi ogni poche ore mentre e' aperto
    backup_manager.avvia_backup_automatico()
    yield


app = FastAPI(title=APP_NAME, version=APP_VERSION, lifespan=lifespan)
# Solo le pagine aperte da questo computer possono parlare con il programma:
# un sito web esterno NON deve poter leggere i dati dello studio.
_ALLOWED_ORIGINS = [f"http://localhost:{p}" for p in PORT_RANGE] + \
                   [f"http://127.0.0.1:{p}" for p in PORT_RANGE]
app.add_middleware(CORSMiddleware, allow_origins=_ALLOWED_ORIGINS,
                   allow_methods=["*"], allow_headers=["*"])

# ─── SICUREZZA RETE STUDIO: PIN di accesso ────────────────────────────────────
# In modalita' locale (default) nessun attrito: l'app e' raggiungibile solo da
# questo PC. In modalita' RETE STUDIO (0.0.0.0, LAN) si attiva un PIN: gli altri
# computer devono inserirlo, altrimenti NON possono leggere i dati dello studio.
RETE_MODE = os.environ.get("DIGITALVAULT_RETE") == "1"


def _carica_pin_rete() -> str:
    """PIN per la rete studio: da env DIGITALVAULT_PIN, oppure generato e
    salvato (stabile fra i riavvii) in data/rete_pin.txt."""
    pin = (os.environ.get("DIGITALVAULT_PIN") or "").strip()
    if pin:
        return pin
    pin_file = DATA_DIR / "rete_pin.txt"
    try:
        if pin_file.exists():
            v = pin_file.read_text(encoding="utf-8").strip()
            if v:
                return v
        nuovo = f"{_secrets.randbelow(900000) + 100000}"   # 6 cifre
        DATA_DIR.mkdir(exist_ok=True)
        pin_file.write_text(nuovo, encoding="utf-8")
        return nuovo
    except Exception:
        return f"{_secrets.randbelow(900000) + 100000}"


ACCESS_PIN = _carica_pin_rete() if RETE_MODE else None

if RETE_MODE:
    @app.middleware("http")
    async def _rete_auth(request: Request, call_next):
        # L'accesso DA QUESTO computer (titolare) resta senza PIN.
        client_host = request.client.host if request.client else ""
        if client_host in ("127.0.0.1", "::1", "localhost"):
            return await call_next(request)
        # Dagli altri PC: serve il PIN (HTTP Basic, gestito dal browser).
        hdr = request.headers.get("authorization", "")
        ok = False
        if hdr.startswith("Basic "):
            try:
                dec = _b64.b64decode(hdr[6:]).decode("utf-8", "ignore")
                _, _, pw = dec.partition(":")
                ok = _secrets.compare_digest(pw.strip(), ACCESS_PIN or "\0")
            except Exception:
                ok = False
        if not ok:
            return Response(
                status_code=401,
                headers={"WWW-Authenticate": 'Basic realm="FiscoSicuro - Rete Studio"'},
                content="Accesso riservato allo studio: inserisci il PIN.",
            )
        return await call_next(request)

BASE_DIR = Path(__file__).parent
(BASE_DIR / "static").mkdir(exist_ok=True)
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")


# ─── FRONTEND ────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def index():
    html_path = BASE_DIR / "templates" / "index.html"
    return FileResponse(str(html_path), media_type="text/html")


# ─── HEALTH ──────────────────────────────────────────────────────────────────

def _tier_attivo() -> dict:
    """Versione attiva (Base/Media/Superior) letta dalla licenza."""
    tier = license_manager.get_tier()
    info = TIERS.get(tier, TIERS[DEFAULT_TIER])
    return {"tier": tier, **info}


@app.get("/api/health")
async def health():
    t = _tier_attivo()
    return {"status": "ok", "app": APP_NAME, "version": APP_VERSION,
            "tier": t["tier"], "versione": t["nome"], "model": t["modelli"][0]}


# ─── LICENZA / ATTIVAZIONE ────────────────────────────────────────────────────

class ActivateRequest(BaseModel):
    key: str


@app.get("/api/license/status")
async def license_status():
    return license_manager.license_status()


@app.post("/api/license/activate")
async def license_activate(req: ActivateRequest):
    if license_manager.activate(req.key):
        return {"activated": True}
    raise HTTPException(status_code=403, detail="Chiave di licenza non valida per questo computer.")


def require_license():
    """Dipendenza: blocca le API protette se il software non e' attivato."""
    if not license_manager.is_activated():
        raise HTTPException(status_code=402, detail="Software non attivato. Inserire la chiave di licenza.")
    return True


# ─── PANNELLO AMMINISTRATORE ─────────────────────────────────────────────────
# Su http://localhost:PORTA/admin : tutto il funzionamento a colpo d'occhio.

def _mask(key: str) -> str:
    if not key or len(key) < 14:
        return "(non impostata)"
    return key[:12] + "…" + key[-4:]


@app.get("/api/admin/info")
async def admin_info(db: Session = Depends(get_db)):
    t = _tier_attivo()
    lic = license_manager.license_status()
    n_clients = db.query(Client).count()
    n_docs = db.query(Document).count()
    n_msgs = db.query(ChatMessage).count()
    return {
        "app": APP_NAME, "version": APP_VERSION,
        "licenza": lic,
        "versione_attiva": {
            "tier": t["tier"], "nome": t["nome"], "descrizione": t["descrizione"],
            "max_tokens": t["max_tokens"], "memoria_chat": t["memoria_chat"],
            "modello_primario": t["modelli"][0],
            "modelli_riserva": t["modelli"][1:],
            "modelli_vision": t["modelli_vision"],
        },
        "chiave_ai_mascherata": _mask(OPENROUTER_API_KEY),
        "costi_ai": await costi_ai(),
        "dati": {
            "database": str(DB_PATH),
            "documenti": str(UPLOAD_DIR),
            "nota_privacy": "Tutti i dati dello studio restano SOLO su questo SSD. "
                            "In internet viaggiano unicamente le domande fatte all'AI.",
        },
        "contatori": {"clienti": n_clients, "documenti": n_docs, "messaggi_chat": n_msgs},
    }


# ─── BACKUP DEI DATI ─────────────────────────────────────────────────────────

@app.get("/api/backup/stato")
async def backup_stato():
    return backup_manager.stato_backup()


@app.get("/api/backup/elenco")
async def backup_elenco():
    return backup_manager.elenco_backup()


@app.post("/api/backup/esegui")
async def backup_esegui():
    esito = backup_manager.esegui_backup("manuale")
    if not esito.get("ok"):
        raise HTTPException(status_code=500, detail=esito.get("errore", "Backup non riuscito."))
    return esito


class RipristinoRequest(BaseModel):
    nome: str


@app.post("/api/backup/ripristina")
async def backup_ripristina(req: RipristinoRequest):
    esito = backup_manager.ripristina_backup(req.nome)
    if not esito.get("ok"):
        raise HTTPException(status_code=400, detail=esito.get("errore", "Ripristino non riuscito."))
    return esito


@app.post("/api/backup/copia-pc")
async def backup_copia_pc():
    """Copia IN CHIARO tutti i dati sul PC (rete 'copia e incolla' anti-disastro)."""
    esito = backup_manager.esporta_chiaro()
    if not esito.get("ok"):
        raise HTTPException(status_code=500, detail=esito.get("errore", "Copia non riuscita."))
    return esito


class PwdBackupReq(BaseModel):
    password: str


@app.post("/api/backup/protetto")
async def backup_protetto(req: PwdBackupReq):
    """Crea un backup PORTATILE protetto dalla password del commercialista."""
    esito = backup_manager.esporta_protetto(req.password)
    if not esito.get("ok"):
        raise HTTPException(status_code=400, detail=esito.get("errore", "Backup non riuscito."))
    return esito


@app.post("/api/backup/ripristina-protetto")
async def backup_ripristina_protetto(file: UploadFile = File(...), password: str = Form(...)):
    """Ripristina da un backup protetto-password (anche di un altro SSD/PC)."""
    import tempfile as _tf
    tmp = Path(_tf.gettempdir()) / f"dvrestore_{datetime.now():%H%M%S}.dvb"
    try:
        tmp.write_bytes(await file.read())
        esito = backup_manager.ripristina_protetto(tmp, password)
    finally:
        try:
            tmp.unlink()
        except Exception:
            pass
    if not esito.get("ok"):
        raise HTTPException(status_code=400, detail=esito.get("errore", "Ripristino non riuscito."))
    return esito


# ─── AGGIORNAMENTI ───────────────────────────────────────────────────────────

@app.get("/api/aggiornamento/controlla")
async def aggiornamento_controlla():
    return updater.controlla()


class ScaricaUpdateReq(BaseModel):
    url_zip: str


@app.post("/api/aggiornamento/scarica")
async def aggiornamento_scarica(req: ScaricaUpdateReq):
    esito = updater.scarica(req.url_zip)
    if not esito.get("ok"):
        raise HTTPException(status_code=400, detail=esito.get("errore", "Download non riuscito."))
    return esito


@app.get("/admin", response_class=HTMLResponse)
async def admin_panel():
    return """<!doctype html><html lang="it"><head><meta charset="utf-8">
<title>DigitalVault — Pannello Amministratore</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
 body{font-family:Segoe UI,system-ui,sans-serif;background:#0f1420;color:#e6e9f0;margin:0;padding:32px}
 h1{font-size:22px;margin:0 0 4px}.sub{color:#8a93a8;font-size:13px;margin-bottom:24px}
 .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:16px;max-width:1100px}
 .card{background:#171e2e;border:1px solid #232c42;border-radius:12px;padding:18px}
 .card h2{font-size:14px;margin:0 0 12px;color:#7aa2ff}
 .row{display:flex;justify-content:space-between;gap:12px;font-size:13px;padding:5px 0;border-bottom:1px solid #1d2538}
 .row:last-child{border-bottom:none}.k{color:#8a93a8}.v{text-align:right;word-break:break-all}
 .badge{display:inline-block;padding:3px 12px;border-radius:20px;font-weight:700;font-size:13px}
 .BASE{background:#1d3a2a;color:#5fd38a}.MEDIA{background:#1d2e4a;color:#6fa8ff}.SUPERIOR{background:#3a2a1d;color:#ffb45f}
 .ok{color:#5fd38a}.no{color:#ff6b6b}ul{margin:6px 0;padding-left:18px;font-size:12px;color:#aab3c7}
 .mono{font-family:Consolas,monospace;font-size:12px}.full{grid-column:1/-1}
 .note{font-size:12px;color:#8a93a8;line-height:1.6}
</style></head><body>
<h1>🛡️ DigitalVault — Pannello Amministratore</h1>
<div class="sub">Tutto il funzionamento del sistema a colpo d'occhio · riservato all'amministratore</div>
<div class="grid" id="g">Caricamento…</div>
<script>
fetch('/api/admin/info').then(r=>r.json()).then(d=>{
 const v=d.versione_attiva, l=d.licenza;
 document.getElementById('g').innerHTML=`
 <div class="card"><h2>VERSIONE ATTIVA (abbonamento)</h2>
   <div style="margin-bottom:10px"><span class="badge ${v.tier}">${v.nome}</span></div>
   <div class="note">${v.descrizione}</div>
   <div class="row"><span class="k">Lunghezza max risposta</span><span class="v">${v.max_tokens.toLocaleString()} token</span></div>
   <div class="row"><span class="k">Memoria conversazione</span><span class="v">${v.memoria_chat} messaggi</span></div>
 </div>
 <div class="card"><h2>LICENZA E PROTEZIONE</h2>
   <div class="row"><span class="k">Stato</span><span class="v ${l.activated?'ok':'no'}">${l.activated?'✔ Attivata':'✖ NON attivata'}</span></div>
   <div class="row"><span class="k">ID computer</span><span class="v mono">${l.machine_id}</span></div>
   <div class="row"><span class="k">Serial SSD (anti-clonazione)</span><span class="v mono">${l.volume_id}</span></div>
   <div class="row"><span class="k">Titolare</span><span class="v">${l.titolare}</span></div>
   <div class="note" style="margin-top:8px">La licenza è legata a questo computer E a questo SSD: una copia su un altro disco non si attiva.</div>
 </div>
 <div class="card"><h2>INTELLIGENZA ARTIFICIALE</h2>
   <div class="row"><span class="k">Modello primario</span><span class="v mono">${v.modello_primario}</span></div>
   <div class="k" style="font-size:12px;margin-top:8px">Riserve automatiche (se il primario non risponde):</div>
   <ul>${v.modelli_riserva.map(m=>'<li class="mono">'+m+'</li>').join('')}</ul>
   <div class="row"><span class="k">Chiave AI di questo studio</span><span class="v mono">${d.chiave_ai_mascherata}</span></div>
 </div>
 <div class="card"><h2>CONSUMO AI DI QUESTO STUDIO</h2>
   ${d.costi_ai && d.costi_ai.ok ? `
   <div class="row"><span class="k">Oggi</span><span class="v">$${(d.costi_ai.oggi||0).toFixed(2)}</span></div>
   <div class="row"><span class="k">Questa settimana</span><span class="v">$${(d.costi_ai.settimana||0).toFixed(2)}</span></div>
   <div class="row"><span class="k">Questo mese</span><span class="v">$${(d.costi_ai.mese||0).toFixed(2)}</span></div>
   <div class="row"><span class="k">Totale dall'inizio</span><span class="v">$${(d.costi_ai.totale||0).toFixed(2)}</span></div>
   ${d.costi_ai.ha_limite ? `
     <div class="row"><span class="k">Limite di spesa</span><span class="v">$${(d.costi_ai.limite||0).toFixed(2)}</span></div>
     <div class="row"><span class="k">Residuo</span><span class="v ${(d.costi_ai.residuo||0) < (d.costi_ai.limite||1)*0.15 ? 'no':'ok'}">$${(d.costi_ai.residuo||0).toFixed(2)}</span></div>
   ` : `<div class="note" style="margin-top:8px">Nessun limite di spesa impostato su questa chiave. Puoi metterne uno su openrouter.ai → Keys.</div>`}
   ` : `<div class="note">Consumo non disponibile in questo momento (serve connessione a Internet).</div>`}
 </div>
 <div class="card"><h2>DATI E PRIVACY</h2>
   <div class="row"><span class="k">Clienti</span><span class="v">${d.contatori.clienti}</span></div>
   <div class="row"><span class="k">Documenti</span><span class="v">${d.contatori.documenti}</span></div>
   <div class="row"><span class="k">Messaggi chat</span><span class="v">${d.contatori.messaggi_chat}</span></div>
   <div class="row"><span class="k">Database</span><span class="v mono">${d.dati.database}</span></div>
   <div class="note" style="margin-top:8px">${d.dati.nota_privacy}</div>
 </div>
 <div class="card full"><h2>COME FUNZIONA (in 3 righe)</h2>
   <div class="note">1. Il programma gira <b>in locale</b> da questo SSD: archivio, clienti e documenti non escono mai dal disco.<br>
   2. Solo le <b>domande all'AI</b> viaggiano cifrate verso OpenRouter con la chiave dedicata di questo studio (controllabile e disattivabile dal titolare).<br>
   3. La <b>versione</b> (Base / Media / Superior) è scritta nella chiave di licenza: per cambiarla serve una nuova chiave dal titolare.</div>
 </div>`;
}).catch(()=>document.getElementById('g').textContent='Errore di caricamento.');
</script></body></html>"""


# ─── CHAT ────────────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    client_id: Optional[int] = None
    document_context: Optional[str] = None


def _prepara_chat(req: "ChatRequest", db: Session):
    """Cronologia recente + messaggio utente. Salva subito il messaggio utente."""
    session_id = req.session_id or str(uuid.uuid4())
    # Gli ULTIMI N messaggi (la memoria dipende dalla versione Base/Media/Superior)
    memoria = _tier_attivo()["memoria_chat"]
    history = db.query(ChatMessage).filter(
        ChatMessage.session_id == session_id
    ).order_by(ChatMessage.id.desc()).limit(memoria).all()[::-1]

    # Token economy: invia all'AI gli ultimi messaggi entro un budget di caratteri
    # (~8000), così la chat ricorda il filo senza rimandare TUTTO lo storico a ogni
    # domanda. I messaggi restano salvati per intero nello storico.
    BUDGET_CARATTERI = 8000
    selezionati, tot = [], 0
    for m in reversed(history):                 # dal più recente
        clen = len(m.content or "")
        if selezionati and tot + clen > BUDGET_CARATTERI:
            break
        selezionati.append(m)
        tot += clen
    history = list(reversed(selezionati))

    messages = [{"role": m.role, "content": m.content} for m in history]
    user_content = req.message
    if req.document_context:
        user_content = f"[DOCUMENTO ALLEGATO]\n{req.document_context}\n\n[DOMANDA]\n{req.message}"

    messages.append({"role": "user", "content": user_content})

    db.add(ChatMessage(session_id=session_id, role="user", content=req.message, client_id=req.client_id))
    db.commit()
    return session_id, messages


@app.post("/api/chat")
async def chat(req: ChatRequest, db: Session = Depends(get_db), _lic=Depends(require_license)):
    session_id, messages = _prepara_chat(req, db)

    # COPILOTA: se è una richiesta di CALCOLO, rispondi col motore deterministico
    # (numero ESATTO, mai inventato dall'AI). Altrimenti chat normale.
    try:
        from copilota_calcoli import rispondi_calcolo
        dal_motore = await rispondi_calcolo(req.message)
    except Exception:
        dal_motore = None
    if dal_motore:
        db.add(ChatMessage(session_id=session_id, role="assistant", content=dal_motore, client_id=req.client_id))
        db.commit()
        return {"response": dal_motore, "session_id": session_id, "da_motore": True}

    try:
        esito = await chat_with_ai_meta(messages)
    except Exception as e:
        raise HTTPException(status_code=500, detail=errore_ai_sicuro(e))
    response = esito["content"]

    db.add(ChatMessage(session_id=session_id, role="assistant", content=response, client_id=req.client_id))
    db.commit()

    # 'modalita_riserva' True = ha risposto la riserva gratuita (qualità ridotta).
    # NON si rivela mai il nome del modello (protezione identità).
    return {"response": response, "session_id": session_id,
            "modalita_riserva": esito.get("degraded", False)}


@app.post("/api/chat/stream")
async def chat_stream(req: ChatRequest, db: Session = Depends(get_db), _lic=Depends(require_license)):
    """Chat in streaming (Server-Sent Events): il testo appare man mano."""
    session_id, messages = _prepara_chat(req, db)
    client_id = req.client_id

    async def gen():
        yield f"data: {_json.dumps({'session_id': session_id})}\n\n"
        # COPILOTA: richiesta di CALCOLO → rispondi col motore (numero esatto) e chiudi.
        try:
            from copilota_calcoli import rispondi_calcolo
            dal_motore = await rispondi_calcolo(req.message)
        except Exception:
            dal_motore = None
        if dal_motore:
            yield f"data: {_json.dumps({'delta': dal_motore})}\n\n"
            db2 = SessionLocal()
            try:
                db2.add(ChatMessage(session_id=session_id, role="assistant",
                                    content=dal_motore, client_id=client_id))
                db2.commit()
            finally:
                db2.close()
            yield "data: [DONE]\n\n"
            return
        parti = []
        try:
            async for delta in stream_chat_with_ai(messages):
                parti.append(delta)
                yield f"data: {_json.dumps({'delta': delta})}\n\n"
        except Exception as e:
            yield f"data: {_json.dumps({'error': errore_ai_sicuro(e)})}\n\n"
        if parti:
            risposta = "".join(parti)
            db2 = SessionLocal()
            try:
                db2.add(ChatMessage(session_id=session_id, role="assistant",
                                    content=risposta, client_id=client_id))
                db2.commit()
            finally:
                db2.close()
        yield "data: [DONE]\n\n"

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.get("/api/chat/history/{session_id}")
async def get_history(session_id: str, db: Session = Depends(get_db)):
    msgs = db.query(ChatMessage).filter(
        ChatMessage.session_id == session_id
    ).order_by(ChatMessage.id).all()
    return [{"role": m.role, "content": m.content, "created_at": m.created_at.isoformat()} for m in msgs]


@app.get("/api/chat/sessions")
async def get_sessions(db: Session = Depends(get_db)):
    from sqlalchemy import func, distinct
    sessions = db.query(
        ChatMessage.session_id,
        func.count(ChatMessage.id).label("count"),
        func.max(ChatMessage.created_at).label("last_message"),
        ChatMessage.client_id
    ).group_by(ChatMessage.session_id).order_by(func.max(ChatMessage.created_at).desc()).limit(50).all()
    result = []
    for s in sessions:
        first_msg = db.query(ChatMessage).filter(
            ChatMessage.session_id == s.session_id,
            ChatMessage.role == "user"
        ).first()
        result.append({
            "session_id": s.session_id,
            "count": s.count,
            "last_message": s.last_message.isoformat() if s.last_message else None,
            "preview": (first_msg.content[:80] + "...") if first_msg and len(first_msg.content) > 80 else (first_msg.content if first_msg else ""),
            "client_id": s.client_id,
        })
    return result


@app.delete("/api/chat/sessions/{session_id}")
async def delete_session(session_id: str, db: Session = Depends(get_db)):
    db.query(ChatMessage).filter(ChatMessage.session_id == session_id).delete()
    db.commit()
    return {"ok": True}


@app.delete("/api/chat/sessions")
async def delete_all_sessions(db: Session = Depends(get_db)):
    """Svuota TUTTA la cronologia delle conversazioni (tutte le chat)."""
    cancellate = db.query(ChatMessage).delete()
    db.commit()
    return {"ok": True, "messaggi_cancellati": cancellate}


# ─── DOCUMENTS ───────────────────────────────────────────────────────────────

@app.post("/api/documents/upload")
async def upload_document(
    file: UploadFile = File(...),
    client_id: Optional[int] = Form(None),
    client_nome: Optional[str] = Form(None),
    anno_riferimento: Optional[int] = Form(None),
    note: Optional[str] = Form(None),
    db: Session = Depends(get_db)
):
    ext = Path(file.filename).suffix.lower()
    if ext not in [".pdf", ".png", ".jpg", ".jpeg", ".txt", ".docx", ".xlsx", ".csv"]:
        raise HTTPException(status_code=400, detail="Formato non supportato")

    unique_name = f"{uuid.uuid4()}{ext}"
    file_path = UPLOAD_DIR / unique_name

    MAX_SIZE = 50 * 1024 * 1024  # 50 MB
    size = 0
    with open(file_path, "wb") as f:
        while chunk := file.file.read(1024 * 1024):
            size += len(chunk)
            if size > MAX_SIZE:
                f.close()
                file_path.unlink(missing_ok=True)
                raise HTTPException(status_code=413, detail="File troppo grande (max 50 MB)")
            f.write(chunk)

    file_size = file_path.stat().st_size
    testo = ""
    tipo = "GENERICO"

    if ext == ".pdf":
        testo = extract_text_from_pdf(str(file_path))
        tipo = detect_document_type(testo, file.filename)
    elif ext in (".txt", ".csv"):
        try:
            testo = file_path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            testo = ""
        tipo = detect_document_type(testo, file.filename)

    # ─── AUTO-CLASSIFICAZIONE INTELLIGENTE (in BACKGROUND, mai bloccante) ────
    # L'upload risponde SUBITO. Se c'è testo, il documento va in coda e un
    # thread in sottofondo lo riconosce, ne estrae i dati e lo abbina al
    # cliente. Così l'interfaccia non si blocca mai, anche con tanti file.
    if client_id and not client_nome:
        _c = db.query(Client).filter(Client.id == client_id).first()
        if _c:
            client_nome = f"{_c.cognome} {_c.nome}".strip()

    if testo and testo.strip():
        stato_classifica = "in_coda"          # lo classifica il worker in background
    elif client_id:
        stato_classifica = "manuale"
    else:
        stato_classifica = "non_classificato"

    doc = Document(
        nome_file=unique_name,
        nome_originale=file.filename,
        tipo=tipo,
        client_id=client_id,
        client_nome=client_nome,
        anno_riferimento=anno_riferimento,
        testo_estratto=testo,
        dimensione=file_size,
        note=note,
        stato_classifica=stato_classifica,
    )
    db.add(doc)
    db.commit()
    db.refresh(doc)

    if client_id:
        log_event(db, client_id, "documento", f"Documento caricato: {tipo}",
                 f"Caricato '{file.filename}'")

    # Avvia (se non già attivo) il classificatore in sottofondo
    if stato_classifica == "in_coda":
        classifica_coda.assicura_avvio()

    return {
        "id": doc.id, "tipo": tipo, "nome_originale": file.filename,
        "in_analisi": stato_classifica == "in_coda",
        "stato": stato_classifica,
        "summary": get_document_summary(testo, tipo) if testo else "",
    }


@app.get("/api/documents")
async def list_documents(
    q: Optional[str] = None,
    tipo: Optional[str] = None,
    client_id: Optional[int] = None,
    anno: Optional[int] = None,
    offset: int = 0,
    limite: int = 100,
    db: Session = Depends(get_db)
):
    # Paginazione (prima vedevi solo gli ultimi 100 documenti, punto e basta)
    limite = max(1, min(int(limite or 100), 200))
    offset = max(0, int(offset or 0))

    ids_fts = None
    if q:
        # Ricerca full-text FTS5 (sub-millisecondo anche su 100k doc); fallback a LIKE.
        ids_fts = cerca_documenti_fts(db, q, limite=1000)
        if ids_fts is None:
            query = db.query(Document).filter(
                Document.nome_originale.contains(q) |
                Document.testo_estratto.contains(q) |
                Document.client_nome.contains(q))
        elif not ids_fts:
            return []
        else:
            query = db.query(Document).filter(Document.id.in_(ids_fts))
    else:
        query = db.query(Document)

    if tipo:
        query = query.filter(Document.tipo == tipo)
    if client_id:
        query = query.filter(Document.client_id == client_id)
    if anno:
        query = query.filter(Document.anno_riferimento == anno)

    if ids_fts:
        # Preserva l'ordine di RILEVANZA dato da FTS, poi pagina
        rank = {doc_id: pos for pos, doc_id in enumerate(ids_fts)}
        docs = sorted(query.all(), key=lambda d: rank.get(d.id, 1_000_000))
        docs = docs[offset:offset + limite]
    else:
        docs = query.order_by(Document.created_at.desc()).offset(offset).limit(limite).all()
    out = []
    for d in docs:
        da_verificare, warns = False, []
        if d.dati_estratti:
            try:
                _de = _json.loads(d.dati_estratti)
                da_verificare = bool(_de.get("importo_da_verificare"))
                warns = _de.get("warnings") or []
            except Exception:
                pass
        out.append({
            "id": d.id, "nome_originale": d.nome_originale, "tipo": d.tipo,
            "client_id": d.client_id, "client_nome": d.client_nome,
            "anno_riferimento": d.anno_riferimento,
            "dimensione": d.dimensione, "created_at": d.created_at.isoformat(),
            "note": d.note,
            "stato_classifica": d.stato_classifica, "controparte": d.controparte,
            "importo": d.importo, "confidenza": d.confidenza,
            "importo_da_verificare": da_verificare, "warnings": warns,
        })
    return out


@app.get("/api/documents/{doc_id}/text")
async def get_document_text(doc_id: int, db: Session = Depends(get_db)):
    doc = db.query(Document).filter(Document.id == doc_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Documento non trovato")
    return {"testo": doc.testo_estratto or "", "tipo": doc.tipo, "nome": doc.nome_originale}


@app.get("/api/documents/{doc_id}/download")
async def download_document(doc_id: int, db: Session = Depends(get_db)):
    doc = db.query(Document).filter(Document.id == doc_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Documento non trovato")
    file_path = UPLOAD_DIR / doc.nome_file
    if not file_path.exists():
        if doc.note and "[ARCHIVIATO" in doc.note:
            raise HTTPException(status_code=410, detail=(
                "Documento ARCHIVIATO sul PC per liberare spazio. Il file originale "
                "si trova nella cartella DigitalVault_Archivio sul computer. "
                "(I dati e il testo restano comunque consultabili qui.)"))
        raise HTTPException(status_code=404, detail="File non trovato")
    return FileResponse(str(file_path), filename=doc.nome_originale)


@app.get("/api/documents/{doc_id}/export")
async def export_document(doc_id: int, db: Session = Depends(get_db)):
    """Scarica metadati del documento come backup prima dell'eliminazione."""
    from fastapi.responses import Response
    import json as _json
    doc = db.query(Document).filter(Document.id == doc_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Documento non trovato")
    data = {
        "esportato_il": datetime.now().isoformat(),
        "documento": {
            "nome_originale": doc.nome_originale,
            "tipo": doc.tipo,
            "anno_riferimento": doc.anno_riferimento,
            "client_nome": doc.client_nome,
            "note": doc.note,
            "dimensione_byte": doc.dimensione,
            "creato_il": doc.created_at.isoformat() if doc.created_at else None,
        },
        "nota": "Questo è un backup dei metadati. Il file originale è stato eliminato. Se serve, contatta DigitalVault.",
    }
    nome_file = f"backup_doc_{doc.nome_originale.rsplit('.', 1)[0]}__{datetime.now():%Y%m%d}.json".replace(" ", "_")
    return Response(
        content=_json.dumps(data, ensure_ascii=False, indent=2),
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="{nome_file}"'},
    )


@app.delete("/api/documents/{doc_id}")
async def delete_document(doc_id: int, db: Session = Depends(get_db)):
    doc = db.query(Document).filter(Document.id == doc_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Documento non trovato")
    file_path = UPLOAD_DIR / doc.nome_file
    if file_path.exists():
        file_path.unlink()
    db.delete(doc)
    db.commit()
    return {"ok": True}


@app.get("/api/documents/da-assegnare")
async def documenti_da_assegnare(db: Session = Depends(get_db)):
    """Documenti riconosciuti ma non ancora collegati a un cliente."""
    docs = db.query(Document).filter(Document.stato_classifica == "da_assegnare") \
             .order_by(Document.created_at.desc()).limit(100).all()
    return [{
        "id": d.id, "nome_originale": d.nome_originale, "tipo": d.tipo,
        "controparte": d.controparte, "importo": d.importo,
        "anno_riferimento": d.anno_riferimento, "confidenza": d.confidenza,
        "created_at": d.created_at.isoformat(),
    } for d in docs]


class AssegnaDoc(BaseModel):
    client_id: int


@app.post("/api/documents/{doc_id}/assegna")
async def assegna_documento(doc_id: int, req: AssegnaDoc, db: Session = Depends(get_db)):
    """Collega manualmente un documento a un cliente."""
    doc = db.query(Document).filter(Document.id == doc_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Documento non trovato")
    cliente = db.query(Client).filter(Client.id == req.client_id).first()
    if not cliente:
        raise HTTPException(status_code=404, detail="Cliente non trovato")
    doc.client_id = cliente.id
    doc.client_nome = f"{cliente.cognome} {cliente.nome}".strip()
    doc.stato_classifica = "manuale"
    db.commit()
    log_event(db, cliente.id, "documento", f"Documento assegnato: {doc.tipo}",
              f"'{doc.nome_originale}' collegato a {doc.client_nome}")
    return {"ok": True, "client_nome": doc.client_nome}


@app.post("/api/documents/{doc_id}/riclassifica")
async def riclassifica_documento(doc_id: int, db: Session = Depends(get_db)):
    """Rilancia l'analisi AI su un documento già caricato."""
    doc = db.query(Document).filter(Document.id == doc_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Documento non trovato")
    if not (doc.testo_estratto and doc.testo_estratto.strip()):
        raise HTTPException(status_code=400, detail="Documento senza testo da analizzare")
    clienti = [{"id": c.id, "nome": c.nome, "cognome": c.cognome,
                "codice_fiscale": c.codice_fiscale, "partita_iva": c.partita_iva}
               for c in db.query(Client).all()]
    cl = await doc_classifier.classifica(doc.testo_estratto, doc.nome_originale, clienti)
    doc.tipo = cl.get("tipo") or doc.tipo
    if cl.get("anno"):
        doc.anno_riferimento = cl["anno"]
    doc.importo = cl.get("importo")
    doc.controparte = cl.get("controparte")
    doc.confidenza = cl.get("confidenza")
    doc.dati_estratti = _json.dumps({k: cl.get(k) for k in
        ("riassunto", "controparte", "importo", "codice_fiscale", "partita_iva", "anno",
         "fonte_importo", "importo_da_verificare", "warnings")},
        ensure_ascii=False)
    if cl.get("cliente_id"):
        c = db.query(Client).filter(Client.id == cl["cliente_id"]).first()
        if c:
            doc.client_id = c.id
            doc.client_nome = f"{c.cognome} {c.nome}".strip()
            doc.stato_classifica = "auto"
    elif not doc.client_id:
        doc.stato_classifica = "da_assegnare"
    db.commit()
    return {"ok": True, "tipo": doc.tipo, "cliente_id": doc.client_id,
            "cliente_nome": doc.client_nome, "stato": doc.stato_classifica}


@app.get("/api/classifica/stato")
async def classifica_stato(db: Session = Depends(get_db)):
    """Stato del classificatore in background: quanti documenti restano da
    analizzare. Serve all'interfaccia per mostrare 'analisi in corso'."""
    return classifica_coda.stato_coda(db)


# ─── MOTORE PROATTIVO (avvisi intelligenti) ──────────────────────────────────

@app.get("/api/avvisi")
async def avvisi(db: Session = Depends(get_db)):
    """L'assistente che ti avvisa da solo: scadenze, documenti da assegnare,
    forfettari vicini alla soglia, dati mancanti. Deterministico e veloce."""
    return motore_proattivo.genera_avvisi(db)


# ─── SPAZIO SSD: avviso "quasi pieno" + archiviazione sicura ─────────────────

@app.get("/api/spazio/stato")
async def spazio_stato():
    """Spazio libero sull'SSD + livello (ok/attenzione/critico)."""
    import spazio_disco
    return spazio_disco.stato_spazio()


class ArchiviaReq(BaseModel):
    anni: int = 5


@app.post("/api/spazio/archivia")
async def spazio_archivia(req: ArchiviaReq, db: Session = Depends(get_db)):
    """Sposta sul PC i file dei documenti più vecchi di N anni e libera l'SSD,
    in sicurezza (copia → verifica → libera). Scheda e testo restano nel programma."""
    import spazio_disco
    return spazio_disco.archivia_vecchi(db, anni=req.anni)


# ─── RISK-AUDIT: scansione di compliance proattiva (deterministica) ──────────

@app.get("/api/risk/scan")
async def risk_scan(db: Session = Depends(get_db)):
    """Risk-Audit: scansione di compliance DETERMINISTICA sui dati già presenti
    (soglie di regime, importi AI da verificare, possibili doppioni, anagrafiche
    incomplete, scadenze scadute). Nessun numero è inventato dall'AI: le soglie
    arrivano dai dati versionati in fiscal_reference. Ritorna i rilievi azionabili
    ordinati per gravità."""
    import risk_audit
    return risk_audit.analizza(db)


# ─── FINANCE-ENGINE: proiezioni + DSCR + stress test (adeguati assetti) ──────

class FinanceReq(BaseModel):
    ricavi: float
    costi: float
    servizio_debito: float = 0
    anni: int = 5
    crescita_ricavi: float = 0.03
    crescita_costi: float = 0.02
    shock_ricavi: float | None = None
    shock_costi: float | None = None


@app.post("/api/finance/analisi")
async def finance_analisi(req: FinanceReq):
    """Finance-Engine: proiezione economica su N anni + DSCR (sostenibilità del
    debito) + stress test. Numeri DETERMINISTICI dal motore (soglie versionate in
    finance_reference), a supporto del monitoraggio degli adeguati assetti
    (art. 2086 c.c. / Codice della Crisi). Il testo del business plan è un passo
    successivo: i numeri restano qui."""
    import finance_engine
    return finance_engine.analisi(
        req.ricavi, req.costi, req.servizio_debito, req.anni,
        req.crescita_ricavi, req.crescita_costi, req.shock_ricavi, req.shock_costi)


# ─── LEGAL-ENGINE: intervista guidata + generazione documentale ──────────────

@app.get("/api/legal/tipi")
async def legal_tipi():
    """Tipi di documento generabili (uno per template versionato in legal_reference/)."""
    import legal_engine
    return {"tipi": legal_engine.tipi_disponibili()}


@app.get("/api/legal/campi")
async def legal_campi(tipo: str):
    """Domande dell'intervista guidata per il tipo di documento richiesto."""
    import legal_engine
    return {"tipo": tipo, "campi": legal_engine.campi_richiesti(tipo)}


class LegalReq(BaseModel):
    tipo: str
    parametri: dict = {}


@app.post("/api/legal/genera")
async def legal_genera(req: LegalReq):
    """Genera la BOZZA del documento dal template versionato, riempiendo i campi
    raccolti. I campi obbligatori mancanti sono segnalati. I documenti che
    richiedono notaio restano bozze da validare."""
    import legal_engine
    return legal_engine.genera(req.tipo, req.parametri)


@app.post("/api/legal/genera-ai")
async def legal_genera_ai(req: LegalReq):
    """Genera la bozza e ne raffina la FORMA con l'AI. I numeri e i dati restano
    dal template versionato (la versione deterministica è in `testo_base`)."""
    import legal_engine
    return await legal_engine.genera_ai(req.tipo, req.parametri)


@app.post("/api/legal/pdf")
async def legal_pdf(req: LegalReq, db: Session = Depends(get_db)):
    """Genera la bozza e la restituisce in PDF con la carta intestata dello studio."""
    from fastapi.responses import Response
    import legal_engine
    r = legal_engine.genera(req.tipo, req.parametri)
    if not r.get("ok"):
        raise HTTPException(status_code=400, detail=r.get("errore", "Tipo non valido"))
    studio = get_studio_info(db)
    pdf_bytes = genera_pdf_consulenza(studio, None, r.get("nome", "Bozza documento"), r["testo"])
    nome = f"bozza_{req.tipo}_{datetime.now():%Y%m%d_%H%M}.pdf"
    return Response(content=pdf_bytes, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{nome}"'})


@app.get("/api/legal/clienti")
async def legal_clienti(db: Session = Depends(get_db)):
    """Elenco clienti con anagrafica già formattata, per precompilare con un clic i
    campi 'parte' dei documenti (nome, CF, P.IVA, indirizzo già in archivio)."""
    out = []
    for c in db.query(Client).order_by(Client.cognome, Client.nome).all():
        nome = f"{c.cognome or ''} {c.nome or ''}".strip()
        parti = [nome] if nome else []
        if c.codice_fiscale:
            parti.append(f"C.F. {c.codice_fiscale}")
        if c.partita_iva:
            parti.append(f"P.IVA {c.partita_iva}")
        if c.indirizzo:
            parti.append(f"con sede/residenza in {c.indirizzo}")
        out.append({"id": c.id, "etichetta": nome or f"Cliente {c.id}",
                    "anagrafica": ", ".join(parti)})
    return {"clienti": out}


# ─── COPILOTA CLIENTE (AI che conosce TUTTO di un cliente) ───────────────────

def _panoramica_cliente(db: Session, c) -> str:
    """Costruisce il dossier completo di un cliente per il copilota AI."""
    from datetime import timedelta
    righe = [f"CLIENTE: {c.cognome} {c.nome}",
             f"Tipo: {c.tipo or '-'} | Regime: {c.regime or '-'}",
             f"Codice fiscale: {c.codice_fiscale or '-'} | P.IVA: {c.partita_iva or '-'}",
             f"Email: {c.email or '-'} | Telefono: {c.telefono or '-'}"]
    if c.note:
        righe.append(f"Note: {c.note}")

    docs = db.query(Document).filter(Document.client_id == c.id) \
             .order_by(Document.created_at.desc()).limit(40).all()
    righe.append(f"\nDOCUMENTI ({len(docs)}):")
    for d in docs:
        riass = ""
        if d.dati_estratti:
            try:
                riass = (_json.loads(d.dati_estratti) or {}).get("riassunto") or ""
            except Exception:
                riass = ""
        imp = f" €{d.importo:,.2f}" if d.importo else ""
        righe.append(f"  - [{d.tipo or 'doc'}{' ' + str(d.anno_riferimento) if d.anno_riferimento else ''}]"
                     f" {d.nome_originale}{imp}{' — ' + d.controparte if d.controparte else ''}"
                     + (f" — {riass}" if riass else ""))

    scad = db.query(Scadenza).filter(Scadenza.client_id == c.id) \
             .order_by(Scadenza.data_scadenza).all()
    if scad:
        righe.append(f"\nSCADENZE ({len(scad)}):")
        for s in scad:
            stato = "fatta" if s.completata else "DA FARE"
            righe.append(f"  - {s.data_scadenza.strftime('%d/%m/%Y')} {s.titolo} [{stato}]")

    eventi = db.query(ClientEvent).filter(ClientEvent.client_id == c.id) \
               .order_by(ClientEvent.created_at.desc()).limit(20).all()
    if eventi:
        righe.append(f"\nTIMELINE (ultimi {len(eventi)} eventi):")
        for e in eventi:
            righe.append(f"  - {e.created_at.strftime('%d/%m/%Y')} [{e.tipo}] {e.titolo}")
    return "\n".join(righe)


class CopilotaRequest(BaseModel):
    domanda: str


@app.post("/api/clients/{client_id}/copilota")
async def copilota_cliente(client_id: int, req: CopilotaRequest, db: Session = Depends(get_db)):
    """Assistente contestuale: conosce TUTTO di questo cliente (anagrafica,
    documenti, scadenze, storico) e risponde alla domanda del commercialista."""
    c = db.query(Client).filter(Client.id == client_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Cliente non trovato")
    if not (req.domanda or "").strip():
        raise HTTPException(status_code=400, detail="Scrivi una domanda")
    dossier = _panoramica_cliente(db, c)
    prompt = (
        "Sei il copilota dello studio per UN cliente specifico. Rispondi alla domanda "
        "del commercialista basandoti SOLO sui dati reali del cliente qui sotto. "
        "Sii concreto: cita documenti, importi, scadenze quando utile. Se un dato non "
        "c'è nei dati, dillo e suggerisci come ottenerlo. Rispondi in italiano.\n\n"
        f"[DOSSIER CLIENTE]\n{dossier}\n\n[DOMANDA]\n{req.domanda}"
    )
    try:
        risposta = await chat_with_ai([{"role": "user", "content": prompt}])
    except Exception as e:
        raise HTTPException(status_code=503, detail=errore_ai_sicuro(e))
    return {"risposta": risposta, "cliente": f"{c.cognome} {c.nome}"}


# ─── RICONCILIAZIONE BANCARIA ────────────────────────────────────────────────

class RiconciliaRequest(BaseModel):
    estratto_doc_id: Optional[int] = None
    estratto_testo: Optional[str] = None
    client_id: Optional[int] = None


@app.post("/api/riconciliazione")
async def riconciliazione_bancaria(req: RiconciliaRequest, db: Session = Depends(get_db)):
    """Confronta le fatture con i movimenti di un estratto conto e segnala
    cosa non risulta incassato. L'estratto può essere un documento già caricato
    (estratto_doc_id) oppure testo incollato (estratto_testo)."""
    testo = (req.estratto_testo or "").strip()
    if req.estratto_doc_id:
        doc = db.query(Document).filter(Document.id == req.estratto_doc_id).first()
        if not doc:
            raise HTTPException(status_code=404, detail="Estratto conto non trovato")
        testo = (doc.testo_estratto or "").strip()
    if not testo:
        raise HTTPException(status_code=400, detail="Manca il testo dell'estratto conto da analizzare")

    q = db.query(Document).filter(Document.tipo == "FATTURA", Document.importo.isnot(None))
    if req.client_id:
        q = q.filter(Document.client_id == req.client_id)
    fatture = [{"id": d.id, "nome": d.nome_originale, "controparte": d.controparte,
                "importo": d.importo, "anno": d.anno_riferimento} for d in q.all()]

    movimenti = await riconciliazione.estrai_movimenti(testo)
    report = riconciliazione.riconcilia(fatture, movimenti)
    report["movimenti_letti"] = len(movimenti)
    return report


# ─── LETTURA POSTA IN ENTRATA (PEC / EMAIL) ──────────────────────────────────

def get_pec_config(db: Session) -> dict:
    raw = get_setting(db, "pec_config")
    if raw:
        try:
            return _json.loads(raw)
        except Exception:
            return {}
    return {}


class PecConfig(BaseModel):
    imap_host: Optional[str] = None
    imap_port: Optional[int] = 993
    user: Optional[str] = None
    password: Optional[str] = None
    cartella: Optional[str] = "INBOX"


@app.get("/api/pec/config")
async def pec_config_get(db: Session = Depends(get_db)):
    """Configurazione casella (la password non viene mai restituita in chiaro)."""
    cfg = get_pec_config(db)
    return {"imap_host": cfg.get("imap_host", ""), "imap_port": cfg.get("imap_port", 993),
            "user": cfg.get("user", ""), "cartella": cfg.get("cartella", "INBOX"),
            "configurata": bool(cfg.get("password"))}


@app.post("/api/pec/config")
async def pec_config_set(req: PecConfig, db: Session = Depends(get_db)):
    cfg = get_pec_config(db)
    nuovo = req.dict(exclude_none=True)
    # Se la password non viene reinviata, si mantiene quella esistente
    if not nuovo.get("password") and cfg.get("password"):
        nuovo["password"] = cfg["password"]
    set_setting(db, "pec_config", _json.dumps(nuovo))
    return {"ok": True}


@app.post("/api/pec/test")
async def pec_test(db: Session = Depends(get_db)):
    cfg = get_pec_config(db)
    if not cfg.get("password"):
        raise HTTPException(status_code=400, detail="Configura prima la casella (host, utente, password).")
    return email_reader.prova_connessione(cfg)


class PecLeggi(BaseModel):
    max_messaggi: Optional[int] = 30
    solo_non_letti: Optional[bool] = True


@app.post("/api/pec/leggi")
async def pec_leggi(req: PecLeggi, db: Session = Depends(get_db)):
    """Scarica gli allegati dei messaggi e li mette in archivio (poi vengono
    classificati in background)."""
    cfg = get_pec_config(db)
    if not cfg.get("password"):
        raise HTTPException(status_code=400, detail="Configura prima la casella nelle Impostazioni.")
    res = email_reader.leggi(cfg, max_messaggi=req.max_messaggi or 30,
                             solo_non_letti=req.solo_non_letti if req.solo_non_letti is not None else True)
    if not res.get("ok"):
        raise HTTPException(status_code=400, detail=f"Lettura non riuscita: {res.get('errore', 'errore')}")
    return res


# ─── CLIENTS ─────────────────────────────────────────────────────────────────

class ClientCreate(BaseModel):
    nome: str
    cognome: str
    codice_fiscale: Optional[str] = None
    partita_iva: Optional[str] = None
    email: Optional[str] = None
    telefono: Optional[str] = None
    indirizzo: Optional[str] = None
    note: Optional[str] = None
    tipo: Optional[str] = "persona_fisica"
    regime: Optional[str] = None


class ValidaRequest(BaseModel):
    codice_fiscale: Optional[str] = None
    partita_iva: Optional[str] = None


@app.post("/api/valida/anagrafica")
async def valida_anagrafica(req: ValidaRequest):
    """Verifica formale di Codice Fiscale e P.IVA (carattere di controllo)."""
    return validators.valida_entrambi(req.codice_fiscale, req.partita_iva)


@app.get("/api/clients")
async def list_clients(q: Optional[str] = None, db: Session = Depends(get_db)):
    query = db.query(Client)
    if q:
        query = query.filter(
            Client.nome.contains(q) | Client.cognome.contains(q) |
            Client.codice_fiscale.contains(q) | Client.partita_iva.contains(q)
        )
    clients = query.order_by(Client.cognome, Client.nome).all()
    return [{
        "id": c.id, "nome": c.nome, "cognome": c.cognome,
        "codice_fiscale": c.codice_fiscale, "partita_iva": c.partita_iva,
        "email": c.email, "telefono": c.telefono, "indirizzo": c.indirizzo,
        "note": c.note, "tipo": c.tipo, "regime": c.regime,
        "created_at": c.created_at.isoformat()
    } for c in clients]


@app.post("/api/clients")
async def create_client(client: ClientCreate, db: Session = Depends(get_db)):
    c = Client(**client.model_dump())
    db.add(c)
    db.commit()
    db.refresh(c)
    log_event(db, c.id, "nota", "Cliente registrato", "Cliente aggiunto all'anagrafica")
    return {"id": c.id, "nome": c.nome, "cognome": c.cognome}


@app.put("/api/clients/{client_id}")
async def update_client(client_id: int, client: ClientCreate, db: Session = Depends(get_db)):
    c = db.query(Client).filter(Client.id == client_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Cliente non trovato")
    for k, v in client.model_dump().items():
        setattr(c, k, v)
    c.updated_at = datetime.now()
    db.commit()
    return {"ok": True}


@app.get("/api/clients/scopri")
async def clients_scopri(db: Session = Depends(get_db)):
    """Trova possibili NUOVI clienti dentro i documenti gia' letti
    (fatture elettroniche, scansioni OCR, PDF). Niente viene inserito:
    e' solo la proposta, decide il commercialista."""
    trovati = scopri_clienti.scopri(db)
    return {"trovati": len(trovati), "candidati": trovati[:200]}


class ScopriInserisciReq(BaseModel):
    selezionati: list


@app.post("/api/clients/scopri/inserisci")
async def clients_scopri_inserisci(req: ScopriInserisciReq, db: Session = Depends(get_db)):
    """Inserisce i clienti scelti e aggancia loro i documenti di provenienza."""
    if not req.selezionati:
        raise HTTPException(status_code=400, detail="Nessun cliente selezionato.")
    return scopri_clienti.inserisci(db, req.selezionati)


@app.get("/api/clients/modello-csv")
async def modello_csv():
    """Modello CSV da compilare (o da generare con l'export del vecchio gestionale)."""
    from fastapi.responses import Response
    esempio = (
        "cognome;nome;codice_fiscale;partita_iva;email;telefono;indirizzo;tipo;regime;note\n"
        "Rossi;Mario;RSSMRA80A01H501U;;mario.rossi@email.it;333 1234567;Via Roma 1, Palermo;persona_fisica;forfettario;\n"
        "Edil Esempio SRL;;;01234567890;info@edilesempio.it;0922 123456;Zona Industriale, Agrigento;societa;societa;cliente dal 2018\n"
    )
    return Response(content=esempio.encode("utf-8-sig"), media_type="text/csv",
                    headers={"Content-Disposition": "attachment; filename=modello_clienti.csv"})


@app.get("/api/clients/esporta")
async def esporta_clienti(db: Session = Depends(get_db)):
    """Esporta TUTTI i clienti in CSV (stesse colonne del modello di import →
    round-trip perfetto). Apribile in Excel; utile per backup o per passare i
    dati ad altri strumenti/gestionali. I campi cifrati escono in chiaro qui."""
    import csv as _csv, io as _io
    from fastapi.responses import Response
    buf = _io.StringIO()
    w = _csv.writer(buf, delimiter=";")
    w.writerow(["cognome", "nome", "codice_fiscale", "partita_iva", "email",
                "telefono", "indirizzo", "tipo", "regime", "note"])
    for c in db.query(Client).order_by(Client.cognome, Client.nome).all():
        w.writerow([c.cognome or "", c.nome or "", c.codice_fiscale or "", c.partita_iva or "",
                    c.email or "", c.telefono or "", c.indirizzo or "", c.tipo or "",
                    c.regime or "", (c.note or "").replace("\n", " ")])
    return Response(content=buf.getvalue().encode("utf-8-sig"), media_type="text/csv",
                    headers={"Content-Disposition": "attachment; filename=clienti_digitalvault.csv"})


@app.get("/api/documents/esporta")
async def esporta_documenti(client_id: Optional[int] = None, anno: Optional[int] = None,
                            db: Session = Depends(get_db)):
    """Esporta l'elenco documenti in CSV (per Excel, analisi o consegna).
    Filtri opzionali per cliente e anno."""
    import csv as _csv, io as _io
    from fastapi.responses import Response
    q = db.query(Document)
    if client_id:
        q = q.filter(Document.client_id == client_id)
    if anno:
        q = q.filter(Document.anno_riferimento == anno)
    buf = _io.StringIO()
    w = _csv.writer(buf, delimiter=";")
    w.writerow(["data", "nome_file", "tipo", "cliente", "anno", "importo", "controparte", "stato"])
    for d in q.order_by(Document.created_at.desc()).all():
        w.writerow([d.created_at.strftime("%d/%m/%Y") if d.created_at else "",
                    d.nome_originale or "", d.tipo or "", d.client_nome or "",
                    d.anno_riferimento or "", ("" if d.importo is None else d.importo),
                    d.controparte or "", d.stato_classifica or ""])
    return Response(content=buf.getvalue().encode("utf-8-sig"), media_type="text/csv",
                    headers={"Content-Disposition": "attachment; filename=documenti_digitalvault.csv"})


@app.get("/api/clients/esporta-excel")
async def esporta_clienti_excel(db: Session = Depends(get_db)):
    """Esporta TUTTI i clienti in un vero file Excel (.xlsx) formattato."""
    import export_excel
    from fastapi.responses import Response
    if not export_excel.disponibile():
        raise HTTPException(status_code=503,
                            detail="Esportazione Excel non disponibile su questo computer. Usa 'Esporta CSV'.")
    intest = ["Cognome", "Nome", "Codice Fiscale", "Partita IVA", "Email",
              "Telefono", "Indirizzo", "Tipo", "Regime", "Note"]
    righe = []
    for c in db.query(Client).order_by(Client.cognome, Client.nome).all():
        righe.append([c.cognome or "", c.nome or "", c.codice_fiscale or "", c.partita_iva or "",
                      c.email or "", c.telefono or "", c.indirizzo or "", c.tipo or "",
                      c.regime or "", (c.note or "").replace("\n", " ")])
    dati = export_excel.crea_xlsx("Anagrafica Clienti", intest, righe, nome_foglio="Clienti")
    return Response(content=dati,
                    media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": "attachment; filename=clienti_digitalvault.xlsx"})


@app.get("/api/documents/esporta-excel")
async def esporta_documenti_excel(client_id: Optional[int] = None, anno: Optional[int] = None,
                                  db: Session = Depends(get_db)):
    """Esporta l'elenco documenti in un vero file Excel (.xlsx). Filtri per cliente/anno."""
    import export_excel
    from fastapi.responses import Response
    if not export_excel.disponibile():
        raise HTTPException(status_code=503,
                            detail="Esportazione Excel non disponibile su questo computer. Usa 'Esporta CSV'.")
    q = db.query(Document)
    if client_id:
        q = q.filter(Document.client_id == client_id)
    if anno:
        q = q.filter(Document.anno_riferimento == anno)
    intest = ["Data", "Nome file", "Tipo", "Cliente", "Anno", "Importo", "Controparte", "Stato"]
    righe = []
    for d in q.order_by(Document.created_at.desc()).all():
        righe.append([d.created_at.strftime("%d/%m/%Y") if d.created_at else "",
                      d.nome_originale or "", d.tipo or "", d.client_nome or "",
                      d.anno_riferimento or "", (None if d.importo is None else float(d.importo)),
                      d.controparte or "", d.stato_classifica or ""])
    dati = export_excel.crea_xlsx("Elenco Documenti", intest, righe, nome_foglio="Documenti")
    return Response(content=dati,
                    media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": "attachment; filename=documenti_digitalvault.xlsx"})


@app.post("/api/clients/importa")
async def importa_clienti(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """Importazione MASSIVA clienti da CSV (export del vecchio gestionale).
    Accetta ; o , come separatore, intestazioni flessibili, salta i duplicati."""
    import csv as _csv
    import io as _io

    raw = await file.read()
    testo = None
    for enc in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            testo = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    if not testo:
        raise HTTPException(status_code=400, detail="File non leggibile: salva il CSV in UTF-8 o ANSI.")

    # Separatore: punto e virgola (Excel italiano) o virgola
    prima_riga = testo.splitlines()[0] if testo.splitlines() else ""
    sep = ";" if prima_riga.count(";") >= prima_riga.count(",") else ","
    reader = _csv.DictReader(_io.StringIO(testo), delimiter=sep)
    if not reader.fieldnames:
        raise HTTPException(status_code=400, detail="Il file CSV è vuoto o senza intestazioni.")

    # Mappa intestazioni flessibile: accetta i nomi piu' comuni dei gestionali
    def _norm(s):
        return (s or "").strip().lower().replace(" ", "_").replace(".", "")
    ALIAS = {
        "cognome": "cognome", "denominazione": "cognome", "ragione_sociale": "cognome",
        "ragionesociale": "cognome", "nominativo": "cognome",
        "nome": "nome",
        "codice_fiscale": "codice_fiscale", "cf": "codice_fiscale", "codfiscale": "codice_fiscale",
        "codicefiscale": "codice_fiscale",
        "partita_iva": "partita_iva", "piva": "partita_iva", "p_iva": "partita_iva",
        "partitaiva": "partita_iva", "vat": "partita_iva",
        "email": "email", "e-mail": "email", "mail": "email", "pec": "email",
        "telefono": "telefono", "tel": "telefono", "cellulare": "telefono", "cell": "telefono",
        "indirizzo": "indirizzo", "via": "indirizzo", "sede": "indirizzo", "residenza": "indirizzo",
        "tipo": "tipo", "regime": "regime", "note": "note", "annotazioni": "note",
    }
    mappa = {}
    for col in reader.fieldnames:
        chiave = ALIAS.get(_norm(col))
        if chiave and chiave not in mappa:
            mappa[chiave] = col
    if "cognome" not in mappa:
        raise HTTPException(status_code=400, detail=
            "Nel CSV manca la colonna del nominativo (accettate: cognome, denominazione, "
            "ragione sociale, nominativo). Scarica il modello per vedere il formato.")

    # Indici esistenti per saltare i duplicati
    esistenti_cf = {c.codice_fiscale.upper() for c in db.query(Client).all() if c.codice_fiscale}
    esistenti_piva = {c.partita_iva for c in db.query(Client).all() if c.partita_iva}
    esistenti_nome = {(c.cognome or "").strip().lower() + "|" + (c.nome or "").strip().lower()
                      for c in db.query(Client).all()}

    importati, saltati, avvisi = 0, 0, []
    for n_riga, riga in enumerate(reader, start=2):
        def v(campo):
            col = mappa.get(campo)
            return (riga.get(col) or "").strip() if col else ""

        cognome = v("cognome")
        if not cognome:
            continue  # riga vuota
        nome = v("nome")
        cf = v("codice_fiscale").upper().replace(" ", "") or None
        piva = "".join(ch for ch in v("partita_iva") if ch.isdigit()) or None

        # Duplicati: per CF, P.IVA o nominativo identico
        chiave_nome = cognome.strip().lower() + "|" + nome.strip().lower()
        if (cf and cf in esistenti_cf) or (piva and piva in esistenti_piva) or chiave_nome in esistenti_nome:
            saltati += 1
            continue

        # Validazione formale (avvisa ma importa comunque: i dati vecchi si correggono dopo)
        if cf and validators.valida_codice_fiscale(cf)["valido"] is False:
            avvisi.append(f"riga {n_riga} ({cognome}): codice fiscale '{cf}' formalmente errato")
        if piva and validators.valida_partita_iva(piva)["valido"] is False:
            avvisi.append(f"riga {n_riga} ({cognome}): partita IVA '{piva}' formalmente errata")

        tipo = v("tipo").lower() or ("societa" if not nome and piva else "persona_fisica")
        if tipo not in ("persona_fisica", "societa", "ditta_individuale"):
            tipo = "persona_fisica"
        regime = v("regime").lower() or None
        if regime and regime not in ("forfettario", "ordinario_pf", "societa", "datore_lavoro", "privato"):
            regime = None

        cl = Client(nome=nome or "", cognome=cognome, codice_fiscale=cf, partita_iva=piva,
                    email=v("email") or None, telefono=v("telefono") or None,
                    indirizzo=v("indirizzo") or None, note=v("note") or None,
                    tipo=tipo, regime=regime)
        db.add(cl)
        importati += 1
        if cf:
            esistenti_cf.add(cf)
        if piva:
            esistenti_piva.add(piva)
        esistenti_nome.add(chiave_nome)

    db.commit()
    return {"ok": True, "importati": importati, "saltati_duplicati": saltati,
            "avvisi": avvisi[:50], "totale_avvisi": len(avvisi)}


# ─── OCR DI MASSA (rende leggibili le scansioni mute) ───────────────────────

@app.get("/api/ocr/massa/scansioni")
async def ocr_massa_scansioni(db: Session = Depends(get_db)):
    """Quante scansioni mute (senza testo) ci sono in archivio."""
    muti = ocr_massa.trova_scansioni(db)
    return {"da_leggere": len(muti),
            "documenti": [{"id": d.id, "nome": d.nome_originale,
                           "cliente": d.client_nome} for d in muti[:50]]}


@app.post("/api/ocr/massa/avvia")
async def ocr_massa_avvia(db: Session = Depends(get_db)):
    """Avvia la lettura AI delle scansioni in sottofondo."""
    return ocr_massa.avvia(db)


@app.get("/api/ocr/massa/stato")
async def ocr_massa_stato():
    return ocr_massa.stato


# ─── FATTURE ELETTRONICHE (XML SDI dal cassetto fiscale) ────────────────────

@app.post("/api/fatture/importa")
async def importa_fatture(files: List[UploadFile] = File(...), db: Session = Depends(get_db)):
    """Importa fatture elettroniche: XML, P7M firmati, o ZIP interi.
    Abbina automaticamente ogni fattura al cliente (per P.IVA / CF),
    estrae importi e IVA, e la indicizza nel cervello documenti."""
    import zipfile as _zip
    import io as _io

    clienti = db.query(Client).all()
    esiti = {"importate": 0, "duplicate": 0, "scartate": 0,
             "abbinate": 0, "senza_cliente": 0, "dettagli": [], "errori": []}

    # 1) Raccogli tutti gli XML dai file caricati (sciogliendo gli zip)
    sorgenti = []  # (nome, xml_bytes)
    for up in files:
        nome = up.filename or "file"
        raw = await up.read()
        nome_low = nome.lower()
        if nome_low.endswith(".zip"):
            try:
                with _zip.ZipFile(_io.BytesIO(raw)) as z:
                    for info in z.infolist():
                        n = info.filename
                        nl = n.lower()
                        if nl.endswith(".xml") or nl.endswith(".p7m"):
                            contenuto = z.read(info)
                            if nl.endswith(".p7m"):
                                contenuto = fe.estrai_xml_da_p7m(contenuto)
                            if contenuto:
                                sorgenti.append((n.split("/")[-1], contenuto))
                            else:
                                esiti["errori"].append(f"{n}: firma P7M non leggibile")
            except _zip.BadZipFile:
                esiti["errori"].append(f"{nome}: ZIP danneggiato o non valido")
        elif nome_low.endswith(".p7m"):
            contenuto = fe.estrai_xml_da_p7m(raw)
            if contenuto:
                sorgenti.append((nome, contenuto))
            else:
                esiti["errori"].append(f"{nome}: firma P7M non leggibile (esporta l'XML dal gestionale)")
        else:
            sorgenti.append((nome, raw))

    # 2) Importa ogni fattura
    for nome, xml_bytes in sorgenti:
        try:
            fatture = fe.parse_fattura(xml_bytes)
        except Exception:
            esiti["scartate"] += 1
            esiti["errori"].append(f"{nome}: non è una fattura elettronica valida")
            continue

        for f in fatture:
            marca = fe.impronta(f)
            gia = db.query(Document).filter(Document.testo_estratto.contains(marca)).first()
            if gia:
                esiti["duplicate"] += 1
                continue

            cliente, verso = fe.abbina_cliente(f, clienti)
            testo = fe.testo_indicizzabile(f)
            if verso:
                testo = f"FATTURA {verso.upper()} del cliente {cliente.cognome} {cliente.nome}".strip() + "\n" + testo

            # Salva l'XML originale negli uploads (tracciabilita')
            unique_name = f"{uuid.uuid4()}.xml"
            try:
                (UPLOAD_DIR / unique_name).write_bytes(xml_bytes)
            except Exception:
                pass

            tipo = "NOTA_CREDITO" if f["tipo_doc"] == "TD04" else "FATTURA_ELETTRONICA"
            doc = Document(
                nome_file=unique_name,
                nome_originale=nome if len(fatture) == 1 else f"{nome} (corpo {f['numero']})",
                tipo=tipo,
                client_id=cliente.id if cliente else None,
                client_nome=f"{cliente.cognome} {cliente.nome}".strip() if cliente else None,
                anno_riferimento=f["anno"],
                testo_estratto=testo,
                dimensione=len(xml_bytes),
                note=f"Importata da XML SDI - {f['tipo_nome']}"
                     + (f" - {verso}" if verso else " - cliente non riconosciuto: assegnala a mano"),
            )
            db.add(doc)
            esiti["importate"] += 1
            if cliente:
                esiti["abbinate"] += 1
                log_event(db, cliente.id, "documento",
                          f"Fattura {verso} n. {f['numero']} del {f['data']}",
                          f"{f['tipo_nome']} - totale {f['totale']} EUR - importata da XML SDI")
            else:
                esiti["senza_cliente"] += 1
            esiti["dettagli"].append({
                "file": nome, "numero": f["numero"], "data": f["data"],
                "totale": f["totale"], "tipo": f["tipo_nome"],
                "cliente": f"{cliente.cognome} {cliente.nome}".strip() if cliente else None,
                "verso": verso,
            })

    db.commit()
    esiti["dettagli"] = esiti["dettagli"][:100]
    esiti["errori"] = esiti["errori"][:50]
    return esiti


@app.get("/api/scadenze/profili")
async def scadenze_profili():
    """Elenco dei profili fiscali per generare lo scadenzario su misura."""
    return scadenze_cliente.profili_disponibili()


class GeneraScadenzeReq(BaseModel):
    profilo: str


@app.post("/api/clients/{client_id}/genera-scadenze")
async def genera_scadenze_cliente(client_id: int, req: GeneraScadenzeReq, db: Session = Depends(get_db)):
    """Crea le scadenze tipiche del profilo scelto, collegate al cliente."""
    c = db.query(Client).filter(Client.id == client_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Cliente non trovato")
    esito = scadenze_cliente.genera_scadenze(db, c, req.profilo)
    if not esito.get("ok"):
        raise HTTPException(status_code=400, detail=esito.get("errore", "Profilo non valido"))
    # Salva il regime sul cliente, così resta memorizzato
    if not c.regime:
        c.regime = req.profilo
        db.commit()
    log_event(db, c.id, "scadenza", f"Scadenzario generato ({esito['profilo']})",
              f"Aggiunte {esito['create']} scadenze su misura")
    return esito


@app.get("/api/clients/{client_id}/export")
async def export_client(client_id: int, db: Session = Depends(get_db)):
    """Scarica un file di backup con tutti i dati del cliente (prima dell'eliminazione)."""
    import json as _json
    from fastapi.responses import Response
    c = db.query(Client).filter(Client.id == client_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Cliente non trovato")
    docs = db.query(Document).filter(Document.client_id == client_id).all()
    data = {
        "esportato_il": datetime.now().isoformat(),
        "cliente": {
            "nome": c.nome, "cognome": c.cognome, "codice_fiscale": c.codice_fiscale,
            "partita_iva": c.partita_iva, "email": c.email, "telefono": c.telefono,
            "indirizzo": c.indirizzo, "note": c.note, "tipo": c.tipo,
        },
        "documenti_collegati": [
            {"nome": d.nome_originale, "tipo": d.tipo, "anno": d.anno_riferimento, "note": d.note}
            for d in docs
        ],
    }
    nome_file = f"backup_{c.cognome}_{c.nome}_{datetime.now():%Y%m%d}.json".replace(" ", "_")
    return Response(
        content=_json.dumps(data, ensure_ascii=False, indent=2),
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="{nome_file}"'},
    )


@app.delete("/api/clients/{client_id}")
async def delete_client(client_id: int, db: Session = Depends(get_db)):
    c = db.query(Client).filter(Client.id == client_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Cliente non trovato")
    # Pulizia collegata: timeline eliminata, documenti scollegati (i file restano)
    db.query(ClientEvent).filter(ClientEvent.client_id == client_id).delete()
    db.query(Document).filter(Document.client_id == client_id).update({Document.client_id: None})
    db.delete(c)
    db.commit()
    return {"ok": True}


# ─── SCADENZE ────────────────────────────────────────────────────────────────

class ScadenzaCreate(BaseModel):
    titolo: str
    descrizione: Optional[str] = None
    data_scadenza: str
    tipo: Optional[str] = None
    client_id: Optional[int] = None
    client_nome: Optional[str] = None


@app.get("/api/scadenze")
async def list_scadenze(db: Session = Depends(get_db)):
    scadenze = db.query(Scadenza).order_by(Scadenza.data_scadenza).all()
    return [{
        "id": s.id, "titolo": s.titolo, "descrizione": s.descrizione,
        "data_scadenza": s.data_scadenza.isoformat(), "tipo": s.tipo,
        "client_nome": s.client_nome, "completata": s.completata
    } for s in scadenze]


@app.post("/api/scadenze")
async def create_scadenza(s: ScadenzaCreate, db: Session = Depends(get_db)):
    try:
        data_scadenza = datetime.fromisoformat(s.data_scadenza)
    except (ValueError, TypeError):
        raise HTTPException(status_code=400, detail="Data non valida (formato atteso: AAAA-MM-GG)")
    scadenza = Scadenza(
        titolo=s.titolo, descrizione=s.descrizione,
        data_scadenza=data_scadenza,
        tipo=s.tipo, client_id=s.client_id, client_nome=s.client_nome
    )
    db.add(scadenza)
    db.commit()
    db.refresh(scadenza)
    return {"id": scadenza.id}


@app.patch("/api/scadenze/{scadenza_id}/toggle")
async def toggle_scadenza(scadenza_id: int, db: Session = Depends(get_db)):
    s = db.query(Scadenza).filter(Scadenza.id == scadenza_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Scadenza non trovata")
    s.completata = not s.completata
    db.commit()
    return {"completata": s.completata}


# ─── OCR SCONTRINI / FATTURE ──────────────────────────────────────────────────

from ocr_processor import extract_invoice_data, format_as_csv


@app.post("/api/invoices/ocr")
async def ocr_invoice(file: UploadFile = File(...)):
    """Estrae dati da una foto di scontrino/fattura con AI vision."""
    if file.content_type not in ["image/jpeg", "image/png", "image/gif", "image/webp"]:
        raise HTTPException(status_code=400, detail="Solo immagini (JPEG, PNG, GIF, WebP)")

    # Salva temporaneamente
    temp_path = UPLOAD_DIR / f"temp_ocr_{uuid.uuid4()}{Path(file.filename).suffix}"
    try:
        with open(temp_path, "wb") as f:
            shutil.copyfileobj(file.file, f)

        # Estrai dati
        data = await extract_invoice_data(str(temp_path))
        return data
    finally:
        if temp_path.exists():
            temp_path.unlink()


@app.post("/api/invoices/ocr-batch")
async def ocr_invoices_batch(files: list[UploadFile] = File(...)):
    """Estrae dati da multiple foto di scontrini/fatture."""
    import tempfile
    from ocr_processor import extract_multiple_invoices

    temp_paths = []
    try:
        # Salva tutti i file temporaneamente
        for file in files:
            if file.content_type not in ["image/jpeg", "image/png", "image/gif", "image/webp"]:
                continue
            temp_path = UPLOAD_DIR / f"temp_ocr_{uuid.uuid4()}{Path(file.filename).suffix}"
            with open(temp_path, "wb") as f:
                shutil.copyfileobj(file.file, f)
            temp_paths.append(str(temp_path))

        # Estrai in parallelo
        results = await extract_multiple_invoices(temp_paths)

        # Formatta come CSV
        csv_data = format_as_csv(results)

        return {
            "risultati": results,
            "csv": csv_data,
            "totale": len(results),
            "successo": sum(1 for r in results if "errore" not in r)
        }
    finally:
        for p in temp_paths:
            if Path(p).exists():
                Path(p).unlink()


@app.get("/api/invoices/download-csv")
async def download_invoices_csv(data: str = None):
    """Scarica i dati estratti come CSV."""
    if not data:
        raise HTTPException(status_code=400, detail="Nessun dato")
    from fastapi.responses import Response
    return Response(
        content=data,
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=scontrini.csv"}
    )


# ─── IMPOSTAZIONI STUDIO + EMAIL ──────────────────────────────────────────────

class StudioInfo(BaseModel):
    nome_studio: Optional[str] = None
    indirizzo_studio: Optional[str] = None
    telefono_studio: Optional[str] = None
    email_studio: Optional[str] = None
    piva_studio: Optional[str] = None


class EmailConfig(BaseModel):
    provider: Optional[str] = None
    host: Optional[str] = None
    port: Optional[int] = 587
    email: Optional[str] = None
    password: Optional[str] = None
    nome_mittente: Optional[str] = None


@app.get("/api/settings/studio")
async def get_studio(db: Session = Depends(get_db)):
    return get_studio_info(db)


@app.post("/api/settings/studio")
async def save_studio(info: StudioInfo, db: Session = Depends(get_db)):
    set_setting(db, "studio_info", _json.dumps(info.model_dump()))
    return {"ok": True}


# ─── ONBOARDING (procedura guidata primo avvio) ───────────────────────────────

@app.get("/api/onboarding/stato")
async def onboarding_stato(db: Session = Depends(get_db)):
    """Dice se mostrare la procedura guidata: solo al primo avvio (finché non
    è stata completata o saltata)."""
    fatto = get_setting(db, "onboarding_done") == "1"
    studio = get_studio_info(db) or {}
    return {"completato": fatto, "ha_dati_studio": bool(studio.get("nome_studio"))}


@app.post("/api/onboarding/completa")
async def onboarding_completa(db: Session = Depends(get_db)):
    """Segna l'onboarding come fatto: non verrà più mostrato in automatico."""
    set_setting(db, "onboarding_done", "1")
    return {"ok": True}


@app.get("/api/settings/email")
async def get_email_settings(db: Session = Depends(get_db)):
    cfg = get_email_config(db)
    # Non restituire la password al frontend
    safe = {k: v for k, v in cfg.items() if k != "password"}
    safe["password_impostata"] = bool(cfg.get("password"))
    return safe


@app.post("/api/settings/email")
async def save_email_settings(cfg: EmailConfig, db: Session = Depends(get_db)):
    data = cfg.model_dump()
    # Se la password è vuota, mantieni quella esistente
    if not data.get("password"):
        existing = get_email_config(db)
        data["password"] = existing.get("password", "")
    set_setting(db, "email_config", _json.dumps(data))
    return {"ok": True}


@app.post("/api/settings/email/test")
async def test_email_settings(db: Session = Depends(get_db)):
    cfg = get_email_config(db)
    if not cfg:
        raise HTTPException(status_code=400, detail="Configura prima l'email")
    result = email_sender.test_connessione(cfg)
    if not result["ok"]:
        raise HTTPException(status_code=400, detail=result["errore"])
    return {"ok": True}


# ─── EXPORT PDF ───────────────────────────────────────────────────────────────

class ConsulenzaPDF(BaseModel):
    client_id: Optional[int] = None
    titolo: str = "Consulenza Fiscale"
    contenuto: str


@app.post("/api/pdf/consulenza")
async def pdf_consulenza(req: ConsulenzaPDF, db: Session = Depends(get_db)):
    from fastapi.responses import Response
    studio = get_studio_info(db)
    cliente = None
    if req.client_id:
        c = db.query(Client).filter(Client.id == req.client_id).first()
        if c:
            cliente = {"nome": c.nome, "cognome": c.cognome,
                      "codice_fiscale": c.codice_fiscale, "partita_iva": c.partita_iva}
            log_event(db, req.client_id, "consulenza", req.titolo, "Consulenza esportata in PDF")
    pdf_bytes = genera_pdf_consulenza(studio, cliente, req.titolo, req.contenuto)
    nome = f"consulenza_{datetime.now():%Y%m%d_%H%M}.pdf"
    return Response(content=pdf_bytes, media_type="application/pdf",
                   headers={"Content-Disposition": f'attachment; filename="{nome}"'})


@app.get("/api/pdf/scheda-cliente/{client_id}")
async def pdf_scheda_cliente(client_id: int, db: Session = Depends(get_db)):
    from fastapi.responses import Response
    c = db.query(Client).filter(Client.id == client_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Cliente non trovato")
    studio = get_studio_info(db)
    cliente = {"nome": c.nome, "cognome": c.cognome, "codice_fiscale": c.codice_fiscale,
              "partita_iva": c.partita_iva, "email": c.email, "telefono": c.telefono,
              "indirizzo": c.indirizzo}
    docs = db.query(Document).filter(Document.client_id == client_id).all()
    documenti = [{"nome_originale": d.nome_originale, "tipo": d.tipo,
                  "anno_riferimento": d.anno_riferimento} for d in docs]
    eventi = db.query(ClientEvent).filter(ClientEvent.client_id == client_id).order_by(ClientEvent.created_at.desc()).all()
    eventi_list = [{"tipo": e.tipo, "titolo": e.titolo, "descrizione": e.descrizione,
                    "created_at": e.created_at.isoformat() if e.created_at else None} for e in eventi]
    pdf_bytes = genera_pdf_scheda_cliente(studio, cliente, documenti, eventi_list)
    nome = f"scheda_{c.cognome}_{c.nome}.pdf".replace(" ", "_")
    return Response(content=pdf_bytes, media_type="application/pdf",
                   headers={"Content-Disposition": f'attachment; filename="{nome}"'})


# ─── INVIO EMAIL ──────────────────────────────────────────────────────────────

class InviaConsulenzaEmail(BaseModel):
    client_id: int
    titolo: str = "Consulenza Fiscale"
    contenuto: str
    messaggio: Optional[str] = None


@app.post("/api/email/consulenza")
async def email_consulenza(req: InviaConsulenzaEmail, db: Session = Depends(get_db)):
    cfg = get_email_config(db)
    if not cfg or not cfg.get("password"):
        raise HTTPException(status_code=400, detail="Configura prima l'email nelle Impostazioni")
    c = db.query(Client).filter(Client.id == req.client_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Cliente non trovato")
    if not c.email:
        raise HTTPException(status_code=400, detail="Il cliente non ha un'email registrata")

    studio = get_studio_info(db)
    cliente = {"nome": c.nome, "cognome": c.cognome,
              "codice_fiscale": c.codice_fiscale, "partita_iva": c.partita_iva}
    pdf_bytes = genera_pdf_consulenza(studio, cliente, req.titolo, req.contenuto)

    corpo = req.messaggio or (
        f"Gentile {c.nome} {c.cognome},\n\nin allegato trova la consulenza richiesta.\n\n"
        f"Cordiali saluti,\n{studio.get('nome_studio', 'Lo Studio')}"
    )
    result = email_sender.invia_email(
        cfg, c.email, f"{req.titolo} - {studio.get('nome_studio', 'Studio')}",
        corpo, pdf_bytes, f"consulenza_{c.cognome}.pdf"
    )
    if not result["ok"]:
        raise HTTPException(status_code=400, detail=result["errore"])
    log_event(db, req.client_id, "contatto", "Email inviata", f"Inviata consulenza '{req.titolo}' a {c.email}")
    return {"ok": True}


# ─── TIMELINE CRM ─────────────────────────────────────────────────────────────

class EventoCreate(BaseModel):
    tipo: str = "nota"
    titolo: str
    descrizione: Optional[str] = None
    importo: Optional[float] = None


@app.get("/api/clients/{client_id}/events")
async def list_events(client_id: int, db: Session = Depends(get_db)):
    eventi = db.query(ClientEvent).filter(
        ClientEvent.client_id == client_id
    ).order_by(ClientEvent.created_at.desc()).all()
    return [{"id": e.id, "tipo": e.tipo, "titolo": e.titolo, "descrizione": e.descrizione,
             "importo": e.importo, "created_at": e.created_at.isoformat() if e.created_at else None}
            for e in eventi]


@app.post("/api/clients/{client_id}/events")
async def add_event(client_id: int, ev: EventoCreate, db: Session = Depends(get_db)):
    c = db.query(Client).filter(Client.id == client_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Cliente non trovato")
    evento = ClientEvent(client_id=client_id, tipo=ev.tipo, titolo=ev.titolo,
                        descrizione=ev.descrizione, importo=ev.importo)
    db.add(evento)
    db.commit()
    db.refresh(evento)
    return {"id": evento.id}


@app.delete("/api/clients/{client_id}/events/{event_id}")
async def delete_event(client_id: int, event_id: int, db: Session = Depends(get_db)):
    ev = db.query(ClientEvent).filter(ClientEvent.id == event_id, ClientEvent.client_id == client_id).first()
    if ev:
        db.delete(ev)
        db.commit()
    return {"ok": True}


# ─── CALCOLATORI FISCALI REALI ────────────────────────────────────────────────

class CalcIrpef(BaseModel):
    reddito: float


class CalcForfettario(BaseModel):
    fatturato: float
    coefficiente: float = 0.78
    nuova_attivita: bool = False


class CalcImu(BaseModel):
    categoria_catastale: str          # es. "A/3", "B", "C/1", "D/2"
    rendita_catastale: float          # rendita accertata Agenzia Entrate (euro)
    aliquota_per_mille: float         # aliquota comunale (es. 8.6, 10.6)
    mesi_possesso: int = 12           # mesi di possesso nel periodo d'imposta


@app.get("/api/calcola/coefficienti")
async def get_coefficienti():
    return tax_calculator.COEFFICIENTI_FORFETTARIO


def _con_disclaimer(d: dict) -> dict:
    """Aggiunge il disclaimer fiscale standard (Fase F) a un risultato dict."""
    from fiscal_engine.common import DISCLAIMER
    if isinstance(d, dict):
        return {**d, "disclaimer": DISCLAIMER}
    return {"risultato": d, "disclaimer": DISCLAIMER}


@app.post("/api/calcola/irpef")
async def calc_irpef(req: CalcIrpef):
    """IRPEF deterministica dal motore (fiscal_engine + fiscal_reference/irpef.yaml).
    Anno d'imposta 2026 (3 scaglioni 23/33/43). Disclaimer + audit + guardia freschezza."""
    from fiscal_engine.irpef import calcola_irpef as _irpef
    from fiscal_engine.common import DataNotFreshError, DISCLAIMER
    import fiscal_audit
    db = SessionLocal()
    try:
        out = _irpef(req.reddito, anno=2026)
        fiscal_audit.registra(db, funzione="irpef", input_dati=req.dict(),
            output_dati={k: out.get(k) for k in ("reddito_imponibile", "irpef_lorda", "aliquota_media")},
            costanti=out.get("constants_used"), fonte=out.get("legal_source"),
            versione_dati=str(out.get("schema_version")), esito="ok")
        return {"disclaimer": DISCLAIMER, **out}
    except DataNotFreshError as e:
        raise HTTPException(status_code=422, detail={"errore": "dati_non_aggiornati", "messaggio": str(e)})
    finally:
        db.close()


@app.post("/api/calcola/forfettario")
async def calc_forfettario(req: CalcForfettario):
    """Forfettario deterministico dal motore (fiscal_reference/forfettario.yaml).
    Disclaimer + audit + avviso soglia ricavi."""
    from fiscal_engine.forfettario import simula_forfettario
    from fiscal_engine.common import DataNotFreshError, DISCLAIMER
    import fiscal_audit
    db = SessionLocal()
    try:
        out = simula_forfettario(req.fatturato, req.coefficiente, req.nuova_attivita, anno=2026)
        fiscal_audit.registra(db, funzione="forfettario", input_dati=req.dict(),
            output_dati={k: out.get(k) for k in ("fatturato", "reddito_forfettario", "imposta_sostitutiva", "netto_in_tasca")},
            costanti={"coefficiente": out.get("coefficiente_redditivita"), "aliquota": out.get("aliquota_imposta")},
            fonte=out.get("legal_source"), versione_dati=str(out.get("schema_version")), esito="ok")
        return {"disclaimer": DISCLAIMER, **out}
    except DataNotFreshError as e:
        raise HTTPException(status_code=422, detail={"errore": "dati_non_aggiornati", "messaggio": str(e)})
    finally:
        db.close()


@app.post("/api/calcola/imu")
async def calc_imu(req: CalcImu):
    """Calcolo IMU DETERMINISTICO (motore fiscale, mai dall'AI).
    Fonte: Art. 1 commi 739-783 L. 160/2019. I numeri provengono solo da
    fiscal_engine/imu.py con dati versionati in fiscal_reference/imu.yaml.
    Se manca un dato determinante, ritorna un errore strutturato così che il
    Consulente AI lo trasformi in una domanda, senza mai inventare il valore."""
    from decimal import Decimal, InvalidOperation
    from fiscal_engine.imu import (calcola_imu_fabbricato,
                                   FiscalValidationError, MissingInputError)
    from fiscal_engine.common import DISCLAIMER
    import fiscal_audit
    db = SessionLocal()
    try:
        res = calcola_imu_fabbricato(
            categoria_catastale=req.categoria_catastale.strip().upper(),
            rendita_catastale=Decimal(str(req.rendita_catastale)),
            aliquota_per_mille=Decimal(str(req.aliquota_per_mille)),
            mesi_possesso=req.mesi_possesso,
        )
        out = res.to_dict()
        # Audit (Fase H): traccia il calcolo per ricostruibilità/contestazioni.
        fiscal_audit.registra(
            db, funzione="imu_fabbricato", input_dati=req.dict(),
            output_dati={k: out.get(k) for k in ("base_imponibile", "imu_annua", "imu_rata", "acconto", "saldo")},
            costanti=out.get("constants_used"), fonte=out.get("legal_source"),
            versione_dati=str((out.get("constants_used") or {}).get("schema_version")), esito="ok")
        return {"ok": True, "disclaimer": DISCLAIMER, **out}
    except MissingInputError as e:
        fiscal_audit.registra(db, funzione="imu_fabbricato", input_dati=req.dict(),
                              output_dati={"errore": str(e)}, esito="errore")
        raise HTTPException(status_code=422, detail={
            "errore": "input_mancante", "campi": e.fields, "messaggio": str(e)})
    except (FiscalValidationError, InvalidOperation, ValueError) as e:
        fiscal_audit.registra(db, funzione="imu_fabbricato", input_dati=req.dict(),
                              output_dati={"errore": str(e)}, esito="errore")
        raise HTTPException(status_code=400, detail={
            "errore": "validazione", "messaggio": str(e)})
    finally:
        db.close()


@app.get("/api/calcola/audit")
async def calcola_audit(limite: int = 100, db: Session = Depends(get_db)):
    """Registro dei calcoli fiscali effettuati (tracciabilità — Fase H)."""
    import fiscal_audit
    return fiscal_audit.ultimi(db, limite=limite)


# ─── CERVELLO DELLO STUDIO (AI con contesto di TUTTI i clienti) ────────────────

class DomandaStudio(BaseModel):
    domanda: str


def _costruisci_panoramica_studio(db: Session) -> str:
    """Crea un riassunto testuale di tutto lo studio da dare all'AI."""
    from datetime import timedelta
    oggi = datetime.now()
    righe = [f"DATA ODIERNA: {oggi.strftime('%d/%m/%Y')}", ""]

    clienti = db.query(Client).all()
    righe.append(f"=== CLIENTI ({len(clienti)}) ===")
    for c in clienti:
        docs = db.query(Document).filter(Document.client_id == c.id).all()
        tipi_doc = ", ".join(sorted(set(d.tipo for d in docs))) if docs else "NESSUN DOCUMENTO"
        righe.append(
            f"- {c.cognome} {c.nome} | tipo: {c.tipo or '-'} | CF: {c.codice_fiscale or '-'} | "
            f"P.IVA: {c.partita_iva or '-'} | email: {c.email or 'MANCANTE'} | "
            f"tel: {c.telefono or 'MANCANTE'} | documenti: {len(docs)} ({tipi_doc})"
        )

    righe.append("")
    righe.append("=== SCADENZE FISCALI ===")
    scadenze = db.query(Scadenza).filter(Scadenza.completata == False).order_by(Scadenza.data_scadenza).all()
    for s in scadenze:
        giorni = (s.data_scadenza - oggi).days
        stato = "SCADUTA" if giorni < 0 else (f"tra {giorni} giorni" if giorni <= 60 else "futura")
        righe.append(f"- {s.titolo} | {s.data_scadenza.strftime('%d/%m/%Y')} ({stato}) | tipo: {s.tipo or '-'}")

    return "\n".join(righe)


# ─── CERVELLO DOCUMENTI (cerca tra TUTTO l'archivio e risponde citando) ───────

class DomandaArchivio(BaseModel):
    domanda: str
    client_id: Optional[int] = None


@app.post("/api/archivio/chiedi")
async def archivio_chiedi(req: DomandaArchivio, db: Session = Depends(get_db), _lic=Depends(require_license)):
    """Cerca tra i testi di TUTTI i documenti archiviati i piu' pertinenti
    alla domanda e fa rispondere l'AI citando i documenti usati."""
    risultati = doc_brain.cerca_documenti(db, req.domanda, client_id=req.client_id)
    prompt = doc_brain.costruisci_prompt(req.domanda, risultati)
    try:
        risposta = await chat_with_ai([{"role": "user", "content": prompt}])
    except Exception as e:
        raise HTTPException(status_code=500, detail=errore_ai_sicuro(e))
    # Citazioni verificabili: marca quali documenti l'AI ha REALMENTE citato [n].
    fonti = doc_brain.fonti_numerate(risultati)
    citate = doc_brain.citazioni_in(risposta, len(fonti))
    for f in fonti:
        f["citato"] = f["numero"] in citate
    fonti.sort(key=lambda f: (not f["citato"], f["numero"]))   # prima le citate
    return {"risposta": risposta, "fonti": fonti,
            "trovati": len(risultati), "citate": len(citate)}


# ─── CHAT DI AIUTO (come si usa il programma) ─────────────────────────────────

class DomandaAiuto(BaseModel):
    domanda: str
    session_id: Optional[str] = None


@app.post("/api/aiuto")
async def chat_aiuto(req: DomandaAiuto, db: Session = Depends(get_db), _lic=Depends(require_license)):
    """Guida interna: spiega al commercialista COME usare il programma,
    passo passo. Vede anche i dati dello studio per dare consigli concreti."""
    session_id = req.session_id or ("help-" + str(uuid.uuid4()))
    # Breve memoria della conversazione di aiuto (riusa la tabella chat)
    history = db.query(ChatMessage).filter(
        ChatMessage.session_id == session_id
    ).order_by(ChatMessage.id.desc()).limit(12).all()[::-1]
    messages = [{"role": m.role, "content": m.content} for m in history]

    panoramica = _costruisci_panoramica_studio(db)
    contenuto = (
        f"[STATO ATTUALE DELLO STUDIO — usalo solo se serve a rispondere]\n{panoramica}\n\n"
        f"[DOMANDA DEL COMMERCIALISTA SU COME USARE IL PROGRAMMA]\n{req.domanda}"
    )
    messages.append({"role": "user", "content": contenuto})

    db.add(ChatMessage(session_id=session_id, role="user", content=req.domanda))
    db.commit()
    try:
        risposta = await chat_with_ai(messages, system=help_system_prompt())
    except Exception as e:
        raise HTTPException(status_code=500, detail=errore_ai_sicuro(e))
    db.add(ChatMessage(session_id=session_id, role="assistant", content=risposta))
    db.commit()
    return {"risposta": risposta, "session_id": session_id}


@app.post("/api/studio/chiedi")
async def chiedi_studio(req: DomandaStudio, db: Session = Depends(get_db), _lic=Depends(require_license)):
    panoramica = _costruisci_panoramica_studio(db)
    prompt = (
        "Sei l'assistente interno di uno studio di commercialista. Hai accesso ai dati REALI "
        "dello studio qui sotto. Rispondi alla domanda del commercialista in modo concreto e "
        "operativo, citando i nomi dei clienti coinvolti e le azioni da fare.\n\n"
        f"[DATI DELLO STUDIO]\n{panoramica}\n\n"
        f"[DOMANDA DEL COMMERCIALISTA]\n{req.domanda}"
    )
    try:
        risposta = await chat_with_ai([{"role": "user", "content": prompt}])
    except Exception as e:
        raise HTTPException(status_code=500, detail=errore_ai_sicuro(e))
    return {"risposta": risposta}


# ─── GENERATORE DOCUMENTI (l'AI scrive la bozza, il commercialista approva) ───

# Ogni tipo ha istruzioni precise per l'AI: struttura professionale italiana.
TIPI_DOCUMENTO = {
    "lettera_incarico": {
        "nome": "Lettera d'incarico professionale",
        "guida": "Scrivi una lettera d'incarico professionale (mandato) tra lo studio e il cliente. "
                 "Struttura: oggetto dell'incarico, prestazioni incluse, compensi (lascia segnaposto "
                 "[COMPENSO] se non indicato), durata, recesso, obblighi antiriciclaggio D.Lgs. 231/2007, "
                 "privacy GDPR, foro competente, spazio per firme di entrambe le parti.",
    },
    "circolare": {
        "nome": "Circolare informativa ai clienti",
        "guida": "Scrivi una circolare informativa dello studio destinata a tutti i clienti, "
                 "sull'argomento indicato. Tono professionale ma comprensibile a non addetti. "
                 "Struttura: oggetto, cosa cambia, chi riguarda, scadenze, cosa deve fare il cliente, "
                 "invito a contattare lo studio.",
    },
    "preventivo": {
        "nome": "Preventivo di parcella",
        "guida": "Scrivi un preventivo di parcella professionale. Struttura: premessa, elenco "
                 "dettagliato delle prestazioni con descrizione, compensi per voce (usa segnaposto "
                 "[IMPORTO] se non indicati), spese e contributi (cassa 4%, IVA), validita' del "
                 "preventivo, modalita' di pagamento.",
    },
    "sollecito": {
        "nome": "Sollecito documenti mancanti",
        "guida": "Scrivi una cortese lettera di sollecito al cliente per la consegna di documenti "
                 "mancanti necessari agli adempimenti. Tono fermo ma gentile. Elenca i documenti "
                 "richiesti, indica la scadenza entro cui servono e le conseguenze del ritardo.",
    },
    "risposta_ade": {
        "nome": "Bozza risposta ad Agenzia delle Entrate",
        "guida": "Scrivi una BOZZA di risposta a una comunicazione/avviso dell'Agenzia delle Entrate, "
                 "secondo le indicazioni fornite. Struttura formale: riferimenti dell'atto, esposizione "
                 "dei fatti, motivazioni con riferimenti normativi, richieste, allegati. "
                 "Segnala con [VERIFICARE] i punti che il professionista deve controllare.",
    },
    "libero": {
        "nome": "Documento libero",
        "guida": "Scrivi il documento professionale richiesto nelle istruzioni, con struttura "
                 "adeguata allo scopo e tono da studio di commercialista.",
    },
}


class GeneraDocumento(BaseModel):
    tipo: str
    client_id: Optional[int] = None
    istruzioni: Optional[str] = None


@app.get("/api/docgen/tipi")
async def docgen_tipi():
    return [{"id": k, "nome": v["nome"]} for k, v in TIPI_DOCUMENTO.items()]


@app.post("/api/docgen/genera")
async def docgen_genera(req: GeneraDocumento, db: Session = Depends(get_db), _lic=Depends(require_license)):
    """Genera la BOZZA del documento. Il commercialista la rivede, la modifica
    e solo dopo la esporta in PDF o la invia: l'AI non finalizza mai da sola."""
    tipo = TIPI_DOCUMENTO.get(req.tipo)
    if not tipo:
        raise HTTPException(status_code=400, detail="Tipo di documento sconosciuto.")

    studio = get_studio_info(db)
    blocco_studio = (
        f"Studio: {studio.get('nome_studio', '[NOME STUDIO]')} | "
        f"Indirizzo: {studio.get('indirizzo_studio', '[INDIRIZZO]')} | "
        f"P.IVA: {studio.get('piva_studio', '[P.IVA]')} | "
        f"Email: {studio.get('email_studio', '[EMAIL]')} | Tel: {studio.get('telefono_studio', '[TEL]')}"
    )
    blocco_cliente = "Nessun cliente specifico (documento generale)."
    c = None
    if req.client_id:
        c = db.query(Client).filter(Client.id == req.client_id).first()
        if c:
            blocco_cliente = (
                f"Cliente: {c.nome} {c.cognome} | CF: {c.codice_fiscale or '-'} | "
                f"P.IVA: {c.partita_iva or '-'} | Indirizzo: {c.indirizzo or '-'} | "
                f"Tipo: {c.tipo or 'persona fisica'}"
            )

    prompt = (
        f"Devi scrivere questo documento: {tipo['nome']}.\n\n"
        f"ISTRUZIONI DI STRUTTURA:\n{tipo['guida']}\n\n"
        f"DATI DELLO STUDIO (mittente):\n{blocco_studio}\n\n"
        f"DATI DEL CLIENTE (destinatario):\n{blocco_cliente}\n\n"
        f"INDICAZIONI SPECIFICHE DEL COMMERCIALISTA:\n{req.istruzioni or 'Nessuna: usa una struttura standard.'}\n\n"
        f"REGOLE: data odierna {datetime.now().strftime('%d/%m/%Y')}. Scrivi SOLO il testo del "
        "documento, pronto da usare, senza commenti prima o dopo. Usa i dati reali forniti; "
        "dove un dato manca usa un segnaposto tra parentesi quadre. Il documento e' una BOZZA "
        "che il professionista rivedra': sii preciso e completo."
    )
    try:
        testo = await chat_with_ai([{"role": "user", "content": prompt}])
    except Exception as e:
        raise HTTPException(status_code=500, detail=errore_ai_sicuro(e))

    if c:
        log_event(db, c.id, "documento", f"Bozza generata: {tipo['nome']}",
                  "Bozza creata dall'AI, in attesa di revisione del professionista")
    return {"testo": testo, "titolo": tipo["nome"]}


# ─── BRIEF MATTUTINO (il programma ti dice cosa fare oggi) ────────────────────

@app.get("/api/studio/brief")
async def studio_brief(db: Session = Depends(get_db)):
    """Riepilogo intelligente da mostrare all'apertura: scadenze imminenti,
    clienti con dati mancanti, priorità del giorno. Generato dall'AI."""
    from datetime import timedelta
    oggi = datetime.now()
    panoramica = _costruisci_panoramica_studio(db)

    # Se lo studio è ancora vuoto, niente chiamata AI inutile
    n_clienti = db.query(Client).count()
    if n_clienti == 0:
        return {"brief": "Benvenuto in DigitalVault! Inizia aggiungendo i tuoi primi clienti "
                          "nella sezione **Clienti**, poi carica i loro documenti nell'**Archivio**. "
                          "Da domani troverai qui il riepilogo della tua giornata.", "generato": False}

    prompt = (
        f"Sei l'assistente dello studio. Oggi è {oggi.strftime('%A %d/%m/%Y')}. "
        "Prepara un BRIEF MATTUTINO breve e concreto per il commercialista, in italiano, "
        "basato sui dati reali qui sotto. Massimo 8 righe. Usa un tono cordiale e diretto. "
        "Struttura: 1) saluto breve col giorno; 2) le scadenze dei prossimi 14 giorni "
        "(le più urgenti per prime, indicando quanti giorni mancano); 3) cose da sistemare "
        "(clienti senza email/documenti); 4) chiudi con UNA priorità consigliata per oggi. "
        "Se non c'è nulla di urgente, dillo in modo rassicurante. Niente formule generiche.\n\n"
        f"[DATI DELLO STUDIO]\n{panoramica}"
    )
    try:
        brief = await chat_with_ai([{"role": "user", "content": prompt}])
    except Exception as e:
        # Fallback senza AI: brief minimo costruito a mano
        scad = db.query(Scadenza).filter(
            Scadenza.completata == False,
            Scadenza.data_scadenza >= oggi,
            Scadenza.data_scadenza <= oggi + timedelta(days=14)
        ).order_by(Scadenza.data_scadenza).all()
        righe = [f"Buongiorno! Oggi è {oggi.strftime('%d/%m/%Y')}."]
        if scad:
            righe.append(f"Hai {len(scad)} scadenze nei prossimi 14 giorni:")
            for s in scad[:5]:
                g = (s.data_scadenza - oggi).days
                righe.append(f"• {s.titolo} — tra {g} giorni")
        else:
            righe.append("Nessuna scadenza urgente nei prossimi 14 giorni. ")
        return {"brief": "\n".join(righe), "generato": False}
    return {"brief": brief, "generato": True}


# ─── PROMEMORIA AUTOMATICI AI CLIENTI ─────────────────────────────────────────

def _scadenze_con_cliente(db: Session, giorni: int):
    """Scadenze entro N giorni collegate a un cliente CON email."""
    from datetime import timedelta
    oggi = datetime.now()
    limite = oggi + timedelta(days=giorni)
    scad = db.query(Scadenza).filter(
        Scadenza.completata == False,
        Scadenza.client_id.isnot(None),
        Scadenza.data_scadenza >= oggi,
        Scadenza.data_scadenza <= limite,
    ).order_by(Scadenza.data_scadenza).all()
    out = []
    for s in scad:
        c = db.query(Client).filter(Client.id == s.client_id).first()
        if c and c.email:
            out.append((s, c))
    return out


@app.get("/api/promemoria/elenco")
async def promemoria_elenco(giorni: int = 14, db: Session = Depends(get_db)):
    """Scadenze imminenti per cui si può mandare un promemoria al cliente."""
    oggi = datetime.now()
    studio = get_studio_info(db)
    nome_studio = studio.get("nome_studio", "Lo Studio")
    risultati = []
    for s, c in _scadenze_con_cliente(db, giorni):
        giorni_mancanti = (s.data_scadenza - oggi).days
        oggetto = f"Promemoria scadenza: {s.titolo}"
        corpo = (
            f"Gentile {c.nome} {c.cognome},\n\n"
            f"Le ricordiamo la seguente scadenza:\n\n"
            f"  • {s.titolo}\n"
            f"  • Data: {s.data_scadenza.strftime('%d/%m/%Y')}\n"
            + (f"  • Dettagli: {s.descrizione}\n" if s.descrizione else "")
            + f"\nRestiamo a disposizione per ogni necessità.\n\n"
            f"Cordiali saluti,\n{nome_studio}"
        )
        risultati.append({
            "scadenza_id": s.id,
            "titolo": s.titolo,
            "data": s.data_scadenza.strftime("%d/%m/%Y"),
            "giorni_mancanti": giorni_mancanti,
            "cliente": f"{c.cognome} {c.nome}",
            "email": c.email,
            "oggetto": oggetto,
            "corpo": corpo,
        })
    return {"promemoria": risultati, "totale": len(risultati)}


class InviaPromemoria(BaseModel):
    scadenza_id: int
    oggetto: Optional[str] = None
    corpo: Optional[str] = None


@app.post("/api/promemoria/invia")
async def promemoria_invia(req: InviaPromemoria, db: Session = Depends(get_db)):
    """Invia il promemoria della scadenza al cliente collegato."""
    cfg = get_email_config(db)
    if not cfg or not cfg.get("password"):
        raise HTTPException(status_code=400, detail="Configura prima l'email nelle Impostazioni.")
    s = db.query(Scadenza).filter(Scadenza.id == req.scadenza_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Scadenza non trovata.")
    c = db.query(Client).filter(Client.id == s.client_id).first() if s.client_id else None
    if not c or not c.email:
        raise HTTPException(status_code=400, detail="Il cliente non ha un'email registrata.")

    studio = get_studio_info(db)
    oggetto = req.oggetto or f"Promemoria scadenza: {s.titolo}"
    corpo = req.corpo or (
        f"Gentile {c.nome} {c.cognome},\n\nLe ricordiamo la scadenza '{s.titolo}' "
        f"del {s.data_scadenza.strftime('%d/%m/%Y')}.\n\nCordiali saluti,\n"
        f"{studio.get('nome_studio', 'Lo Studio')}"
    )
    result = email_sender.invia_email(cfg, c.email, oggetto, corpo)
    if not result["ok"]:
        raise HTTPException(status_code=400, detail=result["errore"])
    log_event(db, c.id, "contatto", "Promemoria inviato",
              f"Inviato promemoria '{s.titolo}' a {c.email}")
    return {"ok": True}


# ─── STATS ───────────────────────────────────────────────────────────────────

@app.get("/api/stats")
async def get_stats(db: Session = Depends(get_db)):
    from sqlalchemy import func
    n_clients = db.query(Client).count()
    n_docs = db.query(Document).count()
    n_chat = db.query(func.count(func.distinct(ChatMessage.session_id))).scalar()
    n_scadenze = db.query(Scadenza).filter(Scadenza.completata == False).count()
    doc_types = db.query(Document.tipo, func.count(Document.id)).group_by(Document.tipo).all()
    return {
        "clienti": n_clients,
        "documenti": n_docs,
        "conversazioni": n_chat or 0,
        "scadenze_aperte": n_scadenze,
        "tipi_documenti": {t: c for t, c in doc_types}
    }


@app.get("/api/stats/dashboard")
async def get_dashboard_stats(db: Session = Depends(get_db)):
    """Statistiche avanzate per la dashboard dello studio."""
    from sqlalchemy import func
    from datetime import timedelta

    n_clients = db.query(Client).count()
    n_docs = db.query(Document).count()

    # Clienti per tipo
    tipi_clienti = dict(db.query(Client.tipo, func.count(Client.id)).group_by(Client.tipo).all())

    # Documenti per tipo
    tipi_doc = dict(db.query(Document.tipo, func.count(Document.id)).group_by(Document.tipo).all())

    # Clienti senza documenti
    clients_con_doc = db.query(func.distinct(Document.client_id)).filter(Document.client_id.isnot(None)).count()
    clienti_senza_doc = max(0, n_clients - clients_con_doc)

    # Scadenze imminenti (prossimi 30 giorni)
    oggi = datetime.now()
    tra_30 = oggi + timedelta(days=30)
    scadenze_imminenti = db.query(Scadenza).filter(
        Scadenza.completata == False,
        Scadenza.data_scadenza >= oggi,
        Scadenza.data_scadenza <= tra_30
    ).count()
    scadenze_scadute = db.query(Scadenza).filter(
        Scadenza.completata == False,
        Scadenza.data_scadenza < oggi
    ).count()

    # Documenti caricati per mese (ultimi 6 mesi)
    docs_per_mese = {}
    for d in db.query(Document).filter(Document.created_at >= oggi - timedelta(days=180)).all():
        if d.created_at:
            key = d.created_at.strftime("%Y-%m")
            docs_per_mese[key] = docs_per_mese.get(key, 0) + 1

    # Attività recenti
    eventi_recenti = db.query(ClientEvent).order_by(ClientEvent.created_at.desc()).limit(8).all()
    attivita = []
    for e in eventi_recenti:
        c = db.query(Client).filter(Client.id == e.client_id).first()
        attivita.append({
            "tipo": e.tipo, "titolo": e.titolo,
            "cliente": f"{c.cognome} {c.nome}" if c else "—",
            "data": e.created_at.isoformat() if e.created_at else None,
        })

    return {
        "clienti": n_clients,
        "documenti": n_docs,
        "tipi_clienti": tipi_clienti,
        "tipi_documenti": tipi_doc,
        "clienti_senza_documenti": clienti_senza_doc,
        "scadenze_imminenti": scadenze_imminenti,
        "scadenze_scadute": scadenze_scadute,
        "documenti_per_mese": docs_per_mese,
        "attivita_recenti": attivita,
    }


def _gia_in_esecuzione() -> Optional[int]:
    """Se DigitalVault sta gia' girando su una delle porte, ritorna la porta."""
    import urllib.request
    for p in PORT_RANGE:
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{p}/api/health", timeout=1) as r:
                if b"DigitalVault" in r.read():
                    return p
        except Exception:
            continue
    return None


def _trova_porta_libera() -> int:
    import socket
    for p in PORT_RANGE:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", p))
                return p
            except OSError:
                continue
    return PORT_RANGE[0]


def _apri_browser_quando_pronto(port: int):
    """In un thread separato: aspetta che il server risponda, poi apre il browser."""
    import threading, time, webbrowser, urllib.request

    def _attendi():
        for _ in range(120):
            try:
                urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=1)
                webbrowser.open(f"http://localhost:{port}")
                return
            except Exception:
                time.sleep(0.5)

    threading.Thread(target=_attendi, daemon=True).start()


def _ip_locale() -> str:
    """L'indirizzo IP del computer nella rete dello studio."""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


if __name__ == "__main__":
    import os as _os
    import uvicorn

    # MODALITA' RETE STUDIO: avviata da "AVVIA IN RETE STUDIO.bat".
    # Il programma resta sul PC del titolare ma diventa raggiungibile
    # anche dagli altri computer dello studio (stessa rete locale).
    rete_studio = _os.environ.get("DIGITALVAULT_RETE") == "1"

    porta_attiva = _gia_in_esecuzione()
    if porta_attiva:
        import webbrowser
        print(f"\n>>> DigitalVault e' GIA' in esecuzione. Apro il browser su http://localhost:{porta_attiva}\n")
        webbrowser.open(f"http://localhost:{porta_attiva}")
    else:
        port = _trova_porta_libera()
        print(f"\n>>> DigitalVault si sta avviando... Il browser si aprira' da solo.")
        print(f">>> Indirizzo manuale (se serve):  http://localhost:{port}\n")
        if rete_studio:
            ip = _ip_locale()
            print("  " + "=" * 58)
            print("   MODALITA' RETE STUDIO ATTIVA")
            print("   Dagli ALTRI computer dello studio aprite il browser su:")
            print(f"       http://{ip}:{port}")
            print(f"   PIN di accesso per i collaboratori:  {ACCESS_PIN}")
            print("   (lo chiede il browser; l'accesso da QUESTO PC non lo richiede)")
            print("   (computer e SSD devono restare accesi su questo PC)")
            print("   Usala SOLO nella rete privata dello studio.")
            print("  " + "=" * 58 + "\n")
        _apri_browser_quando_pronto(port)
        # localhost normale; 0.0.0.0 solo in modalita' rete studio
        host = "0.0.0.0" if rete_studio else "127.0.0.1"
        uvicorn.run("app:app", host=host, port=port, reload=False, log_level="warning")
