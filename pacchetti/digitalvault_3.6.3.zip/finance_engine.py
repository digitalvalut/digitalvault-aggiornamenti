"""
FiscoSicuro - Finance-Engine: proiezioni economiche pluriennali, sostenibilità
del debito (DSCR) e stress test. Secondo modulo della linea "Evolution".
(c) 2026 DigitalVault - Capo Team del Progetto: Dr. Falsone Giuseppe

Ancorato agli ADEGUATI ASSETTI (art. 2086 c.c. / Codice della Crisi): bisogno
ricorrente e imposto per legge, non consulenza occasionale.

REGOLA D'ORO (non negoziabile): ogni NUMERO è calcolato in modo deterministico
da input + soglie VERSIONATE (finance_reference/), MAI inventato dall'AI. Il
testo narrativo del business plan (modulo successivo) potrà essere generato
dall'AI; i numeri restano qui.
"""
from decimal import Decimal, ROUND_HALF_UP

import yaml

from config import BASE_DIR

_REF = BASE_DIR / "finance_reference" / "adeguati_assetti.yaml"


def _load() -> dict:
    return yaml.safe_load(_REF.read_text(encoding="utf-8"))


def _q2(x) -> float:
    return float(Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def proiezione(ricavi_base, costi_base, anni: int = 5,
               crescita_ricavi=0.03, crescita_costi=0.02) -> list:
    """Proiezione anno-per-anno (compound) di ricavi, costi e margine.
    anno 0 = situazione attuale; anni 1..N = proiezione."""
    anni = max(1, min(int(anni), 10))
    r = Decimal(str(ricavi_base))
    c = Decimal(str(costi_base))
    gr = Decimal(str(crescita_ricavi))
    gc = Decimal(str(crescita_costi))
    out = []
    for n in range(0, anni + 1):
        ri = r * (1 + gr) ** n
        co = c * (1 + gc) ** n
        marg = ri - co
        out.append({
            "anno": n,
            "ricavi": _q2(ri),
            "costi": _q2(co),
            "margine": _q2(marg),
            "margine_pct": _q2((marg / ri * 100) if ri else 0),
        })
    return out


def dscr(flusso_operativo, servizio_debito) -> dict:
    """DSCR = flusso operativo / servizio del debito + giudizio dalle soglie versionate."""
    ref = _load()["dscr"]
    fo = Decimal(str(flusso_operativo))
    sd = Decimal(str(servizio_debito))
    if sd <= 0:
        return {"dscr": None, "giudizio": "n/d",
                "messaggio": "Nessun servizio del debito indicato."}
    val = fo / sd
    if val >= Decimal(str(ref["adeguato"])):
        giudizio = "adeguato"
    elif val >= Decimal(str(ref["limite"])):
        giudizio = "da monitorare"
    else:
        giudizio = "allerta"
    return {"dscr": _q2(val), "giudizio": giudizio,
            "soglia_adeguato": ref["adeguato"], "soglia_limite": ref["limite"]}


def stress_test(ricavi_base, costi_base, servizio_debito,
                shock_ricavi=None, shock_costi=None) -> dict:
    """Applica uno shock (calo ricavi / aumento costi) e ricalcola margine e DSCR.
    Il margine è usato come proxy del flusso operativo (semplificazione esplicita)."""
    ref = _load()
    sd_def = ref.get("stress_default", {})
    sr = Decimal(str(shock_ricavi if shock_ricavi is not None else sd_def.get("shock_ricavi", -0.10)))
    sc = Decimal(str(shock_costi if shock_costi is not None else sd_def.get("shock_costi", 0.05)))
    r = Decimal(str(ricavi_base))
    c = Decimal(str(costi_base))
    r2 = r * (1 + sr)
    c2 = c * (1 + sc)
    marg_base = r - c
    marg_str = r2 - c2
    d_base = dscr(marg_base, servizio_debito)
    d_str = dscr(marg_str, servizio_debito)
    limite = float(ref["dscr"]["limite"])
    resiliente = (d_str.get("dscr") is not None and d_str["dscr"] >= limite)
    return {
        "shock_ricavi": float(sr), "shock_costi": float(sc),
        "base": {"ricavi": _q2(r), "costi": _q2(c), "margine": _q2(marg_base), "dscr": d_base},
        "stress": {"ricavi": _q2(r2), "costi": _q2(c2), "margine": _q2(marg_str), "dscr": d_str},
        "resiliente": bool(resiliente),
    }


def analisi(ricavi_base, costi_base, servizio_debito=0, anni: int = 5,
            crescita_ricavi=0.03, crescita_costi=0.02,
            shock_ricavi=None, shock_costi=None) -> dict:
    """Analisi completa: proiezione N anni + DSCR corrente + stress test.
    A supporto del monitoraggio adeguati assetti (art. 2086 c.c. / CCII)."""
    ref = _load()
    proj = proiezione(ricavi_base, costi_base, anni, crescita_ricavi, crescita_costi)
    marg_corrente = Decimal(str(ricavi_base)) - Decimal(str(costi_base))
    has_debito = Decimal(str(servizio_debito)) > 0
    d = dscr(marg_corrente, servizio_debito) if has_debito else {"dscr": None, "giudizio": "n/d"}
    st = stress_test(ricavi_base, costi_base, servizio_debito,
                     shock_ricavi, shock_costi) if has_debito else None
    return {
        "proiezione": proj,
        "dscr_corrente": d,
        "stress_test": st,
        "ambito": ref.get("ambito"),
        "legal_source": ref.get("legal_source"),
        "schema_version": ref.get("schema_version"),
        "disclaimer": ("Proiezioni su ipotesi inserite dall'utente e soglie di prassi; "
                       "non sostituiscono la valutazione professionale."),
    }
