"""
DigitalVault - Generatore di file EXCEL (.xlsx) professionali.
(c) 2026 DigitalVault - Capo Team del Progetto: Dr. Falsone Giuseppe

Il commercialista vuole file Excel VERI, non CSV: intestazioni in grassetto,
colonne larghe al punto giusto, riga di intestazione bloccata, filtri attivi.
Questo modulo costruisce un .xlsx pronto da aprire e usare.

Se openpyxl non fosse disponibile, il chiamante ripiega sul CSV (nessun crash).
"""
import io
from datetime import datetime


def disponibile() -> bool:
    try:
        import openpyxl  # noqa: F401
        return True
    except Exception:
        return False


def crea_xlsx(titolo: str, intestazioni: list, righe: list,
              nome_foglio: str = "Dati") -> bytes:
    """Crea un foglio Excel formattato. `righe` = lista di liste (celle).
    Ritorna i byte del file .xlsx."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = (nome_foglio or "Dati")[:31]  # Excel: max 31 caratteri

    blu = PatternFill("solid", fgColor="1F4E78")
    bianco_grassetto = Font(bold=True, color="FFFFFF", size=11)
    bordo = Border(bottom=Side(style="thin", color="BBBBBB"))

    # Titolo (riga 1) + data
    n_col = max(1, len(intestazioni))
    ws.cell(row=1, column=1, value=titolo).font = Font(bold=True, size=14, color="1F4E78")
    ws.cell(row=2, column=1,
            value=f"DigitalVault — esportato il {datetime.now():%d/%m/%Y %H:%M}").font = \
        Font(italic=True, size=9, color="888888")

    # Intestazioni (riga 4)
    riga_intest = 4
    for c, nome in enumerate(intestazioni, start=1):
        cella = ws.cell(row=riga_intest, column=c, value=str(nome).upper())
        cella.fill = blu
        cella.font = bianco_grassetto
        cella.alignment = Alignment(horizontal="left", vertical="center")

    # Dati
    for r, riga in enumerate(righe, start=riga_intest + 1):
        for c, valore in enumerate(riga, start=1):
            cella = ws.cell(row=r, column=c, value=valore)
            cella.border = bordo

    # Larghezza colonne automatica (in base al contenuto, con un tetto)
    for c in range(1, n_col + 1):
        lettera = get_column_letter(c)
        massimo = len(str(intestazioni[c - 1])) if c - 1 < len(intestazioni) else 10
        for riga in righe:
            if c - 1 < len(riga) and riga[c - 1] is not None:
                massimo = max(massimo, len(str(riga[c - 1])))
        ws.column_dimensions[lettera].width = min(max(massimo + 3, 12), 50)

    # Blocca l'intestazione e attiva i filtri (comodissimo per il commercialista)
    ws.freeze_panes = f"A{riga_intest + 1}"
    ws.auto_filter.ref = f"A{riga_intest}:{get_column_letter(n_col)}{riga_intest + len(righe)}"

    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()
