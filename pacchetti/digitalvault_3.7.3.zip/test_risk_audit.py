"""Test del modulo Risk-Audit (deterministico). DB SQLite in-memory, dati finti."""
import json
from datetime import datetime

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import database as dbmod
import risk_audit

ANNO = datetime.now().year


def _sess():
    eng = create_engine("sqlite:///:memory:")
    dbmod.Base.metadata.create_all(eng)
    return sessionmaker(bind=eng)()


def _cli(db, **kw):
    c = dbmod.Client(nome=kw.pop("nome", "Mario"), cognome=kw.pop("cognome", "Rossi"), **kw)
    db.add(c); db.commit(); db.refresh(c)
    return c


def _doc(db, **kw):
    d = dbmod.Document(nome_file=kw.pop("nome_file", "f.pdf"),
                       nome_originale=kw.pop("nome_originale", "Fattura.pdf"), **kw)
    db.add(d); db.commit(); db.refresh(d)
    return d


def test_forfettario_oltre_soglia_alta():
    db = _sess()
    c = _cli(db, regime="forfettario", codice_fiscale="RSSMRA80A01H501U")
    _doc(db, client_id=c.id, importo=90000.0, anno_riferimento=ANNO, controparte="ACME")
    soglia = [x for x in risk_audit.analizza(db)["rilievi"] if x["categoria"] == "soglia_regime"]
    assert soglia and soglia[0]["gravita"] == "alta"


def test_forfettario_oltre_100k_critica():
    db = _sess()
    c = _cli(db, regime="forfettario", codice_fiscale="RSSMRA80A01H501U")
    _doc(db, client_id=c.id, importo=120000.0, anno_riferimento=ANNO, controparte="ACME")
    soglia = [x for x in risk_audit.analizza(db)["rilievi"] if x["categoria"] == "soglia_regime"]
    assert soglia and soglia[0]["gravita"] == "critica"


def test_importo_da_verificare():
    db = _sess()
    c = _cli(db, codice_fiscale="RSSMRA80A01H501U")
    _doc(db, client_id=c.id, importo=500.0, anno_riferimento=ANNO,
         dati_estratti=json.dumps({"importo_da_verificare": True}))
    assert any(x["categoria"] == "importi_ai" for x in risk_audit.analizza(db)["rilievi"])


def test_duplicati():
    db = _sess()
    c = _cli(db, codice_fiscale="RSSMRA80A01H501U")
    _doc(db, client_id=c.id, importo=1000.0, anno_riferimento=ANNO, controparte="ENEL", nome_file="a.pdf")
    _doc(db, client_id=c.id, importo=1000.0, anno_riferimento=ANNO, controparte="ENEL", nome_file="b.pdf")
    dup = [x for x in risk_audit.analizza(db)["rilievi"] if x["categoria"] == "duplicati"]
    assert dup and len(dup[0]["riferimento"]["doc_ids"]) == 2


def test_societa_senza_piva_e_struttura_report():
    db = _sess()
    _cli(db, tipo="societa", cognome="Alfa", nome="Srl", codice_fiscale="12345678901")
    r = risk_audit.analizza(db)
    assert any(x["categoria"] == "anagrafica" for x in r["rilievi"])
    assert {"rilievi", "totale", "critici", "per_categoria", "generato"}.issubset(r.keys())
    # ordinamento per gravità (le più gravi prima)
    grav = [risk_audit._ORDINE.get(x["gravita"], 4) for x in r["rilievi"]]
    assert grav == sorted(grav)


def test_db_pulito_nessun_crash():
    # nessun cliente/documento: deve restituire un report valido, niente eccezioni
    r = risk_audit.analizza(_sess())
    assert r["totale"] == 0 and r["rilievi"] == []
