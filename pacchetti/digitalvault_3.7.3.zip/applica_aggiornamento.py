"""
DigitalValut - Applica un aggiornamento scaricato (a programma CHIUSO).
(c) 2026 DigitalValut Team - Dr. Falsone Giuseppe

Sostituisce i file del programma con quelli nuovi, MA conserva:
  - i dati dello studio (cartella data/)
  - i documenti caricati (cartella uploads/)
  - i backup (cartella backups/)
  - la CHIAVE AI di questo studio dentro config.py

Prima di tutto fa una copia di sicurezza del programma attuale, cosi' se
qualcosa va storto si puo' tornare indietro.
"""
import os
import re
import shutil
import sys
import zipfile
from datetime import datetime
from pathlib import Path

import update_security

MOTORE = Path(__file__).parent
UPDATE_DIR = MOTORE / "_aggiornamento"
ZIP = UPDATE_DIR / "aggiornamento.zip"
SIG = UPDATE_DIR / "aggiornamento.sig"
ESTRATTO = UPDATE_DIR / "estratto"

# Cartelle/file da NON sovrascrivere mai (sono i dati dello studio)
PRESERVA = {"data", "uploads", "backups", "_aggiornamento"}

# Modalità automatica: quando l'applicatore è lanciato dall'app all'avvio,
# niente prompt 'Premi Invio' (che bloccherebbero l'avvio non interattivo).
AUTO = ("--auto" in sys.argv) or (os.environ.get("DIGITALVAULT_AUTO") == "1")


def _pausa(msg="  Premi Invio per chiudere..."):
    if AUTO:
        return
    try:
        input(msg)
    except EOFError:
        pass


def _chiave_openrouter(testo: str) -> str:
    m = re.search(r'OPENROUTER_API_KEY\s*=\s*"([^"]*)"', testo)
    return m.group(1) if m else None


def _trova_radice(base: Path) -> Path:
    """Trova la cartella che contiene app.py dentro lo zip estratto."""
    if (base / "app.py").exists():
        return base
    for p in base.rglob("app.py"):
        return p.parent
    return None


def main():
    print("=" * 60)
    print("  DIGITALVALUT - APPLICA AGGIORNAMENTO")
    print("=" * 60)
    print()

    if not ZIP.exists():
        print("  Nessun pacchetto da installare.")
        print("  (Scaricalo prima dal programma: Impostazioni -> Aggiornamenti)")
        _pausa("\n  Premi Invio per uscire...")
        return

    # 0) SICUREZZA: ri-verifica la firma del pacchetto prima di toccarlo.
    if update_security.public_key_presente():
        firma = SIG.read_text(encoding="utf-8").strip() if SIG.exists() else None
        if not update_security.verifica_firma(ZIP.read_bytes(), firma):
            print("  [ERRORE] Pacchetto NON firmato o manomesso: aggiornamento ANNULLATO.")
            print("  (Per sicurezza non viene installato nulla.)")
            _pausa("\n  Premi Invio per uscire...")
            return
        print("  0/4  Firma del pacchetto verificata. OK.")

    # 1) Estrai il pacchetto IN MODO SICURO (anti Zip-Slip)
    print("  1/4  Apro il pacchetto...")
    if ESTRATTO.exists():
        shutil.rmtree(ESTRATTO, ignore_errors=True)
    ESTRATTO.mkdir(parents=True, exist_ok=True)
    try:
        update_security.estrai_sicuro(ZIP, ESTRATTO)
    except Exception as e:
        print(f"  [ERRORE] Pacchetto non sicuro o danneggiato: {e}")
        print("  Aggiornamento ANNULLATO.")
        _pausa("\n  Premi Invio per uscire...")
        return

    radice = _trova_radice(ESTRATTO)
    if not radice:
        print("  [ERRORE] Il pacchetto non contiene un programma valido (manca app.py).")
        _pausa("\n  Premi Invio per uscire...")
        return

    # 2) Copia di sicurezza del programma attuale
    print("  2/4  Faccio una copia di sicurezza del programma attuale...")
    safe = MOTORE / f"_backup_programma_{datetime.now():%Y%m%d_%H%M%S}"
    safe.mkdir(exist_ok=True)
    for item in MOTORE.iterdir():
        if item.name in PRESERVA or item.name.startswith("_backup_programma_"):
            continue
        try:
            if item.is_file():
                shutil.copy2(item, safe / item.name)
            elif item.is_dir():
                shutil.copytree(item, safe / item.name, dirs_exist_ok=True)
        except Exception:
            pass

    # 3) Conserva la chiave AI dello studio
    config_vecchio = MOTORE / "config.py"
    chiave = _chiave_openrouter(config_vecchio.read_text(encoding="utf-8")) if config_vecchio.exists() else None

    # 4) Copia i file nuovi (saltando i dati dello studio)
    print("  3/4  Installo i file nuovi...")
    for item in radice.iterdir():
        if item.name in PRESERVA:
            continue
        dest = MOTORE / item.name
        try:
            if item.is_file():
                shutil.copy2(item, dest)
            elif item.is_dir():
                shutil.copytree(item, dest, dirs_exist_ok=True)
        except Exception as e:
            print(f"     attenzione: non ho potuto aggiornare {item.name} ({e})")

    # Reinserisci la chiave AI nel nuovo config.py
    if chiave:
        nuovo = MOTORE / "config.py"
        testo = nuovo.read_text(encoding="utf-8")
        testo = re.sub(r'OPENROUTER_API_KEY\s*=\s*"[^"]*"',
                       f'OPENROUTER_API_KEY = "{chiave}"', testo, count=1)
        nuovo.write_text(testo, encoding="utf-8")
        print("  4/4  Chiave AI dello studio conservata.")

    # Pulizia
    shutil.rmtree(ESTRATTO, ignore_errors=True)
    for f in (ZIP, SIG):
        try:
            f.unlink()
        except Exception:
            pass

    print()
    print("  " + "=" * 56)
    print("  [OK] AGGIORNAMENTO COMPLETATO!")
    print("  " + "=" * 56)
    print(f"  Copia di sicurezza del programma precedente in:")
    print(f"    {safe.name}")
    print("  (puoi cancellarla quando sei sicuro che tutto funziona)")
    print()
    print("  Riavvia DigitalValut con AVVIA DIGITALVALUT.bat")
    print()
    _pausa("  Premi Invio per chiudere...")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n  [ERRORE] {e}")
        _pausa("  Premi Invio per uscire...")
