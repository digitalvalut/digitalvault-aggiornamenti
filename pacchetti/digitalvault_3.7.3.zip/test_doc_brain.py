"""Test del parsing citazioni RAG (verificabilità delle fonti)."""
from doc_brain import citazioni_in


def test_estrae_citazioni_valide():
    assert citazioni_in("Versamento 500€ [1], scadenza nel [3].", 6) == {1, 3}


def test_ignora_fuori_range():
    # [9] non esiste fra i 3 documenti recuperati: va ignorato
    assert citazioni_in("vedi [9] e [2]", 3) == {2}


def test_nessuna_citazione():
    assert citazioni_in("nessun documento pertinente trovato", 5) == set()


def test_citazioni_multiple_adiacenti():
    assert citazioni_in("come da [2][3][2]", 4) == {2, 3}
