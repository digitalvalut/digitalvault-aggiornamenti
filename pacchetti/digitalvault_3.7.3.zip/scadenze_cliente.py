"""
DigitalValut - Scadenzario su misura per ogni cliente.
(c) 2026 DigitalValut Team - Dr. Falsone Giuseppe

In base al REGIME del cliente (forfettario, ordinario, società, datore di
lavoro, privato) genera SOLO le scadenze che lo riguardano, già collegate a
lui. Così ogni cliente ha il suo calendario e nei promemoria parte l'avviso
giusto, senza scadenze inutili.

Nota: le date sono quelle ordinarie. Se cadono di sabato/domenica o festivo,
slittano per legge al primo giorno lavorativo: il commercialista verifica
sempre la data effettiva sul calendario fiscale dell'anno.
"""
from datetime import datetime

# Profili disponibili (etichetta mostrata + scadenze tipiche).
# Ogni scadenza: (titolo, mese, giorno, tipo, descrizione)
PROFILI = {
    "forfettario": {
        "nome": "Forfettario (regime agevolato)",
        "scadenze": [
            ("Saldo + 1° acconto imposta sostitutiva", 6, 30, "F24",
             "Versamento saldo anno precedente e primo acconto (regime forfettario)"),
            ("2° acconto imposta sostitutiva", 11, 30, "F24",
             "Secondo acconto imposta sostitutiva 5%/15%"),
            ("Contributi INPS - 1ª rata", 5, 16, "INPS", "Contributi previdenziali"),
            ("Contributi INPS - 2ª rata", 8, 20, "INPS", "Contributi previdenziali"),
            ("Contributi INPS - 3ª rata", 11, 16, "INPS", "Contributi previdenziali"),
            ("Dichiarazione Redditi PF", 11, 30, "REDDITI", "Modello Redditi Persone Fisiche"),
        ],
    },
    "ordinario_pf": {
        "nome": "Professionista / Ditta individuale (ordinario)",
        "scadenze": [
            ("Liquidazione IVA 1° trimestre", 5, 16, "IVA", "Versamento IVA trimestrale"),
            ("Liquidazione IVA 2° trimestre", 8, 20, "IVA", "Versamento IVA trimestrale"),
            ("Liquidazione IVA 3° trimestre", 11, 16, "IVA", "Versamento IVA trimestrale"),
            ("Liquidazione IVA 4° trimestre", 3, 16, "IVA", "Versamento IVA quarto trimestre / saldo"),
            ("Saldo + 1° acconto IRPEF", 6, 30, "IRPEF", "Saldo e primo acconto IRPEF"),
            ("2° acconto IRPEF", 11, 30, "IRPEF", "Secondo acconto IRPEF"),
            ("Contributi INPS - 1ª rata", 5, 16, "INPS", "Contributi previdenziali"),
            ("Contributi INPS - 2ª rata", 8, 20, "INPS", "Contributi previdenziali"),
            ("Dichiarazione IVA annuale", 4, 30, "IVA", "Dichiarazione IVA annuale"),
            ("Dichiarazione Redditi PF", 11, 30, "REDDITI", "Modello Redditi Persone Fisiche"),
        ],
    },
    "societa": {
        "nome": "Società (SRL / SPA / SNC / SAS)",
        "scadenze": [
            ("Liquidazione IVA 1° trimestre", 5, 16, "IVA", "Versamento IVA trimestrale"),
            ("Liquidazione IVA 2° trimestre", 8, 20, "IVA", "Versamento IVA trimestrale"),
            ("Liquidazione IVA 3° trimestre", 11, 16, "IVA", "Versamento IVA trimestrale"),
            ("Saldo + 1° acconto IRES/IRAP", 6, 30, "IRES", "Saldo e primo acconto IRES e IRAP"),
            ("2° acconto IRES/IRAP", 11, 30, "IRES", "Secondo acconto IRES e IRAP"),
            ("Dichiarazione IVA annuale", 4, 30, "IVA", "Dichiarazione IVA annuale"),
            ("Dichiarazione Redditi SC + IRAP", 11, 30, "REDDITI", "Modello Redditi Società di Capitali e IRAP"),
            ("Deposito bilancio", 5, 29, "BILANCIO", "Deposito bilancio al Registro Imprese (entro 30 gg dall'approvazione)"),
        ],
    },
    "datore_lavoro": {
        "nome": "Datore di lavoro (con dipendenti)",
        "scadenze": [
            ("Ritenute dipendenti - F24 mensile", 1, 16, "F24", "Versamento ritenute (ogni mese il 16)"),
            ("Certificazione Unica (CU)", 3, 16, "CU", "Trasmissione CU all'Agenzia delle Entrate"),
            ("Autoliquidazione INAIL", 2, 16, "INAIL", "Premio INAIL autoliquidazione"),
            ("Modello 770", 10, 31, "770", "Dichiarazione sostituti d'imposta"),
        ],
    },
    "privato": {
        "nome": "Privato (no partita IVA)",
        "scadenze": [
            ("Modello 730", 9, 30, "730", "Presentazione modello 730"),
            ("IMU - 1ª rata (acconto)", 6, 16, "IMU", "Acconto IMU"),
            ("IMU - 2ª rata (saldo)", 12, 16, "IMU", "Saldo IMU"),
        ],
    },
}


def profili_disponibili() -> list:
    return [{"id": k, "nome": v["nome"], "numero_scadenze": len(v["scadenze"])}
            for k, v in PROFILI.items()]


def _prossima_data(mese: int, giorno: int, oggi: datetime) -> datetime:
    """Data di quest'anno; se è già passata, la stessa data dell'anno prossimo."""
    anno = oggi.year
    try:
        data = datetime(anno, mese, giorno)
    except ValueError:
        data = datetime(anno, mese, 28)
    if data.date() < oggi.date():
        try:
            data = datetime(anno + 1, mese, giorno)
        except ValueError:
            data = datetime(anno + 1, mese, 28)
    return data


def genera_scadenze(db, client, profilo: str) -> dict:
    """Crea nel database le scadenze del profilo, collegate al cliente.
    Salta quelle già presenti (stesso titolo+cliente) per non duplicare."""
    from database import Scadenza

    prof = PROFILI.get(profilo)
    if not prof:
        return {"ok": False, "errore": "Profilo sconosciuto."}

    oggi = datetime.now()
    nome_cliente = f"{client.cognome} {client.nome}"
    esistenti = {
        s.titolo for s in db.query(Scadenza).filter(Scadenza.client_id == client.id).all()
    }
    create = 0
    for titolo, mese, giorno, tipo, descr in prof["scadenze"]:
        if titolo in esistenti:
            continue
        db.add(Scadenza(
            titolo=titolo,
            descrizione=descr,
            data_scadenza=_prossima_data(mese, giorno, oggi),
            tipo=tipo,
            client_id=client.id,
            client_nome=nome_cliente,
        ))
        create += 1
    db.commit()
    return {"ok": True, "create": create, "gia_presenti": len(prof["scadenze"]) - create,
            "profilo": prof["nome"]}
