# Aspetta che DigitalVault sia pronto, poi apre il browser.
# Cosi' non appare mai "server non raggiungibile".
for ($i = 0; $i -lt 120; $i++) {
    try {
        Invoke-WebRequest -Uri 'http://localhost:8000/api/health' -UseBasicParsing -TimeoutSec 2 | Out-Null
        break
    } catch {
        Start-Sleep -Milliseconds 800
    }
}
Start-Process 'http://localhost:8000'
