import pdfplumber
import re
from pathlib import Path


def extract_text_from_pdf(file_path: str) -> str:
    text = ""
    try:
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
    except Exception as e:
        text = f"[Errore estrazione testo: {e}]"
    return text.strip()


def detect_document_type(text: str, filename: str) -> str:
    text_lower = text.lower()
    filename_lower = filename.lower()
    if "730" in filename_lower or "modello 730" in text_lower or "dichiarazione 730" in text_lower:
        return "730"
    if "certificazione unica" in text_lower or " cu " in text_lower or "cu2" in filename_lower:
        return "CU"
    if "f24" in filename_lower or "modello f24" in text_lower or "codice tributo" in text_lower:
        return "F24"
    if "modello redditi" in text_lower or "unico" in filename_lower:
        return "REDDITI"
    if "fattura" in text_lower or "iva" in text_lower:
        return "FATTURA"
    if "cedolino" in text_lower or "busta paga" in text_lower or "stipendio" in text_lower:
        return "BUSTA_PAGA"
    if "contratto" in text_lower:
        return "CONTRATTO"
    if "visura" in text_lower or "camera di commercio" in text_lower:
        return "VISURA"
    if "imu" in text_lower:
        return "IMU"
    if "catastale" in text_lower or "rendita" in text_lower:
        return "CATASTO"
    if "inps" in text_lower:
        return "INPS"
    return "GENERICO"


def extract_codice_fiscale(text: str) -> str | None:
    pattern = r'\b[A-Z]{6}\d{2}[A-Z]\d{2}[A-Z]\d{3}[A-Z]\b'
    matches = re.findall(pattern, text.upper())
    return matches[0] if matches else None


def extract_partita_iva(text: str) -> str | None:
    pattern = r'\b\d{11}\b'
    matches = re.findall(pattern, text)
    return matches[0] if matches else None


def get_document_summary(text: str, doc_type: str) -> str:
    lines = [l.strip() for l in text.split('\n') if l.strip()]
    preview = '\n'.join(lines[:50])
    cf = extract_codice_fiscale(text)
    piva = extract_partita_iva(text)
    summary = f"Tipo documento: {doc_type}\n"
    if cf:
        summary += f"Codice Fiscale rilevato: {cf}\n"
    if piva:
        summary += f"Partita IVA rilevata: {piva}\n"
    summary += f"\nPreview contenuto:\n{preview}"
    return summary
