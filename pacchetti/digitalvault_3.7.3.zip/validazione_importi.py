"""
DigitalValut - Validazione condivisa degli importi estratti dall'AI.
(c) 2026 DigitalValut - Capo Team del Progetto: Dr. Falsone Giuseppe

Layer deterministico (Fase D del Brief di affidabilità fiscale) riusato da:
  - doc_classifier.py   (importo del documento)
  - riconciliazione.py  (importi dei movimenti dell'estratto conto)
  - ocr_processor.py    (importo da foto scontrino)

Regola: un importo prodotto dall'AI non è mai "verità". Qui si controlla che
sia plausibile e, quando esiste il testo sorgente, che vi compaia davvero.
"""
import re

# Oltre questa soglia un importo su un documento di studio è quasi certamente
# un errore di lettura (OCR/AI). Si segnala, non si butta via in automatico.
MAX_IMPORTO = 100_000_000.0

# Numeri nel testo: formato italiano (1.234.567,89) o semplice (1234.56 / 1234,56)
_RE_NUM = re.compile(r"\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?")


def numeri_nel_testo(testo: str) -> set:
    """Estrae i numeri presenti nel testo come float, gestendo il formato
    italiano (punto migliaia, virgola decimali). Serve a verificare che un
    importo proposto dall'AI esista DAVVERO nel documento."""
    nums = set()
    for m in _RE_NUM.finditer(testo or ""):
        t = m.group(0)
        if "," in t:                      # virgola = decimali → punto è migliaia
            t = t.replace(".", "").replace(",", ".")
        elif "." in t:                    # solo punti: migliaia (1.220) vs decimale (1.22)
            parti = t.split(".")
            if all(len(p) == 3 for p in parti[1:]):
                t = t.replace(".", "")
        try:
            nums.add(round(float(t), 2))
        except ValueError:
            pass
    return nums


def valida_importo(importo, testo: str = None):
    """Valida un importo estratto dall'AI. Ritorna (importo, warnings, da_verificare).
    - <= 0 o non numerico → scartato (None) con avviso;
    - molto elevato → mantenuto ma segnalato;
    - se `testo` è fornito e l'importo NON vi compare → mantenuto ma segnalato
      (possibile invenzione dell'AI). Se `testo` è None (es. OCR da immagine,
      senza testo sorgente confrontabile) il cross-check di presenza si salta."""
    warnings = []
    if importo is None:
        return None, warnings, False
    try:
        importo = float(importo)
    except (ValueError, TypeError):
        return None, ["Importo non numerico letto dall'AI: ignorato."], True
    if importo <= 0:
        return None, ["Importo non plausibile (<= 0) letto dall'AI: ignorato, da inserire a mano."], True
    da_verificare = False
    if importo > MAX_IMPORTO:
        warnings.append(f"Importo molto elevato (€ {importo:,.2f}): possibile errore di lettura, verificare.")
        da_verificare = True
    if testo is not None:
        nums = numeri_nel_testo(testo)
        if nums:
            trovato = any(abs(n - importo) <= max(0.02, importo * 0.001) for n in nums)
            if not trovato:
                warnings.append("L'importo non risulta nel testo del documento: verificare (possibile stima dell'AI).")
                da_verificare = True
    return importo, warnings, da_verificare
