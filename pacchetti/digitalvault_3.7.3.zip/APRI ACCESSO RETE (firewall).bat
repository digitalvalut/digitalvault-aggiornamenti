﻿@echo off
REM ============================================================
REM  FiscoSicuro - Apre il Firewall di Windows per la RETE STUDIO
REM  Doppio clic e rispondi "Si" alla richiesta di amministratore.
REM ============================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo  Chiedo i permessi di amministratore...
  powershell -Command "Start-Process '%~f0' -Verb RunAs"
  exit /b
)

echo.
echo  Apro la porta 8000-8010 per i colleghi della rete studio...
netsh advfirewall firewall delete rule name="FiscoSicuro Rete Studio" >nul 2>&1
netsh advfirewall firewall add rule name="FiscoSicuro Rete Studio" dir=in action=allow protocol=TCP localport=8000-8010

echo.
echo  ============================================================
echo   FATTO. Firewall aperto per le porte 8000-8010.
echo.
echo   Indirizzo IP di questo PC nella rete locale:
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /C:"IPv4"') do echo      http:%%a:8000
echo.
echo   I colleghi aprono quell'indirizzo nel browser e inseriscono
echo   il PIN che appare nella finestra di DigitalValut.
echo  ============================================================
echo.
pause