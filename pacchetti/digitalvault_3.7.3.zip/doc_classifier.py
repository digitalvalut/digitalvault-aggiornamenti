"""
DigitalValut - Classificatore intelligente di documenti.
(c) 2026 DigitalValut - Capo Team del Progetto: Dr. Falsone Giuseppe

"Butta dentro qualsiasi documento -> si sistema da solo":
dato il testo di un documento (PDF/scansione/file), capisce CHE COS'E',
ne estrae i dati chiave e individua a QUALE CLIENTE appartiene, confrontando
codice fiscale / partita IVA / nome con l'anagrafica esistente.

Robusto: se l'AI non risponde, ripiega su un riconoscimento "a parole chiave"
e su un abbinamento del cliente tramite codice fiscale/P.IVA trovati nel testo.
"""
import re
import json
from datetime import datetime

import ai_client
from pdf_processor import detect_document_type

# Tipi canonici che il classificatore prova a riconoscere
TIPI = ["FATTURA", "F24", "ESTRATTO_CONTO", "CONTRATTO", "BUSTA_PAGA", "CU",
        "730", "REDDITI", "IVA", "VISURA", "RICEVUTA", "DOCUMENTO_IDENTITA", "ALTRO"]

_RE_CF = re.compile(r"\b[A-Z]{6}\d{2}[A-Z]\d{2}[A-Z]\d{3}[A-Z]\b", re.IGNORECASE)
_RE_PIVA = re.compile(r"\b\d{11}\b")

# Validazione importi (Fase D) — logica condivisa con riconciliazione/OCR.
from validazione_importi import valida_importo as _valida_importo, numeri_nel_testo as _numeri_nel_testo


def _normalizza(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def _match_cliente_deterministico(testo: str, clienti: list) -> int | None:
    """Abbina il documento a un cliente tramite CF o P.IVA presenti nel testo.
    `clienti` = lista di dict {id, nome, cognome, codice_fiscale, partita_iva}."""
    if not testo or not clienti:
        return None
    cf_doc = {m.group(0).upper() for m in _RE_CF.finditer(testo)}
    piva_doc = set(_RE_PIVA.findall(testo))
    for c in clienti:
        cf = (c.get("codice_fiscale") or "").upper().strip()
        piva = (c.get("partita_iva") or "").strip()
        if cf and cf in cf_doc:
            return c["id"]
        if piva and piva in piva_doc:
            return c["id"]
    # Ultima spiaggia: nome+cognome citati per intero nel testo (in QUALSIASI ordine)
    t = _normalizza(testo)
    for c in clienti:
        nome = _normalizza(c.get("nome", ""))
        cogn = _normalizza(c.get("cognome", ""))
        for full in (nome + cogn, cogn + nome):
            if len(full) >= 6 and full in t:
                return c["id"]
    return None


def _match_per_cf_piva(cf, piva, clienti: list) -> int | None:
    """Abbina usando CF/P.IVA estratti dall'AI (utile se nel testo erano scritti
    con spaziature/formati che la regex sul testo grezzo non ha colto)."""
    cf = (cf or "").upper().strip()
    piva = (piva or "").strip()
    if not cf and not piva:
        return None
    for c in clienti:
        if cf and cf == (c.get("codice_fiscale") or "").upper().strip():
            return c["id"]
        if piva and piva == (c.get("partita_iva") or "").strip():
            return c["id"]
    return None


def _fallback(testo: str, nome_file: str, clienti: list) -> dict:
    """Classificazione senza AI: tipo a parole chiave + match CF/P.IVA."""
    tipo = detect_document_type(testo or "", nome_file or "") or "GENERICO"
    cid = _match_cliente_deterministico(testo, clienti)
    anno = None
    m = re.search(r"\b(20\d{2})\b", testo or "")
    if m:
        anno = int(m.group(1))
    return {
        "tipo": tipo, "anno": anno, "controparte": None, "importo": None,
        "codice_fiscale": None, "partita_iva": None, "riassunto": "",
        "cliente_id": cid, "confidenza": "bassa", "_ai": False,
        "fonte_importo": None, "importo_da_verificare": False, "warnings": [],
    }


_SYSTEM =("Sei un classificatore di documenti per uno studio di commercialisti italiano. "
           "Rispondi ESCLUSIVAMENTE con un oggetto JSON valido, senza testo attorno.")


async def classifica(testo: str, nome_file: str, clienti: list) -> dict:
    """Classifica il documento e prova ad abbinarlo a un cliente.
    Ritorna un dict con: tipo, anno, controparte, importo, codice_fiscale,
    partita_iva, riassunto, cliente_id (o None), confidenza, _ai (bool)."""
    if not testo or len(testo.strip()) < 15:
        return _fallback(testo, nome_file, clienti)

    estratto = testo[:6000]
    prompt = (
        "Analizza il DOCUMENTO qui sotto e restituisci un JSON con questi campi:\n"
        f'  "tipo": uno tra {TIPI} (scegli il piu\' appropriato);\n'
        '  "anno": anno fiscale di riferimento (numero) o null;\n'
        '  "controparte": ragione sociale/nome del fornitore o emittente, o null;\n'
        '  "importo": importo totale principale come numero (punto decimale), o null;\n'
        '  "codice_fiscale": CF presente nel documento o null;\n'
        '  "partita_iva": P.IVA presente nel documento o null;\n'
        '  "riassunto": una frase che descrive il documento;\n'
        '  "confidenza": "alta", "media" o "bassa".\n\n'
        f"[NOME FILE]\n{nome_file}\n\n"
        f"[TESTO DOCUMENTO]\n{estratto}"
    )
    try:
        d = await ai_client.chat_json(prompt, system=_SYSTEM)
    except Exception:
        return _fallback(testo, nome_file, clienti)

    # Normalizza/valida i campi
    tipo = str(d.get("tipo") or "ALTRO").upper().strip()
    if tipo not in TIPI:
        tipo = detect_document_type(testo, nome_file) or "ALTRO"
    anno = d.get("anno")
    try:
        anno = int(anno) if anno not in (None, "", "null") else None
    except (ValueError, TypeError):
        anno = None
    importo = d.get("importo")
    try:
        importo = float(str(importo).replace(",", ".")) if importo not in (None, "", "null") else None
    except (ValueError, TypeError):
        importo = None
    # Validazione deterministica POST-AI (Fase D): range + presenza nel testo.
    importo, imp_warnings, importo_da_verificare = _valida_importo(importo, testo)

    # Abbinamento cliente 100% DETERMINISTICO (l'AI non vede piu' l'anagrafica:
    # niente migliaia di token sprecati a ogni documento, e nessun rischio che
    # l'AI sbagli cliente). 1) CF/P.IVA/nome nel testo; 2) CF/P.IVA estratti dall'AI.
    cid = _match_cliente_deterministico(testo, clienti)
    if not cid:
        cid = _match_per_cf_piva(d.get("codice_fiscale"), d.get("partita_iva"), clienti)

    conf = str(d.get("confidenza") or "media").lower().strip()
    if conf not in ("alta", "media", "bassa"):
        conf = "media"
    # Se l'importo è sospetto, la confidenza non può restare "alta".
    if imp_warnings and conf == "alta":
        conf = "media"

    return {
        "tipo": tipo, "anno": anno, "controparte": d.get("controparte") or None,
        "importo": importo, "codice_fiscale": d.get("codice_fiscale") or None,
        "partita_iva": d.get("partita_iva") or None,
        "riassunto": d.get("riassunto") or "", "cliente_id": cid,
        "confidenza": conf, "_ai": True,
        # Fase D — tracciabilità dell'importo estratto dall'AI:
        "fonte_importo": "ai" if importo is not None else None,
        "importo_da_verificare": importo_da_verificare,
        "warnings": imp_warnings,
    }
