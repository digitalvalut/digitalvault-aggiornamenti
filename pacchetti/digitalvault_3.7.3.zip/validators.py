"""
DigitalValut - Validazione Codice Fiscale e Partita IVA (algoritmi ufficiali).
(c) 2026 DigitalValut Team - Dr. Falsone Giuseppe

Controlla che il dato sia FORMALMENTE corretto (carattere di controllo).
Non verifica l'esistenza reale presso l'Agenzia delle Entrate: dice solo se
il codice e' ben formato, cosi' il commercialista si accorge subito di un
errore di battitura.
"""
import re

# ── CODICE FISCALE ────────────────────────────────────────────────────────────
_CF_PARI = {
    "0": 0, "1": 1, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9,
    "A": 0, "B": 1, "C": 2, "D": 3, "E": 4, "F": 5, "G": 6, "H": 7, "I": 8, "J": 9,
    "K": 10, "L": 11, "M": 12, "N": 13, "O": 14, "P": 15, "Q": 16, "R": 17, "S": 18,
    "T": 19, "U": 20, "V": 21, "W": 22, "X": 23, "Y": 24, "Z": 25,
}
_CF_DISPARI = {
    "0": 1, "1": 0, "2": 5, "3": 7, "4": 9, "5": 13, "6": 15, "7": 17, "8": 19,
    "9": 21, "A": 1, "B": 0, "C": 5, "D": 7, "E": 9, "F": 13, "G": 15, "H": 17,
    "I": 19, "J": 21, "K": 2, "L": 4, "M": 18, "N": 20, "O": 11, "P": 3, "Q": 6,
    "R": 8, "S": 12, "T": 14, "U": 16, "V": 10, "W": 22, "X": 25, "Y": 24, "Z": 23,
}
_CF_RESTO = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
_CF_RE = re.compile(r"^[A-Z]{6}[0-9LMNPQRSTUV]{2}[A-Z][0-9LMNPQRSTUV]{2}[A-Z][0-9LMNPQRSTUV]{3}[A-Z]$")


def valida_codice_fiscale(cf: str) -> dict:
    """Verifica formato + carattere di controllo del CF (persona fisica, 16
    caratteri). Ritorna {valido, messaggio}."""
    cf = (cf or "").strip().upper().replace(" ", "")
    if not cf:
        return {"valido": None, "messaggio": ""}  # campo vuoto: nessun giudizio
    if len(cf) != 16:
        return {"valido": False, "messaggio": "Il codice fiscale deve avere 16 caratteri."}
    if not _CF_RE.match(cf):
        return {"valido": False, "messaggio": "Formato del codice fiscale non valido."}
    somma = 0
    for i, ch in enumerate(cf[:15]):
        somma += _CF_DISPARI[ch] if (i % 2 == 0) else _CF_PARI[ch]
    atteso = _CF_RESTO[somma % 26]
    if atteso != cf[15]:
        return {"valido": False,
                "messaggio": f"Carattere di controllo errato (atteso '{atteso}'). Verifica la digitazione."}
    return {"valido": True, "messaggio": "Codice fiscale formalmente corretto."}


# ── PARTITA IVA ───────────────────────────────────────────────────────────────
def valida_partita_iva(piva: str) -> dict:
    """Verifica i 11 cifre della P.IVA con l'algoritmo di controllo ufficiale
    (Luhn all'italiana). Ritorna {valido, messaggio}."""
    piva = (piva or "").strip().replace(" ", "")
    if not piva:
        return {"valido": None, "messaggio": ""}
    if not piva.isdigit() or len(piva) != 11:
        return {"valido": False, "messaggio": "La partita IVA deve essere di 11 cifre."}
    somma = 0
    for i in range(11):
        n = int(piva[i])
        if i % 2 == 0:           # posizioni dispari (1ª, 3ª...) -> indice pari
            somma += n
        else:                    # posizioni pari -> doppio, e se >9 si sottrae 9
            d = n * 2
            somma += d - 9 if d > 9 else d
    if somma % 10 != 0:
        return {"valido": False, "messaggio": "Partita IVA non valida (cifra di controllo errata)."}
    return {"valido": True, "messaggio": "Partita IVA formalmente corretta."}


def valida_entrambi(codice_fiscale: str = None, partita_iva: str = None) -> dict:
    return {
        "codice_fiscale": valida_codice_fiscale(codice_fiscale),
        "partita_iva": valida_partita_iva(partita_iva),
    }
