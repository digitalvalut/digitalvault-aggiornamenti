"""
DigitalValut - TEST E2E (End-to-End) col BROWSER VERO.
(c) 2026 DigitalValut Team - Dr. Falsone Giuseppe

A COSA SERVE
------------
E' il test che fanno le grandi software house prima di rilasciare: un ROBOT
apre un vero browser (Chromium), CLICCA come un commercialista e verifica che
i percorsi principali funzionino DAVVERO nell'interfaccia, non solo nel codice.

PERCORSI VERIFICATI (i 5 flussi chiave):
  1. La dashboard si apre e mostra i numeri dello studio.
  2. Si naviga tra tutte le pagine senza errori JavaScript.
  3. Si CREA un cliente dal modulo e compare in elenco (+ contatore aggiornato).
  4. Si GENERA una bozza di documento legale (deterministico, niente AI).
  5. Nessun errore in console durante tutto il giro.

SICUREZZA DEI DATI
------------------
Il test crea un cliente di prova: per NON sporcare l'archivio reale, gira su un
DATABASE TEMPORANEO usa-e-getta (cartella temporanea), che viene CANCELLATO alla
fine. Il master non viene mai toccato. Nessuna chiamata AI, nessun costo.

USO
---
  python test_e2e_browser.py
  python test_e2e_browser.py --mostra      (mostra il browser invece che invisibile)

Richiede una volta sola:  python -m playwright install chromium
"""
import argparse
import os
import sys
import tempfile
import threading
import time
import urllib.request
from pathlib import Path

import config
import uvicorn

# Database temporaneo usa-e-getta: "crea cliente" non deve scrivere nell'archivio
# reale del master. L'isolamento si attiva in _isola_db(), chiamato in main()
# PRIMA che l'app venga importata (cosi' importare questo file non ha effetti).
_TMP = Path(tempfile.gettempdir()) / f"dgv_e2e_{os.getpid()}"

PORTA = 8779
BASE = f"http://127.0.0.1:{PORTA}"


def _isola_db():
    _TMP.mkdir(parents=True, exist_ok=True)
    config.DATA_DIR = _TMP
    config.DB_PATH = _TMP / "digitalvault_e2e.db"
    config.UPLOAD_DIR = _TMP / "uploads"
    config.UPLOAD_DIR.mkdir(exist_ok=True)


def _attendi_server(secondi=25.0) -> bool:
    scadenza = time.time() + secondi
    while time.time() < scadenza:
        try:
            with urllib.request.urlopen(f"{BASE}/api/health", timeout=1) as r:
                if b"ok" in r.read():
                    return True
        except Exception:
            time.sleep(0.3)
    return False


def _pulisci():
    import shutil
    shutil.rmtree(_TMP, ignore_errors=True)


class Esito:
    def __init__(self):
        self.passi = []
    def ok(self, nome):
        self.passi.append((True, nome, ""))
        print(f"  [OK]   {nome}")
    def ko(self, nome, perche):
        self.passi.append((False, nome, perche))
        print(f"  [FAIL] {nome}  ->  {perche}")
    def passati(self):
        return sum(1 for p in self.passi if p[0])
    def falliti(self):
        return [p for p in self.passi if not p[0]]


def esegui(mostra=False):
    from playwright.sync_api import sync_playwright

    esito = Esito()
    errori_console = []

    with sync_playwright() as p:
        # Usa, in ordine: il Chromium di Playwright (se scaricato), altrimenti il
        # Chrome o l'Edge GIA' presenti su Windows (nessun download necessario).
        browser = None
        ultimo_errore = None
        for canale in (None, "chrome", "msedge"):
            try:
                if canale is None:
                    browser = p.chromium.launch(headless=not mostra)
                else:
                    browser = p.chromium.launch(headless=not mostra, channel=canale)
                print(f"  Browser usato: {canale or 'chromium (Playwright)'}")
                break
            except Exception as e:
                ultimo_errore = e
        if browser is None:
            raise RuntimeError(f"Nessun browser disponibile: {ultimo_errore}")
        context = browser.new_context()
        # Salta la schermata dei termini (accettazione gia' fatta).
        context.add_init_script(
            "window.localStorage.setItem('digitalvault_terms_accepted','true');")
        page = context.new_page()
        page.set_default_timeout(10000)
        page.on("pageerror", lambda e: errori_console.append(f"JS: {e}"))
        page.on("console", lambda m: errori_console.append(m.text) if m.type == "error" else None)
        # Conferma automaticamente eventuali finestre di dialogo (confirm/alert):
        # senza questo Playwright le ANNULLA e il salvataggio verrebbe interrotto.
        page.on("dialog", lambda d: d.accept())
        # Diagnostica: registra le chiamate API non riuscite (per capire i guasti).
        api_ko = []
        def _resp(r):
            try:
                if "/api/" in r.url and r.status >= 400:
                    api_ko.append(f"{r.status} {r.request.method} {r.url.split(BASE)[-1]}")
            except Exception:
                pass
        page.on("response", _resp)

        # ── 1) DASHBOARD ─────────────────────────────────────────────────────
        try:
            page.goto(BASE, wait_until="networkidle", timeout=15000)
            page.wait_for_selector("#stat-clienti", timeout=8000)
            page.wait_for_function(
                "document.querySelectorAll('.nav-item').length > 3", timeout=8000)
            esito.ok("1. La dashboard si apre e mostra le statistiche")
        except Exception as e:
            esito.ko("1. La dashboard si apre", str(e)[:140])
            browser.close()
            return esito, errori_console

        clienti_iniziali = page.eval_on_selector(
            "#stat-clienti", "el => parseInt(el.innerText) || 0")

        # ── 2) NAVIGAZIONE TRA LE PAGINE ─────────────────────────────────────
        try:
            for pag in ("clients", "archive", "scadenze", "legal", "dashboard"):
                page.evaluate(f"showPage('{pag}')")
                page.wait_for_timeout(250)
            esito.ok("2. Navigazione tra tutte le pagine senza blocchi")
        except Exception as e:
            esito.ko("2. Navigazione tra le pagine", str(e)[:140])

        # ── 3) CREA UN CLIENTE ───────────────────────────────────────────────
        cognome = f"CollaudoE2E{int(time.time())}"
        try:
            page.evaluate("showPage('clients')")
            page.wait_for_timeout(300)
            page.evaluate("openClientModal()")
            page.wait_for_selector("#c-nome", state="visible", timeout=5000)
            page.fill("#c-nome", "Mario")
            page.fill("#c-cognome", cognome)
            page.fill("#c-email", "mario.collaudo@example.it")
            # dispatch_event invia il click direttamente al pulsante: fa scattare
            # il vero gestore (onsubmit -> saveClient) scavalcando eventuali
            # sovrapposizioni (overlay/modal) che intercetterebbero un click reale.
            page.locator("#client-modal button[type=submit]").dispatch_event("click")
            # il modal si chiude e l'elenco si aggiorna col nuovo cliente
            page.wait_for_function(
                "c => { const t = document.querySelector('#clients-tbody');"
                " return t && t.innerText.includes(c); }",
                arg=cognome, timeout=8000)
            esito.ok("3. Creazione cliente dal modulo e comparsa in elenco")
        except Exception as e:
            esito.ko("3. Creazione cliente", str(e)[:140])

        # contatore dashboard aggiornato
        try:
            page.evaluate("showPage('dashboard')")
            page.wait_for_function(
                "n => (parseInt(document.querySelector('#stat-clienti').innerText)||0) > n",
                arg=clienti_iniziali, timeout=6000)
            esito.ok("3b. Il contatore clienti in dashboard si aggiorna")
        except Exception as e:
            esito.ko("3b. Contatore clienti aggiornato", str(e)[:140])

        # ── 4) GENERA UNA BOZZA DI DOCUMENTO LEGALE ──────────────────────────
        try:
            # difensivo: assicura che nessun modal resti aperto a coprire la pagina
            page.evaluate(
                "() => document.querySelectorAll('.modal-overlay.open')"
                ".forEach(m => m.classList.remove('open'))")
            page.evaluate("showPage('legal')")
            page.wait_for_function(
                "document.querySelector('#legal-tipo') &&"
                " document.querySelector('#legal-tipo').options.length > 1", timeout=8000)
            # scegli il primo tipo reale -> genera i campi dell'intervista
            page.evaluate(
                "() => { const s=document.querySelector('#legal-tipo');"
                " s.selectedIndex=1; s.dispatchEvent(new Event('change')); }")
            page.wait_for_selector("#legal-campi input, #legal-campi textarea", timeout=6000)
            page.evaluate(
                "() => { document.querySelectorAll('#legal-campi input, #legal-campi textarea')"
                ".forEach(el => { el.value='Mario Rossi - C.F. RSSMRA80A01H501U - Via Roma 1, Milano';"
                " el.dispatchEvent(new Event('input',{bubbles:true})); }); }")
            page.locator("button:has-text('Genera bozza')").dispatch_event("click")
            page.wait_for_function(
                "() => { const r=document.querySelector('#legal-risultato');"
                " return r && r.innerText.length > 150; }", timeout=10000)
            esito.ok("4. Generazione bozza documento legale (deterministica)")
        except Exception as e:
            esito.ko("4. Generazione documento legale", str(e)[:140])

        # ── 5) NESSUN ERRORE IN CONSOLE ──────────────────────────────────────
        # L'app e' LOCAL-FIRST: font e icone sono bundlati in /static, nessun CDN
        # esterno. Percio' un errore di rete (404 su /static, net::err, ecc.) NON
        # va piu' ignorato: significherebbe una risorsa non bundlata, cioe' una
        # regressione che romperebbe l'interfaccia OFFLINE. Contano tutti gli errori.
        veri = list(errori_console)
        if veri:
            esito.ko("5. Nessun errore JavaScript in console",
                     f"{len(veri)} errori: {veri[:2]}")
        else:
            esito.ok("5. Nessun errore JavaScript durante tutto il giro")

        if api_ko:
            print("  [diagnostica] chiamate API non riuscite:")
            for x in api_ko[:10]:
                print(f"      {x}")
        browser.close()
    return esito, errori_console


def main():
    ap = argparse.ArgumentParser(description="Test E2E col browser di DigitalValut")
    ap.add_argument("--mostra", action="store_true", help="mostra il browser (default: invisibile)")
    args = ap.parse_args()

    print("=" * 64)
    print("  DIGITALVALUT - TEST E2E (browser vero)")
    print("  Database temporaneo: l'archivio reale NON viene toccato.")
    print("=" * 64)

    _isola_db()   # isola il DB PRIMA che l'app venga importata dal server

    # Verifica che Chromium sia installato
    try:
        from playwright.sync_api import sync_playwright  # noqa
    except Exception:
        print("  [ERRORE] Playwright non installato.")
        print("  Esegui una volta:  python -m pip install playwright && python -m playwright install chromium")
        _pulisci()
        sys.exit(2)

    config_uv = uvicorn.Config("app:app", host="127.0.0.1", port=PORTA,
                               log_level="error", access_log=False)
    server = uvicorn.Server(config_uv)
    t = threading.Thread(target=server.run, daemon=True)
    t.start()

    if not _attendi_server():
        print("  [ERRORE] Il programma non si e' avviato. Test annullato.")
        server.should_exit = True
        _pulisci()
        sys.exit(1)
    print("  Server di prova pronto. Apro il browser e clicco...\n")

    try:
        esito, _ = esegui(mostra=args.mostra)
    except Exception as e:
        print(f"\n  [ERRORE] Il test E2E si e' interrotto: {e}")
        server.should_exit = True
        _pulisci()
        sys.exit(1)

    server.should_exit = True
    time.sleep(0.3)
    _pulisci()

    tot = len(esito.passi)
    print()
    print("=" * 64)
    print(f"  RISULTATO E2E: {esito.passati()}/{tot} controlli superati")
    print("=" * 64)
    if esito.falliti():
        for _, nome, perche in esito.falliti():
            print(f"   - {nome}: {perche}")
        print("  ESITO: BOCCIATO")
        sys.exit(1)
    print("  ESITO: PROMOSSO - l'app funziona davvero cliccando come un utente.")
    sys.exit(0)


if __name__ == "__main__":
    main()
