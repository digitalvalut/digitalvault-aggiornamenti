"""
Invio email via SMTP per DigitalValut.
Il commercialista configura una volta il suo account (Gmail/Outlook/altro).
"""
import smtplib
import ssl
from email.message import EmailMessage

# Preset comuni: il commercialista sceglie il provider e basta
SMTP_PRESETS = {
    "gmail": {"host": "smtp.gmail.com", "port": 587, "tls": True},
    "outlook": {"host": "smtp.office365.com", "port": 587, "tls": True},
    "libero": {"host": "smtp.libero.it", "port": 587, "tls": True},
    "aruba": {"host": "smtps.aruba.it", "port": 465, "tls": False, "ssl": True},
    "pec_aruba": {"host": "smtps.pec.aruba.it", "port": 465, "tls": False, "ssl": True},
}


def invia_email(config: dict, destinatario: str, oggetto: str, corpo: str,
                allegato_bytes: bytes = None, allegato_nome: str = None) -> dict:
    """
    config: {provider|host, port, tls/ssl, email, password, nome_mittente}
    Ritorna {ok: bool, errore: str|None}
    """
    try:
        provider = config.get("provider")
        if provider and provider in SMTP_PRESETS:
            preset = SMTP_PRESETS[provider]
            host = preset["host"]
            port = preset["port"]
            use_tls = preset.get("tls", True)
            use_ssl = preset.get("ssl", False)
        else:
            host = config.get("host")
            port = int(config.get("port", 587))
            use_tls = config.get("tls", True)
            use_ssl = config.get("ssl", False)

        mittente = config.get("email")
        password = config.get("password")
        nome_mittente = config.get("nome_mittente") or mittente

        if not (host and mittente and password):
            return {"ok": False, "errore": "Configurazione email incompleta"}

        msg = EmailMessage()
        msg["Subject"] = oggetto
        msg["From"] = f"{nome_mittente} <{mittente}>"
        msg["To"] = destinatario
        msg.set_content(corpo)

        if allegato_bytes and allegato_nome:
            msg.add_attachment(
                allegato_bytes, maintype="application", subtype="pdf",
                filename=allegato_nome,
            )

        context = ssl.create_default_context()
        if use_ssl:
            with smtplib.SMTP_SSL(host, port, context=context, timeout=30) as server:
                server.login(mittente, password)
                server.send_message(msg)
        else:
            with smtplib.SMTP(host, port, timeout=30) as server:
                if use_tls:
                    server.starttls(context=context)
                server.login(mittente, password)
                server.send_message(msg)

        return {"ok": True, "errore": None}
    except smtplib.SMTPAuthenticationError:
        return {"ok": False, "errore": "Email o password errati. Per Gmail/Outlook serve una 'password per le app'."}
    except Exception as e:
        return {"ok": False, "errore": str(e)}


def test_connessione(config: dict) -> dict:
    """Verifica che le credenziali email funzionino, senza inviare nulla."""
    try:
        provider = config.get("provider")
        if provider and provider in SMTP_PRESETS:
            preset = SMTP_PRESETS[provider]
            host, port = preset["host"], preset["port"]
            use_tls, use_ssl = preset.get("tls", True), preset.get("ssl", False)
        else:
            host = config.get("host")
            port = int(config.get("port", 587))
            use_tls = config.get("tls", True)
            use_ssl = config.get("ssl", False)

        context = ssl.create_default_context()
        if use_ssl:
            with smtplib.SMTP_SSL(host, port, context=context, timeout=20) as server:
                server.login(config.get("email"), config.get("password"))
        else:
            with smtplib.SMTP(host, port, timeout=20) as server:
                if use_tls:
                    server.starttls(context=context)
                server.login(config.get("email"), config.get("password"))
        return {"ok": True, "errore": None}
    except smtplib.SMTPAuthenticationError:
        return {"ok": False, "errore": "Email o password errati. Per Gmail/Outlook serve una 'password per le app'."}
    except Exception as e:
        return {"ok": False, "errore": str(e)}
