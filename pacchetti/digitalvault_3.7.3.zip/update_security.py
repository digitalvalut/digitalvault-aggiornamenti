"""
DigitalValut - Sicurezza degli aggiornamenti (Tier 2.2).
(c) 2026 DigitalValut - Capo Team del Progetto: Dr. Falsone Giuseppe

Verifica la FIRMA Ed25519 dei pacchetti di aggiornamento e li estrae in modo
sicuro (protezione Zip-Slip / path traversal).

- La firma è prodotta SOLO sul master con la chiave privata
  (SOLO PROPRIETARIO/firma_aggiornamento.py). Qui, lato cliente, si verifica
  con la chiave PUBBLICA già a bordo (la stessa delle licenze).
- Un pacchetto non firmato o manomesso viene RIFIUTATO prima di toccare i file.
"""
import base64
import os
import zipfile
from pathlib import Path

try:
    from cryptography.hazmat.primitives.serialization import load_pem_public_key
except Exception:  # cryptography assente: in tal caso non si può verificare
    load_pem_public_key = None

PUBLIC_KEY_FILE = Path(__file__).parent / "chiave_pubblica.pem"


def public_key_presente() -> bool:
    return PUBLIC_KEY_FILE.exists() and load_pem_public_key is not None


def verifica_firma(data: bytes, firma_b64: str) -> bool:
    """True solo se `firma_b64` è una firma Ed25519 valida di `data` secondo la
    chiave pubblica a bordo. Nessuna eccezione propagata: in caso di dubbio, False."""
    if not public_key_presente() or not firma_b64:
        return False
    try:
        pub = load_pem_public_key(PUBLIC_KEY_FILE.read_bytes())
        pub.verify(base64.b64decode(firma_b64), data)
        return True
    except Exception:
        return False


def estrai_sicuro(zip_path, dest_dir) -> None:
    """Estrae uno zip rifiutando i membri che uscirebbero dalla cartella di
    destinazione (Zip-Slip / path traversal). Solleva ValueError se ne trova uno."""
    dest = Path(dest_dir).resolve()
    with zipfile.ZipFile(zip_path, "r") as z:
        for info in z.infolist():
            target = (dest / info.filename).resolve()
            if not (str(target) == str(dest) or str(target).startswith(str(dest) + os.sep)):
                raise ValueError(f"Percorso non sicuro nel pacchetto (Zip-Slip): {info.filename}")
        z.extractall(dest)
