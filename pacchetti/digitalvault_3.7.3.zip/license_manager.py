"""
DigitalValut - Sistema di licenza proprietaria con VERSIONI (Base/Media/Superior)
(c) 2026 DigitalValut - Capo Team del Progetto: Dr. Falsone Giuseppe

PROTEZIONE A "TIMBRO" (firma asimmetrica Ed25519):
  - Il TITOLARE possiede la chiave PRIVATA (il timbro), che vive SOLO nel
    master, nella cartella "SOLO PROPRIETARIO\\chiavi". Con essa, e SOLO con
    essa, si possono fabbricare le licenze.
  - Ogni copia consegnata al cliente contiene SOLTANTO la chiave PUBBLICA
    (MOTORE\\chiave_pubblica.pem): serve a VERIFICARE che una licenza sia
    autentica, ma NON puo' fabbricarne. Anche leggendola, il cliente non ci
    fa nulla.
  => Il segreto non lascia MAI il master. Copiare i file del cliente non
     rivela alcun segreto.

VINCOLO ALL'SSD (anti-clonazione):
  Ogni chiave e' legata al numero di serie del disco/SSD su cui gira il
  programma. Lo STESSO SSD funziona su QUALSIASI PC: il prodotto e' portatile,
  lo si infila dove serve. Clonare o copiare l'SSD produce un serial diverso
  -> la chiave non vale piu' e ne serve una nuova (che solo il titolare puo'
  generare). [Se il serial non e' rilevabile, fallback su host+MAC.]

VERSIONI NELL'ABBONAMENTO (la lettera fa parte della firma, non si falsifica):
     DGV-B-...   -> BASE
     DGV-M-...   -> MEDIA
     DGV-S-...   -> SUPERIOR
"""
import hashlib
import platform
import subprocess
import uuid
import json
import base64
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives import serialization
from cryptography.exceptions import InvalidSignature

TIER_LETTERS = {"B": "BASE", "M": "MEDIA", "S": "SUPERIOR"}
LETTER_OF_TIER = {v: k for k, v in TIER_LETTERS.items()}

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
LICENSE_FILE = DATA_DIR / "licenza.dat"
PUBLIC_KEY_FILE = BASE_DIR / "chiave_pubblica.pem"

# Etichetta di versione del formato firmato (cambiarla invalida le vecchie chiavi).
_PAYLOAD_TAG = "DGVLIC1"
# Sentinella per le chiavi "universali" del titolare (valgono su QUALSIASI PC).
_UNIVERSAL = "UNIVERSAL"


# ── Impronta del computer ─────────────────────────────────────────────────────

def get_volume_id() -> str:
    """Numero di serie del disco/SSD su cui gira il programma.
    E' la protezione anti-clonazione: un SSD copiato ha un serial diverso."""
    here = Path(__file__).resolve()
    try:
        if platform.system() == "Windows":
            import ctypes
            drive = (here.drive or "C:") + "\\"
            serial = ctypes.c_uint(0)
            ok = ctypes.windll.kernel32.GetVolumeInformationW(
                ctypes.c_wchar_p(drive), None, 0,
                ctypes.byref(serial), None, None, None, 0)
            if ok and serial.value:
                return f"{serial.value:08X}"
        elif platform.system() == "Darwin":
            mount = str(here)
            if mount.startswith("/Volumes/"):
                vol = "/Volumes/" + mount.split("/")[2]
            else:
                vol = "/"
            out = subprocess.run(["diskutil", "info", vol], capture_output=True,
                                 text=True, timeout=10).stdout
            for line in out.splitlines():
                if "Volume UUID" in line:
                    return line.split(":")[-1].strip()
    except Exception:
        pass
    return "NOVOLUME"   # se non rilevabile, resta la protezione host+MAC


def get_machine_id() -> str:
    """Impronta legata all'SSD: lo STESSO SSD = stessa licenza su QUALSIASI PC
    (il programma è portatile, lo infili dove vuoi). Anti-clonazione: un SSD
    copiato/clonato ha un serial diverso → ID diverso → serve una nuova chiave.
    Se il serial dell'SSD non è rilevabile (alcune chiavette), si ricade
    sull'impronta del computer per non lasciare l'ID indistinto fra macchine."""
    vol = get_volume_id()
    if vol and vol != "NOVOLUME":
        raw = f"DGV-SSD|{vol}"
    else:
        node = platform.node() or "unknown"
        raw = f"{node}|{uuid.getnode()}|{platform.system()}|{vol}"
    return hashlib.sha256(raw.encode()).hexdigest()[:24].upper()


# ── Verifica della firma (lato cliente: solo chiave PUBBLICA) ─────────────────

def _load_public_key():
    """Carica la chiave pubblica spedita col programma. None se assente."""
    try:
        return serialization.load_pem_public_key(PUBLIC_KEY_FILE.read_bytes())
    except Exception:
        return None


def _payload(tier: str, machine_id: str) -> bytes:
    return f"{_PAYLOAD_TAG}|{tier}|{machine_id}".encode()


def _b32encode(raw: bytes) -> str:
    return base64.b32encode(raw).decode().rstrip("=")


def _b32decode(txt: str) -> bytes:
    pad = "=" * ((8 - len(txt) % 8) % 8)
    return base64.b32decode(txt.upper() + pad)


def tier_of_key(key: str, machine_id: str = None) -> str:
    """Se la chiave e' autentica per QUESTO computer (o universale del titolare),
    ritorna la versione ('BASE'/'MEDIA'/'SUPERIOR'). Altrimenti None."""
    key = (key or "").strip().upper()
    if not key:
        return None
    pub = _load_public_key()
    if pub is None:
        return None

    parts = key.split("-")
    # Formati ammessi:
    #   DGV-<L>-<FIRMA>        -> legata a questo computer
    #   DGV-<L>-U-<FIRMA>      -> universale (titolare), vale ovunque
    if len(parts) < 3 or parts[0] != "DGV" or parts[1] not in TIER_LETTERS:
        return None
    tier = TIER_LETTERS[parts[1]]
    universal = (len(parts) == 4 and parts[2] == "U")
    if not (len(parts) == 3 or universal):
        return None

    sig_txt = parts[3] if universal else parts[2]
    try:
        sig = _b32decode(sig_txt)
    except Exception:
        return None

    bound = _UNIVERSAL if universal else (machine_id or get_machine_id())
    try:
        pub.verify(sig, _payload(tier, bound))
        return tier
    except InvalidSignature:
        return None
    except Exception:
        return None


def verify_key(key: str, machine_id: str = None) -> bool:
    """Verifica se una chiave e' valida per questo computer."""
    return tier_of_key(key, machine_id) is not None


# ── Stato attivazione (interfaccia invariata per app.py) ──────────────────────

def is_activated() -> bool:
    """True se il software e' gia' stato attivato su QUESTO SSD.
    La chiave viene riverificata contro l'impronta ATTUALE: copiare il file
    di licenza (o clonare l'SSD) altrove non basta per attivarlo."""
    if not LICENSE_FILE.exists():
        return False
    try:
        data = json.loads(LICENSE_FILE.read_text(encoding="utf-8"))
        return verify_key(data.get("key", ""))
    except Exception:
        return False


def get_tier() -> str:
    """Versione attiva su questo computer (BASE se non determinabile)."""
    if not LICENSE_FILE.exists():
        return "BASE"
    try:
        data = json.loads(LICENSE_FILE.read_text(encoding="utf-8"))
        tier = tier_of_key(data.get("key", ""))
        return tier or "BASE"
    except Exception:
        return "BASE"


def activate(key: str) -> bool:
    """Attiva il software con una chiave. Salva l'attivazione se valida."""
    mid = get_machine_id()
    tier = tier_of_key(key, mid)
    if tier:
        DATA_DIR.mkdir(exist_ok=True)
        LICENSE_FILE.write_text(
            json.dumps({"key": key.strip().upper(), "machine_id": mid, "tier": tier}),
            encoding="utf-8",
        )
        return True
    return False


def license_status() -> dict:
    from config import TIERS, DEFAULT_TIER
    activated = is_activated()
    tier = get_tier() if activated else DEFAULT_TIER
    info = TIERS.get(tier, TIERS[DEFAULT_TIER])
    return {
        "activated": activated,
        "machine_id": get_machine_id(),
        "volume_id": get_volume_id(),
        "tier": tier if activated else None,
        "versione": info["nome"] if activated else None,
        "titolare": "DigitalValut",
        "capo_staff": "Capo Team del Progetto: Dr. Falsone Giuseppe",
    }


if __name__ == "__main__":
    # Eseguito sul computer del CLIENTE mostra solo l'ID da comunicare al titolare.
    # La generazione delle chiavi NON e' qui: vive in "SOLO PROPRIETARIO\\genera_licenza.py"
    # insieme alla chiave privata, e resta solo nel master.
    print("=" * 60)
    print("  DIGITALVALUT - Attivazione licenza")
    print("=" * 60)
    print(f"\n  ID di questo SSD (da comunicare al titolare):\n")
    print(f"      {get_machine_id()}\n")
    print(f"  (serial SSD rilevato: {get_volume_id()} - la licenza vale su qualsiasi PC con questo SSD)")
    print(f"  Software attivato: {'SI' if is_activated() else 'NO'}")
    if is_activated():
        print(f"  Versione attiva: {get_tier()}")
    print("=" * 60)
