"""
DigitalValut - STRESS TEST DI CARICO (resistenza sotto traffico reale).
(c) 2026 DigitalValut Team - Dr. Falsone Giuseppe

A COSA SERVE
------------
`test_stress.py` verifica che i CALCOLI non si rompano mai (logica).
QUESTO file verifica un'altra cosa: che il PROGRAMMA, mentre molti
collaboratori lo usano CONTEMPORANEAMENTE (rete studio), non si pianti,
non rallenti oltre il tollerabile e non restituisca mai un errore di server.

E' la stessa idea dei test di carico che fanno le grandi software house
(stile "Locust"): tanti utenti finti che martellano l'app tutti insieme.

COSA FA (in sicurezza)
----------------------
  - Avvia il programma su una porta di prova (127.0.0.1), in locale.
  - Spara MIGLIAIA di richieste in parallelo, scegliendo a caso tra le
    pagine "a lettura" e i CALCOLI deterministici (IRPEF, forfettario,
    documenti legali): operazioni SENZA costi AI e SENZA modificare i dati.
  - NON chiama mai l'AI (niente token spesi), NON scrive clienti/documenti,
    NON tocca la rete esterna.
  - Misura: richieste/secondo, tempi di risposta (p50/p95/p99), errori.

ESITO
-----
  PROMOSSO se: 0 errori di server (5xx), >=99% richieste OK, p95 sotto soglia.
  BOCCIATO   altrimenti (stampa il dettaglio del problema).

USO
---
  python stress_test_carico.py                 (20 utenti, 15 secondi)
  python stress_test_carico.py --utenti 50 --secondi 30
  python stress_test_carico.py --utenti 100 --secondi 60   (prova "tosta")
"""
import argparse
import asyncio
import random
import statistics
import sys
import threading
import time
import urllib.request

import httpx
import uvicorn

# ── Soglie di promozione (regolabili) ────────────────────────────────────────
SUCCESSO_MINIMO = 99.0      # % di richieste 2xx richiesta per PROMUOVERE
P95_MAX_MS = 1500.0         # 95% delle risposte deve stare sotto questo tempo
MAX_5XX = 0                 # nessun errore di server tollerato


def _attendi_server(porta: int, secondi: float = 25.0) -> bool:
    """Aspetta che /api/health risponda 'ok'."""
    scadenza = time.time() + secondi
    url = f"http://127.0.0.1:{porta}/api/health"
    while time.time() < scadenza:
        try:
            with urllib.request.urlopen(url, timeout=1) as r:
                if b"ok" in r.read():
                    return True
        except Exception:
            time.sleep(0.3)
    return False


def _scopri_tipo_legale(porta: int) -> str:
    """Prende un tipo di documento legale valido (per il mix di carico)."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{porta}/api/legal/tipi", timeout=3) as r:
            import json
            tipi = json.loads(r.read()).get("tipi", [])
            if tipi:
                t = tipi[0]
                if isinstance(t, dict):
                    return t.get("tipo") or t.get("id") or t.get("nome")
                return str(t)
    except Exception:
        pass
    return "locazione_abitativa"


def _parametri_validi(porta: int, tipo: str) -> dict:
    """Riempie TUTTI i campi richiesti dal documento con valori di prova, cosi'
    la generazione sotto carico arriva a buon fine (200) invece di essere
    correttamente respinta per dati mancanti (422)."""
    try:
        with urllib.request.urlopen(
                f"http://127.0.0.1:{porta}/api/legal/campi?tipo={tipo}", timeout=3) as r:
            import json
            campi = json.loads(r.read()).get("campi", [])
        par = {}
        for c in campi:
            chiave = c.get("chiave") if isinstance(c, dict) else str(c)
            if chiave:
                par[chiave] = "Mario Rossi - C.F. RSSMRA80A01H501U - Via Roma 1, Milano"
        return par
    except Exception:
        return {}


def costruisci_mix(tipo_legale: str, parametri_legali: dict):
    """Il 'mix' realistico di richieste: piu' letture, qualche calcolo.
    Ogni voce: (peso, metodo, percorso, corpo_json | None).
    SOLO operazioni sicure: lettura o calcolo deterministico, mai AI/scrittura."""
    return [
        # --- pagine e stati "a lettura" (le piu' frequenti) ---
        (10, "GET", "/api/health", None),
        (6,  "GET", "/api/clients", None),
        (6,  "GET", "/api/documents", None),
        (4,  "GET", "/api/scadenze", None),
        (4,  "GET", "/api/avvisi", None),
        (3,  "GET", "/api/license/status", None),
        (3,  "GET", "/api/classifica/stato", None),
        (3,  "GET", "/api/spazio/stato", None),
        (3,  "GET", "/api/backup/stato", None),
        (3,  "GET", "/api/settings/studio", None),
        (3,  "GET", "/api/onboarding/stato", None),
        (3,  "GET", "/api/legal/clienti", None),
        (2,  "GET", "/api/calcola/coefficienti", None),
        (2,  "GET", "/api/legal/tipi", None),
        (2,  "GET", f"/api/legal/campi?tipo={tipo_legale}", None),
        (2,  "GET", "/", None),                              # la home (HTML)
        # --- CALCOLI deterministici (motore fiscale, niente AI) ---
        (5,  "POST", "/api/calcola/irpef", {"reddito": 35000}),
        (4,  "POST", "/api/calcola/forfettario",
                     {"fatturato": 50000, "coefficiente": 0.78, "nuova_attivita": False}),
        (3,  "POST", "/api/calcola/imu",
                     {"categoria_catastale": "A/2", "rendita_catastale": 650.0,
                      "aliquota_per_mille": 8.6, "mesi_possesso": 12}),
        (2,  "POST", "/api/legal/genera",
                     {"tipo": tipo_legale, "parametri": parametri_legali}),
        (2,  "POST", "/api/valida/anagrafica",
                     {"codice_fiscale": "RSSMRA80A01H501U", "partita_iva": "12345670017"}),
    ]


def _espandi(mix, solo_letture=False):
    """Trasforma i pesi in una lista pescabile a caso.
    Con solo_letture=True tiene solo le GET (per isolare la contesa in scrittura)."""
    pool = []
    for peso, metodo, percorso, corpo in mix:
        if solo_letture and metodo != "GET":
            continue
        pool += [(metodo, percorso, corpo)] * peso
    return pool


async def _worker(client, base, pool, deadline, stats):
    """Un 'utente' finto: continua a fare richieste finche' scade il tempo."""
    while time.time() < deadline:
        metodo, percorso, corpo = random.choice(pool)
        t0 = time.perf_counter()
        try:
            if metodo == "GET":
                resp = await client.get(base + percorso)
            else:
                resp = await client.post(base + percorso, json=corpo)
            dt = (time.perf_counter() - t0) * 1000.0
            stats["lat"].append(dt)
            code = resp.status_code
            stats["per_endpoint"].setdefault(percorso, [0, 0, 0.0])
            ep = stats["per_endpoint"][percorso]
            ep[0] += 1
            ep[2] += dt
            if 200 <= code < 300:
                stats["ok"] += 1
            elif 500 <= code < 600:
                stats["err5"] += 1
                ep[1] += 1
                stats["dettaglio_5xx"].append((percorso, code))
            else:
                stats["err4"] += 1
                stats["dettaglio_4xx"].setdefault((percorso, code), 0)
                stats["dettaglio_4xx"][(percorso, code)] += 1
        except Exception as e:
            stats["eccezioni"] += 1
            stats["dettaglio_ecc"].setdefault(type(e).__name__, 0)
            stats["dettaglio_ecc"][type(e).__name__] += 1


async def _carica(porta, utenti, secondi, pool):
    base = f"http://127.0.0.1:{porta}"
    stats = {"ok": 0, "err4": 0, "err5": 0, "eccezioni": 0, "lat": [],
             "per_endpoint": {}, "dettaglio_5xx": [], "dettaglio_4xx": {},
             "dettaglio_ecc": {}}
    limits = httpx.Limits(max_connections=utenti * 2, max_keepalive_connections=utenti)
    deadline = time.time() + secondi
    t_inizio = time.perf_counter()
    async with httpx.AsyncClient(timeout=10.0, limits=limits) as client:
        await asyncio.gather(*[
            _worker(client, base, pool, deadline, stats) for _ in range(utenti)
        ])
    stats["durata"] = time.perf_counter() - t_inizio
    return stats


def _pct(valori, q):
    if not valori:
        return 0.0
    v = sorted(valori)
    i = min(len(v) - 1, int(round((q / 100.0) * (len(v) - 1))))
    return v[i]


def _stampa_report(stats, utenti, secondi):
    tot = stats["ok"] + stats["err4"] + stats["err5"] + stats["eccezioni"]
    lat = stats["lat"]
    durata = stats["durata"]
    rps = (tot / durata) if durata else 0.0
    # "gestite": il server ha risposto in modo controllato (anche un 4xx di
    # validazione e' il server che FUNZIONA, non che crasha). Crash veri = 5xx
    # o connessioni cadute (eccezioni).
    gestite = stats["ok"] + stats["err4"]
    tasso_gestite = (gestite / tot * 100.0) if tot else 0.0
    succ_app = (stats["ok"] / tot * 100.0) if tot else 0.0

    print()
    print("=" * 64)
    print("  RISULTATO STRESS TEST DI CARICO")
    print("=" * 64)
    print(f"  Utenti contemporanei : {utenti}")
    print(f"  Durata               : {durata:.1f} s")
    print(f"  Richieste totali     : {tot}")
    print(f"  Richieste/secondo    : {rps:.0f}")
    print(f"  Gestite senza crash  : {gestite}  ({tasso_gestite:.2f}%)")
    print(f"  Risposte OK (2xx)    : {stats['ok']}  ({succ_app:.2f}%)")
    print(f"  Errori client (4xx)  : {stats['err4']}  (input respinto = comportamento corretto)")
    print(f"  Errori SERVER (5xx)  : {stats['err5']}")
    print(f"  Eccezioni rete       : {stats['eccezioni']}")
    if lat:
        print("  --- Tempi di risposta (millisecondi) ---")
        print(f"    medio  : {statistics.mean(lat):.0f} ms")
        print(f"    p50    : {_pct(lat, 50):.0f} ms")
        print(f"    p95    : {_pct(lat, 95):.0f} ms")
        print(f"    p99    : {_pct(lat, 99):.0f} ms")
        print(f"    max    : {max(lat):.0f} ms")

    # endpoint piu' lenti (media)
    medie = []
    for ep, (n, n5, somma) in stats["per_endpoint"].items():
        if n:
            medie.append((somma / n, ep, n, n5))
    medie.sort(reverse=True)
    if medie:
        print("  --- Endpoint piu' lenti (media) ---")
        for media, ep, n, n5 in medie[:5]:
            tag = f"  [!] {n5} errori 5xx" if n5 else ""
            print(f"    {media:7.0f} ms  ({n:5d} chiam.)  {ep}{tag}")

    if stats["dettaglio_4xx"]:
        print("  --- Risposte 4xx (attese per alcuni input) ---")
        for (ep, code), n in sorted(stats["dettaglio_4xx"].items()):
            print(f"    {code}  x{n}  {ep}")
    if stats["dettaglio_5xx"]:
        print("  --- ERRORI DI SERVER 5xx (DA RISOLVERE) ---")
        visti = {}
        for ep, code in stats["dettaglio_5xx"]:
            visti.setdefault((ep, code), 0)
            visti[(ep, code)] += 1
        for (ep, code), n in sorted(visti.items()):
            print(f"    {code}  x{n}  {ep}")
    if stats["dettaglio_ecc"]:
        print("  --- Eccezioni di rete ---")
        for nome, n in sorted(stats["dettaglio_ecc"].items()):
            print(f"    {nome}  x{n}")

    # ── verdetto ──
    # Un load test promuove se il SERVER non si pianta: niente errori di server
    # (5xx), niente connessioni cadute, e tempi sotto soglia. I 4xx di
    # validazione NON sono un guasto (il server risponde correttamente).
    p95 = _pct(lat, 95) if lat else 0.0
    promosso = (
        stats["err5"] <= MAX_5XX
        and stats["eccezioni"] == 0
        and tasso_gestite >= SUCCESSO_MINIMO
        and p95 <= P95_MAX_MS
    )
    print("=" * 64)
    if promosso:
        print(f"  ESITO: PROMOSSO  -  l'app regge {utenti} utenti insieme senza piantarsi.")
    else:
        print("  ESITO: BOCCIATO  -  controlla i punti qui sopra:")
        if stats["err5"] > MAX_5XX:
            print(f"     - {stats['err5']} errori di server 5xx (max ammesso {MAX_5XX})")
        if stats["eccezioni"]:
            print(f"     - {stats['eccezioni']} richieste cadute (connessioni rifiutate/timeout)")
        if tasso_gestite < SUCCESSO_MINIMO:
            print(f"     - solo {tasso_gestite:.2f}% gestite senza crash (soglia {SUCCESSO_MINIMO}%)")
        if p95 > P95_MAX_MS:
            print(f"     - p95 {p95:.0f} ms sopra la soglia {P95_MAX_MS:.0f} ms")
    print("=" * 64)
    return promosso


def main():
    ap = argparse.ArgumentParser(description="Stress test di carico DigitalValut")
    ap.add_argument("--utenti", type=int, default=20, help="utenti contemporanei (default 20)")
    ap.add_argument("--secondi", type=int, default=15, help="durata in secondi (default 15)")
    ap.add_argument("--porta", type=int, default=8771, help="porta di prova (default 8771)")
    ap.add_argument("--solo-letture", action="store_true",
                    help="usa solo richieste in lettura (diagnostica: isola la contesa in scrittura)")
    args = ap.parse_args()

    print("=" * 64)
    print("  DIGITALVALUT - STRESS TEST DI CARICO")
    print(f"  Avvio del programma su porta di prova {args.porta} (solo locale)...")
    print("=" * 64)

    # Avvia il server in un thread separato (event loop proprio).
    config = uvicorn.Config("app:app", host="127.0.0.1", port=args.porta,
                            log_level="error", access_log=False)
    server = uvicorn.Server(config)
    t = threading.Thread(target=server.run, daemon=True)
    t.start()

    if not _attendi_server(args.porta):
        print("  [ERRORE] Il programma non si e' avviato in tempo. Test annullato.")
        server.should_exit = True
        sys.exit(1)
    print("  Server pronto. Inizio il carico...\n")

    tipo_legale = _scopri_tipo_legale(args.porta)
    parametri_legali = _parametri_validi(args.porta, tipo_legale)
    pool = _espandi(costruisci_mix(tipo_legale, parametri_legali),
                    solo_letture=args.solo_letture)
    if args.solo_letture:
        print("  Modalita' DIAGNOSTICA: solo richieste in lettura (GET).\n")

    try:
        stats = asyncio.run(_carica(args.porta, args.utenti, args.secondi, pool))
    finally:
        server.should_exit = True

    promosso = _stampa_report(stats, args.utenti, args.secondi)
    time.sleep(0.5)
    sys.exit(0 if promosso else 1)


if __name__ == "__main__":
    main()
