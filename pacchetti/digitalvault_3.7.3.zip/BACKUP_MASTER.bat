@echo off
setlocal enabledelayedexpansion
title DigitalValut - BACKUP MASTER
color 0A
cls
echo.
echo  ============================================================
echo   DIGITALVALUT - BACKUP MASTER SU PC
echo   Crea uno snapshot completo e versionato del master SSD
echo  ============================================================
echo.

REM --- Leggi versione da config.py ---
set VERSION=sconosciuta
for /f "tokens=2 delims== " %%A in ('findstr "APP_VERSION" "D:\MOTORE\config.py"') do set VERSION=%%~A
set VERSION=%VERSION:"=%

REM --- Cartella destinazione con data e versione ---
set TODAY=%DATE:~6,4%-%DATE:~3,2%-%DATE:~0,2%
set BACKUP_DEST=C:\BACKUP_MASTER\BACKUP_%TODAY%_v%VERSION%

echo  Data:     %TODAY%
echo  Versione: %VERSION%
echo  Salvo in: %BACKUP_DEST%
echo.

if exist "%BACKUP_DEST%\MOTORE\config.py" (
    echo  [!] Esiste gia' un backup per questa versione e questa data.
    set /p FORZA="  Sovrascrivere? (s/n): "
    if /i not "!FORZA!"=="s" (
        echo  Annullato. Nulla e' stato modificato.
        pause
        exit /b 0
    )
)

echo  Avvio copia... puo' richiedere qualche minuto.
echo.

mkdir "C:\BACKUP_MASTER" 2>nul
mkdir "%BACKUP_DEST%" 2>nul

robocopy "D:\." "%BACKUP_DEST%" /E /R:1 /W:1 /NP /NFL /NDL /XD "System Volume Information" "$RECYCLE.BIN" ".Spotlight-V100" ".fseventsd" ".claude"

if %errorlevel% GEQ 8 (
    echo.
    echo  [ERRORE] Copia non completata - codice %errorlevel%.
    echo  Verifica spazio su C: e che l'SSD non sia stato scollegato, poi riprova.
    pause
    exit /b 1
)

echo.
echo  ============================================================
echo   BACKUP COMPLETATO CORRETTAMENTE
echo   Cartella: %BACKUP_DEST%
echo  ============================================================
echo.
echo  In caso di perdita SSD: copia quella cartella su un nuovo
echo  SSD e il master e' identico a questo momento.
echo.
pause
