"""STRESS TEST PERMANENTE (deterministico, senza chiamate AI).
Verifica che lo sciame non si inceppi mai su valori limite, input AI spazzatura
e guasti dell'AI, e che il Revisore blocchi i risultati incoerenti.
Eseguibile in CI: nessun costo, nessuna rete."""
import asyncio
import ai_client
import sciame
from fiscal_engine import (irpef as _irpef, forfettario as _forf, iva as _iva,
                           dichiarativo_730 as _s730, cedolare as _ced, ravvedimento as _rav)


def _run(coro):
    return asyncio.run(coro)


def _fake(ret):
    async def _f(prompt, system=None):
        return ret
    return _f


def _boom():
    async def _f(prompt, system=None):
        raise RuntimeError("AI giù")
    return _f


# ── 1) MOTORI: valori limite, nessuna eccezione, invarianti ──────────────────

def test_irpef_boundaries():
    for r in (0, 28000, 28000.01, 50000, 50000.01, 1_000_000, -100):
        d = _irpef.calcola_irpef(r, anno=2026)
        somma = round(sum(s["imposta"] for s in d["dettaglio_scaglioni"]), 2)
        assert abs(somma - d["irpef_lorda"]) < 0.05
        assert d["irpef_lorda"] <= max(0, r) + 0.01


def test_forfettario_boundaries():
    for fatt, co in ((0, 0.78), (85000, 0.78), (100000.01, 0.4), (5_000_000, 0.67)):
        d = _forf.simula_forfettario(fatt, co, anno=2026)
        assert d["netto_in_tasca"] <= fatt + 0.01
        assert abs(d["reddito_forfettario"] - fatt * co) < 0.5


def test_iva_boundaries():
    for tot in (0, 1, 1220, 99.99, 10_000_000):
        d = _iva.scorpora_iva(tot, 22, anno=2026)
        assert abs(d["imponibile"] + d["iva"] - tot) < 0.02


def test_730_boundaries():
    for rit, detr in ((0, 0), (9000, 1910), (0, 999999)):
        d = _s730.esito_730(35000, ritenute=rit, detrazioni=detr, anno=2026)
        assert d["irpef_netta"] >= 0
        assert abs(d["importo"] - abs(d["saldo"])) < 0.02


def test_cedolare_ravvedimento_boundaries():
    assert _ced.calcola_cedolare(0, "ordinario", anno=2026)["imposta"] == 0.0
    r = _rav.calcola_ravvedimento(1000, 0, anno=2026)
    assert abs(r["totale_da_versare"] - (r["imposta"] + r["sanzione"] + r["interessi"])) < 0.02


# ── 2) SCIAME: input AI spazzatura → mai crash, str|None ─────────────────────

def _adv(fn, dicts):
    for a in dicts:
        ai_client.chat_json = _fake(a)
        out = _run(fn("x 1000"))
        assert out is None or isinstance(out, str)


def test_adversarial_forfettario():
    _adv(sciame.rispondi_forfettario,
         [{}, {"e_forfettario": True}, {"e_forfettario": True, "fatturato": "abc"},
          {"e_forfettario": True, "fatturato": -5, "settore": "x"},
          {"e_forfettario": True, "fatturato": 1e12, "settore": "inesistente"}])


def test_adversarial_iva_irpef_730():
    _adv(sciame.rispondi_iva, [{}, {"e_iva": True}, {"e_iva": True, "operazione": "x", "importo": 1}])
    _adv(sciame.rispondi_irpef, [{}, {"e_irpef": True}, {"e_irpef": True, "reddito": "x"}])
    _adv(sciame.rispondi_730, [{}, {"e_730": True}, {"e_730": True, "reddito": 1, "ritenute": "x"}])


def test_adversarial_cedolare_ravvedimento():
    _adv(sciame.rispondi_cedolare, [{}, {"e_cedolare": True}, {"e_cedolare": True, "canone": "x"}])
    _adv(sciame.rispondi_ravvedimento, [{}, {"e_ravvedimento": True}, {"e_ravvedimento": True, "imposta": 1}])


# ── 3) REVISORE: blocca i risultati incoerenti ───────────────────────────────

def test_revisore_blocca_coeff_assurdo():
    ai_client.chat_json = _fake({"e_forfettario": True, "fatturato": 50000, "coefficiente": 2.0})
    out = _run(sciame.rispondi_forfettario("x"))
    assert out and "non mostro" in out.lower()


# ── 4) GUASTO AI: degrada a None, nessun crash ───────────────────────────────

def test_guasto_ai_degrada():
    ai_client.chat_json = _boom()
    for fn in (sciame.rispondi_forfettario, sciame.rispondi_iva, sciame.rispondi_irpef,
               sciame.rispondi_730, sciame.rispondi_cedolare, sciame.rispondi_ravvedimento):
        assert _run(fn("forfettario iva irpef 730 cedolare ravvedimento 1000")) is None
