"""
FiscoSicuro - Spazio su disco: avviso "SSD quasi pieno" + archiviazione sicura.
(c) 2026 DigitalValut - Capo Team del Progetto: Dr. Falsone Giuseppe

Due funzioni che lavorano insieme:
  1) stato_spazio()/avviso_spazio(): controllano lo spazio libero sull'SSD e
     producono un avviso PRIMA che si riempia (così non si arriva mai al pieno,
     dove l'app non riesce più a salvare).
  2) archivia_vecchi(): sposta sul PC i FILE dei documenti più vecchi (verifica
     la copia, POI libera lo spazio sull'SSD), MANTENENDO nel database la scheda
     e il testo (la ricerca/AI continua a funzionare; cambia solo che il file
     originale ora è sul PC). Niente "azzera tutto": solo i vecchi, in sicurezza.
"""
import shutil
from datetime import datetime
from pathlib import Path

from config import BASE_DIR, UPLOAD_DIR

# Cartella sul PC dove finiscono i documenti archiviati (fuori dall'SSD)
ARCHIVIO_PC = Path.home() / "DigitalValut_Archivio"

# Soglie di allerta
_GB = 1024 ** 3
SOGLIA_CRITICA_GB = 0.3
SOGLIA_ATTENZIONE_GB = 1.5
SOGLIA_CRITICA_PCT = 3
SOGLIA_ATTENZIONE_PCT = 10


def stato_spazio(percorso=None) -> dict:
    """Spazio libero sull'unità dove gira il programma."""
    try:
        u = shutil.disk_usage(str(percorso or BASE_DIR))
        free_gb = u.free / _GB
        total_gb = u.total / _GB
        pct = (u.free / u.total * 100) if u.total else 0
        if free_gb <= SOGLIA_CRITICA_GB or pct <= SOGLIA_CRITICA_PCT:
            livello = "critico"
        elif free_gb <= SOGLIA_ATTENZIONE_GB or pct <= SOGLIA_ATTENZIONE_PCT:
            livello = "attenzione"
        else:
            livello = "ok"
        return {"ok": True, "livello": livello,
                "libero_gb": round(free_gb, 2), "totale_gb": round(total_gb, 1),
                "percento_libero": round(pct, 1)}
    except Exception as e:
        return {"ok": False, "errore": str(e), "livello": "ok"}


def avviso_spazio() -> dict | None:
    """Avviso (stessa forma di motore_proattivo) se lo spazio scarseggia, altrimenti None."""
    s = stato_spazio()
    if not s.get("ok") or s["livello"] == "ok":
        return None
    if s["livello"] == "critico":
        return {"gravita": "alta", "categoria": "spazio", "icona": "ri-hard-drive-2-line",
                "testo": f"SPAZIO SSD QUASI ESAURITO: liberi solo {s['libero_gb']} GB "
                         f"({s['percento_libero']}%). Archivia i documenti vecchi per non bloccare i salvataggi.",
                "azione": "Libera spazio", "vai": "settings"}
    return {"gravita": "media", "categoria": "spazio", "icona": "ri-hard-drive-line",
            "testo": f"Spazio SSD in calo: liberi {s['libero_gb']} GB ({s['percento_libero']}%). "
                     f"Valuta di archiviare i documenti vecchi.",
            "azione": "Libera spazio", "vai": "settings"}


def _anno_doc(d) -> int | None:
    if d.anno_riferimento:
        return d.anno_riferimento
    if getattr(d, "created_at", None):
        try:
            return d.created_at.year
        except Exception:
            return None
    return None


def archivia_vecchi(db, anni: int = 5) -> dict:
    """Sposta sul PC i file dei documenti più vecchi di `anni` e libera l'SSD.
    SICURO: copia → VERIFICA dimensione → solo allora cancella l'originale.
    Mantiene scheda+testo nel database (la ricerca continua a funzionare)."""
    from database import Document
    anno_soglia = datetime.now().year - max(0, int(anni))
    try:
        ARCHIVIO_PC.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return {"ok": False, "errore": f"Non riesco a creare la cartella archivio: {e}"}

    archiviati = 0
    liberati = 0
    errori = 0
    docs = db.query(Document).filter(Document.nome_file.isnot(None)).all()
    for d in docs:
        anno = _anno_doc(d)
        if not anno or anno > anno_soglia:
            continue                              # non abbastanza vecchio
        if d.note and "[ARCHIVIATO" in (d.note or ""):
            continue                              # già archiviato
        src = UPLOAD_DIR / d.nome_file
        if not src.exists():
            continue                              # file già assente
        try:
            size = src.stat().st_size
            sub = ARCHIVIO_PC / str(anno)
            sub.mkdir(parents=True, exist_ok=True)
            dst = sub / d.nome_file
            shutil.copy2(src, dst)
            # VERIFICA: copia integra PRIMA di cancellare l'originale
            if not dst.exists() or dst.stat().st_size != size:
                errori += 1
                continue
            src.unlink()                          # libera spazio sull'SSD
            nota = f"[ARCHIVIATO su PC: {dst} il {datetime.now():%Y-%m-%d}]"
            d.note = (d.note + " " + nota) if d.note else nota
            archiviati += 1
            liberati += size
        except Exception:
            errori += 1
    try:
        db.commit()
    except Exception as e:
        db.rollback()
        return {"ok": False, "errore": str(e)}
    return {"ok": True, "archiviati": archiviati,
            "spazio_liberato_mb": round(liberati / 1024 / 1024, 1),
            "errori": errori, "cartella": str(ARCHIVIO_PC), "anni_soglia": anni}
