"""
FiscoSicuro — SCIAME multi-agente per i calcoli fiscali (primo dominio: FORFETTARIO).
(c) 2026 DigitalValut - Capo Team del Progetto: Dr. Falsone Giuseppe

Filosofia (vedi RELAZIONE_TECNICA_E_HANDOVER.md, sez. "sciame"):
  CHIARIFICATORE (AI) -> MOTORE (deterministico) -> REVISORE (deterministico) -> COMUNICATORE
  - 1 SOLA chiamata AI nel caso normale (veloce ~2-3s, costo basso → regge €19,90).
  - L'AI capisce/estrae e CLASSIFICA l'attività; i NUMERI (coefficienti, aliquote,
    scadenze) vengono SOLO da fiscal_reference/forfettario.yaml, mai inventati.
  - Il REVISORE ricontrolla il risultato PRIMA di mostrarlo: se i conti non
    tornano, NON si mostra un numero sbagliato (si scala a verifica umana).
"""
from pathlib import Path
import yaml

import ai_client
from fiscal_engine import forfettario as _forf
from fiscal_engine import iva as _iva
from fiscal_engine import irpef as _irpef
from fiscal_engine import dichiarativo_730 as _s730
from fiscal_engine import cedolare as _ced
from fiscal_engine import ravvedimento as _rav
from fiscal_engine.common import DISCLAIMER, DataNotFreshError

_REFERENCE = Path(__file__).parent / "fiscal_reference" / "forfettario.yaml"


def _ref() -> dict:
    with open(_REFERENCE, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _settori(ref: dict) -> list:
    return [r["settore"] for r in (ref.get("coefficienti_redditivita") or [])]


def _coeff_da_settore(ref: dict, settore: str):
    """Cerca il coefficiente NORMATIVO per l'etichetta di settore (match esatto,
    poi tollerante). Ritorna float o None. Il numero viene SEMPRE dalla tabella."""
    if not settore:
        return None
    tab = ref.get("coefficienti_redditivita") or []
    s = settore.strip().lower()
    for r in tab:
        if r["settore"].strip().lower() == s:
            return float(r["coeff"])
    for r in tab:                       # match tollerante (contiene)
        if s and (s in r["settore"].lower() or r["settore"].lower() in s):
            return float(r["coeff"])
    return None


# ── 1) CHIARIFICATORE (unico passo con AI) ───────────────────────────────────

_CHIARIF_SYSTEM = ("Sei il Chiarificatore di FiscoSicuro. NON rispondi alla domanda e NON "
                   "calcoli nulla. Trasformi un messaggio (anche confuso) in dati strutturati. "
                   "Rispondi ESCLUSIVAMENTE con un oggetto JSON valido, senza testo attorno.")


def _chiarif_prompt(messaggio: str, settori: list) -> str:
    elenco = "\n".join(f'  - "{s}"' for s in settori)
    return f"""Capisci se il messaggio riguarda un calcolo di REGIME FORFETTARIO (imposta
sostitutiva / partita IVA forfettaria) ed estrai i dati.

NON inventare numeri di coefficienti, aliquote o imposte: tu CLASSIFICHI soltanto.
Per il coefficiente, scegli l'etichetta di settore ESATTA da questo elenco (oppure null):
{elenco}

Restituisci SOLO questo JSON:
{{
  "e_forfettario": true|false,
  "fatturato": <numero dei ricavi/incassi> | null,
  "settore": "<una etichetta ESATTA dall'elenco>" | null,
  "coefficiente": <numero 0-1 SOLO se l'utente lo dichiara esplicitamente> | null,
  "nuova_attivita": true|false|null,
  "anno": <anno se citato> | null,
  "domanda": "<UNA domanda breve in italiano se manca un dato indispensabile>" | null
}}

Regole:
- "40mila e rotti" -> fatturato ~ 40000. "85k" -> 85000.
- Se descrive il mestiere (es. idraulico, commerciante, avvocato), scegli il settore giusto dall'elenco.
- Se manca il fatturato OPPURE non riesci a capire il settore (e non c'è un coefficiente esplicito), metti una sola "domanda".
- Se il messaggio NON riguarda il forfettario: {{"e_forfettario": false, ...resto null}}.

MESSAGGIO:
{messaggio[:1500]}"""


async def chiarifica(messaggio: str) -> dict:
    """Unica chiamata AI. Ritorna il dict del Chiarificatore (o e_forfettario=False)."""
    ref = _ref()
    try:
        d = await ai_client.chat_json(_chiarif_prompt(messaggio, _settori(ref)),
                                      system=_CHIARIF_SYSTEM)
    except Exception:
        return {"e_forfettario": False}
    return d if isinstance(d, dict) else {"e_forfettario": False}


# ── 3) REVISORE (deterministico: nessuna AI) ─────────────────────────────────

def revisiona(fatturato: float, coeff: float, nuova: bool, dati: dict) -> dict:
    """Ricontrolla la coerenza interna del risultato del motore PRIMA di mostrarlo.
    Invarianti strutturali che devono valere SEMPRE; se uno salta, non mostriamo
    numeri sbagliati. Ritorna {ok, problemi:[...]}"""
    p = []
    g = lambda k: float(dati.get(k) or 0)
    redd, contr = g("reddito_forfettario"), g("contributi_inps")
    imposta, netto = g("imposta_sostitutiva"), g("netto_in_tasca")

    if abs(redd - fatturato * coeff) > 0.5:
        p.append("reddito imponibile diverso da fatturato × coefficiente")
    if redd > fatturato + 0.01:
        p.append("reddito imponibile maggiore del fatturato")
    if imposta < -0.01:
        p.append("imposta negativa")
    imponibile = max(0.0, redd - contr)
    if imposta > imponibile + 0.5:
        p.append("imposta maggiore dell'imponibile netto contributi")
    atteso = "5%" if nuova else "15%"
    if str(dati.get("aliquota_imposta")) != atteso:
        p.append(f"aliquota {dati.get('aliquota_imposta')} non coerente con nuova_attivita={nuova}")
    if abs(netto - (fatturato - contr - imposta)) > 0.5:
        p.append("netto in tasca non coerente con fatturato − contributi − imposta")
    if netto > fatturato + 0.01:
        p.append("netto maggiore del fatturato")
    return {"ok": not p, "problemi": p}


# ── 4) COMUNICATORE (deterministico) ─────────────────────────────────────────

def _eur(x) -> str:
    try:
        return f"{float(x):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    except Exception:
        return str(x)


def comunica(dati: dict, ipotesi: list, ref: dict) -> str:
    sc = ref.get("scadenze_versamento") or {}
    avvisi = "".join(f"\n⚠️ {w}" for w in (dati.get("warnings") or []))
    note = "".join(f"\n_ℹ️ {i}_" for i in ipotesi)
    return (
        "**Regime forfettario — calcolo verificato (motore deterministico + revisore)**\n"
        f"- Fatturato/ricavi: € {_eur(dati.get('fatturato'))}\n"
        f"- Reddito imponibile (× coefficiente {dati.get('coefficiente_redditivita')}): € {_eur(dati.get('reddito_forfettario'))}\n"
        f"- Contributi INPS (stima): € {_eur(dati.get('contributi_inps'))}\n"
        f"- Imposta sostitutiva ({dati.get('aliquota_imposta')}): € {_eur(dati.get('imposta_sostitutiva'))}\n"
        f"- Netto stimato in tasca: € {_eur(dati.get('netto_in_tasca'))}\n"
        "\n**Come l'ho calcolato:** reddito = ricavi × coefficiente di redditività; "
        "l'imposta sostitutiva si applica al reddito AL NETTO dei contributi previdenziali.\n"
        f"**Scadenze ordinarie:** saldo + 1° acconto entro il {sc.get('saldo_e_primo_acconto','30/06')}, "
        f"2° acconto entro il {sc.get('secondo_o_unico_acconto','30/11')}.\n"
        f"{note}{avvisi}\n\n_{DISCLAIMER}_"
    )


# ── ORCHESTRATORE ────────────────────────────────────────────────────────────

def _to_float(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


async def rispondi_forfettario(messaggio: str):
    """Sciame completo sul forfettario. Ritorna:
      - testo della risposta (numeri verificati) se è andato a buon fine,
      - testo con UNA domanda se mancano dati,
      - None se il messaggio NON è un calcolo forfettario (il chiamante prosegue)."""
    ref = _ref()
    c = await chiarifica(messaggio)
    if not c.get("e_forfettario"):
        return None

    fatturato = _to_float(c.get("fatturato"))
    if fatturato is None or fatturato <= 0:
        return (c.get("domanda")
                or "Per il forfettario mi serve il fatturato (ricavi incassati nell'anno): quanto è?")

    # Coefficiente: SOLO dalla tabella normativa (o esplicito dell'utente). Mai inventato.
    coeff = _to_float(c.get("coefficiente"))
    fonte_coeff = "indicato da te"
    if coeff is None:
        coeff = _coeff_da_settore(ref, c.get("settore"))
        fonte_coeff = f"settore «{c.get('settore')}»" if coeff is not None else None
    if coeff is None:
        return (c.get("domanda")
                or "Di che attività si tratta? (es. commercio, servizi/professionista, edilizia, "
                   "ristorazione…) Mi serve per il coefficiente di redditività corretto.")

    nuova = bool(c.get("nuova_attivita"))
    anno = int(c.get("anno") or ref.get("anno_imposta") or 2026)

    # MOTORE deterministico
    try:
        dati = _forf.simula_forfettario(fatturato, coeff, nuova, anno=anno)
    except DataNotFreshError as e:
        return f"Non posso calcolare per l'anno richiesto: {e}"
    except Exception as e:
        return f"Non riesco a completare il calcolo: {e}"

    # REVISORE: se i conti non tornano, NON mostro numeri sbagliati
    rev = revisiona(fatturato, coeff, nuova, dati)
    if not rev["ok"]:
        ai_client._log_interno(f"sciame forfettario: REVISORE ha bloccato — {rev['problemi']}")
        return ("Ho rilevato un'incoerenza interna nel calcolo e, per sicurezza, non mostro un "
                "numero che potrebbe essere errato. Riprova specificando meglio i dati o contatta "
                "l'assistenza.")

    # COMUNICATORE
    ipotesi = [f"Coefficiente di redditività: {fonte_coeff} ({coeff})."]
    if c.get("nuova_attivita") is None:
        ipotesi.append("Ho ipotizzato regime ORDINARIO (15%). Se sei nei primi 5 anni con i "
                       "requisiti startup, l'aliquota è 5%: dimmelo e ricalcolo.")
    return comunica(dati, ipotesi, ref)


# ═════════════════════════ DOMINIO: IVA ═════════════════════════════════════

def _ref_iva() -> dict:
    p = Path(__file__).parent / "fiscal_reference" / "iva.yaml"
    with open(p, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


_CHIARIF_IVA_PROMPT = """Capisci se il messaggio chiede un calcolo IVA ed estrai i dati.
NON inventare aliquote: estrai l'aliquota SOLO se l'utente la indica (es. "al 10%").

Operazioni possibili:
- "calcolo": dato l'IMPONIBILE (netto) si vuole l'IVA e il totale. Indizi: "IVA su", "imponibile", "netto".
- "scorporo": dato il TOTALE (lordo) si vogliono imponibile e IVA. Indizi: "scorpora", "quanta IVA c'è in", "da un totale", "lordo", "comprensivo".
- "liquidazione": IVA vendite − IVA acquisti del periodo. Indizi: "liquidazione", "a debito", "vendite ... acquisti".

Restituisci SOLO questo JSON:
{{
  "e_iva": true|false,
  "operazione": "calcolo"|"scorporo"|"liquidazione"|null,
  "importo": <imponibile per 'calcolo', totale per 'scorporo'> | null,
  "aliquota": <percentuale SOLO se indicata, es. 10> | null,
  "iva_vendite": <numero> | null,
  "iva_acquisti": <numero> | null,
  "domanda": "<UNA domanda breve se manca un dato indispensabile>" | null
}}
Se NON riguarda l'IVA: {{"e_iva": false, ...resto null}}.

MESSAGGIO:
{messaggio}"""


async def chiarifica_iva(messaggio: str) -> dict:
    try:
        d = await ai_client.chat_json(_CHIARIF_IVA_PROMPT.format(messaggio=(messaggio or "")[:1500]),
                                      system=_CHIARIF_SYSTEM)
    except Exception:
        return {"e_iva": False}
    return d if isinstance(d, dict) else {"e_iva": False}


def revisiona_iva(res: dict) -> dict:
    """Invarianti di coerenza IVA; se uno salta, non si mostrano numeri."""
    p = []
    g = lambda k: float(res.get(k) or 0)
    op = res.get("operazione")
    al = g("aliquota")
    if op == "calcolo":
        imp, ivav, tot = g("imponibile"), g("iva"), g("totale")
        if abs(ivav - imp * al / 100) > 0.02: p.append("IVA diversa da imponibile × aliquota")
        if abs(tot - (imp + ivav)) > 0.02: p.append("totale diverso da imponibile + IVA")
        if ivav < -0.01: p.append("IVA negativa")
    elif op == "scorporo":
        imp, ivav, tot = g("imponibile"), g("iva"), g("totale")
        if abs((imp + ivav) - tot) > 0.02: p.append("imponibile + IVA diverso dal totale")
        if imp > tot + 0.01: p.append("imponibile maggiore del totale")
        if ivav < -0.01: p.append("IVA negativa")
    elif op == "liquidazione":
        ven, acq, saldo, imp = g("iva_vendite"), g("iva_acquisti"), g("saldo"), g("importo")
        if abs(saldo - (ven - acq)) > 0.02: p.append("saldo diverso da vendite − acquisti")
        if abs(imp - abs(saldo)) > 0.02: p.append("importo diverso dal valore assoluto del saldo")
    else:
        p.append("operazione IVA non riconosciuta")
    return {"ok": not p, "problemi": p}


def comunica_iva(res: dict, ipotesi: list) -> str:
    op = res.get("operazione")
    note = "".join(f"\n_ℹ️ {i}_" for i in ipotesi)
    avvisi = "".join(f"\n⚠️ {w}" for w in (res.get("warnings") or []))
    testa = "**IVA — calcolo verificato (motore deterministico + revisore)**\n"
    if op == "calcolo":
        corpo = (f"- Imponibile (netto): € {_eur(res.get('imponibile'))}\n"
                 f"- IVA ({_eur(res.get('aliquota'))}%): € {_eur(res.get('iva'))}\n"
                 f"- Totale (lordo): € {_eur(res.get('totale'))}\n"
                 "\n**Come l'ho calcolato:** IVA = imponibile × aliquota; totale = imponibile + IVA.")
    elif op == "scorporo":
        corpo = (f"- Totale (lordo): € {_eur(res.get('totale'))}\n"
                 f"- Imponibile (netto): € {_eur(res.get('imponibile'))}\n"
                 f"- IVA ({_eur(res.get('aliquota'))}%): € {_eur(res.get('iva'))}\n"
                 "\n**Come l'ho calcolato (scorporo):** imponibile = totale ÷ (1 + aliquota); IVA = totale − imponibile.")
    else:  # liquidazione
        sc = res.get("scadenze") or {}
        corpo = (f"- IVA a debito (vendite): € {_eur(res.get('iva_vendite'))}\n"
                 f"- IVA a credito (acquisti): € {_eur(res.get('iva_acquisti'))}\n"
                 f"- Saldo: € {_eur(res.get('importo'))} — **{res.get('tipo')}**\n"
                 f"\n**Versamento:** mensile {sc.get('mensile','')}; trimestrale {sc.get('trimestrale','')}.")
    return testa + corpo + note + avvisi + f"\n\n_{DISCLAIMER}_"


async def rispondi_iva(messaggio: str):
    """Sciame IVA. Testo (verificato) | domanda se mancano dati | None se non è IVA."""
    ref = _ref_iva()
    c = await chiarifica_iva(messaggio)
    if not c.get("e_iva"):
        return None
    op = (c.get("operazione") or "").strip().lower()
    aliquota = _to_float(c.get("aliquota"))
    ipotesi = []
    if aliquota is None and op in ("calcolo", "scorporo"):
        ipotesi.append("Ho usato l'aliquota ORDINARIA 22%. Se è ridotta (10/5/4) dimmelo e ricalcolo.")

    try:
        if op == "liquidazione":
            ven, acq = _to_float(c.get("iva_vendite")), _to_float(c.get("iva_acquisti"))
            if ven is None or acq is None:
                return (c.get("domanda")
                        or "Per la liquidazione IVA mi servono l'IVA sulle vendite e l'IVA sugli acquisti del periodo.")
            res = _iva.liquidazione_iva(ven, acq, anno=ref.get("anno_imposta"))
        elif op in ("calcolo", "scorporo"):
            importo = _to_float(c.get("importo"))
            if importo is None or importo <= 0:
                return c.get("domanda") or "Su quale importo calcolo l'IVA?"
            res = (_iva.calcola_iva(importo, aliquota, anno=ref.get("anno_imposta")) if op == "calcolo"
                   else _iva.scorpora_iva(importo, aliquota, anno=ref.get("anno_imposta")))
        else:
            if _to_float(c.get("importo")) is not None:
                return ("Vuoi CALCOLARE l'IVA su un imponibile (netto) o SCORPORARLA da un totale (lordo)? "
                        "Dimmelo e procedo.")
            return c.get("domanda") or "Cosa vuoi fare con l'IVA: calcolo, scorporo o liquidazione?"
    except DataNotFreshError as e:
        return f"Non posso calcolare per l'anno richiesto: {e}"
    except Exception as e:
        return f"Non riesco a completare il calcolo IVA: {e}"

    rev = revisiona_iva(res)
    if not rev["ok"]:
        ai_client._log_interno(f"sciame IVA: REVISORE ha bloccato — {rev['problemi']}")
        return ("Ho rilevato un'incoerenza interna nel calcolo IVA e, per sicurezza, non mostro un "
                "numero che potrebbe essere errato.")
    return comunica_iva(res, ipotesi)


# ═════════════════════════ DOMINIO: IRPEF ═══════════════════════════════════

def _ref_irpef() -> dict:
    p = Path(__file__).parent / "fiscal_reference" / "irpef.yaml"
    with open(p, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


_CHIARIF_IRPEF_PROMPT = """Capisci se il messaggio chiede di calcolare l'IRPEF ed estrai il reddito.
Restituisci SOLO questo JSON:
{{
  "e_irpef": true|false,
  "reddito": <reddito imponibile in euro> | null,
  "anno": <anno se citato> | null,
  "domanda": "<UNA domanda breve se manca il reddito>" | null
}}
Note:
- "35 mila" -> 35000 ; "60k" -> 60000.
- Il numero è il REDDITO IMPONIBILE (su cui si calcola l'IRPEF).
- Se il messaggio NON riguarda l'IRPEF: {{"e_irpef": false, "reddito": null, "anno": null, "domanda": null}}.

MESSAGGIO:
{messaggio}"""


async def chiarifica_irpef(messaggio: str) -> dict:
    try:
        d = await ai_client.chat_json(_CHIARIF_IRPEF_PROMPT.format(messaggio=(messaggio or "")[:1500]),
                                      system=_CHIARIF_SYSTEM)
    except Exception:
        return {"e_irpef": False}
    return d if isinstance(d, dict) else {"e_irpef": False}


def revisiona_irpef(reddito: float, dati: dict) -> dict:
    """Invarianti IRPEF: la somma per scaglioni deve fare l'IRPEF lorda, ecc."""
    p = []
    lorda = float(dati.get("irpef_lorda") or 0)
    scagl = dati.get("dettaglio_scaglioni") or []
    somma = sum(float(s.get("imposta") or 0) for s in scagl)
    if abs(somma - lorda) > 0.05:
        p.append("somma degli scaglioni diversa dall'IRPEF lorda")
    if lorda < -0.01:
        p.append("IRPEF negativa")
    if lorda > reddito + 0.01:
        p.append("IRPEF maggiore del reddito")
    media = float(dati.get("aliquota_media") or 0)
    if reddito > 0 and abs(media - lorda / reddito * 100) > 0.1:
        p.append("aliquota media incoerente")
    if any(float(s.get("imposta") or 0) < -0.01 for s in scagl):
        p.append("imposta di scaglione negativa")
    return {"ok": not p, "problemi": p}


def comunica_irpef(dati: dict) -> str:
    righe = "\n".join(
        f"  · {s.get('scaglione')} ({s.get('aliquota')}): € {_eur(s.get('imposta'))}"
        for s in (dati.get("dettaglio_scaglioni") or []))
    return (
        "**IRPEF — calcolo verificato (motore deterministico + revisore)**\n"
        f"- Reddito imponibile: € {_eur(dati.get('reddito_imponibile'))}\n"
        f"- IRPEF LORDA: € {_eur(dati.get('irpef_lorda'))}\n"
        f"- Aliquota media: {dati.get('aliquota_media')}%\n"
        f"- Dettaglio per scaglioni:\n{righe}\n"
        "\n_ℹ️ È l'IRPEF LORDA: NON comprende le detrazioni (lavoro dipendente/autonomo, "
        "familiari a carico, spese) né le addizionali regionali e comunali. L'imposta netta "
        "effettiva sarà inferiore._\n\n"
        f"_{DISCLAIMER}_"
    )


async def rispondi_irpef(messaggio: str):
    """Sciame IRPEF. Testo (verificato) | domanda se manca il reddito | None se non è IRPEF."""
    ref = _ref_irpef()
    c = await chiarifica_irpef(messaggio)
    if not c.get("e_irpef"):
        return None
    reddito = _to_float(c.get("reddito"))
    if reddito is None or reddito < 0:
        return (c.get("domanda")
                or "Per calcolare l'IRPEF mi serve il reddito imponibile (€): quanto è?")
    anno = int(c.get("anno") or ref.get("anno_imposta") or 2026)
    try:
        dati = _irpef.calcola_irpef(reddito, anno=anno)
    except DataNotFreshError as e:
        return f"Non posso calcolare per l'anno richiesto: {e}"
    except Exception as e:
        return f"Non riesco a completare il calcolo IRPEF: {e}"

    rev = revisiona_irpef(reddito, dati)
    if not rev["ok"]:
        ai_client._log_interno(f"sciame IRPEF: REVISORE ha bloccato — {rev['problemi']}")
        return ("Ho rilevato un'incoerenza interna nel calcolo IRPEF e, per sicurezza, non mostro "
                "un numero che potrebbe essere errato.")
    return comunica_irpef(dati)


# ═════════════════════════ DOMINIO: 730 (esito) ═════════════════════════════

def _ref_730() -> dict:
    p = Path(__file__).parent / "fiscal_reference" / "dichiarativo_730.yaml"
    with open(p, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


_CHIARIF_730_PROMPT = """Capisci se il messaggio chiede l'ESITO di un Modello 730 (se il
contribuente avrà un RIMBORSO o un importo A DEBITO) ed estrai i dati.

Restituisci SOLO questo JSON:
{{
  "e_730": true|false,
  "reddito": <reddito imponibile in euro> | null,
  "ritenute": <IRPEF già trattenuta/subita nell'anno, dalla CU> | null,
  "detrazioni": <totale detrazioni d'imposta, se indicato> | null,
  "tipo_reddito": "lavoro_dipendente"|"pensione"|"autonomo"|null,
  "anno": <anno se citato> | null,
  "domanda": "<UNA domanda breve se manca un dato indispensabile>" | null
}}
Note:
- "35 mila" -> 35000 ; "9k di ritenute" -> 9000.
- Se dice "dipendente"/"in busta paga" -> tipo_reddito "lavoro_dipendente"; "pensionato" -> "pensione".
- Servono ALMENO reddito e ritenute per l'esito. Le detrazioni sono opzionali (se mancano, null).
- Se NON riguarda il 730/esito dichiarazione: {{"e_730": false, "reddito": null, "ritenute": null, "detrazioni": null, "anno": null, "domanda": null}}.

MESSAGGIO:
{messaggio}"""


async def chiarifica_730(messaggio: str) -> dict:
    try:
        d = await ai_client.chat_json(_CHIARIF_730_PROMPT.format(messaggio=(messaggio or "")[:1500]),
                                      system=_CHIARIF_SYSTEM)
    except Exception:
        return {"e_730": False}
    return d if isinstance(d, dict) else {"e_730": False}


def revisiona_730(dati: dict) -> dict:
    """Invarianti 730: netta = max(0, lorda−detrazioni) ; saldo = ritenute−netta ; ecc."""
    p = []
    g = lambda k: float(dati.get(k) or 0)
    lorda, detr, netta = g("irpef_lorda"), g("detrazioni"), g("irpef_netta")
    rit, saldo, imp = g("ritenute"), g("saldo"), g("importo")
    if abs(netta - max(0.0, lorda - detr)) > 0.02:
        p.append("IRPEF netta diversa da max(0, lorda − detrazioni)")
    if netta < -0.01:
        p.append("IRPEF netta negativa")
    if abs(saldo - (rit - netta)) > 0.02:
        p.append("saldo diverso da ritenute − IRPEF netta")
    if abs(imp - abs(saldo)) > 0.02:
        p.append("importo diverso dal valore assoluto del saldo")
    atteso = "rimborso" if saldo > 0 else "a debito"
    if dati.get("esito") != atteso:
        p.append("etichetta esito non coerente col segno del saldo")
    return {"ok": not p, "problemi": p}


def comunica_730(dati: dict) -> str:
    sc = dati.get("scadenze") or {}
    esito = dati.get("esito")
    riga_esito = (f"- **ESITO: RIMBORSO di € {_eur(dati.get('importo'))}**"
                  if esito == "rimborso"
                  else f"- **ESITO: A DEBITO di € {_eur(dati.get('importo'))}**")
    avvisi = "".join(f"\n⚠️ {w}" for w in (dati.get("warnings") or []))
    det_label = {"indicata": "(indicate)", "stimata": "(STIMATE — da verificare)",
                 "assente": "(non indicate)"}.get(dati.get("detrazione_fonte"), "")
    return (
        "**Modello 730 — esito verificato (motore deterministico + revisore)**\n"
        f"- Reddito imponibile: € {_eur(dati.get('reddito_imponibile'))}\n"
        f"- IRPEF lorda: € {_eur(dati.get('irpef_lorda'))}\n"
        f"- Detrazioni {det_label}: € {_eur(dati.get('detrazioni'))}\n"
        f"- IRPEF netta: € {_eur(dati.get('irpef_netta'))}\n"
        f"- Ritenute già subite (CU): € {_eur(dati.get('ritenute'))}\n"
        f"{riga_esito}\n"
        f"\n**Quando:** conguaglio tramite sostituto d'imposta (busta paga/pensione); "
        f"presentazione entro il {sc.get('presentazione','30/09')}."
        f"{avvisi}\n\n_{DISCLAIMER}_"
    )


async def rispondi_730(messaggio: str):
    """Sciame 730 (esito rimborso/debito). Testo | domanda | None se non è 730."""
    ref = _ref_730()
    c = await chiarifica_730(messaggio)
    if not c.get("e_730"):
        return None
    reddito = _to_float(c.get("reddito"))
    if reddito is None or reddito < 0:
        return (c.get("domanda")
                or "Per l'esito del 730 mi serve il reddito imponibile (€): quanto è?")
    ritenute = _to_float(c.get("ritenute"))
    if ritenute is None:
        return (c.get("domanda")
                or "Per dirti se è rimborso o a debito mi servono le ritenute IRPEF già subite "
                   "(le trovi nella Certificazione Unica): quanto?")
    detrazioni = _to_float(c.get("detrazioni"))   # None se non fornite → eventuale stima
    tipo = (c.get("tipo_reddito") or None)
    anno = int(c.get("anno") or ref.get("anno_imposta") or 2026)
    try:
        dati = _s730.esito_730(reddito, ritenute, detrazioni=detrazioni, tipo_reddito=tipo, anno=anno)
    except DataNotFreshError as e:
        return f"Non posso calcolare per l'anno richiesto: {e}"
    except Exception as e:
        return f"Non riesco a completare il calcolo del 730: {e}"

    rev = revisiona_730(dati)
    if not rev["ok"]:
        ai_client._log_interno(f"sciame 730: REVISORE ha bloccato — {rev['problemi']}")
        return ("Ho rilevato un'incoerenza interna nel calcolo del 730 e, per sicurezza, non mostro "
                "un numero che potrebbe essere errato.")
    return comunica_730(dati)


# ═════════════════════════ DOMINIO: CEDOLARE SECCA ══════════════════════════

_CHIARIF_CED_PROMPT = """Capisci se il messaggio chiede la CEDOLARE SECCA su una locazione ed estrai i dati.
Restituisci SOLO questo JSON:
{{
  "e_cedolare": true|false,
  "canone": <canone ANNUO in euro> | null,
  "tipo": "ordinario"|"concordato"|"breve"|null,
  "aliquota": <percentuale SOLO se indicata> | null,
  "domanda": "<UNA domanda breve se manca il canone>" | null
}}
Note:
- Se il canone è MENSILE (es. "800 al mese"), convertilo in ANNUO (×12).
- "canone concordato"/"comune ad alta tensione" -> "concordato"; "locazione breve"/"airbnb" -> "breve"; altrimenti "ordinario".
- Se NON riguarda la cedolare/locazione: {{"e_cedolare": false, "canone": null, "tipo": null, "aliquota": null, "domanda": null}}.

MESSAGGIO:
{messaggio}"""


async def chiarifica_cedolare(messaggio: str) -> dict:
    try:
        d = await ai_client.chat_json(_CHIARIF_CED_PROMPT.format(messaggio=(messaggio or "")[:1500]),
                                      system=_CHIARIF_SYSTEM)
    except Exception:
        return {"e_cedolare": False}
    return d if isinstance(d, dict) else {"e_cedolare": False}


def revisiona_cedolare(res: dict) -> dict:
    p = []
    g = lambda k: float(res.get(k) or 0)
    canone, al, imp, netto = g("canone_annuo"), g("aliquota"), g("imposta"), g("netto")
    if abs(imp - canone * al / 100) > 0.02:
        p.append("imposta diversa da canone × aliquota")
    if abs(netto - (canone - imp)) > 0.02:
        p.append("netto diverso da canone − imposta")
    if netto < -0.01:
        p.append("netto negativo")
    return {"ok": not p, "problemi": p}


def comunica_cedolare(res: dict) -> str:
    sc = res.get("scadenze") or {}
    return (
        "**Cedolare secca — calcolo verificato (motore deterministico + revisore)**\n"
        f"- Canone annuo: € {_eur(res.get('canone_annuo'))}\n"
        f"- Aliquota ({res.get('tipo')}): {_eur(res.get('aliquota'))}%\n"
        f"- Imposta sostitutiva: € {_eur(res.get('imposta'))}\n"
        f"- Netto al locatore: € {_eur(res.get('netto'))}\n"
        f"\n**Scadenze:** saldo + 1° acconto {sc.get('saldo_e_primo_acconto','30/06')}, "
        f"2° acconto {sc.get('secondo_o_unico_acconto','30/11')}.\n\n_{DISCLAIMER}_"
    )


async def rispondi_cedolare(messaggio: str):
    ref = _ced._load()
    c = await chiarifica_cedolare(messaggio)
    if not c.get("e_cedolare"):
        return None
    canone = _to_float(c.get("canone"))
    if canone is None or canone <= 0:
        return c.get("domanda") or "Qual è il canone di locazione annuo (€)?"
    aliquota = _to_float(c.get("aliquota"))
    tipo = c.get("tipo") or "ordinario"
    try:
        res = _ced.calcola_cedolare(canone, tipo=tipo, aliquota=aliquota, anno=ref.get("anno_imposta"))
    except DataNotFreshError as e:
        return f"Non posso calcolare per l'anno richiesto: {e}"
    except Exception as e:
        return f"Non riesco a completare il calcolo della cedolare: {e}"
    rev = revisiona_cedolare(res)
    if not rev["ok"]:
        ai_client._log_interno(f"sciame cedolare: REVISORE ha bloccato — {rev['problemi']}")
        return ("Ho rilevato un'incoerenza interna e, per sicurezza, non mostro un numero che "
                "potrebbe essere errato.")
    return comunica_cedolare(res)


# ═════════════════════════ DOMINIO: RAVVEDIMENTO OPEROSO ════════════════════

_CHIARIF_RAV_PROMPT = """Capisci se il messaggio chiede un RAVVEDIMENTO OPEROSO (regolarizzare un
versamento tardivo/omesso) ed estrai i dati.
Restituisci SOLO questo JSON:
{{
  "e_ravvedimento": true|false,
  "imposta": <importo del tributo NON versato, in euro> | null,
  "giorni_ritardo": <giorni di ritardo, numero intero> | null,
  "domanda": "<UNA domanda breve se manca un dato>" | null
}}
Note:
- "2 mesi di ritardo" -> ~60 ; "un anno" -> 365.
- Servono imposta e giorni di ritardo. Se mancano, metti una "domanda".
- Se NON riguarda il ravvedimento: {{"e_ravvedimento": false, "imposta": null, "giorni_ritardo": null, "domanda": null}}.

MESSAGGIO:
{messaggio}"""


async def chiarifica_ravvedimento(messaggio: str) -> dict:
    try:
        d = await ai_client.chat_json(_CHIARIF_RAV_PROMPT.format(messaggio=(messaggio or "")[:1500]),
                                      system=_CHIARIF_SYSTEM)
    except Exception:
        return {"e_ravvedimento": False}
    return d if isinstance(d, dict) else {"e_ravvedimento": False}


def revisiona_ravvedimento(res: dict) -> dict:
    p = []
    g = lambda k: float(res.get(k) or 0)
    imp, san, inter, tot = g("imposta"), g("sanzione"), g("interessi"), g("totale_da_versare")
    if abs(tot - (imp + san + inter)) > 0.02:
        p.append("totale diverso da imposta + sanzione + interessi")
    if san < -0.01 or inter < -0.01:
        p.append("sanzione/interessi negativi")
    return {"ok": not p, "problemi": p}


def comunica_ravvedimento(res: dict) -> str:
    avvisi = "".join(f"\n⚠️ {w}" for w in (res.get("warnings") or []))
    return (
        "**Ravvedimento operoso — STIMA (motore deterministico + revisore)**\n"
        f"- Imposta non versata: € {_eur(res.get('imposta'))}\n"
        f"- Giorni di ritardo: {res.get('giorni_ritardo')}\n"
        f"- Sanzione ridotta ({res.get('regola')}): € {_eur(res.get('sanzione'))}\n"
        f"- Interessi legali ({_eur(res.get('tasso_legale'))}%): € {_eur(res.get('interessi'))}\n"
        f"- **Totale da versare: € {_eur(res.get('totale_da_versare'))}**"
        f"{avvisi}\n\n_{DISCLAIMER}_"
    )


async def rispondi_ravvedimento(messaggio: str):
    ref = _rav._load()
    c = await chiarifica_ravvedimento(messaggio)
    if not c.get("e_ravvedimento"):
        return None
    imposta = _to_float(c.get("imposta"))
    if imposta is None or imposta <= 0:
        return c.get("domanda") or "Qual è l'importo del tributo non versato (€)?"
    giorni = _to_float(c.get("giorni_ritardo"))
    if giorni is None or giorni < 0:
        return c.get("domanda") or "Da quanti giorni è in ritardo il versamento?"
    try:
        res = _rav.calcola_ravvedimento(imposta, int(giorni), anno=ref.get("anno_imposta"))
    except DataNotFreshError as e:
        return f"Non posso calcolare per l'anno richiesto: {e}"
    except Exception as e:
        return f"Non riesco a completare il calcolo del ravvedimento: {e}"
    rev = revisiona_ravvedimento(res)
    if not rev["ok"]:
        ai_client._log_interno(f"sciame ravvedimento: REVISORE ha bloccato — {rev['problemi']}")
        return ("Ho rilevato un'incoerenza interna e, per sicurezza, non mostro un numero che "
                "potrebbe essere errato.")
    return comunica_ravvedimento(res)
