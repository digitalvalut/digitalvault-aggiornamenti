"""
Generatore di PDF professionali per DigitalValut.
Crea documenti di consulenza con intestazione dello studio.
"""
import io
import re
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
)
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY


PRIMARY = colors.HexColor("#3b82f6")
DARK = colors.HexColor("#1a2235")
GRAY = colors.HexColor("#64748b")
LIGHT = colors.HexColor("#f1f5f9")


def _clean_markdown(text: str) -> str:
    """Converte markdown base in tag che reportlab capisce."""
    text = text or ""
    # bold
    text = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)
    # heading -> bold
    text = re.sub(r"^#{1,6}\s*(.+)$", r"<b>\1</b>", text, flags=re.M)
    # bullet
    text = re.sub(r"^[-*]\s+", "• ", text, flags=re.M)
    # escape & < > residui pericolosi (ma lasciamo i tag b/i)
    return text


def _styles():
    ss = getSampleStyleSheet()
    styles = {
        "titolo": ParagraphStyle("titolo", parent=ss["Title"], fontSize=20,
                                 textColor=DARK, spaceAfter=2, leading=24),
        "sub": ParagraphStyle("sub", parent=ss["Normal"], fontSize=10,
                              textColor=GRAY, spaceAfter=2),
        "h2": ParagraphStyle("h2", parent=ss["Heading2"], fontSize=13,
                             textColor=PRIMARY, spaceBefore=12, spaceAfter=6),
        "body": ParagraphStyle("body", parent=ss["Normal"], fontSize=10.5,
                              textColor=colors.HexColor("#1f2937"), leading=16,
                              alignment=TA_JUSTIFY, spaceAfter=6),
        "small": ParagraphStyle("small", parent=ss["Normal"], fontSize=8,
                               textColor=GRAY, alignment=TA_CENTER),
        "label": ParagraphStyle("label", parent=ss["Normal"], fontSize=8,
                               textColor=GRAY),
        "value": ParagraphStyle("value", parent=ss["Normal"], fontSize=10,
                               textColor=DARK),
    }
    return styles


def _header_footer(canvas, doc, studio):
    canvas.saveState()
    # Barra superiore
    canvas.setFillColor(PRIMARY)
    canvas.rect(0, A4[1] - 6*mm, A4[0], 6*mm, fill=1, stroke=0)
    # Footer
    canvas.setFillColor(GRAY)
    canvas.setFont("Helvetica", 7)
    footer = f"{studio.get('nome_studio','Studio Commercialista')}  ·  Documento generato con DigitalValut  ·  pag. {doc.page}"
    canvas.drawCentredString(A4[0]/2, 10*mm, footer)
    canvas.setStrokeColor(LIGHT)
    canvas.line(20*mm, 14*mm, A4[0]-20*mm, 14*mm)
    canvas.restoreState()


def genera_pdf_consulenza(studio: dict, cliente: dict, titolo: str, contenuto: str) -> bytes:
    """Genera un PDF di consulenza professionale. Ritorna i byte."""
    buf = io.BytesIO()
    studio = studio or {}
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        topMargin=22*mm, bottomMargin=20*mm,
        leftMargin=20*mm, rightMargin=20*mm,
        title=titolo,
    )
    s = _styles()
    flow = []

    # Intestazione studio
    nome_studio = studio.get("nome_studio", "Studio del Commercialista")
    flow.append(Paragraph(nome_studio, s["titolo"]))
    riga_studio = " · ".join(filter(None, [
        studio.get("indirizzo_studio"),
        studio.get("telefono_studio"),
        studio.get("email_studio"),
    ]))
    if riga_studio:
        flow.append(Paragraph(riga_studio, s["sub"]))
    if studio.get("piva_studio"):
        flow.append(Paragraph(f"P.IVA / CF: {studio.get('piva_studio')}", s["sub"]))
    flow.append(Spacer(1, 4))
    flow.append(HRFlowable(width="100%", thickness=1.2, color=PRIMARY))
    flow.append(Spacer(1, 10))

    # Box dati cliente + data
    if cliente:
        nome_c = f"{cliente.get('cognome','')} {cliente.get('nome','')}".strip()
        dati = [
            [Paragraph("CLIENTE", s["label"]), Paragraph("DATA", s["label"])],
            [Paragraph(nome_c or "—", s["value"]),
             Paragraph(datetime.now().strftime("%d/%m/%Y"), s["value"])],
            [Paragraph("CODICE FISCALE", s["label"]), Paragraph("PARTITA IVA", s["label"])],
            [Paragraph(cliente.get("codice_fiscale") or "—", s["value"]),
             Paragraph(cliente.get("partita_iva") or "—", s["value"])],
        ]
        t = Table(dati, colWidths=[(doc.width)/2]*2)
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
            ("BOX", (0, 0), (-1, -1), 0.5, LIGHT),
            ("INNERGRID", (0, 0), (-1, -1), 0.3, LIGHT),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ]))
        flow.append(t)
        flow.append(Spacer(1, 14))

    # Titolo documento
    flow.append(Paragraph(titolo, s["h2"]))
    flow.append(Spacer(1, 2))

    # Contenuto (paragrafi)
    for blocco in _clean_markdown(contenuto).split("\n"):
        blocco = blocco.strip()
        if not blocco:
            flow.append(Spacer(1, 4))
            continue
        try:
            flow.append(Paragraph(blocco, s["body"]))
        except Exception:
            # se il markup rompe, mettiamo testo grezzo
            safe = blocco.replace("<", "&lt;").replace(">", "&gt;")
            flow.append(Paragraph(safe, s["body"]))

    # Disclaimer
    flow.append(Spacer(1, 16))
    flow.append(HRFlowable(width="100%", thickness=0.5, color=LIGHT))
    flow.append(Spacer(1, 6))
    disclaimer = ("Documento informativo redatto dallo studio. Le elaborazioni sono fornite a titolo "
                  "di supporto; la responsabilità professionale resta in capo al commercialista. "
                  "Software fornito gratuitamente dall'APS DigitalValut (CF 90036980846).")
    flow.append(Paragraph(disclaimer, s["small"]))

    doc.build(
        flow,
        onFirstPage=lambda c, d: _header_footer(c, d, studio),
        onLaterPages=lambda c, d: _header_footer(c, d, studio),
    )
    buf.seek(0)
    return buf.read()


def genera_pdf_scheda_cliente(studio: dict, cliente: dict, documenti: list, eventi: list) -> bytes:
    """Genera la scheda completa di un cliente (anagrafica + documenti + timeline)."""
    buf = io.BytesIO()
    studio = studio or {}
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=22*mm, bottomMargin=20*mm,
                            leftMargin=20*mm, rightMargin=20*mm,
                            title=f"Scheda {cliente.get('cognome','')}")
    s = _styles()
    flow = []
    flow.append(Paragraph(studio.get("nome_studio", "Studio del Commercialista"), s["titolo"]))
    flow.append(Spacer(1, 4))
    flow.append(HRFlowable(width="100%", thickness=1.2, color=PRIMARY))
    flow.append(Spacer(1, 10))

    nome_c = f"{cliente.get('cognome','')} {cliente.get('nome','')}".strip()
    flow.append(Paragraph(f"Scheda Cliente: {nome_c}", s["h2"]))

    info = [
        ["Codice Fiscale", cliente.get("codice_fiscale") or "—"],
        ["Partita IVA", cliente.get("partita_iva") or "—"],
        ["Email", cliente.get("email") or "—"],
        ["Telefono", cliente.get("telefono") or "—"],
        ["Indirizzo", cliente.get("indirizzo") or "—"],
    ]
    t = Table([[Paragraph(k, s["label"]), Paragraph(v, s["value"])] for k, v in info],
              colWidths=[doc.width*0.3, doc.width*0.7])
    t.setStyle(TableStyle([
        ("INNERGRID", (0, 0), (-1, -1), 0.3, LIGHT),
        ("BOX", (0, 0), (-1, -1), 0.5, LIGHT),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
    ]))
    flow.append(t)
    flow.append(Spacer(1, 14))

    # Documenti
    flow.append(Paragraph("Documenti collegati", s["h2"]))
    if documenti:
        rows = [[Paragraph("Documento", s["label"]), Paragraph("Tipo", s["label"]),
                 Paragraph("Anno", s["label"])]]
        for d in documenti:
            rows.append([Paragraph(d.get("nome_originale", "—"), s["value"]),
                         Paragraph(d.get("tipo", "—"), s["value"]),
                         Paragraph(str(d.get("anno_riferimento") or "—"), s["value"])])
        t = Table(rows, colWidths=[doc.width*0.55, doc.width*0.25, doc.width*0.2])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eef2ff")),
            ("INNERGRID", (0, 0), (-1, -1), 0.3, LIGHT),
            ("BOX", (0, 0), (-1, -1), 0.5, LIGHT),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ]))
        flow.append(t)
    else:
        flow.append(Paragraph("Nessun documento collegato.", s["body"]))
    flow.append(Spacer(1, 14))

    # Timeline
    flow.append(Paragraph("Storia / Timeline", s["h2"]))
    if eventi:
        for e in eventi:
            data = e.get("created_at", "")[:10] if e.get("created_at") else ""
            riga = f"<b>{data}</b> — [{e.get('tipo','')}] {e.get('titolo','')}"
            if e.get("descrizione"):
                riga += f"<br/>{e.get('descrizione')}"
            flow.append(Paragraph(riga, s["body"]))
    else:
        flow.append(Paragraph("Nessun evento registrato.", s["body"]))

    doc.build(flow,
              onFirstPage=lambda c, d: _header_footer(c, d, studio),
              onLaterPages=lambda c, d: _header_footer(c, d, studio))
    buf.seek(0)
    return buf.read()
