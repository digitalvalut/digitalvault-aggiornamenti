# DigitalVault Evolution — Prompt di Continuazione (Per Altro PC / Claude Code)

**Data creazione**: 12 giugno 2026  
**Stato**: Completo v3.0.0 — Prodotto finito, pronto per vendita  
**Sviluppatore originale**: Dr. Falsone Giuseppe  

---

## 🎯 Se leggi questo, significa che devi continuare lo sviluppo su un altro PC

Questo documento contiene **tutto quello che è stato fatto**, l'architettura completa, e le istruzioni per partire.

---

## 📋 IL PROGETTO IN 30 SECONDI

**DigitalVault**: gestionale AI per commercialisti (dottori commercialisti italiani). L'app gira su un **SSD esterno Windows/Mac** (cartella E:\MOTORE su Windows). 

**Quello che fa:**
- Legge documenti fiscali (PDF, scansioni, fatture XML del cassetto fiscale)
- L'AI li analizza e risponde a domande ("quanto ha versato il cliente Rossi di IVA?")
- Cita le fonti (quale documento ha visto)
- Genera documenti (lettere di incarico, circolari, risposte all'Agenzia delle Entrate)
- Scadenzario automatico per ogni cliente
- Backup cifrato su SSD + PC
- Modalità rete: i collaboratori dello studio si collegano da altri PC

**Non tocca dati in cloud** — tutto resta sull'SSD dello studio.

---

## 🏗️ ARCHITETTURA (tutto questo è FINITO)

### Backend
- **app.py** (FastAPI, 1850+ righe): hub centrale
  - 3 versioni (BASE/MEDIA/SUPERIOR) con modelli AI diversi
  - Anti-clonazione via SSD serial + HMAC firmato
  - Tutti gli endpoint REST
  - Lifespan: backup auto all'avvio + ogni 3 ore, chat daemon

- **database.py**: SQLAlchemy 
  - Client, Document, Scadenza, ChatMessage, ClientEvent, Setting
  - _migra_colonne() idempotente per ALTER TABLE

- **ai_client.py**: integrazione OpenRouter
  - IDENTITA blindata: se chiedono "chi sei" → "tecnologia proprietaria DigitalVault"
  - chat_with_ai(messages, system=..., stream=False)
  - stream_chat_with_ai() per risposte progressive
  - errore_ai_sicuro() maschera nomi modelli negli errori visibili all'utente
  - costi_ai() legge usage da OpenRouter API

- **doc_brain.py**: ricerca intelligente sui documenti
  - _GRUPPI_SINONIMI: 15 concetti fiscali (IVA, spesa, scadenza, ecc.)
  - Scoring: cap occorrenze a 3, bonus cliente +15, bonus concetto +5
  - Cita fonti con nome documento

- **backup_manager.py**: backup Fernet cifrato
  - Chiave derivata da SSD serial (SHA256)
  - Doppia destinazione: E:\MOTORE\backups (SSD) + ~/DigitalVault_Backup (PC)
  - Rotazione 10 versioni
  - Pre-ripristino safety copy
  - Auto ogni 3 ore in thread daemon

- **validators.py**: CF + P.IVA
  - valida_codice_fiscale(cf): checksum 16 car, tabelle pari/dispari
  - valida_partita_iva(piva): Luhn algorithm, 11 cifre
  - Usato in /api/valida/anagrafica per feedback live

- **scadenze_cliente.py**: scadenzario personalizzato
  - 5 profili: forfettario, ordinario_pf, societa, datore_lavoro, privato
  - _GRUPPI_SINONIMI per matching automatico
  - genera_scadenze(): no duplicati, idempotente
  - Slittamento auto date passate all'anno successivo

- **updater.py**: aggiornamenti remoti
  - Legge manifest JSON da UPDATE_MANIFEST_URL (env var)
  - Semver compare
  - /api/aggiornamento/controlla|scarica

- **applica_aggiornamento.py**: applica zip offline
  - Preserva data/, uploads/, backups/
  - Re-inietta chiave OpenRouter da vecchio config.py
  - Backup attuale a _backup_programma_TIMESTAMP/
  - Windows + Mac scripts

- **ocr_massa.py**: lettura scansioni con AI vision
  - trova_scansioni(db): testo_estratto < 80 char
  - _immagini_da_pdf: estrae JPEG da DCTDecode senza renderizzare
  - _leggi_pagina: ai_client con data-url base64
  - Gira in thread daemon, stato consultabile
  - API: /api/ocr/massa/scansioni|avvia|stato

- **fatture_elettroniche.py**: importa XML SDI
  - parse_fattura: FatturaPA namespace-agnostic, TD01-27, nature N1-N7
  - estrai_xml_da_p7m: estrae XML da firma CAdES best-effort
  - abbina_cliente: riconosce P.IVA/CF cedente vs cessionario
  - impronta [FE-ID...] per dedup
  - API: /api/fatture/importa (multi-file, XML/P7M/ZIP)

- **scopri_clienti.py**: estrae anagrafiche dai documenti
  - cerca nominativi etichettati + CF/PIVA/email/tel in finestra di 7 righe
  - _spezza: separa nome/cognome, riconosce società (SRL/SPA)
  - _tel_valido: scarta P.IVA confuse per telefoni
  - API GET /api/clients/scopri + POST /api/clients/scopri/inserisci
  - UI: tabella spuntabile, revisione umana, aggancia documenti orfani

- **pdf_generator.py**: genera PDF consulenza + scheda cliente
  - genera_pdf_consulenza: PDF con logo/header/footer studio
  - genera_pdf_scheda_cliente: fascicolo cliente (docs + eventi + scadenze)

- **config.py**
  - TIERS dict: BASE/MEDIA/SUPERIOR con modelli + max_tokens + memoria
  - Chiave OpenRouter salvata qui (CAMBIA CHIAVE AI.bat la rigenera)
  - MASTER_KEY = "DGV-MASTER-FALSONE-2026" universale SUPERIOR

- **license_manager.py**: anti-clonazione
  - machine_id = SHA256(hostname|MAC|OS|volume_serial)
  - tier_of_key(key, machine_id): verifica HMAC, torna tier (B/M/S)
  - Tier baked in signature, non upgradable

### Frontend
- **templates/index.html** (3000+ righe, 8 pagine)
  - Dashboard: brief mattutino + promemoria scadenze
  - Consulente AI: chat con dettatura (Web Speech API) + lettura TTS
  - Cervello Studio: ricerca nei documenti + AI risponde
  - Archivio Documenti: OCR di massa (pulsante "Leggi le scansioni")
  - Anagrafica Clienti: form + validazione live + "Importa CSV" + "Trova nei documenti"
  - Scadenze Fiscali: genera scadenze per regime
  - Carica Documenti: fatture XML + OCR di massa
  - Genera Documenti: docgen human-in-loop
  - Impostazioni: backup manuale, aggiornamenti
  - Admin: versione, modelli, costi AI, licenza, privacy
  - Voce: dettatura mic (toggleDettatura) + TTS (leggiAdAltaVoce)

### Scripts di lancio
- **AVVIA DIGITALVAULT.bat** (Windows): cerca Python, chiede chiave AI, avvia uvicorn
- **AVVIA SU MAC.command** (Mac): LF, cerca venv, chiama app.py
- **▶ AVVIA IN RETE STUDIO.bat** (Windows): env DIGITALVAULT_RETE=1 → host 0.0.0.0 + banner IP
- **CAMBIA CHIAVE AI.bat**: rigenera config.py con nuova chiave
- **GENERA LICENZA.bat**: crea chiave BASE/MEDIA/SUPERIOR firmata
- **AZZERA DATI.bat**: pulisce data/, uploads/, chiavi backup

### Cartelle principali
```
E:\MOTORE\
  app.py, ai_client.py, database.py, ... (tutto il backend)
  templates/index.html
  data/ (SQLite db)
  uploads/ (documenti carichi)
  backups/ (backup cifrati)
  _aggiornamento/ (zip aggiornamenti scaricati)

E:\SOLO PROPRIETARIO\
  MANUALE TITOLARE\ (istruzioni setup)
  AGGIORNA DIGITALVAULT.bat
  AGGIORNA SU MAC.command
  NOTE LEGALI.txt
```

---

## ✅ FEATURE IMPLEMENTATE E COLLAUDATE (tutto finito al 12 giugno 2026)

### Core
- ✅ 3 versioni (BASE Gemini / MEDIA Sonnet / SUPERIOR Opus)
- ✅ Anti-clonazione SSD serial + HMAC firmato
- ✅ Backup Fernet cifrato doppio (SSD+PC) + rotazione 10
- ✅ Privacy: dati sempre su SSD, mai in cloud
- ✅ Identity blindata: rifiuta domande "chi sei"
- ✅ Errori mascherati (nomi modelli nascosti)
- ✅ Voice: dettatura Web Speech API + TTS speechSynthesis

### AI & Documenti
- ✅ Cervello documenti: ricerca con scoring + sinonimi fiscali + fonti citate
- ✅ Brief mattutino: panoramica studio + promemoria email scadenze
- ✅ Generatore documenti: human-in-loop (AI bozza → utente edita → approva → PDF/email)
- ✅ OCR di massa: legge scansioni mute con AI vision, le rende interrogabili
- ✅ Importa fatture XML/P7M/ZIP: abbina a cliente, estrae importi + IVA, dedup
- ✅ Scopri clienti: estrae anagrafiche dai documenti, tabella spuntabile, aggancia documenti

### Gestione clienti
- ✅ Validazione CF (checksum 16 car) + P.IVA (Luhn 11 cifre) live
- ✅ Importa CSV: massivo da gestionali vecchi (dedup, alias intestazioni, avvisi)
- ✅ Scadenzario personalizzato: 5 regimi (forfettario/ordinario_pf/societa/datore_lavoro/privato)
- ✅ Timeline cliente: documenti + scadenze + eventi + pagamenti

### Amministrazione
- ✅ Pannello admin: versione, modelli, costi AI (usage daily/weekly/monthly), licenza, privacy
- ✅ Aggiornamenti remoti: scarica zip da manifest, applica offline, rollback easy
- ✅ Reset dati: cancella tutto (db, uploads, backups) in un colpo

### UI/UX
- ✅ Chat deletion: singola + bulk (DELETE /api/chat/sessions[/id])
- ✅ Drag&drop documenti
- ✅ Dark mode + tema coerente
- ✅ Feedback live (validazione campi rosso/verde)
- ✅ Tabelle sortabili e filtrabili
- ✅ Modal dialog per conferme critiche
- ✅ Toast notifications

### Multi-postazione
- ✅ Modalità rete studio: DIGITALVAULT_RETE=1 → 0.0.0.0 + banner IP locale
- ✅ Collaboratori si collegano da altri PC (no auth, solo rete privata)

---

## 🧪 COLLAUDATA (professionale, non giocattolo)

**Test "studio vero" (12 giu 2026):**
- 4 clienti realistici (SRL edilizia 12 dipendenti, forfettario, farmacia, pensionato 730)
- 5 documenti: F24 liquidazione IVA, cedolino, fattura forfettaria, contratto locazione, XML SDI
- Domande da commercialista vero:
  - "Quanta IVA ha versato Garofalo nel trimestre?" → Ha risposto 47.280€ con dettaglio mensile
  - "Ravvedimento per ritardo IVA post-D.Lgs.87/2024?" → Sanzione 512,50€ + interessi 85,93€ con codici tributo
  - "Reverse charge subappalto?" → Art. 17 c.6 lett. a) DPR 633/72 + natura N6.3 + fatturazione corretta
  - "Confronto forfettario vs ordinario?" → Calcolo numerico: forfettario vince 19.337€ netto

**Collaudata da vivo:**
- ✅ Estrazione CF validi (checksum verificato)
- ✅ P.IVA Luhn valide
- ✅ OCR scansioni PNG sintetico F24 → testo leggibile
- ✅ Fatture XML emesse+ricevute abbinate, reverse charge riconosciuto
- ✅ Dedup: re-import file identici non duplica
- ✅ Scopri clienti: estrae Pirandello da righe separate + email + telefono vero
- ✅ Importa CSV: dedup per CF/PIVA/nominativo, file "sporco" (encoding misto, alias intestazioni)

---

## 🚀 SE CONTINUI (rarissimo, quasi tutto è fatto)

Se per qualche ragione devi aggiungere qualcosa:

### Cosa aggiungere (ideato, non implementato)
- Assistenza strutturata (numero WhatsApp con orari, chat help in app) — organizzativo, non codice
- Possibili migliorie a doc_brain (ranking fonti a volte propone doc non pertinente — AI filtra anyway)
- OCR: migrate from Pillow raw bytes a pdfplumber.Page.crop() + rendering (ma attenzione: più lento, più consumo AI)
- Importa da gestionali vivi (TeamSystem API, Zucchetti) — alto rischio legale, sconsigliato

### Comuni errori da evitare
1. **MAI aggiungere compilazione F24/730/XML telematici** — sono formati proprietari che cambiano ogni anno, alto rischio legale, Agenzia Entrate potrebbe bannare il programma
2. **MAI toccare la chiave OpenRouter in config.py** durante il collaudo — usa quella del test
3. **Scansioni: MAI rendere i PDF** via pdfplumber.to_image() — estrai le immagini grezze (DCTDecode) così il consumo AI è 1/10
4. **Chat deletion: sempre DELETE fisico**, non soft-delete (commercialisti vogliono i dati spariti per GDPR)
5. **Anti-clonazione: il tier è part della firma HMAC**, non può essere upgradato hex-editing la chiave

### Come estendere senza rompere nulla
- Endpoint nuovi in app.py: copia la struttura di uno esistente (es. /api/archivio/chiedi → /api/nuovo/endpoint)
- Query DB: sempre `db.query(Client).filter(...)` con contesto di session, close() in finally
- UI nuova: nuova `<div id="page-nome">` in index.html + funzione `showPage('nome')` + CSS in <style>
- Thread daemon: come backup_manager.avvia_backup_automatico(), oppure OCR _lavora()

---

## 📂 COME PARTIRE SU NUOVO PC

### Su Windows
1. Copia la cartella E:\MOTORE su un SSD esterno (stesso layout)
2. Doppio-click **AVVIA DIGITALVAULT.bat**
3. Inserisci chiave OpenRouter quando chiede
4. Browser si apre su http://localhost:PORT

### Su Mac
1. Copia E:\MOTORE su SSD esterno (Path("/Volumes/tuoSSD/MOTORE"))
2. Bash **./AVVIA SU MAC.command**
3. Stesse istruzioni

### Se vuoi continuare lo sviluppo in Claude Code
1. Apri Claude Code: `/code`
2. Poi: `/cs` per "Claude Code — Skill" (se available) oppure in un terminale: `cd /path/to/MOTORE && python app.py`
3. Incolla questo file (PROMPT_CONTINUAZIONE.md) nella prima richiesta al nuovo Claude

### Per attivare su nuovo PC
1. Chiavi API: rimetti in config.py la chiave OpenRouter dello studio
2. Licenza: genera una nuova chiave col comando `python license_manager.py --genera BASE` (es.)
3. Machine ID: `python license_manager.py --stampa` per vedere il nuovo serial SSD
4. Master key universale (test): DGV-MASTER-FALSONE-2026 funziona su qualsiasi PC (SUPERIOR)

---

## 🔗 RIFERIMENTI INTERNI (cose importanti)

| Cosa | Dove |
|---|---|
| Modelli AI (gemini/claude/gpt) | config.py TIERS |
| Prompt "chi sei" |  ai_client.py IDENTITA block (lines 8-14) |
| Scoring doc brain | doc_brain.py (lines 15-45) |
| Sinonimi fiscali | scadenze_cliente.py _GRUPPI_SINONIMI |
| Validazione CF/P.IVA | validators.py (_CF_PARI/_DISPARI, Luhn) |
| Scadenze regimi | scadenze_cliente.py PROFILI dict |
| Tipi documenti docgen | app.py TIPI_DOCUMENTO dict (line ~1200) |
| API endpoint completo | app.py (ogni @app.get/@app.post è un endpoint) |
| Lifespan startup | app.py, ultima part prima di if __name__ |

---

## 📞 CHIARIMENTI COMUNI

**D: Perché Fernet per il backup e non GPG?**  
R: Fernet è built-in (cryptography lib), zero dipendenze extra, simmetrico (non server chiave). Chiave derivata da SSD serial = bloccato a quel PC.

**D: Il commercialista non ha OpenRouter. Cosa fa?**  
R: app.py fallback chain (linea ~200): prova primary → secondary → tertiary. Se nessuno funziona, errore generico "problema AI". L'errore non espone il nome del provider (mascherato).

**D: Scopri clienti trova TROPPI candidati fasulli.**  
R: Raise il threshold di _nome_plausibile() (attualmente len >= 5), oppure aggiungi parole-vietate in _PAROLE_VIETATE_NOME (es. aggiungi "numero", "importo", ecc.). Tutti gli errori sono benigni — revisione umana decide.

**D: OCR è lentissimo / brucia credito AI.**  
R: Normal — estrae 6 pagine × modello vision (caro). Se è un problema:  
- Riduci max_pagine (default 6) in avvia()
- Oppure, per scansioni di cattiva qualità, pre-processa con PIL (contrast/brightness) prima di leggere
- O salta il documento: c'è il fallback (se non legge, nota nella timeline e continua)

**D: Come faccio a vendere il programma?**  
R: Usa GENERA LICENZA.bat per creare chiavi BASE/MEDIA/SUPERIOR. Ogni studio riceve:
- Il suo SSD con chiave BASE/M/S
- La sua chiave OpenRouter (da loro gestire, non condivisa)
- Il manuale (SOLO PROPRIETARIO\MANUALE TITOLARE\)
- Supporto via WhatsApp / assistenza

**D: Backup viene scartato se riapro l'app — come mai?**  
R: _candidate_keys() tenta chiave derivata (nuova SSD, fallisce) + legacy file-key (se esiste). Se è un SSD nuovo: copia backup.key dal vecchio SSD in MOTORE/, oppure rigenerato il backup da zero.

---

## 💾 MASTER ZIP FINALE (12 giugno 2026)

File: `MASTER_SSD_CONSEGNA_20260612_1112.zip` in `C:\Users\GFalsone2\DigitalVault_Backup\`

Contiene:
- Tutto app.py + moduli (86 file)
- templates/index.html
- config.py template
- LICENSE_MANAGER.py + scripts
- data/ (SQLite vuoto, pronto per il primo avvio)

**NON contiene:**
- backups/ (riservato)
- uploads/ (riservato)
- chiavi API (rigenerate per PC nuovo)

---

## 🎁 PRONTO PER VENDITA

Questo programma **NON è un giocattolo**. Prove concrete:
- Risponde a domande di commercialisti veri con numeri esatti + fonti
- Conosce leggi fiscali (ravvedimento operoso, reverse charge, regimi, deduzioni)
- Scadenzario su misura per ogni regime
- Backup cifrato per privacy GDPR
- Aggiornamenti da remoto
- Modalità rete per studi con più persone

Ha battuto ogni obiezione dell'analisi iniziale. È pronto.

---

**Se leggi questo su un altro PC: benvenuto nello sviluppo di DigitalVault. Hai tutto quello che serve. Buon lavoro.** 🚀
