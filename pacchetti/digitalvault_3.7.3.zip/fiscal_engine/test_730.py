"""Test di regressione 730 — esito rimborso/debito (golden cases)."""
from fiscal_engine import dichiarativo_730 as s730


def test_rimborso():
    # reddito 35000 -> IRPEF lorda 8750 ; netta = 8750-1910 = 6840 ; 9000-6840 = +2160
    r = s730.esito_730(35000, ritenute=9000, detrazioni=1910, anno=2026)
    assert r["irpef_lorda"] == 8750.00
    assert r["irpef_netta"] == 6840.00
    assert r["esito"] == "rimborso" and r["importo"] == 2160.00


def test_a_debito():
    # netta 6840 ; ritenute 5000 -> 5000-6840 = -1840 (a debito)
    r = s730.esito_730(35000, ritenute=5000, detrazioni=1910, anno=2026)
    assert r["esito"] == "a debito" and r["importo"] == 1840.00


def test_senza_detrazioni_warning():
    r = s730.esito_730(35000, ritenute=9000, detrazioni=0, anno=2026)
    assert r["irpef_netta"] == 8750.00
    assert r["esito"] == "rimborso" and r["importo"] == 250.00
    assert r["warnings"], "doveva avvisare che mancano le detrazioni"


def test_netta_non_negativa():
    # detrazioni enormi non rendono l'IRPEF netta negativa
    r = s730.esito_730(20000, ritenute=0, detrazioni=999999, anno=2026)
    assert r["irpef_netta"] == 0.00
    assert r["esito"] == "a debito" and r["importo"] == 0.00


def test_detrazione_lavoro_fissa():
    from fiscal_engine import irpef
    assert irpef.detrazione_lavoro_dipendente(12000, anno=2026)["detrazione"] == 1955.00


def test_detrazione_lavoro_zero_oltre_50000():
    from fiscal_engine import irpef
    assert irpef.detrazione_lavoro_dipendente(60000, anno=2026)["detrazione"] == 0.00


def test_730_detrazione_auto_dipendente():
    # detrazioni non fornite + tipo dipendente -> stima automatica
    r = s730.esito_730(35000, ritenute=9000, tipo_reddito="lavoro_dipendente", anno=2026)
    assert r["detrazione_fonte"] == "stimata"
    assert r["detrazioni"] > 0
    assert r["esito"] == "rimborso"
    assert r["warnings"]
