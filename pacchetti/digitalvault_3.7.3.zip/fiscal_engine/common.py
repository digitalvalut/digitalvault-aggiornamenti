"""
DigitalValut Fiscal Engine — elementi comuni.
(c) 2026 DigitalValut - Capo Team del Progetto: Dr. Falsone Giuseppe

Punto UNICO per il disclaimer fiscale (Fase F del Brief di affidabilità):
ogni output fiscale (calcolatori e risposte AI con numeri) deve chiudersi con
questa stringa. Centralizzarla evita versioni divergenti.
"""

# Disclaimer standard, obbligatorio su ogni output fiscale.
DISCLAIMER = (
    "Bozza tecnica generata da DigitalValut su base di calcolo deterministica — "
    "da validare da un professionista abilitato prima di qualsiasi uso o versamento. "
    "Non costituisce perizia."
)


def disclaimer() -> str:
    """Ritorna il disclaimer fiscale standard."""
    return DISCLAIMER


class DataNotFreshError(Exception):
    """I dati di riferimento per l'anno d'imposta richiesto non sono disponibili
    o sono scaduti: meglio bloccare che usare silenziosamente valori vecchi
    (Data freshness guard — Parte 2, §4.6)."""
    pass


def verifica_anno(ref: dict, anno) -> None:
    """Blocca se l'anno d'imposta richiesto non coincide con quello dei dati di
    riferimento caricati. `ref` è il dict del file YAML (con `anno_imposta`)."""
    if anno is None:
        return
    atteso = ref.get("anno_imposta")
    if atteso is not None and int(anno) != int(atteso):
        raise DataNotFreshError(
            f"Dati fiscali non disponibili per l'anno {anno} (caricati per il {atteso}). "
            f"Aggiornare i dati in fiscal_reference/ prima di calcolare."
        )
