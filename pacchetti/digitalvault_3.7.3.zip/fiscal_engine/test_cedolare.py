"""Test di regressione cedolare secca (golden cases)."""
from fiscal_engine import cedolare as ced


def test_ordinario_21():
    r = ced.calcola_cedolare(12000, "ordinario", anno=2026)
    assert r["aliquota"] == 21.0 and r["imposta"] == 2520.00 and r["netto"] == 9480.00


def test_concordato_10():
    r = ced.calcola_cedolare(12000, "concordato", anno=2026)
    assert r["aliquota"] == 10.0 and r["imposta"] == 1200.00


def test_breve_26():
    r = ced.calcola_cedolare(10000, "breve", anno=2026)
    assert r["aliquota"] == 26.0 and r["imposta"] == 2600.00


def test_aliquota_esplicita():
    r = ced.calcola_cedolare(10000, aliquota=21, anno=2026)
    assert r["imposta"] == 2100.00


def test_zero():
    r = ced.calcola_cedolare(0, "ordinario", anno=2026)
    assert r["imposta"] == 0.00 and r["netto"] == 0.00
