"""
DigitalValut — Calcolatore Regime Forfettario deterministico (Parte 2).
(c) 2026 DigitalValut - Capo Team del Progetto: Dr. Falsone Giuseppe

Legge soglia/aliquote/coefficienti da fiscal_reference/forfettario.yaml.
Imponibile = ricavi * coefficiente di redditività; l'imposta sostitutiva
(5% startup / 15% ordinaria) si applica al reddito AL NETTO dei contributi.
"""
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import yaml

from fiscal_engine.common import verifica_anno

REFERENCE = Path(__file__).parent.parent / "fiscal_reference" / "forfettario.yaml"

# Aliquota INPS Gestione Separata (VARIABILE ANNUALE) — usata per la stima del netto.
_INPS_GESTIONE_SEPARATA = Decimal("0.2607")


def _load() -> dict:
    if not REFERENCE.exists():
        raise FileNotFoundError(f"Dati di riferimento forfettario non trovati: {REFERENCE}")
    with open(REFERENCE, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _q(n: Decimal) -> float:
    return float(n.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def simula_forfettario(fatturato, coefficiente, nuova_attivita: bool = False,
                       anno: int = None, aliquota_inps: float = None) -> dict:
    """Simulazione completa forfettario. Output compatibile col frontend +
    tracciabilità e avviso soglia. `anno` attiva il data-freshness guard."""
    ref = _load()
    verifica_anno(ref, anno)

    fatturato = Decimal(str(max(0.0, float(fatturato))))
    coeff = Decimal(str(coefficiente))
    inps_aliq = Decimal(str(aliquota_inps)) if aliquota_inps is not None else _INPS_GESTIONE_SEPARATA

    reddito_forfettario = (fatturato * coeff)
    contributi = (reddito_forfettario * inps_aliq).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    imponibile = max(Decimal("0"), reddito_forfettario - contributi)
    aliquota = Decimal(str(ref["imposta_sostitutiva"]["startup_primi_5_anni"] if nuova_attivita
                           else ref["imposta_sostitutiva"]["ordinaria"]))
    imposta = (imponibile * aliquota).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    netto = fatturato - contributi - imposta

    warnings = []
    soglia = Decimal(str(ref.get("soglia_ricavi", 85000)))
    if fatturato > Decimal("100000"):
        warnings.append("Ricavi oltre 100.000 €: uscita immediata dal regime nell'anno (IVA dalla fattura che supera la soglia).")
    elif fatturato > soglia:
        soglia_fmt = f"{_q(soglia):,.0f}".replace(",", ".")
        warnings.append(f"Ricavi oltre la soglia di {soglia_fmt} €: uscita dal regime dall'anno successivo.")

    return {
        # --- chiavi compatibili col frontend esistente ---
        "fatturato": _q(fatturato),
        "reddito_forfettario": _q(reddito_forfettario),
        "reddito_lordo": _q(reddito_forfettario),
        "contributi_inps": _q(contributi),
        "imposta_sostitutiva": _q(imposta),
        "netto_in_tasca": _q(netto),
        "percentuale_netto": round(float(netto / fatturato * 100), 1) if fatturato > 0 else 0,
        "tipo": "Nuova attività (5%)" if nuova_attivita else "Regime ordinario forfettario (15%)",
        # --- tracciabilità (Parte 2) ---
        "coefficiente_redditivita": float(coeff),
        "aliquota_imposta": f"{int(aliquota * 100)}%",
        "anno_imposta": ref.get("anno_imposta"),
        "schema_version": ref.get("schema_version"),
        "legal_source": ref.get("legal_source"),
        "warnings": warnings,
    }


if __name__ == "__main__":
    for fatt, co in ((30000, 0.78), (50000, 0.86), (60000, 0.40)):
        r = simula_forfettario(fatt, co, anno=2026)
        print(f"Fatturato {fatt} coeff {co}: imponibile forfettario € {r['reddito_forfettario']}")
