"""Test di regressione del motore IVA (golden cases)."""
from fiscal_engine import iva


def test_calcolo_ordinaria():
    r = iva.calcola_iva(1000, 22, anno=2026)
    assert r["iva"] == 220.00 and r["totale"] == 1220.00


def test_calcolo_ridotta_10():
    r = iva.calcola_iva(1000, 10, anno=2026)
    assert r["iva"] == 100.00 and r["totale"] == 1100.00


def test_calcolo_default_ordinaria():
    # senza aliquota -> usa l'ordinaria del YAML (22)
    r = iva.calcola_iva(1000, None, anno=2026)
    assert r["aliquota"] == 22.0 and r["iva"] == 220.00


def test_scorporo_esatto():
    r = iva.scorpora_iva(1220, 22, anno=2026)
    assert r["imponibile"] == 1000.00 and r["iva"] == 220.00


def test_scorporo_arrotondamento():
    r = iva.scorpora_iva(100, 22, anno=2026)
    # 100 / 1.22 = 81.9672... -> 81.97 ; iva = 18.03 ; somma = totale
    assert r["imponibile"] == 81.97
    assert round(r["imponibile"] + r["iva"], 2) == 100.00


def test_liquidazione_debito():
    r = iva.liquidazione_iva(5000, 3000, anno=2026)
    assert r["saldo"] == 2000.00 and r["importo"] == 2000.00
    assert "debito" in r["tipo"]


def test_liquidazione_credito():
    r = iva.liquidazione_iva(2000, 3000, anno=2026)
    assert r["saldo"] == -1000.00 and r["importo"] == 1000.00
    assert "credito" in r["tipo"]


def test_aliquota_anomala_warning():
    r = iva.calcola_iva(1000, 8, anno=2026)   # 8% non è ammessa
    assert r["warnings"], "doveva segnalare l'aliquota anomala"
