"""
Test di regressione IMU — caso Golden + confine.
Il test caso IMU fallisce se il moltiplicatore per A/3 non è 160.
"""
import pytest
from decimal import Decimal
from fiscal_engine.imu import calcola_imu_fabbricato, FiscalValidationError, MissingInputError


class TestIMUGoldenCase:
    """Caso reale da Brief di affidabilità: rendita 232,41, A/3, 9 mesi."""

    def test_imu_a3_rendita_232_41_9_mesi(self):
        """
        Golden case: il bug era moltiplicatore 100 invece di 160.
        Questo test DEVE fallire se il moltiplicatore è sbagliato.
        """
        res = calcola_imu_fabbricato(
            categoria_catastale="A/3",
            rendita_catastale=Decimal("232.41"),
            aliquota_per_mille=Decimal("10.6"),
            mesi_possesso=9,
        )

        # Controlli deterministici
        assert res.moltiplicatore_usato == 160, "A/3 deve usare moltiplicatore 160, NON 100"

        # Base imponibile attesa: 232.41 * 1.05 * 160 = 39044.88
        expected_base = Decimal("39044.88")
        assert res.base_imponibile == expected_base, \
            f"Base imponibile attesa {expected_base}, ricevuta {res.base_imponibile}"

        # IMU annua: 39044.88 * 10.6 / 1000 = 413.8756... → 413.88
        expected_imu_annua = Decimal("413.88")
        assert res.imu_annua == expected_imu_annua, \
            f"IMU annua attesa {expected_imu_annua}, ricevuta {res.imu_annua}"

        # IMU rata (9 mesi): 413.88 * 9 / 12 ≈ 310.41
        expected_imu_rata = Decimal("310.41")
        assert res.imu_rata == expected_imu_rata, \
            f"IMU rata attesa {expected_imu_rata}, ricevuta {res.imu_rata}"

        # Acconto 50%
        expected_acconto = Decimal("206.94")
        assert res.acconto == expected_acconto, \
            f"Acconto atteso {expected_acconto}, ricevuto {res.acconto}"

        # Saldo
        expected_saldo = Decimal("206.94")
        assert res.saldo == expected_saldo, \
            f"Saldo atteso {expected_saldo}, ricevuto {res.saldo}"

    def test_moltiplicatore_mai_100_per_a3(self):
        """
        Verifica esplicita: se qualcuno rimette 100 come moltiplicatore per A/3,
        questo test fallisce PRIMA che il numero errato raggiunga i clienti.
        """
        res = calcola_imu_fabbricato(
            categoria_catastale="A/3",
            rendita_catastale=Decimal("100"),
            aliquota_per_mille=Decimal("8.6"),
        )

        # Se il moltiplicatore fosse 100 (errore), la base sarebbe:
        # 100 * 1.05 * 100 = 10500 (SBAGLIATO)
        # Se il moltiplicatore è 160 (corretto), la base è:
        # 100 * 1.05 * 160 = 16800 (GIUSTO)

        assert res.moltiplicatore_usato == 160
        assert res.base_imponibile == Decimal("16800")  # Rigore: no tolleranza


class TestIMUConfineRegola15Giorni:
    """Test di confine: regola dei 15 giorni per il mese."""

    def test_acquistato_primo_giorno_mese(self):
        """Acquistato 01/04 — quel mese si conta."""
        res = calcola_imu_fabbricato(
            categoria_catastale="A/3",
            rendita_catastale=Decimal("200"),
            aliquota_per_mille=Decimal("8.6"),
            mesi_possesso=9,  # Apr + Mag + Giu + Lug + Ago + Set + Ott + Nov + Dic = 9
        )
        assert res.mesi_possesso == 9
        assert Decimal("0.75") * res.imu_annua == res.imu_rata  # 9/12

    def test_acquistato_decimo_giorno_mese(self):
        """Acquistato 10/04 — il mese si conta (>15 giorni)."""
        # In questo calcolatore semplificato, il client passa già i mesi conteggiati.
        # Test che mesi_possesso sia rispettato.
        res = calcola_imu_fabbricato(
            categoria_catastale="A/3",
            rendita_catastale=Decimal("200"),
            aliquota_per_mille=Decimal("8.6"),
            mesi_possesso=9,
        )
        assert res.mesi_possesso == 9

    def test_acquistato_sedicesimo_giorno_mese(self):
        """Acquistato 16/04 — il mese si conta comunque (>15 giorni)."""
        res = calcola_imu_fabbricato(
            categoria_catastale="A/3",
            rendita_catastale=Decimal("200"),
            aliquota_per_mille=Decimal("8.6"),
            mesi_possesso=9,
        )
        assert res.mesi_possesso == 9


class TestIMUAltreCategorie:
    """Test di confine: altre categorie catastali."""

    def test_categoria_a1_lusso_moltiplicatore_160(self):
        """A/1 (Palazzo, Castello) è di lusso ma ha moltiplicatore 160."""
        res = calcola_imu_fabbricato(
            categoria_catastale="A/1",
            rendita_catastale=Decimal("500"),
            aliquota_per_mille=Decimal("5.0"),  # Aliquota lusso di base
        )
        assert res.moltiplicatore_usato == 160

    def test_categoria_b_magazzini_moltiplicatore_140(self):
        """B (Magazzini, laboratori) moltiplicatore 140."""
        res = calcola_imu_fabbricato(
            categoria_catastale="B",
            rendita_catastale=Decimal("1000"),
            aliquota_per_mille=Decimal("8.6"),
        )
        assert res.moltiplicatore_usato == 140

    def test_categoria_c1_negozi_moltiplicatore_55(self):
        """C/1 (Negozi, botteghe) moltiplicatore 55."""
        res = calcola_imu_fabbricato(
            categoria_catastale="C/1",
            rendita_catastale=Decimal("1000"),
            aliquota_per_mille=Decimal("8.6"),
        )
        assert res.moltiplicatore_usato == 55

    def test_categoria_d5_centrale_idroelettrica_moltiplicatore_80(self):
        """D/5 (Centrale idroelettrica) moltiplicatore 80."""
        res = calcola_imu_fabbricato(
            categoria_catastale="D/5",
            rendita_catastale=Decimal("5000"),
            aliquota_per_mille=Decimal("10.6"),
        )
        assert res.moltiplicatore_usato == 80


class TestIMUValidazione:
    """Test di validazione input."""

    def test_categoria_non_riconosciuta(self):
        """Categoria inesistente — errore."""
        with pytest.raises(FiscalValidationError):
            calcola_imu_fabbricato(
                categoria_catastale="ZZZZ",
                rendita_catastale=Decimal("100"),
                aliquota_per_mille=Decimal("8.6"),
            )

    def test_mesi_possesso_fuori_range(self):
        """Mesi possesso > 12 — errore."""
        with pytest.raises(FiscalValidationError):
            calcola_imu_fabbricato(
                categoria_catastale="A/3",
                rendita_catastale=Decimal("100"),
                aliquota_per_mille=Decimal("8.6"),
                mesi_possesso=13,
            )

    def test_rendita_zero_o_negativa(self):
        """Rendita <= 0 — errore."""
        with pytest.raises(FiscalValidationError):
            calcola_imu_fabbricato(
                categoria_catastale="A/3",
                rendita_catastale=Decimal("0"),
                aliquota_per_mille=Decimal("8.6"),
            )

    def test_aliquota_mancante(self):
        """Aliquota assente/zero → MissingInputError (così l'assistente la chiede)."""
        with pytest.raises(MissingInputError):
            calcola_imu_fabbricato(
                categoria_catastale="A/3",
                rendita_catastale=Decimal("100"),
                aliquota_per_mille=Decimal("0"),
            )


if __name__ == "__main__":
    # Esecuzione veloce
    pytest.main([__file__, "-v"])
