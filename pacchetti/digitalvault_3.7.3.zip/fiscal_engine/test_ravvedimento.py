"""Test di regressione ravvedimento operoso (golden cases sui valori YAML correnti)."""
from fiscal_engine import ravvedimento as rav


def test_sprint_10_giorni():
    # 1000 × 0,1% × 10 = 10 sanzione ; interessi 1000×2%×10/365 = 0,55
    r = rav.calcola_ravvedimento(1000, 10, anno=2026)
    assert r["sanzione"] == 10.00
    assert r["interessi"] == 0.55
    assert r["totale_da_versare"] == 1010.55


def test_bucket_15_30():
    # base 25% × 1/10 = 2,5% → 25 ; interessi 1000×2%×20/365 = 1,10
    r = rav.calcola_ravvedimento(1000, 20, anno=2026)
    assert r["sanzione"] == 25.00
    assert r["interessi"] == 1.10
    assert r["totale_da_versare"] == 1026.10


def test_oltre_2_anni():
    # base 25% × 1/6 = 4,1667% → 1000×0,041675 = 41,675 → 41,68 (HALF_UP)
    r = rav.calcola_ravvedimento(1000, 800, anno=2026)
    assert r["sanzione"] == 41.68


def test_sempre_avviso_stima():
    r = rav.calcola_ravvedimento(500, 5, anno=2026)
    assert r["warnings"], "deve sempre avvisare che è una stima"
