"""
Golden test IRPEF 2026 (Parte 2 §3.2) e Forfettario 2026 (§3.3).
Falliscono se rientrano costanti sbagliate (es. 2° scaglione al 35%).
"""
import pytest
from fiscal_engine.irpef import calcola_irpef
from fiscal_engine.forfettario import simula_forfettario
from fiscal_engine.common import DataNotFreshError


class TestIRPEF2026Golden:
    def test_28000(self):
        r = calcola_irpef(28000, anno=2026)
        assert r["irpef_lorda"] == 6440.0          # 28.000 × 23%

    def test_35000(self):
        r = calcola_irpef(35000, anno=2026)
        assert r["irpef_lorda"] == 8750.0          # 6440 + 7000×33%

    def test_38000(self):
        r = calcola_irpef(38000, anno=2026)
        assert r["irpef_lorda"] == 9740.0          # 6440 + 10000×33%

    def test_60000(self):
        r = calcola_irpef(60000, anno=2026)
        assert r["irpef_lorda"] == 18000.0         # 6440 + 22000×33% + 10000×43%

    def test_secondo_scaglione_e_33_non_35(self):
        """Test NEGATIVO obbligatorio: fallisce se il 2° scaglione torna al 35% o 25%."""
        r = calcola_irpef(35000, anno=2026)
        aliquote = r["constants_used"]["aliquote"]
        assert 0.33 in aliquote, "Il 2° scaglione 2026 deve essere 33%"
        assert 0.35 not in aliquote, "ERRORE: rientrato il 35% (dati 2024/pre-riforma)"
        assert 0.25 not in aliquote, "ERRORE: rientrato il 25% (dati pre-2024)"

    def test_tracciabilita(self):
        r = calcola_irpef(30000, anno=2026)
        assert r["legal_source"] and r["anno_imposta"] == 2026


class TestDataFreshnessGuard:
    def test_anno_non_disponibile_blocca(self):
        """Chiedere il 2030 (dati non presenti) deve BLOCCARE, non usare dati vecchi."""
        with pytest.raises(DataNotFreshError):
            calcola_irpef(30000, anno=2030)

    def test_senza_anno_non_blocca(self):
        """Senza anno esplicito calcola coi dati correnti (retrocompatibile)."""
        r = calcola_irpef(30000)
        assert r["irpef_lorda"] > 0


class TestForfettario2026Golden:
    def test_professionista_78(self):
        r = simula_forfettario(30000, 0.78, anno=2026)
        assert r["reddito_forfettario"] == 23400.0     # 30.000 × 78%

    def test_costruzioni_86(self):
        r = simula_forfettario(50000, 0.86, anno=2026)
        assert r["reddito_forfettario"] == 43000.0     # 50.000 × 86%

    def test_commercio_40(self):
        r = simula_forfettario(60000, 0.40, anno=2026)
        assert r["reddito_forfettario"] == 24000.0     # 60.000 × 40%

    def test_soglia_superata_avvisa(self):
        r = simula_forfettario(90000, 0.78, anno=2026)
        assert r["warnings"], "Oltre 85.000 € deve esserci un avviso soglia"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
