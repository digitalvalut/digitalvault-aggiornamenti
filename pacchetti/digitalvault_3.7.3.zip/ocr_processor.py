"""
OCR per scontrini/fatture fotografate.
Usa l'AI (modelli vision) per estrarre: importo, data, fornitore, numero documento.
"""
import base64
import csv
import io
import json
import re
from pathlib import Path
from ai_client import chat_with_ai
from validazione_importi import valida_importo
import asyncio

_PROMPT = """Analizza questa foto di scontrino/fattura e estrai SOLO in formato JSON valido (senza markdown):
{
  "importo": "numero con decimali (es: 25.50)",
  "data": "YYYY-MM-DD",
  "fornitore": "nome ditta/negozio",
  "numero_documento": "numero scontrino/fattura se presente",
  "categoria": "una di: alimentare, cancelleria, trasporto, servizi, elettronica, altro",
  "descrizione": "breve descrizione articoli"
}

Se un campo non c'è, metti null. Rispondi SOLO con il JSON, niente altro."""

_MEDIA_TYPES = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".webp": "image/webp",
}


def _extract_json(text: str) -> dict:
    """Estrae il primo oggetto JSON dalla risposta, anche se avvolto in markdown."""
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```[a-zA-Z]*\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass
    # Ultimo tentativo: cerca il blocco { ... } più esterno
    m = re.search(r"\{[\s\S]*\}", cleaned)
    if m:
        return json.loads(m.group(0))
    raise json.JSONDecodeError("nessun JSON trovato", cleaned, 0)


async def extract_invoice_data(image_path: str) -> dict:
    """
    Legge uno scontrino/fattura fotografato e estrae i dati principali.
    Ritorna: {importo, data, fornitore, numero_documento, categoria, descrizione}
    """
    try:
        with open(image_path, "rb") as f:
            image_data = base64.b64encode(f.read()).decode()

        ext = Path(image_path).suffix.lower()
        media_type = _MEDIA_TYPES.get(ext, "image/jpeg")

        # Formato immagini OpenAI/OpenRouter (data URL)
        messages = [{
            "role": "user",
            "content": [
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:{media_type};base64,{image_data}"},
                },
                {"type": "text", "text": _PROMPT},
            ],
        }]

        response = await chat_with_ai(messages)

        try:
            dati = _extract_json(response)
        except json.JSONDecodeError:
            return {"errore": "Non riuscito a estrarre i dati", "risposta_raw": response}

        # Validazione importo (Fase D): è una foto, non c'è testo sorgente da
        # confrontare → solo controllo di plausibilità (range). L'importo da OCR
        # va SEMPRE verificato sull'originale: lo marchiamo esplicitamente.
        raw = dati.get("importo")
        if isinstance(raw, str):
            raw = raw.replace("€", "").replace(",", ".").strip() or None
        imp, warns, _ = valida_importo(raw, testo=None)
        dati["importo"] = imp
        dati["importo_da_verificare"] = imp is not None
        dati["warnings"] = warns
        return dati

    except Exception as e:
        return {"errore": str(e)}


async def extract_multiple_invoices(image_paths: list) -> list:
    """Estrae dati da più scontrini in parallelo (max 4 alla volta)."""
    sem = asyncio.Semaphore(4)

    async def _one(p):
        async with sem:
            return await extract_invoice_data(p)

    return list(await asyncio.gather(*[_one(p) for p in image_paths]))


def format_as_csv(invoice_list: list) -> str:
    """Formatta i dati estratti come CSV (separatore ; per Excel italiano)."""
    if not invoice_list:
        return ""
    buf = io.StringIO()
    writer = csv.writer(buf, delimiter=";", quoting=csv.QUOTE_MINIMAL, lineterminator="\n")
    writer.writerow(["Importo", "Data", "Fornitore", "Numero", "Categoria", "Descrizione", "Controllo"])
    for inv in invoice_list:
        if "errore" in inv:
            continue
        writer.writerow([
            inv.get("importo") or "",
            inv.get("data") or "",
            inv.get("fornitore") or "",
            inv.get("numero_documento") or "",
            inv.get("categoria") or "",
            inv.get("descrizione") or "",
            "Verificare originale (letto da OCR)",
        ])
    return buf.getvalue()
