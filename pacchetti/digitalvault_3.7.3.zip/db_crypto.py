"""
DigitalValut - Cifratura dei campi sensibili del database (Tier 1.1).
(c) 2026 DigitalValut - Capo Team del Progetto: Dr. Falsone Giuseppe

Protegge i dati personali a riposo: se l'SSD viene perso/rubato e il file .db
viene aperto con un visualizzatore SQLite, i campi cifrati risultano illeggibili.

- Chiave DERIVATA dal numero di serie dell'SSD (scrypt), NON salvata: si
  ricalcola a ogni avvio. Su un altro disco la chiave cambia → i dati non si
  decifrano (come per i backup). Se il serial non è rilevabile, si usa una
  chiave di scorta su file (resta sull'SSD, non viene replicata).
- Tollerante alla MIGRAZIONE: un valore già in chiaro (pre-cifratura) viene
  restituito così com'è; i nuovi salvataggi sono cifrati. Vedi migra_cifra_campi().

NOTA ONESTA: la derivazione è nel codice, quindi protegge dall'accesso "casuale"
al file .db (furto SSD aperto in un viewer), non da chi esegue il programma sul
dispositivo. Per protezione totale serve cifratura di volume o passphrase utente.
"""
import base64
import hashlib
from pathlib import Path

try:
    from cryptography.fernet import Fernet
    _CRYPTO = True
except Exception:
    _CRYPTO = False

_LABEL = b"DGV-DBFIELD-v1"
DATA_DIR = Path(__file__).parent / "data"
_KEY_FILE = DATA_DIR / "dbfield.key"   # chiave di scorta se il serial non è leggibile

_fernet = None


def _device_key():
    """Chiave derivata dal serial dell'SSD (scrypt). None se non disponibile."""
    if not _CRYPTO:
        return None
    try:
        import license_manager
        serial = license_manager.get_volume_id()
        if not serial or serial == "NOVOLUME":
            return None
        material = serial.encode() + _LABEL
        dk = hashlib.scrypt(material, salt=_LABEL, n=2 ** 14, r=8, p=1, dklen=32)
        return base64.urlsafe_b64encode(dk)
    except Exception:
        return None


def _fallback_key():
    DATA_DIR.mkdir(exist_ok=True)
    if _KEY_FILE.exists():
        return _KEY_FILE.read_bytes()
    key = Fernet.generate_key()
    _KEY_FILE.write_bytes(key)
    return key


def _f():
    global _fernet
    if _fernet is None and _CRYPTO:
        _fernet = Fernet(_device_key() or _fallback_key())
    return _fernet


def attivo() -> bool:
    return _CRYPTO


def cifra(plaintext):
    """Cifra una stringa. None/'' restano invariati. Idempotente: se è già un
    token cifrato valido, non lo ri-cifra."""
    if plaintext is None or not _CRYPTO:
        return plaintext
    if not isinstance(plaintext, str):
        plaintext = str(plaintext)
    if plaintext == "":
        return plaintext
    # già cifrato? non ri-cifrare
    try:
        _f().decrypt(plaintext.encode("ascii"))
        return plaintext
    except Exception:
        pass
    return _f().encrypt(plaintext.encode("utf-8")).decode("ascii")


def decifra(token):
    """Decifra un token. Se non è cifrabile (valore legacy in chiaro) lo
    restituisce com'è → migrazione indolore."""
    if token is None or not _CRYPTO:
        return token
    if not isinstance(token, str) or token == "":
        return token
    try:
        return _f().decrypt(token.encode("ascii")).decode("utf-8")
    except Exception:
        return token  # valore in chiaro pre-cifratura


# ── Tipo SQLAlchemy trasparente: cifra in scrittura, decifra in lettura ───────
try:
    from sqlalchemy.types import TypeDecorator, Text

    class EncryptedText(TypeDecorator):
        """Colonna di testo cifrata in modo trasparente. La logica Python che
        legge l'oggetto vede il valore IN CHIARO (decifrato); su disco è cifrato.
        NB: non usare su colonne filtrate via SQL (WHERE/LIKE/unique)."""
        impl = Text
        cache_ok = True

        def process_bind_param(self, value, dialect):
            return cifra(value)

        def process_result_value(self, value, dialect):
            return decifra(value)
except Exception:
    EncryptedText = None
