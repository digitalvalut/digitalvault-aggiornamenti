"""
Test di sicurezza (Parte 3, Tier 3.1) — parsing input non fidati.
Verifica che il parser delle fatture neutralizzi XXE e billion-laughs.
Esegui: cd D:\\MOTORE ; python-win\\python.exe -m pytest test_security.py -q
"""
import pytest
import fatture_elettroniche as fe

# 1) XXE: prova a leggere un file locale tramite entità esterna.
_XXE = b"""<?xml version="1.0"?>
<!DOCTYPE foo [ <!ENTITY xxe SYSTEM "file:///C:/Windows/win.ini"> ]>
<p:FatturaElettronica xmlns:p="x"><FatturaElettronicaHeader><x>&xxe;</x></FatturaElettronicaHeader></p:FatturaElettronica>
"""

# 2) Billion laughs: espansione esponenziale di entità (DoS).
_BILLION = b"""<?xml version="1.0"?>
<!DOCTYPE lolz [
 <!ENTITY lol "lol">
 <!ENTITY lol2 "&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;">
 <!ENTITY lol3 "&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;">
 <!ENTITY lol4 "&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;">
]>
<FatturaElettronica><x>&lol4;</x></FatturaElettronica>
"""

# 3) XML benigno ma non fattura: deve dare errore GESTITO (ValueError), non crash.
_NON_FATTURA = b"<root><ciao>mondo</ciao></root>"


def test_xxe_neutralizzato():
    """Un payload XXE non deve né leggere file locali né passare il parsing."""
    with pytest.raises(Exception):
        fe.parse_fattura(_XXE)


def test_billion_laughs_neutralizzato():
    """Il payload billion-laughs deve essere bloccato (niente espansione/DoS)."""
    with pytest.raises(Exception):
        fe.parse_fattura(_BILLION)


def test_non_fattura_errore_gestito():
    """Un XML valido ma non-fattura deve sollevare un errore gestibile dal chiamante."""
    with pytest.raises(Exception):
        fe.parse_fattura(_NON_FATTURA)


def test_parser_e_defusedxml():
    """Il modulo deve usare defusedxml, non xml.etree."""
    assert "defusedxml" in type(fe.ET).__module__ or fe.ET.__name__.startswith("defusedxml") \
        or "defused" in getattr(fe.ET, "__name__", "")


# ─── Tier 2.2 — Aggiornamenti firmati Ed25519 + Zip-Slip ──────────────────────
import zipfile
from pathlib import Path as _P
import update_security as _us


def _zip_con(membri: dict, path):
    with zipfile.ZipFile(path, "w") as z:
        for nome, cont in membri.items():
            z.writestr(nome, cont)


def test_zipslip_bloccato(tmp_path):
    """Un pacchetto con path traversal (../) deve essere rifiutato."""
    evil = tmp_path / "evil.zip"
    _zip_con({"../../evil.txt": "pwned"}, evil)
    with pytest.raises(ValueError):
        _us.estrai_sicuro(evil, tmp_path / "out")


def test_estrazione_benigna_ok(tmp_path):
    """Un pacchetto normale si estrae correttamente."""
    ok = tmp_path / "ok.zip"
    _zip_con({"app.py": "x=1"}, ok)
    dest = tmp_path / "out"
    dest.mkdir()
    _us.estrai_sicuro(ok, dest)
    assert (dest / "app.py").exists()


_PRIV = _P(__file__).parent.parent / "SOLO PROPRIETARIO" / "chiavi" / "chiave_privata.pem"


@pytest.mark.skipif(not _PRIV.exists(), reason="chiave privata presente solo sul master")
def test_firma_update_roundtrip(tmp_path):
    """Firma col master → verifica OK; manomesso/non firmato → rifiutato."""
    import sys
    sys.path.insert(0, str(_P(__file__).parent.parent / "SOLO PROPRIETARIO"))
    import firma_aggiornamento as fa
    z = tmp_path / "u.zip"
    _zip_con({"app.py": "x=1", "config.py": "Y=2"}, z)
    firma = fa.firma_file(z)["firma"]
    assert _us.verifica_firma(z.read_bytes(), firma) is True
    tampered = bytearray(z.read_bytes())
    tampered[12] ^= 0xFF
    assert _us.verifica_firma(bytes(tampered), firma) is False
    assert _us.verifica_firma(z.read_bytes(), None) is False


# ─── Tier 1.1 — Cifratura campi sensibili del DB ──────────────────────────────
import db_crypto as _dbc


def test_dbcrypto_roundtrip():
    s = "RSSMRA80A01H501U"
    tok = _dbc.cifra(s)
    assert tok != s and _dbc.decifra(tok) == s


def test_dbcrypto_idempotente():
    """cifra() su un valore già cifrato non aggiunge un secondo strato."""
    s = "dati riservati del cliente"
    tok = _dbc.cifra(s)
    assert _dbc.cifra(tok) == tok
    assert _dbc.decifra(tok) == s


def test_dbcrypto_legacy_plaintext():
    """Un valore mai cifrato (pre-migrazione) viene restituito com'è."""
    assert _dbc.decifra("mario@esempio.it") == "mario@esempio.it"


def test_dbcrypto_none_e_vuoto():
    assert _dbc.cifra(None) is None
    assert _dbc.cifra("") == ""
    assert _dbc.decifra(None) is None


def test_dbcrypto_token_nasconde_plaintext():
    s = "CODICEFISCALE_SEGRETO_123"
    assert s not in _dbc.cifra(s)


def test_encryptedtext_typedecorator():
    """Il tipo SQLAlchemy cifra in bind e decifra in result."""
    t = _dbc.EncryptedText()
    cifrato = t.process_bind_param("indirizzo riservato", None)
    assert cifrato != "indirizzo riservato"
    assert t.process_result_value(cifrato, None) == "indirizzo riservato"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
