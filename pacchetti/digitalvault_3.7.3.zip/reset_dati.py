"""
DigitalValut - Azzeramento dati.
Permette di svuotare i dati (clienti, documenti, chat) oppure
di riportare tutto a NUOVO (come un SSD appena preparato).
"""
import shutil
import urllib.request
from pathlib import Path

BASE = Path(__file__).parent
DB = BASE / "data" / "digitalvault.db"
LICENZA = BASE / "data" / "licenza.dat"
BACKUP_KEY = BASE / "data" / "backup.key"
BACKUP_STATUS = BASE / "data" / "backup_status.json"
UPLOADS = BASE / "uploads"
BACKUPS_SSD = BASE / "backups"
PORTE = range(8000, 8011)


def digitalvault_in_esecuzione() -> bool:
    """True se il programma e' acceso (tiene bloccato il database)."""
    for p in PORTE:
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{p}/api/health", timeout=1) as r:
                if b"DigitalValut" in r.read():
                    return True
        except Exception:
            continue
    return False


def _cancella_file(path: Path, problemi: list):
    try:
        if path.exists():
            path.unlink()
    except Exception:
        problemi.append(str(path.name))


def _svuota_cartella(cartella: Path, problemi: list):
    if not cartella.exists():
        return
    for f in cartella.iterdir():
        try:
            if f.is_file():
                f.unlink()
            elif f.is_dir():
                shutil.rmtree(f)
        except Exception:
            problemi.append(str(f.name))


def reset_dati(completo: bool) -> list:
    """Esegue l'azzeramento. Ritorna l'elenco dei file NON cancellabili."""
    problemi = []
    # Database + file di appoggio WAL/SHM (senza questi resterebbero dati!)
    _cancella_file(DB, problemi)
    _cancella_file(Path(str(DB) + "-wal"), problemi)
    _cancella_file(Path(str(DB) + "-shm"), problemi)
    _svuota_cartella(UPLOADS, problemi)
    # Backup di config eventuali
    for b in BASE.glob("config_backup_*.py"):
        _cancella_file(b, problemi)
    if completo:
        # Come SSD NUOVO: via licenza, chiave di cifratura e VECCHI BACKUP
        # (privacy: il prossimo studio non deve poter recuperare i dati del precedente)
        _cancella_file(LICENZA, problemi)
        _cancella_file(BACKUP_KEY, problemi)
        _cancella_file(BACKUP_STATUS, problemi)
        _svuota_cartella(BACKUPS_SSD, problemi)
    return problemi


def main():
    print("=" * 60)
    print("  DIGITALVALUT - AZZERAMENTO DATI")
    print("=" * 60)

    # Il database non si puo' cancellare se il programma e' acceso
    while digitalvault_in_esecuzione():
        print()
        print("  [ATTENZIONE] DigitalValut e' ANCORA APERTO su questo computer.")
        print("  Windows non permette di cancellare i dati mentre il programma li usa.")
        print()
        print("  1. Chiudi la finestra del browser di DigitalValut")
        print("  2. Chiudi la FINESTRA NERA di DigitalValut (quella di avvio)")
        print()
        try:
            scelta = input("  Fatto? Premi Invio per riprovare (oppure 0 per annullare): ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n  Annullato.")
            return
        if scelta == "0":
            print("\n  Annullato. Niente e' stato cancellato.")
            input("  Premi Invio per uscire...")
            return

    print()
    print("  Scegli cosa fare:")
    print()
    print("   [1] SVUOTA I DATI")
    print("       Cancella clienti, documenti, chat e note.")
    print("       MANTIENE l'attivazione e le impostazioni dello studio.")
    print()
    print("   [2] AZZERA TUTTO (come un SSD nuovo)")
    print("       Cancella TUTTO: dati, attivazione, impostazioni e backup")
    print("       presenti sull'SSD. Al prossimo avvio chiedera' la chiave.")
    print()
    print("   [0] ANNULLA (non fa niente)")
    print()

    try:
        scelta = input("  Scrivi 1, 2 oppure 0 e premi Invio: ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\n  Annullato.")
        return

    if scelta in ("0", ""):
        print("\n  Annullato. Niente e' stato cancellato.")
        input("  Premi Invio per uscire...")
        return

    if scelta not in ("1", "2"):
        print("\n  Scelta non valida. Niente e' stato cancellato.")
        input("  Premi Invio per uscire...")
        return

    completo = (scelta == "2")
    print()
    avviso = "TUTTO (dati + attivazione + impostazioni + backup SSD)" if completo \
             else "i DATI (clienti, documenti, chat)"
    print(f"  ATTENZIONE: stai per cancellare {avviso}.")
    print("  Questa operazione NON si puo' annullare.")
    conferma = input("  Scrivi CANCELLA (in maiuscolo) per confermare: ").strip()

    if conferma != "CANCELLA":
        print("\n  Annullato. Niente e' stato cancellato.")
        input("  Premi Invio per uscire...")
        return

    problemi = reset_dati(completo)

    print()
    print("  " + "=" * 56)
    if problemi:
        print("  [QUASI FATTO] Alcuni file non si sono potuti cancellare:")
        for p in problemi:
            print(f"    - {p}")
        print("  Probabilmente il programma e' ancora aperto: chiudilo")
        print("  del tutto e rilancia questo strumento.")
    else:
        print("  [OK] FATTO! I dati sono stati azzerati.")
    print("  " + "=" * 56)
    if completo and not problemi:
        print("  L'SSD e' come nuovo. Al prossimo avvio il programma")
        print("  chiedera' la chiave di licenza.")
    elif not problemi:
        print("  Il programma e' pronto, vuoto e con le scadenze fiscali standard.")
    print()
    input("  Premi Invio per chiudere...")


if __name__ == "__main__":
    main()
