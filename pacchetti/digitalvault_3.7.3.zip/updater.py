"""
DigitalValut - Controllo aggiornamenti per gli SSD già consegnati.
(c) 2026 DigitalValut Team - Dr. Falsone Giuseppe

Come funziona (semplice e sicuro):
1. Il titolare pubblica un piccolo file JSON (il "manifest") a un indirizzo web
   suo, con la versione piu' recente e il link al pacchetto.
2. Ogni SSD, quando e' aperto, lo legge e capisce se e' indietro.
3. Se c'e' una versione nuova, AVVISA il commercialista e puo' SCARICARE il
   pacchetto. L'installazione vera la fa lo script "AGGIORNA DIGITALVALUT.bat"
   a programma chiuso, cosi' non si rischia di rompere file in uso.

NIENTE viene installato di nascosto: l'aggiornamento e' sempre una scelta.
"""
import json
import urllib.request
from pathlib import Path

from config import APP_VERSION, UPDATE_MANIFEST_URL, BASE_DIR
import update_security

# Cartella dove finisce il pacchetto scaricato (sull'SSD, accanto al programma)
UPDATE_DIR = BASE_DIR / "_aggiornamento"


def _leggi_manifest() -> dict:
    """Scarica e interpreta il manifest. None se non configurato/non raggiungibile."""
    if not UPDATE_MANIFEST_URL:
        return None
    try:
        req = urllib.request.Request(UPDATE_MANIFEST_URL, headers={"User-Agent": "DigitalValut"})
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return None


def _versione_tuple(v: str) -> tuple:
    """'3.10.2' -> (3,10,2) per confrontare le versioni correttamente."""
    parti = []
    for p in str(v).split("."):
        num = "".join(ch for ch in p if ch.isdigit())
        parti.append(int(num) if num else 0)
    while len(parti) < 3:
        parti.append(0)
    return tuple(parti[:3])


def controlla() -> dict:
    """Controlla se esiste una versione piu' recente. Non scarica nulla."""
    if not UPDATE_MANIFEST_URL:
        return {"configurato": False, "versione_locale": APP_VERSION,
                "messaggio": "Controllo aggiornamenti non configurato."}
    manifest = _leggi_manifest()
    if manifest is None:
        return {"configurato": True, "disponibile": False, "versione_locale": APP_VERSION,
                "messaggio": "Impossibile controllare ora (serve Internet)."}

    remota = str(manifest.get("versione", "")).strip()
    disponibile = bool(remota) and _versione_tuple(remota) > _versione_tuple(APP_VERSION)
    return {
        "configurato": True,
        "disponibile": disponibile,
        "versione_locale": APP_VERSION,
        "versione_remota": remota or None,
        "note": manifest.get("note", ""),
        "url_zip": manifest.get("url_zip", ""),
        "firmato": bool(manifest.get("firma")),
        "messaggio": (f"Aggiornamento disponibile: versione {remota}." if disponibile
                      else "Il programma è aggiornato all'ultima versione."),
    }


def scarica(url_zip: str) -> dict:
    """Scarica il pacchetto e ne VERIFICA la firma Ed25519 prima di accettarlo.
    La firma autorevole è presa dal manifest del titolare (non dal browser).
    Un pacchetto non firmato o manomesso viene rifiutato e cancellato."""
    if not url_zip:
        return {"ok": False, "errore": "Nessun pacchetto da scaricare."}
    try:
        UPDATE_DIR.mkdir(parents=True, exist_ok=True)
        dest = UPDATE_DIR / "aggiornamento.zip"
        sig_path = UPDATE_DIR / "aggiornamento.sig"
        req = urllib.request.Request(url_zip, headers={"User-Agent": "DigitalValut"})
        with urllib.request.urlopen(req, timeout=120) as r:
            blob = r.read()
        # 1) Dev'essere uno zip valido
        import zipfile, io
        if not zipfile.is_zipfile(io.BytesIO(blob)):
            return {"ok": False, "errore": "Il file scaricato non è un pacchetto valido."}
        # 2) Firma obbligatoria: la prendiamo dal manifest del titolare
        manifest = _leggi_manifest() or {}
        firma = manifest.get("firma")
        if update_security.public_key_presente():
            if not update_security.verifica_firma(blob, firma):
                return {"ok": False, "errore": "Pacchetto NON firmato o manomesso: "
                        "aggiornamento rifiutato per sicurezza."}
        # 3) Solo ora scriviamo zip + firma su disco (per la verifica in fase di apply)
        dest.write_bytes(blob)
        if firma:
            sig_path.write_text(firma, encoding="utf-8")
        return {"ok": True, "percorso": str(dest), "dimensione": dest.stat().st_size,
                "firmato": bool(firma),
                "nota": "Pacchetto scaricato e firma verificata. CHIUDI e RIAPRI il programma: "
                        "l'aggiornamento si installa DA SOLO all'avvio. (In alternativa puoi "
                        "ancora lanciare a mano 'AGGIORNA DIGITALVALUT'.)"}
    except Exception as e:
        return {"ok": False, "errore": str(e)}
