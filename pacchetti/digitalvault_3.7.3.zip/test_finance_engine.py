"""Test del Finance-Engine (deterministico): proiezioni, DSCR, stress test."""
import finance_engine as fe


def test_proiezione_compound():
    p = fe.proiezione(100000, 80000, anni=5, crescita_ricavi=0.03, crescita_costi=0.02)
    assert len(p) == 6                       # anno 0 + 5
    assert p[0]["ricavi"] == 100000.00 and p[0]["costi"] == 80000.00
    assert p[0]["margine"] == 20000.00 and p[0]["margine_pct"] == 20.00
    assert p[1]["ricavi"] == 103000.00       # 100000 * 1.03
    assert p[1]["costi"] == 81600.00         # 80000 * 1.02


def test_dscr_adeguato():
    assert fe.dscr(120000, 100000)["giudizio"] == "adeguato"     # 1.2


def test_dscr_da_monitorare():
    r = fe.dscr(100000, 100000)                                  # 1.0
    assert r["dscr"] == 1.00 and r["giudizio"] == "da monitorare"


def test_dscr_allerta():
    r = fe.dscr(90000, 100000)                                   # 0.9
    assert r["dscr"] == 0.90 and r["giudizio"] == "allerta"


def test_dscr_senza_debito():
    assert fe.dscr(50000, 0)["giudizio"] == "n/d"


def test_stress_test_riduce_resilienza():
    st = fe.stress_test(100000, 80000, 15000, shock_ricavi=-0.10, shock_costi=0.05)
    # base: margine 20000 / 15000 = 1.33 -> adeguato
    assert st["base"]["dscr"]["giudizio"] == "adeguato"
    # stress: ricavi 90000, costi 84000, margine 6000 / 15000 = 0.4 -> allerta
    assert st["stress"]["ricavi"] == 90000.00 and st["stress"]["costi"] == 84000.00
    assert st["stress"]["margine"] == 6000.00
    assert st["stress"]["dscr"]["giudizio"] == "allerta"
    assert st["resiliente"] is False


def test_analisi_struttura():
    r = fe.analisi(100000, 80000, servizio_debito=15000, anni=3)
    assert {"proiezione", "dscr_corrente", "stress_test", "legal_source", "disclaimer"}.issubset(r.keys())
    assert len(r["proiezione"]) == 4          # anno 0 + 3
    assert r["dscr_corrente"]["giudizio"] == "adeguato"
    assert r["stress_test"] is not None


def test_analisi_senza_debito_niente_stress():
    r = fe.analisi(100000, 80000, servizio_debito=0)
    assert r["stress_test"] is None and r["dscr_corrente"]["giudizio"] == "n/d"
