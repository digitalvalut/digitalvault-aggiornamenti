"""
DigitalValut - Importatore di FATTURE ELETTRONICHE (XML SDI / FatturaPA).
(c) 2026 DigitalValut Team - Dr. Falsone Giuseppe

Lo studio scarica gli XML dal cassetto fiscale (o dal gestionale) e li butta
dentro a cartelle intere: DigitalValut li legge, capisce di chi sono
(abbinamento automatico per P.IVA / codice fiscale), estrae numeri, importi,
IVA e descrizioni, e li indicizza nel cervello documenti.

Formati accettati:
- .xml          (FatturaPA versione FPR12/FPA12, anche con lotti multipli)
- .xml.p7m      (firmato CAdES: estrazione best-effort dell'XML interno)
- .zip          (un sacco di fatture in un colpo solo)

Niente invii, niente modifiche: SOLO LETTURA e archiviazione.
"""
import base64
import re
# SICUREZZA (Tier 3.1): le fatture XML sono input NON fidati. Usiamo defusedxml
# al posto di xml.etree per neutralizzare XXE (lettura file locali/SSRF) e
# "billion laughs" (DoS da espansione entità). API identica a ElementTree.
import defusedxml.ElementTree as ET
from datetime import datetime

TIPI_DOC = {
    "TD01": "Fattura", "TD02": "Acconto/anticipo su fattura", "TD03": "Acconto/anticipo su parcella",
    "TD04": "Nota di credito", "TD05": "Nota di debito", "TD06": "Parcella",
    "TD16": "Integrazione reverse charge interno", "TD17": "Integrazione acquisto servizi estero",
    "TD18": "Integrazione acquisto beni intracomunitari", "TD19": "Integrazione acquisto beni art.17 c.2",
    "TD20": "Autofattura regolarizzazione", "TD21": "Autofattura splafonamento",
    "TD24": "Fattura differita", "TD25": "Fattura differita triangolare",
    "TD26": "Cessione beni ammortizzabili", "TD27": "Autoconsumo/cessioni gratuite",
}

NATURE = {
    "N1": "escluse art.15", "N2": "non soggette", "N2.1": "non soggette art.7", "N2.2": "non soggette - altri",
    "N3": "non imponibili", "N3.1": "non imp. esportazioni", "N3.2": "non imp. cessioni intraUE",
    "N3.3": "non imp. San Marino", "N3.4": "non imp. assimilate", "N3.5": "non imp. dich. intento",
    "N3.6": "non imp. altre", "N4": "esenti", "N5": "regime del margine",
    "N6": "reverse charge", "N6.1": "reverse charge rottami", "N6.2": "reverse charge oro",
    "N6.3": "reverse charge subappalto edilizia", "N6.4": "reverse charge fabbricati",
    "N6.5": "reverse charge telefonini", "N6.6": "reverse charge elettronici",
    "N6.7": "reverse charge edile/completamento", "N6.8": "reverse charge energia",
    "N6.9": "reverse charge altri casi", "N7": "IVA assolta in altro stato UE",
}


def _strip_ns(tag: str) -> str:
    return tag.split("}")[-1] if "}" in tag else tag


def _find(el, *percorso):
    """Naviga l'albero ignorando i namespace. Ritorna il primo elemento o None."""
    corrente = el
    for nome in percorso:
        trovato = None
        for figlio in corrente:
            if _strip_ns(figlio.tag) == nome:
                trovato = figlio
                break
        if trovato is None:
            return None
        corrente = trovato
    return corrente


def _findall(el, nome):
    return [f for f in el.iter() if _strip_ns(f.tag) == nome]


def _testo(el, *percorso, default=""):
    t = _find(el, *percorso)
    return (t.text or "").strip() if t is not None and t.text else default


def estrai_xml_da_p7m(raw: bytes) -> bytes:
    """Estrae l'XML da un .p7m firmato CAdES (best effort, senza verificare
    la firma: a noi serve solo LEGGERE il contenuto)."""
    candidati = [raw]
    # Alcuni p7m sono in base64 (PEM)
    try:
        pulito = b"".join(raw.split())
        candidati.append(base64.b64decode(pulito, validate=False))
    except Exception:
        pass
    for blob in candidati:
        inizio = blob.find(b"<?xml")
        if inizio == -1:
            # a volte manca il prologo: cerca direttamente la radice
            inizio = blob.find(b"<p:FatturaElettronica")
            if inizio == -1:
                inizio = blob.find(b"<FatturaElettronica")
        if inizio == -1:
            continue
        fine = blob.rfind(b"FatturaElettronica>")
        if fine == -1:
            continue
        fine = blob.find(b">", fine) + 1
        return blob[inizio:fine]
    return b""


def _anagrafica(nodo) -> dict:
    """Estrae denominazione/nome, P.IVA e CF da CedentePrestatore o CessionarioCommittente."""
    if nodo is None:
        return {"nome": "", "piva": "", "cf": ""}
    dati = _find(nodo, "DatiAnagrafici") or nodo
    denominazione = _testo(dati, "Anagrafica", "Denominazione")
    if not denominazione:
        nome = _testo(dati, "Anagrafica", "Nome")
        cognome = _testo(dati, "Anagrafica", "Cognome")
        denominazione = f"{cognome} {nome}".strip()
    piva = _testo(dati, "IdFiscaleIVA", "IdCodice")
    cf = _testo(dati, "CodiceFiscale")
    return {"nome": denominazione, "piva": piva, "cf": cf.upper()}


def _euro(s: str) -> str:
    try:
        return f"{float(s):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    except Exception:
        return s or "0,00"


def parse_fattura(xml_bytes: bytes) -> list:
    """Legge un XML FatturaPA. Ritorna una LISTA di fatture (un file puo'
    contenere un lotto con piu' corpi). Ogni fattura e' un dict completo."""
    root = ET.fromstring(xml_bytes)
    header = _find(root, "FatturaElettronicaHeader")
    if header is None:
        raise ValueError("Non sembra una fattura elettronica (manca l'header).")

    cedente = _anagrafica(_find(header, "CedentePrestatore"))
    cessionario = _anagrafica(_find(header, "CessionarioCommittente"))

    fatture = []
    for body in _findall(root, "FatturaElettronicaBody"):
        dgd = _find(body, "DatiGenerali", "DatiGeneraliDocumento")
        tipo_doc = _testo(dgd, "TipoDocumento") if dgd is not None else ""
        numero = _testo(dgd, "Numero") if dgd is not None else ""
        data = _testo(dgd, "Data") if dgd is not None else ""
        totale = _testo(dgd, "ImportoTotaleDocumento") if dgd is not None else ""

        # Righe di dettaglio (prime 12: bastano per capire di cosa parla)
        righe = []
        for linea in _findall(body, "DettaglioLinee")[:12]:
            descr = _testo(linea, "Descrizione")
            prezzo = _testo(linea, "PrezzoTotale")
            if descr:
                righe.append(f"- {descr}" + (f" ({_euro(prezzo)} EUR)" if prezzo else ""))

        # Riepiloghi IVA
        riepiloghi = []
        tot_imponibile = tot_imposta = 0.0
        for r in _findall(body, "DatiRiepilogo"):
            aliquota = _testo(r, "AliquotaIVA")
            imponibile = _testo(r, "ImponibileImporto")
            imposta = _testo(r, "Imposta")
            natura = _testo(r, "Natura")
            try:
                tot_imponibile += float(imponibile or 0)
                tot_imposta += float(imposta or 0)
            except Exception:
                pass
            voce = f"aliquota {aliquota or '0'}%: imponibile {_euro(imponibile)} imposta {_euro(imposta)}"
            if natura:
                voce += f" [{natura} {NATURE.get(natura, '')}]".rstrip()
            riepiloghi.append(voce)

        # Pagamenti
        pagamenti = []
        for p in _findall(body, "DettaglioPagamento"):
            scad = _testo(p, "DataScadenzaPagamento")
            imp = _testo(p, "ImportoPagamento")
            if scad or imp:
                pagamenti.append(f"scadenza {scad or 'n.d.'} importo {_euro(imp)} EUR")

        if not totale:
            totale = str(tot_imponibile + tot_imposta)

        fatture.append({
            "tipo_doc": tipo_doc,
            "tipo_nome": TIPI_DOC.get(tipo_doc, tipo_doc or "Documento"),
            "numero": numero,
            "data": data,
            "anno": int(data[:4]) if len(data) >= 4 and data[:4].isdigit() else None,
            "totale": totale,
            "cedente": cedente,
            "cessionario": cessionario,
            "righe": righe,
            "riepiloghi": riepiloghi,
            "pagamenti": pagamenti,
        })
    if not fatture:
        raise ValueError("Nessun corpo fattura trovato nel file.")
    return fatture


def testo_indicizzabile(f: dict) -> str:
    """Testo strutturato in italiano che finisce in testo_estratto:
    e' quello su cui lavora il cervello documenti."""
    ce, cs = f["cedente"], f["cessionario"]
    righe = [
        f"FATTURA ELETTRONICA {f['tipo_doc']} ({f['tipo_nome']}) n. {f['numero']} del {f['data']}",
        f"EMESSA DA (cedente/prestatore): {ce['nome']}"
        + (f" - P.IVA {ce['piva']}" if ce['piva'] else "") + (f" - CF {ce['cf']}" if ce['cf'] else ""),
        f"INTESTATA A (cessionario/committente): {cs['nome']}"
        + (f" - P.IVA {cs['piva']}" if cs['piva'] else "") + (f" - CF {cs['cf']}" if cs['cf'] else ""),
    ]
    if f["righe"]:
        righe.append("DESCRIZIONE:")
        righe.extend(f["righe"])
    if f["riepiloghi"]:
        righe.append("RIEPILOGO IVA: " + "; ".join(f["riepiloghi"]))
    if f["pagamenti"]:
        righe.append("PAGAMENTI: " + "; ".join(f["pagamenti"]))
    righe.append(f"TOTALE DOCUMENTO: {_euro(f['totale'])} EUR")
    # Impronta per non importare due volte la stessa fattura
    righe.append(f"[FE-ID {ce['piva'] or ce['cf']}|{f['numero']}|{f['data']}]")
    return "\n".join(righe)


def impronta(f: dict) -> str:
    ce = f["cedente"]
    return f"[FE-ID {ce['piva'] or ce['cf']}|{f['numero']}|{f['data']}]"


def abbina_cliente(f: dict, clienti: list):
    """Cerca a quale cliente dello studio appartiene la fattura.
    Se il cliente e' il CEDENTE -> fattura EMESSA (vendita).
    Se il cliente e' il CESSIONARIO -> fattura RICEVUTA (acquisto).
    Ritorna (client, verso) o (None, None)."""
    for cl in clienti:
        piva = (cl.partita_iva or "").strip()
        cf = (cl.codice_fiscale or "").strip().upper()
        if (piva and piva == f["cedente"]["piva"]) or (cf and cf == f["cedente"]["cf"]):
            return cl, "emessa"
        if (piva and piva == f["cessionario"]["piva"]) or (cf and cf == f["cessionario"]["cf"]):
            return cl, "ricevuta"
    return None, None
